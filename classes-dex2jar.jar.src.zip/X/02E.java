package X;

public class 02E extends 02F {
  public 02E(Class paramClass, String paramString1, String paramString2, int paramInt) {
    super(paramClass, 0BH.NO_RECEIVER, paramString1, paramString2, paramInt);
  }
  
  public Object get(Object paramObject) {
    BEQ();
    throw 0GH.createAndThrow();
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\02E.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */