package X;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;

public abstract class 027 extends 155 {
  public static final int A00(Object[] paramArrayOfObject, Object paramObject) {
    // Byte code:
    //   0: aload_0
    //   1: iconst_0
    //   2: invokestatic A0E : (Ljava/lang/Object;I)V
    //   5: iconst_0
    //   6: istore_2
    //   7: iconst_0
    //   8: istore_3
    //   9: aload_0
    //   10: arraylength
    //   11: istore #4
    //   13: aload_1
    //   14: ifnonnull -> 40
    //   17: iload_3
    //   18: istore_2
    //   19: iload_2
    //   20: iload #4
    //   22: if_icmpge -> 65
    //   25: iload_2
    //   26: istore_3
    //   27: aload_0
    //   28: iload_2
    //   29: aaload
    //   30: ifnull -> 67
    //   33: iload_2
    //   34: iconst_1
    //   35: iadd
    //   36: istore_2
    //   37: goto -> 19
    //   40: iload_2
    //   41: iload #4
    //   43: if_icmpge -> 65
    //   46: iload_2
    //   47: istore_3
    //   48: aload_1
    //   49: aload_0
    //   50: iload_2
    //   51: aaload
    //   52: invokevirtual equals : (Ljava/lang/Object;)Z
    //   55: ifne -> 67
    //   58: iload_2
    //   59: iconst_1
    //   60: iadd
    //   61: istore_2
    //   62: goto -> 40
    //   65: iconst_m1
    //   66: istore_3
    //   67: iload_3
    //   68: ireturn
  }
  
  public static final 1CV A01(int[] paramArrayOfint) {
    return new 1CV(paramArrayOfint, 1);
  }
  
  public static final Object A02(Object[] paramArrayOfObject) {
    if (paramArrayOfObject.length == 0)
      throw new NoSuchElementException("Array is empty."); 
    return paramArrayOfObject[0];
  }
  
  public static final String A03(CharSequence paramCharSequence1, CharSequence paramCharSequence2, CharSequence paramCharSequence3, 0BQ param0BQ, Object[] paramArrayOfObject) {
    StringBuilder stringBuilder = 001.A0s();
    stringBuilder.append(paramCharSequence2);
    int k = paramArrayOfObject.length;
    int i = 0;
    int j = 0;
    while (true) {
      Object object;
      if (i < k) {
        Object object1 = paramArrayOfObject[i];
        if (++j > 1)
          stringBuilder.append(paramCharSequence1); 
        if (param0BQ != null) {
          object = param0BQ.invoke(object1);
        } else {
          object = object1;
          if (object1 != null) {
            object = object1;
            if (!(object1 instanceof CharSequence)) {
              if (object1 instanceof Character) {
                stringBuilder.append(((Character)object1).charValue());
              } else {
                object = String.valueOf(object1);
                stringBuilder.append((CharSequence)object);
              } 
              i++;
              continue;
            } 
          } 
        } 
      } else {
        break;
      } 
      stringBuilder.append((CharSequence)object);
    } 
    stringBuilder.append(paramCharSequence3);
    return 16F.A04(stringBuilder);
  }
  
  public static final String A04(CharSequence paramCharSequence1, CharSequence paramCharSequence2, 0BQ param0BQ, byte[] paramArrayOfbyte, int paramInt) {
    // Byte code:
    //   0: aload_3
    //   1: iconst_0
    //   2: invokestatic A0E : (Ljava/lang/Object;I)V
    //   5: invokestatic A0s : ()Ljava/lang/StringBuilder;
    //   8: astore #10
    //   10: aload #10
    //   12: ldc ''
    //   14: invokevirtual append : (Ljava/lang/CharSequence;)Ljava/lang/Appendable;
    //   17: pop
    //   18: aload_3
    //   19: arraylength
    //   20: istore #9
    //   22: iconst_0
    //   23: istore #7
    //   25: iconst_0
    //   26: istore #6
    //   28: iload #7
    //   30: iload #9
    //   32: if_icmpge -> 105
    //   35: aload_3
    //   36: iload #7
    //   38: baload
    //   39: istore #5
    //   41: iload #6
    //   43: iconst_1
    //   44: iadd
    //   45: istore #6
    //   47: iload #6
    //   49: iconst_1
    //   50: if_icmple -> 60
    //   53: aload #10
    //   55: aload_0
    //   56: invokevirtual append : (Ljava/lang/CharSequence;)Ljava/lang/Appendable;
    //   59: pop
    //   60: iload #4
    //   62: iflt -> 76
    //   65: iload #6
    //   67: istore #8
    //   69: iload #6
    //   71: iload #4
    //   73: if_icmpgt -> 114
    //   76: aload #10
    //   78: aload_2
    //   79: iload #5
    //   81: invokestatic valueOf : (B)Ljava/lang/Byte;
    //   84: invokeinterface invoke : (Ljava/lang/Object;)Ljava/lang/Object;
    //   89: checkcast java/lang/CharSequence
    //   92: invokevirtual append : (Ljava/lang/CharSequence;)Ljava/lang/Appendable;
    //   95: pop
    //   96: iload #7
    //   98: iconst_1
    //   99: iadd
    //   100: istore #7
    //   102: goto -> 28
    //   105: iload #4
    //   107: iflt -> 128
    //   110: iload #6
    //   112: istore #8
    //   114: iload #8
    //   116: iload #4
    //   118: if_icmple -> 128
    //   121: aload #10
    //   123: aload_1
    //   124: invokevirtual append : (Ljava/lang/CharSequence;)Ljava/lang/Appendable;
    //   127: pop
    //   128: aload #10
    //   130: ldc ''
    //   132: invokevirtual append : (Ljava/lang/CharSequence;)Ljava/lang/Appendable;
    //   135: pop
    //   136: aload #10
    //   138: invokestatic A04 : (Ljava/lang/Object;)Ljava/lang/String;
    //   141: areturn
  }
  
  public static final String A05(CharSequence paramCharSequence, int[] paramArrayOfint) {
    StringBuilder stringBuilder = 001.A0s();
    stringBuilder.append("");
    int k = paramArrayOfint.length;
    int i = 0;
    int j = 0;
    while (i < k) {
      int m = paramArrayOfint[i];
      if (++j > 1)
        stringBuilder.append(paramCharSequence); 
      stringBuilder.append(String.valueOf(m));
      i++;
    } 
    stringBuilder.append("");
    return 16F.A04(stringBuilder);
  }
  
  public static final ArrayList A06(Object[] paramArrayOfObject) {
    16F.A0E(paramArrayOfObject, 0);
    return 001.A10(new 07M(paramArrayOfObject, false));
  }
  
  public static final List A07(byte[] paramArrayOfbyte) {
    1AJ 1AJ;
    int i = 0;
    16F.A0E(paramArrayOfbyte, 0);
    int j = paramArrayOfbyte.length;
    if (j != 0) {
      if (j != 1) {
        ArrayList<Byte> arrayList = 001.A0z(j);
        while (true) {
          arrayList.add(Byte.valueOf(paramArrayOfbyte[i]));
          i++;
          ArrayList<Byte> arrayList1 = arrayList;
          if (i < j)
            continue; 
          break;
        } 
      } else {
        return 16F.A05(Byte.valueOf(paramArrayOfbyte[0]));
      } 
    } else {
      1AJ = 1AJ.A00;
    } 
    return 1AJ;
  }
  
  public static final List A08(int[] paramArrayOfint) {
    1AJ 1AJ;
    int i = 0;
    int j = paramArrayOfint.length;
    if (j != 0) {
      if (j != 1) {
        ArrayList<Integer> arrayList = new ArrayList(j);
        while (true) {
          arrayList.add(Integer.valueOf(paramArrayOfint[i]));
          i++;
          ArrayList<Integer> arrayList1 = arrayList;
          if (i < j)
            continue; 
          break;
        } 
      } else {
        return 16F.A05(Integer.valueOf(paramArrayOfint[0]));
      } 
    } else {
      1AJ = 1AJ.A00;
    } 
    return 1AJ;
  }
  
  public static final List A09(Object[] paramArrayOfObject) {
    ArrayList<Object> arrayList = new ArrayList();
    int j = paramArrayOfObject.length;
    for (int i = 0; i < j; i++) {
      Object object = paramArrayOfObject[i];
      if (object != null)
        arrayList.add(object); 
    } 
    return arrayList;
  }
  
  public static final List A0A(Object[] paramArrayOfObject) {
    16F.A0E(paramArrayOfObject, 0);
    int i = paramArrayOfObject.length;
    return (i != 0) ? ((i != 1) ? A06(paramArrayOfObject) : 16F.A05(paramArrayOfObject[0])) : 1AJ.A00;
  }
  
  public static Set A0B(02B param02B1, 02B param02B2) {
    return A0D((Object[])new 02B[] { param02B1, param02B2 });
  }
  
  public static Set A0C(02B param02B1, 02B param02B2, 02B param02B3) {
    return A0D((Object[])new 02B[] { param02B1, param02B2, param02B3 });
  }
  
  public static final Set A0D(Object[] paramArrayOfObject) {
    int i = 0;
    16F.A0E(paramArrayOfObject, 0);
    int j = paramArrayOfObject.length;
    if (j != 0) {
      Set set;
      if (j != 1) {
        LinkedHashSet<Object> linkedHashSet = new LinkedHashSet(01m.A0D(j));
        while (true) {
          linkedHashSet.add(paramArrayOfObject[i]);
          i++;
          set = linkedHashSet;
          if (i < j)
            continue; 
          break;
        } 
      } else {
        set = 16F.A06(paramArrayOfObject[0]);
      } 
      return set;
    } 
    return 1AH.A00;
  }
  
  public static Set A0E(Object[] paramArrayOfObject, int paramInt) {
    16F.A0E(paramArrayOfObject, paramInt);
    return A0D(paramArrayOfObject);
  }
  
  public static final boolean A0F(Object paramObject, Object[] paramArrayOfObject) {
    boolean bool = false;
    16F.A0E(paramArrayOfObject, 0);
    if (A00(paramArrayOfObject, paramObject) >= 0)
      bool = true; 
    return bool;
  }
  
  public static final boolean A0G(int[] paramArrayOfint, int paramInt) {
    16F.A0E(paramArrayOfint, 0);
    int j = paramArrayOfint.length;
    for (int i = 0;; i++) {
      if (i < j) {
        if (paramInt == paramArrayOfint[i]) {
          boolean bool = true;
          return (i < 0) ? false : bool;
        } 
        continue;
      } 
      return false;
    } 
  }
  
  public static final boolean A0H(long[] paramArrayOflong, long paramLong) {
    int j = paramArrayOflong.length;
    for (int i = 0;; i++) {
      if (i < j) {
        if (paramLong == paramArrayOflong[i]) {
          boolean bool = true;
          return (i < 0) ? false : bool;
        } 
        continue;
      } 
      return false;
    } 
  }
  
  public static final byte[] A0I(06f param06f, byte[] paramArrayOfbyte) {
    return param06f.isEmpty() ? new byte[0] : 155.A0N(paramArrayOfbyte, param06f.A00, param06f.A01 + 1);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\027.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */