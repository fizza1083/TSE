package X;

public final class 03p implements 03q {
  public 03p(03o param03o) {}
  
  public final void Ch7(0hr param0hr) {
    03o.A00(this.A00);
  }
  
  public final void CiL(0hr param0hr) {
    03o.A00(this.A00);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\03p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */