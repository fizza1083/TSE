package X;

import com.facebook.common.stringformat.StringFormatUtil;

public abstract class 00e {
  public static Object A00(Object paramObject) {
    paramObject.getClass();
    return paramObject;
  }
  
  public static void A01(Object paramObject, String paramString) {
    if (paramObject != null)
      return; 
    throw 001.A0V(paramString);
  }
  
  public static void A02(Object paramObject, String paramString, Object... paramVarArgs) {
    if (paramObject != null)
      return; 
    throw 001.A0V(StringFormatUtil.formatStrLocaleSafe(paramString, paramVarArgs));
  }
  
  public static void A03(String paramString) {
    if (paramString != null) {
      if (!paramString.isEmpty())
        return; 
      throw 001.A0Z("Expected a non-empty string");
    } 
    throw 001.A0Z("Expected a non-empty string, but got null");
  }
  
  public static void A04(boolean paramBoolean) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException();
  }
  
  public static void A05(boolean paramBoolean) {
    if (paramBoolean)
      return; 
    throw 001.A0Q();
  }
  
  public static void A06(boolean paramBoolean, String paramString) {
    if (paramBoolean)
      return; 
    throw 001.A0O(paramString);
  }
  
  public static void A07(boolean paramBoolean, String paramString) {
    if (paramBoolean)
      return; 
    throw 001.A0S(paramString);
  }
  
  public static void A08(boolean paramBoolean, String paramString, Object paramObject) {
    if (paramBoolean)
      return; 
    throw 001.A0S(StringFormatUtil.formatStrLocaleSafe(paramString, paramObject));
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */