package X;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface 04L {
  static void A00(04L param04L, 0zd param0zd, Object paramObject) {
    param04L.AEH("connection_state", paramObject.toString());
    param04L.AEH("client_type", param0zd.A0F);
  }
  
  void ABp(String paramString, Boolean paramBoolean);
  
  void ACA(String paramString, Double paramDouble);
  
  void ACE(07A param07A, String paramString);
  
  void ACP(String paramString, Float paramFloat);
  
  void ACf(String paramString, Integer paramInteger);
  
  void AD3(String paramString, Long paramLong);
  
  void AD5(String paramString, Map paramMap);
  
  void ADG(String paramString, Object paramObject);
  
  void AE9(07B param07B, String paramString);
  
  void AEB(String paramString, Set paramSet);
  
  void AEH(String paramString1, String paramString2);
  
  void AEJ(08Z param08Z, String paramString);
  
  void AEl(String paramString, List paramList);
  
  void CEm();
  
  boolean isSampled();
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\04L.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */