package X;

public abstract class 05z extends 060 {
  public static final String __redex_internal_original_name = "DispatchedTask";
  
  public int A00;
  
  public final void A06(Throwable paramThrowable1, Throwable paramThrowable2) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: \r\n\tat com.googlecode.dex2jar.ir.ts.NewTransformer.transform(NewTransformer.java:134)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:148)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public abstract Object A07();
  
  public Object A08(Object paramObject) {
    return paramObject;
  }
  
  public Throwable A09(Object paramObject) {
    boolean bool = paramObject instanceof 0IX;
    Throwable throwable2 = null;
    Throwable throwable1 = throwable2;
    if (bool) {
      paramObject = paramObject;
      throwable1 = throwable2;
      if (paramObject != null)
        throwable1 = ((0IX)paramObject).A00; 
    } 
    return throwable1;
  }
  
  public abstract 05D A0A();
  
  public abstract void A0B(Object paramObject, Throwable paramThrowable);
  
  public final void run() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual A0A : ()LX/05D;
    //   4: astore_2
    //   5: aload_2
    //   6: ldc 'null cannot be cast to non-null type kotlinx.coroutines.internal.DispatchedContinuation<T of kotlinx.coroutines.DispatchedTask>'
    //   8: invokestatic A0I : (Ljava/lang/Object;Ljava/lang/String;)V
    //   11: aload_2
    //   12: checkcast X/05y
    //   15: astore_2
    //   16: aload_2
    //   17: getfield A02 : LX/05D;
    //   20: astore #4
    //   22: aload_2
    //   23: getfield A01 : Ljava/lang/Object;
    //   26: astore_2
    //   27: aload #4
    //   29: invokeinterface B2c : ()LX/04I;
    //   34: astore_3
    //   35: aload_2
    //   36: aload_3
    //   37: invokestatic A00 : (Ljava/lang/Object;LX/04I;)Ljava/lang/Object;
    //   40: astore #5
    //   42: aload #5
    //   44: getstatic X/063.A01 : LX/04o;
    //   47: if_acmpeq -> 62
    //   50: aload #5
    //   52: aload #4
    //   54: aload_3
    //   55: invokestatic A02 : (Ljava/lang/Object;LX/05D;LX/04I;)LX/0ID;
    //   58: astore_2
    //   59: goto -> 64
    //   62: aconst_null
    //   63: astore_2
    //   64: aload #4
    //   66: invokeinterface B2c : ()LX/04I;
    //   71: astore #7
    //   73: aload_0
    //   74: invokevirtual A07 : ()Ljava/lang/Object;
    //   77: astore #6
    //   79: aload_0
    //   80: aload #6
    //   82: invokevirtual A09 : (Ljava/lang/Object;)Ljava/lang/Throwable;
    //   85: astore #8
    //   87: aload #8
    //   89: ifnonnull -> 110
    //   92: aload_0
    //   93: getfield A00 : I
    //   96: istore_1
    //   97: iload_1
    //   98: iconst_1
    //   99: if_icmpeq -> 129
    //   102: iload_1
    //   103: iconst_2
    //   104: if_icmpne -> 204
    //   107: goto -> 129
    //   110: aload #4
    //   112: new X/068
    //   115: dup
    //   116: aload #8
    //   118: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   121: invokeinterface DiG : (Ljava/lang/Object;)V
    //   126: goto -> 192
    //   129: aload #7
    //   131: getstatic X/04l.A00 : LX/054;
    //   134: invokeinterface get : (LX/04R;)LX/04H;
    //   139: checkcast X/04l
    //   142: astore #7
    //   144: aload #7
    //   146: ifnull -> 204
    //   149: aload #7
    //   151: invokeinterface C2C : ()Z
    //   156: ifne -> 204
    //   159: aload #7
    //   161: invokeinterface AzG : ()Ljava/util/concurrent/CancellationException;
    //   166: astore #7
    //   168: aload_0
    //   169: aload #6
    //   171: aload #7
    //   173: invokevirtual A0B : (Ljava/lang/Object;Ljava/lang/Throwable;)V
    //   176: aload #4
    //   178: new X/068
    //   181: dup
    //   182: aload #7
    //   184: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   187: invokeinterface DiG : (Ljava/lang/Object;)V
    //   192: getstatic X/0BV.A00 : LX/0BV;
    //   195: astore #4
    //   197: aload_2
    //   198: ifnull -> 227
    //   201: goto -> 220
    //   204: aload #4
    //   206: aload_0
    //   207: aload #6
    //   209: invokevirtual A08 : (Ljava/lang/Object;)Ljava/lang/Object;
    //   212: invokeinterface DiG : (Ljava/lang/Object;)V
    //   217: goto -> 192
    //   220: aload_2
    //   221: invokevirtual A0W : ()Z
    //   224: ifeq -> 233
    //   227: aload #5
    //   229: aload_3
    //   230: invokestatic A01 : (Ljava/lang/Object;LX/04I;)V
    //   233: aload_0
    //   234: aconst_null
    //   235: aload #4
    //   237: invokestatic A00 : (Ljava/lang/Object;)Ljava/lang/Throwable;
    //   240: invokevirtual A06 : (Ljava/lang/Throwable;Ljava/lang/Throwable;)V
    //   243: return
    //   244: astore #4
    //   246: aload_2
    //   247: ifnull -> 257
    //   250: aload_2
    //   251: invokevirtual A0W : ()Z
    //   254: ifeq -> 263
    //   257: aload #5
    //   259: aload_3
    //   260: invokestatic A01 : (Ljava/lang/Object;LX/04I;)V
    //   263: aload #4
    //   265: athrow
    //   266: astore_3
    //   267: getstatic X/0BV.A00 : LX/0BV;
    //   270: astore_2
    //   271: goto -> 284
    //   274: astore_2
    //   275: new X/068
    //   278: dup
    //   279: aload_2
    //   280: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   283: astore_2
    //   284: aload_0
    //   285: aload_3
    //   286: aload_2
    //   287: invokestatic A00 : (Ljava/lang/Object;)Ljava/lang/Throwable;
    //   290: invokevirtual A06 : (Ljava/lang/Throwable;Ljava/lang/Throwable;)V
    //   293: return
    // Exception table:
    //   from	to	target	type
    //   0	59	266	finally
    //   64	87	244	finally
    //   92	97	244	finally
    //   110	126	244	finally
    //   129	144	244	finally
    //   149	192	244	finally
    //   192	197	244	finally
    //   204	217	244	finally
    //   220	227	266	finally
    //   227	233	266	finally
    //   250	257	266	finally
    //   257	263	266	finally
    //   263	266	266	finally
    //   267	271	274	finally
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\05z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */