package X;

import android.content.Context;
import java.util.Map;

public final class 03e {
  public static 03e A04;
  
  public final 03f A00;
  
  public final 0tW A01;
  
  public final Map A02 = 001.A11();
  
  public final 00q A03;
  
  public 03e(Context paramContext, 0tW param0tW) {
    01N 01N = new 01N(this);
    this.A03 = 01N;
    Context context = paramContext.getApplicationContext();
    if (03f.A02 == null) {
      03f.A02 = new 03f(context);
      03f.A03 = 013.A00();
    } 
    this.A00 = 03f.A02;
    this.A01 = param0tW;
    00u.A00(paramContext, "activity");
    00u.A01(01N);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\03e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */