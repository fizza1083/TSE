package X;

import android.view.ViewGroup;
import androidx.fragment.app.Fragment;

public final class 091 extends 08s {
  public final ViewGroup container;
  
  public 091(ViewGroup paramViewGroup, Fragment paramFragment) {
    super(stringBuilder.toString(), paramFragment);
    this.container = paramViewGroup;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\091.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */