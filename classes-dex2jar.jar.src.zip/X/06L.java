package X;

import java.nio.ByteBuffer;

public final class 06L {
  public static final ByteBuffer A04 = ByteBuffer.allocate(4);
  
  public final int A00;
  
  public final 06N A01;
  
  public final 06O A02;
  
  public final ByteBuffer A03;
  
  public 06L(ByteBuffer paramByteBuffer, int paramInt) {}
  
  public static int A00(06L param06L, String paramString, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: iload_3
    //   1: ifeq -> 760
    //   4: aload_1
    //   5: ifnonnull -> 14
    //   8: iconst_0
    //   9: istore #4
    //   11: iload #4
    //   13: ireturn
    //   14: aload_0
    //   15: getfield A02 : LX/06O;
    //   18: astore #12
    //   20: aload_1
    //   21: invokevirtual getBytes : ()[B
    //   24: astore_1
    //   25: aload #12
    //   27: aload_1
    //   28: putfield A01 : [B
    //   31: aload #12
    //   33: aload_2
    //   34: putfield A02 : [B
    //   37: aload #12
    //   39: iload #4
    //   41: putfield A00 : I
    //   44: aload_0
    //   45: getfield A03 : Ljava/nio/ByteBuffer;
    //   48: astore #13
    //   50: aload #13
    //   52: ifnull -> 639
    //   55: aload_1
    //   56: arraylength
    //   57: iconst_1
    //   58: iadd
    //   59: istore #6
    //   61: iload #6
    //   63: istore #5
    //   65: iload #4
    //   67: ifeq -> 401
    //   70: iload #6
    //   72: iconst_1
    //   73: iadd
    //   74: istore #6
    //   76: getstatic X/06O.A03 : [I
    //   79: iload #4
    //   81: iaload
    //   82: istore #7
    //   84: iload #6
    //   86: istore #5
    //   88: iload #7
    //   90: ifle -> 401
    //   93: iload #6
    //   95: istore #5
    //   97: iload #7
    //   99: istore #4
    //   101: iload #5
    //   103: iload #4
    //   105: iadd
    //   106: iconst_4
    //   107: iadd
    //   108: istore #4
    //   110: iload #4
    //   112: iconst_4
    //   113: irem
    //   114: istore #5
    //   116: iload #4
    //   118: istore #6
    //   120: iload #5
    //   122: ifeq -> 134
    //   125: iload #4
    //   127: iconst_4
    //   128: iload #5
    //   130: isub
    //   131: iadd
    //   132: istore #6
    //   134: aload_0
    //   135: getfield A00 : I
    //   138: istore #8
    //   140: iload #6
    //   142: iload #8
    //   144: bipush #12
    //   146: isub
    //   147: if_icmpgt -> 639
    //   150: aload #13
    //   152: invokevirtual position : ()I
    //   155: iload #6
    //   157: iadd
    //   158: iload #8
    //   160: if_icmple -> 206
    //   163: aload #13
    //   165: invokevirtual position : ()I
    //   168: iconst_4
    //   169: iadd
    //   170: iload #8
    //   172: if_icmpgt -> 182
    //   175: aload #13
    //   177: iconst_0
    //   178: invokevirtual putInt : (I)Ljava/nio/ByteBuffer;
    //   181: pop
    //   182: aload_0
    //   183: getfield A01 : LX/06N;
    //   186: astore_1
    //   187: aload_1
    //   188: iconst_1
    //   189: putfield A03 : Z
    //   192: aload #13
    //   194: bipush #12
    //   196: invokevirtual position : (I)Ljava/nio/Buffer;
    //   199: pop
    //   200: aload_1
    //   201: bipush #12
    //   203: putfield A02 : I
    //   206: aload_0
    //   207: getfield A01 : LX/06N;
    //   210: astore_2
    //   211: aload_2
    //   212: getfield A03 : Z
    //   215: ifeq -> 469
    //   218: aload_2
    //   219: getfield A02 : I
    //   222: istore #4
    //   224: aload #13
    //   226: invokevirtual position : ()I
    //   229: istore #9
    //   231: iload #9
    //   233: iload #6
    //   235: iadd
    //   236: iload #4
    //   238: if_icmple -> 440
    //   241: aload #13
    //   243: iload #4
    //   245: invokevirtual position : (I)Ljava/nio/Buffer;
    //   248: pop
    //   249: aload #13
    //   251: invokevirtual getInt : ()I
    //   254: ifne -> 282
    //   257: aload #13
    //   259: invokevirtual capacity : ()I
    //   262: iconst_4
    //   263: iadd
    //   264: aload #13
    //   266: invokevirtual position : ()I
    //   269: isub
    //   270: istore #5
    //   272: iload #4
    //   274: iload #5
    //   276: iadd
    //   277: istore #4
    //   279: goto -> 231
    //   282: aload #13
    //   284: invokevirtual position : ()I
    //   287: istore #5
    //   289: aload #13
    //   291: invokevirtual get : ()B
    //   294: iconst_1
    //   295: iadd
    //   296: istore #7
    //   298: aload #13
    //   300: iload #5
    //   302: iload #7
    //   304: iadd
    //   305: invokevirtual position : (I)Ljava/nio/Buffer;
    //   308: pop
    //   309: aload #13
    //   311: invokevirtual get : ()B
    //   314: istore #10
    //   316: iload #10
    //   318: iconst_1
    //   319: iadd
    //   320: istore #5
    //   322: iload #10
    //   324: ifge -> 353
    //   327: iload #10
    //   329: invokestatic abs : (I)I
    //   332: istore #5
    //   334: getstatic X/06O.A03 : [I
    //   337: iload #5
    //   339: iaload
    //   340: istore #5
    //   342: iload #5
    //   344: ifle -> 389
    //   347: iload #5
    //   349: iconst_1
    //   350: iadd
    //   351: istore #5
    //   353: iload #7
    //   355: iload #5
    //   357: iadd
    //   358: iconst_4
    //   359: iadd
    //   360: istore #7
    //   362: iload #7
    //   364: iconst_4
    //   365: irem
    //   366: istore #10
    //   368: iload #7
    //   370: istore #5
    //   372: iload #10
    //   374: ifeq -> 272
    //   377: iload #7
    //   379: iconst_4
    //   380: iload #10
    //   382: isub
    //   383: iadd
    //   384: istore #5
    //   386: goto -> 272
    //   389: aload #13
    //   391: invokevirtual get : ()B
    //   394: iconst_2
    //   395: iadd
    //   396: istore #5
    //   398: goto -> 353
    //   401: getstatic X/06O.A04 : [Z
    //   404: iload #4
    //   406: baload
    //   407: istore #11
    //   409: aload_2
    //   410: arraylength
    //   411: istore #6
    //   413: iload #6
    //   415: istore #4
    //   417: iload #11
    //   419: ifne -> 431
    //   422: iload #6
    //   424: bipush #50
    //   426: invokestatic min : (II)I
    //   429: istore #4
    //   431: iload #4
    //   433: iconst_1
    //   434: iadd
    //   435: istore #4
    //   437: goto -> 101
    //   440: aload #13
    //   442: iload #9
    //   444: invokevirtual position : (I)Ljava/nio/Buffer;
    //   447: pop
    //   448: iload #4
    //   450: istore #5
    //   452: iload #4
    //   454: iload #8
    //   456: if_icmple -> 463
    //   459: bipush #12
    //   461: istore #5
    //   463: aload_2
    //   464: iload #5
    //   466: putfield A02 : I
    //   469: aload #13
    //   471: iload_3
    //   472: invokevirtual putInt : (I)Ljava/nio/ByteBuffer;
    //   475: pop
    //   476: aload #12
    //   478: getfield A01 : [B
    //   481: astore_0
    //   482: aload_0
    //   483: arraylength
    //   484: istore_3
    //   485: iload_3
    //   486: bipush #50
    //   488: if_icmple -> 742
    //   491: aload #13
    //   493: bipush #50
    //   495: invokevirtual put : (B)Ljava/nio/ByteBuffer;
    //   498: pop
    //   499: aload #13
    //   501: aload_0
    //   502: iconst_0
    //   503: bipush #50
    //   505: invokevirtual put : ([BII)Ljava/nio/ByteBuffer;
    //   508: pop
    //   509: aload #12
    //   511: getfield A00 : I
    //   514: istore #4
    //   516: iload #4
    //   518: ifne -> 672
    //   521: aload #12
    //   523: getfield A02 : [B
    //   526: astore_0
    //   527: getstatic X/06O.A04 : [Z
    //   530: iload #4
    //   532: baload
    //   533: ifeq -> 723
    //   536: aload_0
    //   537: arraylength
    //   538: bipush #50
    //   540: if_icmple -> 723
    //   543: aload #13
    //   545: bipush #50
    //   547: invokevirtual put : (B)Ljava/nio/ByteBuffer;
    //   550: pop
    //   551: aload #13
    //   553: aload_0
    //   554: iconst_0
    //   555: bipush #50
    //   557: invokevirtual put : ([BII)Ljava/nio/ByteBuffer;
    //   560: pop
    //   561: aload #13
    //   563: invokevirtual position : ()I
    //   566: iconst_4
    //   567: irem
    //   568: istore_3
    //   569: iload_3
    //   570: ifeq -> 588
    //   573: aload #13
    //   575: aload #13
    //   577: invokevirtual position : ()I
    //   580: iconst_4
    //   581: iadd
    //   582: iload_3
    //   583: isub
    //   584: invokevirtual position : (I)Ljava/nio/Buffer;
    //   587: pop
    //   588: aload #13
    //   590: invokevirtual position : ()I
    //   593: istore_3
    //   594: aload_2
    //   595: iload_3
    //   596: putfield A00 : I
    //   599: aload #13
    //   601: iconst_0
    //   602: iload_3
    //   603: invokevirtual putInt : (II)Ljava/nio/ByteBuffer;
    //   606: pop
    //   607: aload_2
    //   608: getfield A03 : Z
    //   611: istore #11
    //   613: aload_2
    //   614: getfield A02 : I
    //   617: istore #4
    //   619: iload #4
    //   621: istore_3
    //   622: iload #11
    //   624: ifeq -> 631
    //   627: iload #4
    //   629: ineg
    //   630: istore_3
    //   631: aload #13
    //   633: iconst_4
    //   634: iload_3
    //   635: invokevirtual putInt : (II)Ljava/nio/ByteBuffer;
    //   638: pop
    //   639: iconst_1
    //   640: istore_3
    //   641: aload #12
    //   643: getfield A01 : [B
    //   646: arraylength
    //   647: bipush #50
    //   649: if_icmple -> 654
    //   652: iconst_3
    //   653: istore_3
    //   654: iload_3
    //   655: istore #4
    //   657: aload #12
    //   659: getfield A02 : [B
    //   662: arraylength
    //   663: bipush #50
    //   665: if_icmple -> 11
    //   668: iload_3
    //   669: iconst_4
    //   670: ior
    //   671: ireturn
    //   672: aload #13
    //   674: iload #4
    //   676: ineg
    //   677: i2b
    //   678: invokevirtual put : (B)Ljava/nio/ByteBuffer;
    //   681: pop
    //   682: aload #12
    //   684: getfield A00 : I
    //   687: istore #4
    //   689: getstatic X/06O.A03 : [I
    //   692: iload #4
    //   694: iaload
    //   695: istore #5
    //   697: iconst_0
    //   698: istore_3
    //   699: iload #5
    //   701: ifle -> 706
    //   704: iconst_1
    //   705: istore_3
    //   706: aload #12
    //   708: getfield A02 : [B
    //   711: astore_1
    //   712: aload_1
    //   713: astore_0
    //   714: iload_3
    //   715: ifeq -> 527
    //   718: aload_1
    //   719: astore_0
    //   720: goto -> 732
    //   723: aload #13
    //   725: aload_0
    //   726: arraylength
    //   727: i2b
    //   728: invokevirtual put : (B)Ljava/nio/ByteBuffer;
    //   731: pop
    //   732: aload #13
    //   734: aload_0
    //   735: invokevirtual put : ([B)Ljava/nio/ByteBuffer;
    //   738: pop
    //   739: goto -> 561
    //   742: aload #13
    //   744: iload_3
    //   745: i2b
    //   746: invokevirtual put : (B)Ljava/nio/ByteBuffer;
    //   749: pop
    //   750: aload #13
    //   752: aload_0
    //   753: invokevirtual put : ([B)Ljava/nio/ByteBuffer;
    //   756: pop
    //   757: goto -> 509
    //   760: ldc '0 can't be used as id - it is reserved'
    //   762: invokestatic A0O : (Ljava/lang/String;)Ljava/lang/IllegalArgumentException;
    //   765: athrow
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\06L.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */