package X;

import java.io.File;
import java.util.List;

public final class 02V implements 02W {
  public int A00;
  
  public int A01;
  
  public int A02 = 0;
  
  public long A03;
  
  public long A04;
  
  public long A05;
  
  public long A06;
  
  public long A07;
  
  public long A08;
  
  public long A09;
  
  public long A0A;
  
  public 0GC A0B;
  
  public 0GC A0C;
  
  public 02s A0D;
  
  public File A0E;
  
  public Long A0F;
  
  public Long A0G;
  
  public Long A0H;
  
  public Long A0I;
  
  public String A0J;
  
  public String A0K;
  
  public String A0L;
  
  public String A0M;
  
  public String A0N;
  
  public String A0O;
  
  public String A0P;
  
  public String A0Q;
  
  public String A0R;
  
  public String A0S;
  
  public boolean A0T;
  
  public boolean A0U;
  
  public boolean A0V;
  
  public boolean A0W;
  
  public boolean A0X;
  
  public boolean A0Y;
  
  public final 0tW A0Z;
  
  public final List A0a = 001.A0y();
  
  public final 14q A0b;
  
  public final 14q A0c;
  
  public final 14q A0d;
  
  public 02V(0tW param0tW, 14q param14q1, 14q param14q2, 14q param14q3) {
    this.A0Z = param0tW;
    this.A0d = param14q1;
    this.A0c = param14q2;
    this.A0b = param14q3;
    File file = param0tW.A07;
    0ah.A03(file);
    this.A0E = 001.A0E(file, 0XK.A0k("anr_report_", ".dmp", 0));
  }
  
  public static void A00(02V param02V) {
    // Byte code:
    //   0: new X/0jQ
    //   3: dup
    //   4: aconst_null
    //   5: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   8: astore #9
    //   10: aload_0
    //   11: getfield A0R : Ljava/lang/String;
    //   14: astore #7
    //   16: aload #7
    //   18: astore #6
    //   20: aload #7
    //   22: ifnonnull -> 214
    //   25: aload_0
    //   26: getfield A0N : Ljava/lang/String;
    //   29: astore #7
    //   31: aload #7
    //   33: astore #6
    //   35: aload #7
    //   37: ifnonnull -> 146
    //   40: aload_0
    //   41: getfield A0O : Ljava/lang/String;
    //   44: astore #6
    //   46: aload #6
    //   48: ifnull -> 152
    //   51: aload #6
    //   53: invokestatic A0F : (Ljava/lang/String;)Ljava/io/File;
    //   56: astore #7
    //   58: aload #7
    //   60: invokevirtual exists : ()Z
    //   63: ifeq -> 152
    //   66: invokestatic A0s : ()Ljava/lang/StringBuilder;
    //   69: astore #6
    //   71: aload #7
    //   73: invokestatic A0E : (Ljava/io/File;)Ljava/io/BufferedReader;
    //   76: astore #7
    //   78: aload #7
    //   80: invokevirtual readLine : ()Ljava/lang/String;
    //   83: astore #8
    //   85: aload #8
    //   87: ifnull -> 109
    //   90: aload #6
    //   92: aload #8
    //   94: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   97: pop
    //   98: aload #6
    //   100: ldc '\\n'
    //   102: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   105: pop
    //   106: goto -> 78
    //   109: aload #7
    //   111: invokevirtual close : ()V
    //   114: goto -> 139
    //   117: astore #6
    //   119: aload #7
    //   121: invokevirtual close : ()V
    //   124: goto -> 136
    //   127: astore #7
    //   129: aload #6
    //   131: aload #7
    //   133: invokestatic A00 : (Ljava/lang/Throwable;Ljava/lang/Throwable;)V
    //   136: aload #6
    //   138: athrow
    //   139: aload #6
    //   141: invokevirtual toString : ()Ljava/lang/String;
    //   144: astore #6
    //   146: aload_0
    //   147: aload #6
    //   149: putfield A0R : Ljava/lang/String;
    //   152: aload_0
    //   153: getfield A0R : Ljava/lang/String;
    //   156: astore #7
    //   158: aload #7
    //   160: astore #6
    //   162: aload #7
    //   164: ifnonnull -> 214
    //   167: aload #7
    //   169: astore #6
    //   171: goto -> 201
    //   174: astore #7
    //   176: invokestatic A00 : ()LX/0t7;
    //   179: astore #8
    //   181: aconst_null
    //   182: astore #6
    //   184: aload #8
    //   186: ldc 'AnrDataGetTrace'
    //   188: aload #7
    //   190: aconst_null
    //   191: invokeinterface Ci5 : (Ljava/lang/String;Ljava/lang/Throwable;Ljava/util/Map;)V
    //   196: aload_0
    //   197: aconst_null
    //   198: putfield A0R : Ljava/lang/String;
    //   201: aload_0
    //   202: getfield A0U : Z
    //   205: ifeq -> 214
    //   208: aload_0
    //   209: aconst_null
    //   210: putfield A0E : Ljava/io/File;
    //   213: return
    //   214: aload_0
    //   215: getfield A0Z : LX/0tW;
    //   218: astore #10
    //   220: aload #10
    //   222: getfield A07 : Ljava/io/File;
    //   225: astore #7
    //   227: aload #7
    //   229: invokestatic A03 : (Ljava/lang/Object;)V
    //   232: aload_0
    //   233: aload #7
    //   235: ldc 'anr_report_'
    //   237: ldc '.dmp'
    //   239: aload_0
    //   240: getfield A02 : I
    //   243: invokestatic A0k : (Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;
    //   246: invokestatic A0E : (Ljava/io/File;Ljava/lang/String;)Ljava/io/File;
    //   249: putfield A0E : Ljava/io/File;
    //   252: aload_0
    //   253: getfield A0U : Z
    //   256: ifne -> 269
    //   259: aload #9
    //   261: getstatic X/0qV.A8h : LX/17U;
    //   264: ldc 'true'
    //   266: invokevirtual DXk : (LX/17U;Ljava/lang/String;)V
    //   269: aload #6
    //   271: ifnull -> 388
    //   274: getstatic X/0qV.A9R : LX/17U;
    //   277: astore #11
    //   279: aconst_null
    //   280: astore #8
    //   282: aload #8
    //   284: astore #7
    //   286: aload #6
    //   288: invokevirtual length : ()I
    //   291: ifeq -> 379
    //   294: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
    //   297: astore #7
    //   299: aload #7
    //   301: invokestatic A0B : (Ljava/lang/Object;)V
    //   304: aload #6
    //   306: aload #7
    //   308: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   311: astore #6
    //   313: aload #6
    //   315: invokestatic A0A : (Ljava/lang/Object;)V
    //   318: new java/io/ByteArrayOutputStream
    //   321: dup
    //   322: invokespecial <init> : ()V
    //   325: astore #7
    //   327: new java/util/zip/GZIPOutputStream
    //   330: dup
    //   331: aload #7
    //   333: invokespecial <init> : (Ljava/io/OutputStream;)V
    //   336: astore #12
    //   338: aload #12
    //   340: aload #6
    //   342: invokevirtual write : ([B)V
    //   345: aload #12
    //   347: invokevirtual close : ()V
    //   350: aload #7
    //   352: invokevirtual toByteArray : ()[B
    //   355: iconst_2
    //   356: invokestatic encodeToString : ([BI)Ljava/lang/String;
    //   359: astore #7
    //   361: goto -> 379
    //   364: astore #6
    //   366: ldc 'ReportFieldHelper'
    //   368: aload #6
    //   370: ldc 'Failed to compress string'
    //   372: invokestatic A0R : (Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V
    //   375: aload #8
    //   377: astore #7
    //   379: aload #9
    //   381: aload #11
    //   383: aload #7
    //   385: invokevirtual DXk : (LX/17U;Ljava/lang/String;)V
    //   388: getstatic X/0qV.A48 : LX/17U;
    //   391: astore #7
    //   393: aload_0
    //   394: getfield A0Y : Z
    //   397: ifeq -> 986
    //   400: ldc_w '1'
    //   403: astore #6
    //   405: aload #9
    //   407: aload #7
    //   409: aload #6
    //   411: invokevirtual DXk : (LX/17U;Ljava/lang/String;)V
    //   414: aload_0
    //   415: getfield A04 : J
    //   418: lstore_2
    //   419: aload #10
    //   421: getfield A01 : J
    //   424: lstore #4
    //   426: getstatic X/0qV.A0l : LX/17V;
    //   429: aload #9
    //   431: lload_2
    //   432: invokestatic A03 : (LX/17V;LX/0jQ;J)V
    //   435: getstatic X/0qV.A0q : LX/17V;
    //   438: aload #9
    //   440: lload_2
    //   441: lload #4
    //   443: lsub
    //   444: invokestatic A03 : (LX/17V;LX/0jQ;J)V
    //   447: aload #9
    //   449: getstatic X/0qV.A3l : LX/17U;
    //   452: aload_0
    //   453: getfield A0X : Z
    //   456: invokestatic toString : (Z)Ljava/lang/String;
    //   459: invokevirtual DXk : (LX/17U;Ljava/lang/String;)V
    //   462: aload #9
    //   464: getstatic X/0qV.A0n : LX/17V;
    //   467: aload_0
    //   468: getfield A00 : I
    //   471: invokevirtual DXi : (LX/17V;I)V
    //   474: getstatic X/0qV.A0o : LX/17V;
    //   477: aload #9
    //   479: aload_0
    //   480: getfield A05 : J
    //   483: invokestatic A03 : (LX/17V;LX/0jQ;J)V
    //   486: aload #9
    //   488: getstatic X/0qV.A00 : LX/17X;
    //   491: aload_0
    //   492: getfield A0V : Z
    //   495: invokevirtual DXh : (LX/17X;Z)V
    //   498: aload #9
    //   500: getstatic X/0qV.A01 : LX/17X;
    //   503: aload_0
    //   504: getfield A0W : Z
    //   507: invokevirtual DXh : (LX/17X;Z)V
    //   510: aload #9
    //   512: getstatic X/0qV.A0t : LX/17V;
    //   515: aload_0
    //   516: getfield A0G : Ljava/lang/Long;
    //   519: invokevirtual DXj : (LX/17V;Ljava/lang/Long;)V
    //   522: aload #9
    //   524: getstatic X/0qV.A0s : LX/17V;
    //   527: aload_0
    //   528: getfield A0F : Ljava/lang/Long;
    //   531: invokevirtual DXj : (LX/17V;Ljava/lang/Long;)V
    //   534: aload #9
    //   536: getstatic X/0qV.A11 : LX/17V;
    //   539: aload_0
    //   540: getfield A0I : Ljava/lang/Long;
    //   543: invokevirtual DXj : (LX/17V;Ljava/lang/Long;)V
    //   546: aload #9
    //   548: getstatic X/0qV.A10 : LX/17V;
    //   551: aload_0
    //   552: getfield A0H : Ljava/lang/Long;
    //   555: invokevirtual DXj : (LX/17V;Ljava/lang/Long;)V
    //   558: aload #9
    //   560: getstatic X/0qV.A41 : LX/17U;
    //   563: aload_0
    //   564: getfield A0Q : Ljava/lang/String;
    //   567: invokevirtual DXk : (LX/17U;Ljava/lang/String;)V
    //   570: aload #9
    //   572: getstatic X/0qV.A40 : LX/17U;
    //   575: aload_0
    //   576: getfield A0P : Ljava/lang/String;
    //   579: invokevirtual DXk : (LX/17U;Ljava/lang/String;)V
    //   582: getstatic X/0qV.A0i : LX/17V;
    //   585: aload #9
    //   587: aload_0
    //   588: getfield A03 : J
    //   591: invokestatic A03 : (LX/17V;LX/0jQ;J)V
    //   594: getstatic X/0qV.A0x : LX/17V;
    //   597: aload #9
    //   599: aload_0
    //   600: getfield A09 : J
    //   603: invokestatic A03 : (LX/17V;LX/0jQ;J)V
    //   606: getstatic X/0qV.A0w : LX/17V;
    //   609: aload #9
    //   611: aload_0
    //   612: getfield A01 : I
    //   615: i2l
    //   616: invokestatic A03 : (LX/17V;LX/0jQ;J)V
    //   619: getstatic X/0qV.A0y : LX/17V;
    //   622: aload #9
    //   624: lconst_0
    //   625: invokestatic A03 : (LX/17V;LX/0jQ;J)V
    //   628: getstatic X/0qV.A0r : LX/17V;
    //   631: aload #9
    //   633: aload_0
    //   634: getfield A06 : J
    //   637: invokestatic A03 : (LX/17V;LX/0jQ;J)V
    //   640: getstatic X/0qV.A0v : LX/17V;
    //   643: aload #9
    //   645: aload_0
    //   646: getfield A08 : J
    //   649: invokestatic A03 : (LX/17V;LX/0jQ;J)V
    //   652: getstatic X/0qV.A0u : LX/17V;
    //   655: aload #9
    //   657: aload_0
    //   658: getfield A07 : J
    //   661: invokestatic A03 : (LX/17V;LX/0jQ;J)V
    //   664: aload #9
    //   666: getstatic X/0qV.AA0 : LX/17U;
    //   669: aload_0
    //   670: getfield A0S : Ljava/lang/String;
    //   673: invokevirtual DXk : (LX/17U;Ljava/lang/String;)V
    //   676: aload #9
    //   678: getstatic X/0qV.A3b : LX/17U;
    //   681: aload_0
    //   682: getfield A0K : Ljava/lang/String;
    //   685: invokevirtual DXk : (LX/17U;Ljava/lang/String;)V
    //   688: aload #9
    //   690: getstatic X/0qV.A3X : LX/17U;
    //   693: aload_0
    //   694: getfield A0J : Ljava/lang/String;
    //   697: invokevirtual DXk : (LX/17U;Ljava/lang/String;)V
    //   700: aload_0
    //   701: getfield A0D : LX/02s;
    //   704: astore #6
    //   706: aload #6
    //   708: ifnull -> 724
    //   711: aload #9
    //   713: getstatic X/0qV.A3y : LX/17U;
    //   716: aload #6
    //   718: invokevirtual name : ()Ljava/lang/String;
    //   721: invokevirtual DXk : (LX/17U;Ljava/lang/String;)V
    //   724: aload #9
    //   726: getstatic X/0qV.A4e : LX/17U;
    //   729: aload_0
    //   730: getfield A0M : Ljava/lang/String;
    //   733: invokevirtual DXk : (LX/17U;Ljava/lang/String;)V
    //   736: aload #9
    //   738: getstatic X/0qV.A6x : LX/17U;
    //   741: aload_0
    //   742: getfield A0L : Ljava/lang/String;
    //   745: invokevirtual DXk : (LX/17U;Ljava/lang/String;)V
    //   748: getstatic X/0qV.A0z : LX/17V;
    //   751: aload #9
    //   753: aload_0
    //   754: getfield A0A : J
    //   757: invokestatic A03 : (LX/17V;LX/0jQ;J)V
    //   760: aload_0
    //   761: getfield A0B : LX/0GC;
    //   764: astore #6
    //   766: aload #6
    //   768: ifnull -> 784
    //   771: aload #9
    //   773: getstatic X/0qV.A50 : LX/17U;
    //   776: aload #6
    //   778: invokevirtual A00 : ()Ljava/lang/String;
    //   781: invokevirtual DXk : (LX/17U;Ljava/lang/String;)V
    //   784: aload_0
    //   785: getfield A0C : LX/0GC;
    //   788: astore #6
    //   790: aload #6
    //   792: ifnull -> 808
    //   795: aload #9
    //   797: getstatic X/0qV.A51 : LX/17U;
    //   800: aload #6
    //   802: invokevirtual A00 : ()Ljava/lang/String;
    //   805: invokevirtual DXk : (LX/17U;Ljava/lang/String;)V
    //   808: aload_0
    //   809: getfield A0T : Z
    //   812: ifeq -> 830
    //   815: aload #9
    //   817: getstatic X/0qV.A3x : LX/17U;
    //   820: aload_0
    //   821: getfield A0G : Ljava/lang/Long;
    //   824: invokestatic getRecordsJson : (Ljava/lang/Long;)Ljava/lang/String;
    //   827: invokevirtual DXk : (LX/17U;Ljava/lang/String;)V
    //   830: iconst_0
    //   831: istore_1
    //   832: aload_0
    //   833: getfield A0a : Ljava/util/List;
    //   836: invokeinterface iterator : ()Ljava/util/Iterator;
    //   841: astore #6
    //   843: aload #6
    //   845: invokeinterface hasNext : ()Z
    //   850: ifeq -> 900
    //   853: aload #6
    //   855: invokestatic A0p : (Ljava/util/Iterator;)Ljava/lang/String;
    //   858: astore #7
    //   860: aload #9
    //   862: getstatic X/0qV.A3r : LX/17U;
    //   865: getfield A01 : Ljava/lang/String;
    //   868: iload_1
    //   869: invokestatic A0Z : (Ljava/lang/String;I)Ljava/lang/String;
    //   872: aload #7
    //   874: invokevirtual DXf : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   877: pop
    //   878: iload_1
    //   879: iconst_1
    //   880: iadd
    //   881: istore_1
    //   882: goto -> 843
    //   885: astore #6
    //   887: aload #9
    //   889: invokestatic A00 : ()LX/0t7;
    //   892: ldc_w 'AnrDataSaveReport'
    //   895: aload #6
    //   897: invokestatic A04 : (LX/0jQ;LX/0t7;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   900: aload_0
    //   901: getfield A0E : Ljava/io/File;
    //   904: ifnull -> 985
    //   907: new java/util/Properties
    //   910: dup
    //   911: invokespecial <init> : ()V
    //   914: astore #6
    //   916: aload #9
    //   918: aload #6
    //   920: invokevirtual DXy : (Ljava/util/Properties;)V
    //   923: aload_0
    //   924: getfield A0E : Ljava/io/File;
    //   927: invokestatic A0H : (Ljava/io/File;)Ljava/io/FileOutputStream;
    //   930: astore_0
    //   931: aload #6
    //   933: aload_0
    //   934: ldc_w 'no pool'
    //   937: invokevirtual store : (Ljava/io/OutputStream;Ljava/lang/String;)V
    //   940: aload_0
    //   941: invokevirtual close : ()V
    //   944: return
    //   945: astore #6
    //   947: aload_0
    //   948: invokevirtual close : ()V
    //   951: goto -> 961
    //   954: astore_0
    //   955: aload #6
    //   957: aload_0
    //   958: invokestatic A00 : (Ljava/lang/Throwable;Ljava/lang/Throwable;)V
    //   961: aload #6
    //   963: athrow
    //   964: astore_0
    //   965: ldc_w 'lacrima'
    //   968: ldc_w 'Could not save ANR report file'
    //   971: aload_0
    //   972: invokestatic A01 : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)LX/0t7;
    //   975: ldc_w 'AnrSaveProp'
    //   978: aload_0
    //   979: aconst_null
    //   980: invokeinterface Ci5 : (Ljava/lang/String;Ljava/lang/Throwable;Ljava/util/Map;)V
    //   985: return
    //   986: ldc_w '0'
    //   989: astore #6
    //   991: goto -> 405
    // Exception table:
    //   from	to	target	type
    //   10	16	885	finally
    //   25	31	885	finally
    //   40	46	885	finally
    //   51	71	885	finally
    //   71	78	174	java/io/IOException
    //   71	78	885	finally
    //   78	85	117	finally
    //   90	106	117	finally
    //   109	114	174	java/io/IOException
    //   109	114	885	finally
    //   119	124	127	finally
    //   129	136	174	java/io/IOException
    //   129	136	885	finally
    //   136	139	174	java/io/IOException
    //   136	139	885	finally
    //   139	146	885	finally
    //   146	152	885	finally
    //   152	158	885	finally
    //   176	181	885	finally
    //   184	201	885	finally
    //   201	213	885	finally
    //   214	269	885	finally
    //   274	279	885	finally
    //   286	294	885	finally
    //   294	361	364	java/io/IOException
    //   294	361	885	finally
    //   366	375	885	finally
    //   379	388	885	finally
    //   388	400	885	finally
    //   405	706	885	finally
    //   711	724	885	finally
    //   724	766	885	finally
    //   771	784	885	finally
    //   784	790	885	finally
    //   795	808	885	finally
    //   808	830	885	finally
    //   832	843	885	finally
    //   843	878	885	finally
    //   907	931	964	java/io/IOException
    //   931	940	945	finally
    //   940	944	964	java/io/IOException
    //   947	951	954	finally
    //   955	961	964	java/io/IOException
    //   961	964	964	java/io/IOException
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\02V.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */