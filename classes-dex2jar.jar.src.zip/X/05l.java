package X;

import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;

public final class 05l extends 04F implements 04M {
  public final int A00;
  
  public final Object A01;
  
  public final 04F A02;
  
  public final 05W A03;
  
  public 05l(04F param04F, int paramInt) {}
  
  public static final Runnable A00(05l param05l) {
    AtomicIntegerFieldUpdater<05l> atomicIntegerFieldUpdater;
    while (true) {
      05W 05W1 = param05l.A03;
      Runnable runnable2 = (Runnable)05W1.A01();
      Runnable runnable1 = runnable2;
      if (runnable2 == null) {
        synchronized (param05l.A01) {
          atomicIntegerFieldUpdater = A05;
          atomicIntegerFieldUpdater.decrementAndGet(param05l);
          if (05W1.A00() == 0) {
            atomicIntegerFieldUpdater = null;
            break;
          } 
          atomicIntegerFieldUpdater.incrementAndGet(param05l);
        } 
        continue;
      } 
      break;
    } 
    return (Runnable)atomicIntegerFieldUpdater;
  }
  
  public final 04F A02(int paramInt) {
    05k.A00(paramInt);
    if (paramInt < this.A00) {
      05k.A00(paramInt);
      return new 05l(this, paramInt);
    } 
    return this;
  }
  
  public final void A03(Runnable paramRunnable, 04I param04I) {
    this.A03.A03(paramRunnable);
    AtomicIntegerFieldUpdater<05l> atomicIntegerFieldUpdater = A05;
    int i = atomicIntegerFieldUpdater.get(this);
    int j = this.A00;
    if (i < j) {
      synchronized (this.A01) {
        if (atomicIntegerFieldUpdater.get((T)this) >= j) {
          i = 0;
        } else {
          atomicIntegerFieldUpdater.incrementAndGet(this);
          i = 1;
        } 
      } 
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Runnable}, name=paramRunnable} */
      if (i != 0) {
        paramRunnable = A00(this);
        if (paramRunnable != null) {
          paramRunnable = new 0SI(paramRunnable, this);
          this.A02.A03(paramRunnable, this);
        } 
      } 
    } 
  }
  
  public final void A05(Runnable paramRunnable, 04I param04I) {
    this.A03.A03(paramRunnable);
    AtomicIntegerFieldUpdater<05l> atomicIntegerFieldUpdater = A05;
    int i = atomicIntegerFieldUpdater.get(this);
    int j = this.A00;
    if (i < j) {
      synchronized (this.A01) {
        if (atomicIntegerFieldUpdater.get((T)this) >= j) {
          i = 0;
        } else {
          atomicIntegerFieldUpdater.incrementAndGet(this);
          i = 1;
        } 
      } 
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Runnable}, name=paramRunnable} */
      if (i != 0) {
        paramRunnable = A00(this);
        if (paramRunnable != null) {
          paramRunnable = new 0SI(paramRunnable, this);
          this.A02.A05(paramRunnable, this);
        } 
      } 
    } 
  }
  
  public final 04s C25(Runnable paramRunnable, 04I param04I, long paramLong) {
    return this.A04.C25(paramRunnable, param04I, paramLong);
  }
  
  public final void Djw(0IU param0IU, long paramLong) {
    this.A04.Djw(param0IU, paramLong);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\05l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */