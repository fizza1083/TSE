package X;

import com.facebook.voltron.metadata.VoltronModuleMetadataHelper;

public abstract class 02Y {
  public static final int[] APP_MODULE_INDICES;
  
  public static final int[] APP_MODULE_RANGES = new int[] { 
      124370, 124380, 124383, 124498, 124499, 124635, 124636, 124751, 124753, 124753, 
      124755, 124833, 124834, 124956, 124957, 127492, 127494, 127494, 127496, 127948, 
      127949, 129555, 129556, 130129, 130132, 150834, 150844, 150900, 150902, 151290, 
      151291, 151378, 151380, 151796, 151797, 151844, 152054, 152105, 152107, 152124, 
      152126, 153105, 153106, 153123 };
  
  static {
    APP_MODULE_INDICES = new int[] { 
        0, 1, 16, 17, 21, 24, 25, 26, 28, 116, 
        117, 118, 120, 121, 123, 124, 126, 135, 143, 147, 
        148, 149 };
  }
  
  public static int A00(String paramString) {
    int i = paramString.hashCode();
    byte b = 9;
    switch (i) {
      default:
        return -1;
      case 2147200167:
        if (paramString.equals("baseline_profiles_12_plus_vdex_stored_cntrl_in_dm"))
          return 7; 
      case 1981122917:
        if (paramString.equals("heliumiabexp"))
          return 27; 
      case 1901043637:
        if (paramString.equals("location"))
          return 119; 
      case 1857116530:
        if (paramString.equals("supmediastreamcontroller"))
          return 148; 
      case 1836942609:
        if (paramString.equals("baseline_profiles_9_11_reels_scroll"))
          return 12; 
      case 1806890506:
        if (paramString.equals("groupsadminactivity"))
          return 25; 
      case 1736157167:
        if (paramString.equals("arservicesoptional"))
          return 0; 
      case 1674213328:
        if (paramString.equals("diverse"))
          return 21; 
      case 1657482747:
        if (paramString.equals("groupsadmin"))
          return 24; 
      case 1591189602:
        if (paramString.equals("surveyplatformremixnt"))
          return 149; 
      case 1546235727:
        if (paramString.equals("d2_native_ab_test_libdav1dexo_test_142_upgrade"))
          return 19; 
      case 1511694373:
        if (paramString.equals("rtcdeps"))
          return 133; 
      case 1431256707:
        if (paramString.equals("baseline_profiles_12_plus_vdex_stored_in_dm"))
          return 8; 
      case 1389976608:
        if (paramString.equals("pvdcontextprediction"))
          return 131; 
      case 1378673757:
        if (paramString.equals("baseline_profiles_12_plus"))
          return 2; 
      case 1355258514:
        if (paramString.equals("iddetectorpytorch"))
          return 115; 
      case 1166307313:
        if (paramString.equals("cgwebrtc"))
          return 17; 
      case 1117095352:
        if (paramString.equals("heliumiab"))
          return 26; 
      case 1109953648:
        if (paramString.equals("metaaivoiceclient"))
          return 122; 
      case 1097468315:
        if (paramString.equals("horizon"))
          return 29; 
      case 1085472458:
        if (paramString.equals("magicmontage"))
          return 121; 
      case 1021349168:
        if (paramString.equals("smartcropnative"))
          return 145; 
      case 983068323:
        if (paramString.equals("s_papaya_torchedlooper"))
          return 137; 
      case 798208611:
        if (paramString.equals("securitycheckup"))
          return 143; 
      case 782025013:
        if (paramString.equals("internsettings"))
          return 118; 
      case 539696248:
        if (paramString.equals("executorch"))
          return 23; 
      case 486403171:
        if (paramString.equals("baseline_profiles_9_11_vdex_in_dm"))
          return 13; 
      case 309557543:
        if (paramString.equals("baseline_profiles_12_plus_vdex_in_dm"))
          return 6; 
      case 263246876:
        if (paramString.equals("cgnativeplayer"))
          return 16; 
      case 106426308:
        if (paramString.equals("pages"))
          return 126; 
      case 3532869:
        if (paramString.equals("slam"))
          return 144; 
      case 3389917:
        if (paramString.equals("nrib"))
          return 125; 
      case -25016096:
        if (paramString.equals("awesomizer"))
          return 1; 
      case -27619454:
        if (paramString.equals("s_magicmontage_smarttrim"))
          return 136; 
      case -104127597:
        if (paramString.equals("pytorch"))
          return 132; 
      case -141853315:
        if (paramString.equals("eventsguestlist"))
          return 22; 
      case -146842901:
        if (paramString.equals("baseline_profiles_9_11_vdex_stored_cntrl_in_dm"))
          return 14; 
      case -248737408:
        if (paramString.equals("instantgames"))
          return 116; 
      case -302788801:
        if (paramString.equals("baseline_profiles_12_plus_no_sv"))
          return 4; 
      case -302789182:
        if (paramString.equals("baseline_profiles_12_plus_no_gm"))
          return 3; 
      case -333158834:
        if (paramString.equals("s_smartcropnative_smartplacementnative"))
          return 141; 
      case -548695934:
        if (paramString.equals("photo3djni"))
          return 130; 
      case -582462278:
        if (paramString.equals("s_smartcropnative_smartplacementnative_smarttrim"))
          return 142; 
      case -607981355:
        if (paramString.equals("baseline_profiles_12_plus_reels_scroll"))
          return 5; 
      case -743385003:
        if (paramString.equals("creditcardscanner"))
          return 18; 
      case -808277076:
        if (paramString.equals("torchedlooper"))
          return 151; 
      case -862087783:
        if (paramString.equals("s_cgwebrtc_horizon"))
          return 135; 
      case -872357293:
        if (paramString.equals("smartplacementnative"))
          return 146; 
      case -877364000:
        if (paramString.equals("papayaanalyticstorch"))
          return 128; 
      case -995487190:
        if (paramString.equals("papaya"))
          return 127; 
      case -1027258749:
        if (paramString.equals("baseline_profiles_9_11_no_sv"))
          return 11; 
      case -1027259130:
        if (paramString.equals("baseline_profiles_9_11_no_gm"))
          return 10; 
      case -1150029881:
        if (paramString.equals("baseline_profiles_9_11_vdex_stored_in_dm"))
          return 15; 
      case -1158050198:
        if (paramString.equals("hermessnapshot"))
          return 28; 
      case -1203178877:
        if (paramString.equals("d_native_raw_v5"))
          return 20; 
      case -1317439696:
        if (paramString.equals("instantgamesads"))
          return 117; 
      case -1334697654:
        if (paramString.equals("i18n_zu_ZA"))
          return 114; 
      case -1335085101:
        if (paramString.equals("i18n_zh_TW"))
          return 113; 
      case -1335085485:
        if (paramString.equals("i18n_zh_HK"))
          return 112; 
      case -1335085637:
        if (paramString.equals("i18n_zh_CN"))
          return 111; 
      case -1337647167:
        if (paramString.equals("i18n_wo_SN"))
          return 110; 
      case -1338749341:
        if (paramString.equals("i18n_vi_VN"))
          return 109; 
      case -1339166434:
        if (paramString.equals("i18n_uz_UZ"))
          return 108; 
      case -1339404932:
        if (paramString.equals("i18n_ur_PK"))
          return 107; 
      case -1339613324:
        if (paramString.equals("i18n_uk_UA"))
          return 106; 
      case -1340328322:
        if (paramString.equals("i18n_tr_TR"))
          return 105; 
      case -1340507202:
        if (paramString.equals("i18n_tl_PH"))
          return 104; 
      case -1340536864:
        if (paramString.equals("i18n_tk_TM"))
          return 103; 
      case -1340626242:
        if (paramString.equals("i18n_th_TH"))
          return 102; 
      case -1340656031:
        if (paramString.equals("i18n_tg_TJ"))
          return 101; 
      case -1340715950:
        if (paramString.equals("i18n_te_IN"))
          return 100; 
      case -1340835114:
        if (paramString.equals("i18n_ta_IN"))
          return 99; 
      case -1341103180:
        if (paramString.equals("i18n_sw_KE"))
          return 98; 
      case -1341132723:
        if (paramString.equals("i18n_sv_SE"))
          return 97; 
      case -1341251904:
        if (paramString.equals("i18n_sr_RS"))
          return 96; 
      case -1341282229:
        if (paramString.equals("i18n_sq_AL"))
          return 95; 
      case -1341341250:
        if (paramString.equals("i18n_so_SO"))
          return 94; 
      case -1341370816:
        if (paramString.equals("i18n_sn_ZW"))
          return 93; 
      case -1341430629:
        if (paramString.equals("i18n_sl_SI"))
          return 92; 
      case -1341460418:
        if (paramString.equals("i18n_sk_SK"))
          return 91; 
      case -1341520217:
        if (paramString.equals("i18n_si_LK"))
          return 90; 
      case -1342086050:
        if (paramString.equals("i18n_ru_RU"))
          return 89; 
      case -1342264802:
        if (paramString.equals("i18n_ro_RO"))
          return 88; 
      case -1342860779:
        if (paramString.equals("i18n_qz_MM"))
          return 87; 
      case -1343962946:
        if (paramString.equals("i18n_pt_PT"))
          return 86; 
      case -1343963382:
        if (paramString.equals("i18n_pt_BR"))
          return 85; 
      case -1343993216:
        if (paramString.equals("i18n_ps_AF"))
          return 84; 
      case -1344201282:
        if (paramString.equals("i18n_pl_PL"))
          return 83; 
      case -1344529198:
        if (paramString.equals("i18n_pa_IN"))
          return 82; 
      case -1346048386:
        if (paramString.equals("i18n_nl_NL"))
          return 81; 
      case -1346256919:
        if (paramString.equals("i18n_ne_NP"))
          return 80; 
      case -1346346293:
        if (paramString.equals("i18n_nb_NO"))
          return 79; 
      case -1346584654:
        if (paramString.equals("i18n_my_MM"))
          return 78; 
      case -1346763388:
        if (paramString.equals("i18n_ms_MY"))
          return 77; 
      case -1346793314:
        if (paramString.equals("i18n_mr_IN"))
          return 76; 
      case -1346912354:
        if (paramString.equals("i18n_mn_MN"))
          return 75; 
      case -1346972060:
        if (paramString.equals("i18n_ml_IN"))
          return 74; 
      case -1347001730:
        if (paramString.equals("i18n_mk_MK"))
          return 73; 
      case -1347597570:
        if (paramString.equals("i18n_lv_LV"))
          return 72; 
      case -1347657154:
        if (paramString.equals("i18n_lt_LT"))
          return 71; 
      case -1347806128:
        if (paramString.equals("i18n_lo_LA"))
          return 70; 
      case -1348431764:
        if (paramString.equals("i18n_ky_KG"))
          return 69; 
      case -1348550638:
        if (paramString.equals("i18n_ku_TR"))
          return 68; 
      case -1348729663:
        if (paramString.equals("i18n_ko_KR"))
          return 67; 
      case -1348759520:
        if (paramString.equals("i18n_kn_IN"))
          return 66; 
      case -1348789255:
        if (paramString.equals("i18n_km_KH"))
          return 65; 
      case -1348848819:
        if (paramString.equals("i18n_kk_KZ"))
          return 64; 
      case -1349146874:
        if (paramString.equals("i18n_ka_GE"))
          return 63; 
      case -1349444723:
        if (paramString.equals("i18n_jv_ID"))
          return 62; 
      case -1350070291:
        if (paramString.equals("i18n_ja_JP"))
          return 61; 
      case -1350427810:
        if (paramString.equals("i18n_it_IT"))
          return 60; 
      case -1350457602:
        if (paramString.equals("i18n_is_IS"))
          return 59; 
      case -1350904482:
        if (paramString.equals("i18n_id_ID"))
          return 58; 
      case -1351202631:
        if (paramString.equals("i18n_hy_AM"))
          return 57; 
      case -1351321570:
        if (paramString.equals("i18n_hu_HU"))
          return 56; 
      case -1351410946:
        if (paramString.equals("i18n_hr_HR"))
          return 55; 
      case -1351679038:
        if (paramString.equals("i18n_hi_IN"))
          return 54; 
      case -1351798204:
        if (paramString.equals("i18n_he_IL"))
          return 53; 
      case -1352245067:
        if (paramString.equals("i18n_gu_IN"))
          return 52; 
      case -1353258050:
        if (paramString.equals("i18n_fr_FR"))
          return 51; 
      case -1353526178:
        if (paramString.equals("i18n_fi_FI"))
          return 50; 
      case -1353734661:
        if (paramString.equals("i18n_fb_HA"))
          return 49; 
      case -1353764404:
        if (paramString.equals("i18n_fa_IR"))
          return 48; 
      case -1354122033:
        if (paramString.equals("i18n_et_EE"))
          return 47; 
      case -1354151611:
        if (paramString.equals("i18n_es_LA"))
          return 46; 
      case -1354151810:
        if (paramString.equals("i18n_es_ES"))
          return 45; 
      case -1354300720:
        if (paramString.equals("i18n_en_GB"))
          return 44; 
      case -1354360286:
        if (paramString.equals("i18n_el_GR"))
          return 43; 
      case -1355492450:
        if (paramString.equals("i18n_de_DE"))
          return 42; 
      case -1355611608:
        if (paramString.equals("i18n_da_DK"))
          return 41; 
      case -1355998907:
        if (paramString.equals("i18n_cs_CZ"))
          return 40; 
      case -1356505177:
        if (paramString.equals("i18n_cb_IQ"))
          return 39; 
      case -1356535090:
        if (paramString.equals("i18n_ca_ES"))
          return 38; 
      case -1356922484:
        if (paramString.equals("i18n_bs_BA"))
          return 37; 
      case -1357071209:
        if (paramString.equals("i18n_bn_IN"))
          return 36; 
      case -1357279970:
        if (paramString.equals("i18n_bg_BG"))
          return 35; 
      case -1357339534:
        if (paramString.equals("i18n_be_BY"))
          return 34; 
      case -1357637474:
        if (paramString.equals("i18n_az_AZ"))
          return 33; 
      case -1357845775:
        if (paramString.equals("i18n_as_IN"))
          return 32; 
      case -1357875810:
        if (paramString.equals("i18n_ar_AR"))
          return 31; 
      case -1358232544:
        if (paramString.equals("i18n_af_ZA"))
          return 30; 
      case -1438816020:
        if (paramString.equals("s_papayaanalyticstorch_papayatorch_torchedlooper"))
          return 139; 
      case -1443103381:
        if (paramString.equals("smarttrim"))
          return 147; 
      case -1512835713:
        if (paramString.equals("s_papayaanalyticstorch_papayatorch"))
          return 138; 
      case -1574297951:
        return !paramString.equals("baseline_profiles_9_11") ? -1 : b;
      case -2073469748:
        if (paramString.equals("longtail"))
          return 120; 
      case -1651711629:
        if (paramString.equals("s_papayatorch_torchedlooper"))
          return 140; 
      case -1693217774:
        if (paramString.equals("papayatorch"))
          return 129; 
      case -1753153382:
        if (paramString.equals("mlplayground"))
          return 123; 
      case -1827883650:
        if (paramString.equals("testmodule"))
          return 150; 
      case -1961913756:
        if (paramString.equals("mobileconfig"))
          return 124; 
      case -1975373111:
        break;
    } 
    if (paramString.equals("s_arservicesoptional_slam"))
      return 134; 
  }
  
  public static Integer A01(String paramString) {
    switch (A00(paramString)) {
      default:
        0pd.A0H("VoltronModuleMetadata", 0XK.A0b("Unexpected module name: ", paramString));
        return 0Xy.A00;
      case 0:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
      case 8:
      case 9:
      case 10:
      case 11:
      case 12:
      case 13:
      case 14:
      case 15:
      case 16:
      case 17:
      case 18:
      case 19:
      case 20:
      case 21:
      case 22:
      case 23:
      case 24:
      case 25:
      case 26:
      case 27:
      case 28:
      case 29:
      case 30:
      case 31:
      case 32:
      case 33:
      case 34:
      case 35:
      case 36:
      case 37:
      case 38:
      case 39:
      case 40:
      case 41:
      case 42:
      case 43:
      case 44:
      case 45:
      case 46:
      case 47:
      case 48:
      case 49:
      case 50:
      case 51:
      case 52:
      case 53:
      case 54:
      case 55:
      case 56:
      case 57:
      case 58:
      case 59:
      case 60:
      case 61:
      case 62:
      case 63:
      case 64:
      case 65:
      case 66:
      case 67:
      case 68:
      case 69:
      case 70:
      case 71:
      case 72:
      case 73:
      case 74:
      case 75:
      case 76:
      case 77:
      case 78:
      case 79:
      case 80:
      case 81:
      case 82:
      case 83:
      case 84:
      case 85:
      case 86:
      case 87:
      case 88:
      case 89:
      case 90:
      case 91:
      case 92:
      case 93:
      case 94:
      case 95:
      case 96:
      case 97:
      case 98:
      case 99:
      case 100:
      case 101:
      case 102:
      case 103:
      case 104:
      case 105:
      case 106:
      case 107:
      case 108:
      case 109:
      case 110:
      case 111:
      case 112:
      case 113:
      case 114:
      case 115:
      case 116:
      case 117:
      case 118:
      case 119:
      case 121:
      case 122:
      case 123:
      case 124:
      case 126:
      case 127:
      case 128:
      case 129:
      case 130:
      case 131:
      case 132:
      case 134:
      case 135:
      case 136:
      case 137:
      case 138:
      case 139:
      case 140:
      case 141:
      case 142:
      case 143:
      case 144:
      case 145:
      case 146:
      case 147:
      case 148:
      case 149:
      case 150:
      case 151:
        return 0Xy.A0N;
      case 125:
      case 133:
        return 0Xy.A01;
      case 120:
        break;
    } 
    return 0Xy.A0C;
  }
  
  public static String A02(Integer paramInteger) {
    switch (paramInteger.intValue()) {
      default:
        return null;
      case 1456215507:
        return getModuleName(25);
      case 141525831:
        return getModuleName(21);
      case -1047771569:
      case -205302911:
      case 295886682:
      case 451207149:
      case 726599949:
      case 993907953:
      case 1595850074:
      case 1925773830:
        return getModuleName(0);
      case -1103660227:
      case 936991273:
        return getModuleName(24);
      case -1147517067:
      case -129824487:
      case 109840480:
        return getModuleName(22);
      case -1239886098:
      case 388345256:
      case 461244426:
      case 529200072:
      case 1732706226:
        return getModuleName(16);
      case -1751828659:
      case 119328291:
        return getModuleName(1);
      case 1373498909:
      case 1525631193:
      case 1916841882:
      case -2001674842:
      case -1333088673:
      case -834749744:
      case 331996240:
      case 807956999:
        break;
    } 
    return getModuleName(17);
  }
  
  public static String A03(Integer paramInteger) {
    switch (paramInteger.intValue()) {
      default:
        return null;
      case 1228848869:
      case 1235572889:
      case -1275171621:
        return getModuleName(25);
      case -2068242779:
      case -1596659821:
      case -1557459227:
      case -1515369013:
      case -1201852614:
      case -652252511:
      case -559531710:
      case -558292956:
      case -116934526:
      case 26976023:
      case 55926273:
      case 226130352:
      case 412242460:
      case 468334453:
      case 676073163:
      case 712911081:
      case 819930967:
      case 1041504643:
      case 1251978660:
      case 1271092635:
      case 1398387912:
      case 1404597608:
      case 1485464333:
      case 1555498398:
      case 1571432791:
      case 1673195678:
      case 1867436643:
        break;
    } 
    return getModuleName(26);
  }
  
  public static String A04(Integer paramInteger) {
    switch (paramInteger.intValue()) {
      default:
        return null;
      case 589081589:
      case 1878811263:
      case -1886006371:
        return getModuleName(116);
      case 1774652639:
      case 1976127464:
      case 2146672817:
      case -2114369943:
      case -1987168584:
      case -1940435673:
      case -1710790540:
      case -1371279153:
      case -1241618728:
      case -1061315661:
      case -1013313180:
      case -762077863:
      case -656301094:
      case -520893478:
      case -503289818:
      case -502902628:
      case -88957530:
      case -35516254:
      case -9026858:
      case 148772989:
      case 192907524:
      case 274050584:
      case 740097762:
      case 874937347:
      case 1309625251:
      case 1407275952:
      case 1495667363:
        break;
    } 
    return getModuleName(29);
  }
  
  public static String A05(Integer paramInteger) {
    switch (paramInteger.intValue()) {
      default:
        return null;
      case -1949136376:
      case -1310775569:
      case -933470354:
      case -360322526:
      case -187524139:
      case 196521900:
      case 383091170:
      case 933313084:
      case 1277412263:
      case 2082222854:
        return getModuleName(117);
      case 1066016148:
      case 1446063310:
      case 2067085737:
      case -2108690480:
      case -1657835623:
      case -1628774082:
      case -1622548446:
      case -1525951315:
      case -930049891:
      case -856575393:
      case -802479007:
      case -638177430:
      case -586623500:
      case -523400740:
      case -167293941:
      case 125838372:
      case 191620173:
      case 255694957:
      case 478524400:
      case 552670032:
        break;
    } 
    return getModuleName(116);
  }
  
  public static String A06(Integer paramInteger) {
    switch (paramInteger.intValue()) {
      default:
        return null;
      case -2135724975:
      case -2103682411:
      case -1842104928:
      case -1780617188:
      case -1691702792:
      case -1690908854:
      case -1452891706:
      case -1340089978:
      case -1200206245:
      case -1054442633:
      case -952830860:
      case -921792342:
      case -845676658:
      case -737557871:
      case -415046603:
      case -392664499:
      case -274290368:
      case -266173261:
      case 38462381:
      case 38462434:
      case 38465447:
      case 90785995:
      case 308890436:
      case 562669711:
      case 869952905:
      case 1367662739:
      case 1456397522:
      case 1604327652:
      case 1738346345:
      case 2110698055:
        break;
    } 
    return getModuleName(117);
  }
  
  public static String A07(Integer paramInteger) {
    switch (paramInteger.intValue()) {
      default:
        return null;
      case -2041007763:
      case -2000833195:
      case -1960291365:
      case -1719412836:
      case -1676935988:
      case -1663692505:
      case -1022434378:
      case -801848751:
      case -621007013:
      case -617110055:
      case -584430345:
      case -497494522:
      case -432236517:
      case -416345989:
      case -413859679:
      case -304559564:
      case -118163421:
      case 38473758:
      case 38478892:
      case 59977478:
      case 223912394:
      case 404719683:
      case 482652125:
      case 665517467:
      case 676152958:
      case 1192935226:
      case 1250165200:
      case 1541488000:
      case 1779557801:
      case 1785245457:
        break;
    } 
    return getModuleName(117);
  }
  
  public static String A08(Integer paramInteger) {
    switch (paramInteger.intValue()) {
      default:
        return null;
      case -2032956884:
      case -1912120175:
      case -1506353129:
      case -981624017:
      case -932057170:
      case -918138275:
      case -881847365:
      case -864014017:
      case -698393365:
      case -542885822:
      case 378214423:
      case 489066202:
      case 566385439:
      case 577929639:
      case 586139606:
      case 619263901:
      case 1122444326:
      case 1192954333:
      case 1258774236:
      case 1330044453:
      case 1348677736:
      case 1418771590:
      case 1425663524:
      case 1562010396:
      case 1591767338:
      case 1652370904:
      case 1705912224:
      case 1785714900:
      case 1960359020:
      case 2076682051:
        break;
    } 
    return getModuleName(117);
  }
  
  public static String A09(Integer paramInteger) {
    switch (paramInteger.intValue()) {
      default:
        return null;
      case -1992580159:
      case -1822919446:
      case -1822914668:
      case -1822906189:
      case -1822898672:
      case -1791611172:
      case -1245175103:
      case -675780412:
      case -454145875:
      case -162928238:
      case -106029319:
      case 54513241:
      case 54877243:
      case 668754930:
      case 772480731:
      case 987865228:
      case 1124218635:
      case 1610135773:
      case 1777796116:
      case 1922775500:
        return getModuleName(117);
      case 1412651995:
      case 1918450743:
      case -2110121831:
      case -2023824757:
      case -1702292193:
      case -1675532472:
      case -1653027493:
      case -489049760:
      case -433423116:
      case -162248990:
        break;
    } 
    return getModuleName(118);
  }
  
  public static String A0A(Integer paramInteger) {
    switch (paramInteger.intValue()) {
      default:
        return null;
      case -2097555899:
      case -1897332328:
      case -1667034445:
      case -1215476019:
      case -1124125701:
      case -1072542278:
      case -1063501286:
      case -1007212386:
      case -967639551:
      case -831808964:
      case -817249184:
      case -752613313:
      case -725173034:
      case -661223889:
      case -457740142:
      case -123570646:
      case 9451995:
      case 106485324:
      case 323575093:
      case 426740066:
      case 643710101:
      case 767850002:
      case 882693345:
      case 900880992:
      case 907860409:
      case 1052338222:
      case 1068553170:
      case 1083668102:
      case 1325013665:
      case 2040357178:
        break;
    } 
    return getModuleName(118);
  }
  
  public static String A0B(Integer paramInteger) {
    switch (paramInteger.intValue()) {
      default:
        return null;
      case -1788561583:
      case -1734949806:
      case -1603460824:
      case -1583037918:
      case -1474344082:
      case -1459682376:
      case -1218810227:
      case -1114469537:
      case -984543523:
      case -882156754:
      case -704597673:
      case -630731224:
      case -424124092:
      case -174096421:
      case -37636271:
      case 79371139:
      case 111736414:
      case 313489114:
      case 367208661:
      case 556282474:
      case 583764076:
      case 681884373:
      case 746523702:
      case 871437607:
      case 1160659956:
      case 1449080113:
      case 1624059719:
      case 1853078193:
      case 1940276420:
      case 1980399466:
        break;
    } 
    return getModuleName(118);
  }
  
  public static String A0C(Integer paramInteger) {
    switch (paramInteger.intValue()) {
      default:
        return null;
      case 1687194289:
      case 1917632496:
      case -2104452996:
      case -1551891037:
      case -1361772815:
      case -1060096996:
      case -715315625:
      case -590008717:
      case -322892872:
      case -129522069:
        return getModuleName(119);
      case 430298942:
      case 456601043:
      case 1009860869:
      case 1444649983:
      case 1727391659:
      case 1872731677:
      case 1885697199:
      case 1931273879:
      case 2102653622:
      case -2126519388:
      case -1802227498:
      case -1601381298:
      case -1345891856:
      case -1096442267:
      case -959989054:
      case -379024858:
      case -321349389:
      case 200230338:
      case 430309660:
      case 955923133:
        break;
    } 
    return getModuleName(121);
  }
  
  public static String A0D(Integer paramInteger) {
    switch (paramInteger.intValue()) {
      default:
        return null;
      case -344155573:
      case -182321426:
        return getModuleName(121);
      case 810121669:
      case 1216567121:
      case 1216568200:
      case 1668135061:
      case 1734451891:
      case 2102948513:
      case -1889650801:
      case -1404608118:
      case -1269484458:
      case -942047537:
      case -336589418:
      case 34466915:
        return getModuleName(122);
      case 1212116617:
      case -1915636592:
      case -1705126217:
      case -1350829852:
      case -689597956:
      case -114889949:
      case 362445129:
      case 373874044:
      case 591152038:
      case 806928419:
      case 945448403:
      case 1374430592:
      case 1574433048:
      case 1576933140:
      case 1842882507:
      case 1903522166:
        break;
    } 
    return getModuleName(123);
  }
  
  public static String A0E(Integer paramInteger) {
    switch (paramInteger.intValue()) {
      default:
        return null;
      case -2072873194:
      case -1702663437:
      case -1471079564:
      case -1471075711:
      case -1307701722:
      case -1153208559:
      case -1133073648:
      case -886808460:
      case -860101840:
      case -773073082:
      case -539979252:
      case -326534600:
      case -90342387:
      case -76272683:
      case 93738939:
      case 129434616:
      case 214530655:
      case 319983618:
      case 381003443:
      case 741568174:
      case 981228400:
      case 1220547833:
      case 1344557115:
      case 1554564925:
      case 1579578328:
      case 1722982047:
      case 1754872348:
      case 1756334246:
      case 1810851551:
      case 1927643365:
        break;
    } 
    return getModuleName(26);
  }
  
  public static String A0F(Integer paramInteger) {
    switch (paramInteger.intValue()) {
      default:
        return null;
      case 1914989306:
        return getModuleName(124);
      case -903104227:
      case -818854280:
      case -125618587:
        return getModuleName(123);
      case -1893098205:
      case -1430181014:
      case -1050395438:
      case -652499506:
      case -639911363:
      case -443345149:
      case -442434547:
      case -236758974:
      case -46949663:
      case 21125565:
      case 22776011:
      case 69111695:
      case 167556983:
      case 310737536:
      case 349789787:
      case 414425109:
      case 459859149:
      case 607124453:
      case 832872155:
      case 923977286:
      case 1082468350:
      case 1261034995:
      case 1322972521:
      case 1443302277:
      case 1620530212:
      case 1745819741:
        break;
    } 
    return getModuleName(126);
  }
  
  public static String A0G(Integer paramInteger) {
    switch (paramInteger.intValue()) {
      default:
        return null;
      case -1721697420:
      case -1624392229:
      case -1501801509:
      case -1499300372:
      case -1448568242:
      case -1295007731:
      case -1148047346:
      case -837397295:
      case -742301495:
      case -740519620:
      case -495441792:
      case -77550444:
      case 73602367:
      case 110242201:
      case 308849024:
      case 897941849:
      case 1150522038:
      case 1241583741:
      case 1359010689:
      case 1372339238:
      case 1482095598:
      case 1537521314:
      case 1661188637:
      case 1679648348:
      case 1707519628:
      case 1708900222:
      case 1963936719:
      case 2024846604:
      case 2035041344:
      case 2100813436:
        break;
    } 
    return getModuleName(126);
  }
  
  public static String A0H(Integer paramInteger) {
    switch (paramInteger.intValue()) {
      default:
        return null;
      case 993950101:
        return getModuleName(147);
      case 63808471:
      case 1384163290:
        return getModuleName(148);
      case -570868276:
      case 148204723:
      case 295045877:
      case 628910959:
      case 987862385:
      case 1890024677:
        return getModuleName(126);
      case -1953810680:
      case -374207504:
      case -374037158:
      case -362951093:
        return getModuleName(143);
      case 679670625:
      case 853417284:
      case 1184420069:
      case -2066791365:
      case -1676525346:
      case -1485780288:
      case -1092928044:
      case -923640963:
      case -773151446:
      case -530909468:
      case -519655477:
      case -432989065:
      case 37958441:
      case 139570136:
      case 143343063:
      case 1107874802:
      case 1161738239:
        break;
    } 
    return getModuleName(135);
  }
  
  public static String A0I(Integer paramInteger) {
    switch (paramInteger.intValue()) {
      default:
        return null;
      case -2061207957:
      case -1811361297:
      case -1115967016:
      case -934774126:
      case -830143166:
      case -627734778:
      case -550099025:
      case -548631527:
      case -291627402:
      case -76884602:
      case 35601400:
      case 88865964:
      case 95200516:
      case 533365858:
      case 536836592:
      case 649055699:
      case 651016594:
      case 686770933:
      case 712021327:
      case 828749677:
      case 887233481:
      case 897379441:
      case 942287064:
      case 1015257280:
      case 1270247422:
      case 1438079571:
      case 1497082991:
      case 1674277281:
      case 1743005117:
      case 2015062389:
        break;
    } 
    return getModuleName(148);
  }
  
  public static String A0J(Integer paramInteger) {
    switch (paramInteger.intValue()) {
      default:
        return null;
      case 349840360:
        return getModuleName(151);
      case -1504281732:
        return getModuleName(149);
      case 1156756210:
      case 1675963310:
      case 1893668477:
      case 2047641437:
      case -1737308571:
      case -1508758976:
      case -1497644808:
      case -1225215216:
      case -1223374112:
      case -1185822025:
      case -1127099298:
      case -393773872:
      case -107546400:
      case 34452813:
      case 288498321:
      case 510502303:
      case 695299328:
      case 864146885:
      case 900206162:
      case 900219554:
        break;
    } 
    return getModuleName(148);
  }
  
  public static String A0K(Integer paramInteger) {
    switch (paramInteger.intValue()) {
      default:
        return null;
      case -1960259932:
      case -1841995405:
      case -1664537770:
      case -1316992041:
      case -1017117942:
      case -830282062:
      case -716207734:
      case -712489818:
      case -238824480:
      case -232011809:
      case -37732852:
      case 233681021:
      case 403771323:
      case 453834038:
      case 500689064:
      case 853475039:
      case 872440530:
      case 883883516:
      case 1001076726:
      case 1029701021:
      case 1085054225:
      case 1124536800:
      case 1399442070:
      case 1475239494:
      case 1621720333:
      case 1684710168:
      case 1809074708:
      case 1873422432:
      case 2034360106:
      case 2043722468:
        break;
    } 
    return getModuleName(26);
  }
  
  public static String A0L(Integer paramInteger) {
    switch (paramInteger.intValue()) {
      default:
        return null;
      case -2102912685:
      case -2069280260:
      case -1914783335:
      case -1803181326:
      case -1624086786:
      case -1624067679:
      case -1494888174:
      case -1271948484:
      case -1008779015:
      case -798937809:
      case -675213988:
      case -397949249:
      case -7186944:
      case 78691834:
      case 101418376:
      case 119296199:
      case 161479380:
      case 176889304:
      case 268814653:
      case 507657647:
      case 612290698:
      case 857194858:
      case 1132852720:
      case 1345665535:
      case 1390920280:
      case 1598066020:
      case 1630647609:
      case 1639812266:
      case 1728411265:
      case 1810992326:
        break;
    } 
    return getModuleName(26);
  }
  
  public static String A0M(Integer paramInteger) {
    switch (paramInteger.intValue()) {
      default:
        return null;
      case -1450311858:
      case -1158165492:
      case -798852361:
      case -746038288:
      case -486512144:
      case -387045354:
      case -236858760:
      case -218880891:
      case -188732971:
      case -123847643:
      case 16774393:
      case 292415607:
      case 395480439:
      case 449540893:
      case 875109635:
      case 962203152:
      case 989719920:
      case 1020096025:
      case 1047785284:
      case 1174133061:
      case 1250055873:
      case 1262703206:
      case 1285472700:
      case 1315067806:
      case 1485505061:
      case 1488249323:
      case 1515417947:
      case 1559599160:
      case 1643896520:
      case 1924704746:
        break;
    } 
    return getModuleName(26);
  }
  
  public static String A0N(Integer paramInteger) {
    switch (paramInteger.intValue()) {
      default:
        return null;
      case -2010580316:
      case -1983376412:
      case -1980403995:
      case -1781338577:
      case -1670678645:
      case -1547713518:
      case -1398816591:
      case -1302910532:
      case -1287620586:
      case -1091198161:
      case -790213969:
      case -775698753:
      case -667521252:
      case -591215826:
      case -567837177:
      case -412266836:
      case 3775329:
      case 3782458:
      case 260850632:
      case 302356686:
      case 366122551:
      case 415764038:
      case 1028626876:
      case 1126656291:
      case 1193137347:
      case 1328786967:
      case 1361382763:
      case 1723316975:
      case 1883099606:
      case 1989215725:
        break;
    } 
    return getModuleName(26);
  }
  
  public static String A0O(Integer paramInteger) {
    switch (paramInteger.intValue()) {
      default:
        return null;
      case -2104039768:
      case -2103568842:
      case -2027139251:
      case -1947253767:
      case -1720079379:
      case -1552187669:
      case -1406093974:
      case -1291757007:
      case -838481876:
      case -775692273:
      case -552135491:
      case -444731865:
      case -428502127:
      case -337257767:
      case -329183162:
      case -315292005:
      case -161309455:
      case 328250605:
      case 342265708:
      case 433030206:
      case 450219800:
      case 854681043:
      case 971721048:
      case 1082779443:
      case 1126800854:
      case 1726350848:
      case 1757978892:
      case 1760300897:
      case 1825587767:
      case 1917931528:
        break;
    } 
    return getModuleName(26);
  }
  
  public static String A0P(Integer paramInteger) {
    switch (paramInteger.intValue()) {
      default:
        return null;
      case -1730742903:
      case -1599907456:
      case -1522337427:
      case -1201219225:
      case -1029124455:
      case -934265904:
      case -839316844:
      case -788350935:
      case -775685151:
      case -504797776:
      case -223623184:
      case 52026205:
      case 52566457:
      case 52610190:
      case 113525218:
      case 216678008:
      case 376656047:
      case 391327530:
      case 1046193280:
      case 1383485855:
      case 1410064665:
      case 1433954486:
      case 1447543330:
      case 1623379930:
      case 1782572361:
      case 1890554993:
      case 1890939555:
      case 1922583106:
      case 1937602724:
      case 2056596088:
        break;
    } 
    return getModuleName(26);
  }
  
  public static String A0Q(Integer paramInteger) {
    switch (paramInteger.intValue()) {
      default:
        return null;
      case -1801853103:
      case -1793723759:
      case -1463175106:
      case 142696140:
        return getModuleName(26);
      case 833400952:
      case 1250891477:
      case 1304199947:
      case 1669336321:
      case 1692088456:
      case 1791387958:
      case -1872763672:
      case -1832189824:
      case -1790588549:
      case -1706525235:
      case -1676528654:
      case -1676521679:
      case -1580553890:
      case -1529798032:
      case -1394678316:
      case -1326580337:
      case -1244257186:
      case -1227392280:
      case -1206974810:
      case -603545851:
      case -255343741:
      case -205236138:
      case 140052206:
      case 322650789:
      case 361040306:
      case 563283667:
        break;
    } 
    return getModuleName(29);
  }
  
  public static String A0R(String paramString) {
    String str1;
    String str2 = VoltronModuleMetadataHelper.getPackageNameForClass(paramString);
    boolean bool = "X".equals(str2);
    int i = -1;
    if (bool) {
      i = VoltronModuleMetadataHelper.getModuleRangeIndexForRedexClassName(paramString, APP_MODULE_RANGES);
      return (i == -1) ? null : getModuleName(APP_MODULE_INDICES[i]);
    } 
    paramString = VoltronModuleMetadataHelper.getShortNameForClass(paramString, str2);
    str2.hashCode();
    switch (str2.hashCode()) {
      default:
        switch (i) {
          default:
            str1 = A02(Integer.valueOf(str2.hashCode()));
            paramString = str1;
            if (str1 == null)
              paramString = A03(Integer.valueOf(str2.hashCode())); 
            str1 = paramString;
            if (paramString == null)
              str1 = A0E(Integer.valueOf(str2.hashCode())); 
            paramString = str1;
            if (str1 == null)
              paramString = A0K(Integer.valueOf(str2.hashCode())); 
            str1 = paramString;
            if (paramString == null)
              str1 = A0L(Integer.valueOf(str2.hashCode())); 
            paramString = str1;
            if (str1 == null)
              paramString = A0M(Integer.valueOf(str2.hashCode())); 
            str1 = paramString;
            if (paramString == null)
              str1 = A0N(Integer.valueOf(str2.hashCode())); 
            paramString = str1;
            if (str1 == null)
              paramString = A0O(Integer.valueOf(str2.hashCode())); 
            str1 = paramString;
            if (paramString == null)
              str1 = A0P(Integer.valueOf(str2.hashCode())); 
            paramString = str1;
            if (str1 == null)
              paramString = A0Q(Integer.valueOf(str2.hashCode())); 
            str1 = paramString;
            if (paramString == null)
              str1 = A04(Integer.valueOf(str2.hashCode())); 
            paramString = str1;
            if (str1 == null)
              paramString = A05(Integer.valueOf(str2.hashCode())); 
            str1 = paramString;
            if (paramString == null)
              str1 = A06(Integer.valueOf(str2.hashCode())); 
            paramString = str1;
            if (str1 == null)
              paramString = A07(Integer.valueOf(str2.hashCode())); 
            str1 = paramString;
            if (paramString == null)
              str1 = A08(Integer.valueOf(str2.hashCode())); 
            paramString = str1;
            if (str1 == null)
              paramString = A09(Integer.valueOf(str2.hashCode())); 
            str1 = paramString;
            if (paramString == null)
              str1 = A0A(Integer.valueOf(str2.hashCode())); 
            paramString = str1;
            if (str1 == null)
              paramString = A0B(Integer.valueOf(str2.hashCode())); 
            str1 = paramString;
            if (paramString == null)
              str1 = A0C(Integer.valueOf(str2.hashCode())); 
            paramString = str1;
            if (str1 == null)
              paramString = A0D(Integer.valueOf(str2.hashCode())); 
            str1 = paramString;
            if (paramString == null)
              str1 = A0F(Integer.valueOf(str2.hashCode())); 
            paramString = str1;
            if (str1 == null)
              paramString = A0G(Integer.valueOf(str2.hashCode())); 
            str1 = paramString;
            if (paramString == null)
              str1 = A0H(Integer.valueOf(str2.hashCode())); 
            paramString = str1;
            if (str1 == null)
              paramString = A0I(Integer.valueOf(str2.hashCode())); 
            str1 = paramString;
            if (paramString == null)
              str1 = A0J(Integer.valueOf(str2.hashCode())); 
            return str1;
          case 19:
            return A0W(paramString);
          case 18:
            return A0d(paramString);
          case 17:
            return A0b(paramString);
          case 16:
            return A0T(paramString);
          case 15:
            return A0h(paramString);
          case 14:
            return A0l(paramString);
          case 13:
            return A0f(paramString);
          case 12:
            return A0Y(paramString);
          case 11:
            return A0U(paramString);
          case 10:
            return A0S(paramString);
          case 9:
            return A0V(paramString);
          case 8:
            return A0Z(paramString);
          case 7:
            return A0a(paramString);
          case 6:
            return A0j(paramString);
          case 5:
            return A0X(paramString);
          case 4:
            return A0e(paramString);
          case 3:
            return A0i(paramString);
          case 2:
            return A0c(paramString);
          case 1:
            return A0k(paramString);
          case 0:
            break;
        } 
        return A0g(paramString);
      case 1904255720:
        if (str2.equals("com.facebook.analytics.structuredlogger.enums"))
          i = 19; 
      case 1028569746:
        if (str2.equals("com.facebook.fbreact.specs"))
          i = 18; 
      case 655543158:
        if (str2.equals("com.facebook.cvat.ctsmartcreation.ctsmarttrim"))
          i = 17; 
      case 583470293:
        if (str2.equals("com.facebook.ads"))
          i = 16; 
      case 555781212:
        if (str2.equals("com.google.android.exoplayer2"))
          i = 15; 
      case 269970647:
        if (str2.equals("org.webrtc"))
          i = 14; 
      case 85254915:
        if (str2.equals("com.facebook.mobileconfig.ui"))
          i = 13; 
      case 43059476:
        if (str2.equals("com.facebook.analytics.structuredlogger.structs"))
          i = 12; 
      case 38470116:
        if (str2.equals("com.facebook.ads.internal.ipc"))
          i = 11; 
      case 0:
        if (str2.equals(""))
          i = 10; 
      case -124441812:
        if (str2.equals("com.facebook.analytics.legacy"))
          i = 9; 
      case -256178819:
        if (str2.equals("com.facebook.browser.helium.util"))
          i = 8; 
      case -381156179:
        if (str2.equals("com.facebook.cameracore.mediapipeline.dataproviders.worldtracker.implementation"))
          i = 7; 
      case -455200350:
        if (str2.equals("com.instagram.common.bloks.actions"))
          i = 6; 
      case -1090702205:
        if (str2.equals("com.facebook.analytics.structuredlogger.events"))
          i = 5; 
      case -1138107259:
        if (str2.equals("com.facebook.hermes.reactexecutor"))
          i = 4; 
      case -1557009646:
        if (str2.equals("com.google.android.exoplayer2.extractor"))
          i = 3; 
      case -1560459364:
        if (str2.equals("com.facebook.fbreact.fbreactlinks"))
          i = 2; 
      case -1661979092:
        if (str2.equals("com.instagram.common.bloks.screens"))
          i = 1; 
      case -1910045719:
        break;
    } 
    if (!str2.equals("com.facebook.redex"));
    i = 0;
  }
  
  public static String A0S(String paramString) {
    paramString.hashCode();
    int i = paramString.hashCode();
    byte b = -1;
    switch (i) {
      default:
        switch (b) {
          default:
            return null;
          case 90:
            return getModuleName(114);
          case 89:
            return getModuleName(113);
          case 88:
            return getModuleName(112);
          case 87:
            return getModuleName(111);
          case 86:
            return getModuleName(110);
          case 85:
            return getModuleName(109);
          case 84:
            return getModuleName(108);
          case 83:
            return getModuleName(107);
          case 82:
            return getModuleName(106);
          case 81:
            return getModuleName(105);
          case 80:
            return getModuleName(104);
          case 79:
            return getModuleName(103);
          case 78:
            return getModuleName(102);
          case 77:
            return getModuleName(101);
          case 76:
            return getModuleName(100);
          case 75:
            return getModuleName(99);
          case 74:
            return getModuleName(98);
          case 73:
            return getModuleName(97);
          case 72:
            return getModuleName(96);
          case 71:
            return getModuleName(95);
          case 70:
            return getModuleName(94);
          case 69:
            return getModuleName(93);
          case 68:
            return getModuleName(92);
          case 67:
            return getModuleName(91);
          case 66:
            return getModuleName(90);
          case 65:
            return getModuleName(89);
          case 64:
            return getModuleName(88);
          case 63:
            return getModuleName(87);
          case 62:
            return getModuleName(86);
          case 61:
            return getModuleName(85);
          case 60:
            return getModuleName(84);
          case 59:
            return getModuleName(83);
          case 58:
            return getModuleName(82);
          case 57:
            return getModuleName(81);
          case 56:
            return getModuleName(80);
          case 55:
            return getModuleName(79);
          case 54:
            return getModuleName(78);
          case 53:
            return getModuleName(77);
          case 52:
            return getModuleName(76);
          case 51:
            return getModuleName(75);
          case 50:
            return getModuleName(74);
          case 49:
            return getModuleName(73);
          case 48:
            return getModuleName(72);
          case 47:
            return getModuleName(71);
          case 46:
            return getModuleName(70);
          case 45:
            return getModuleName(69);
          case 44:
            return getModuleName(68);
          case 43:
            return getModuleName(67);
          case 42:
            return getModuleName(66);
          case 41:
            return getModuleName(65);
          case 40:
            return getModuleName(64);
          case 39:
            return getModuleName(63);
          case 38:
            return getModuleName(62);
          case 37:
            return getModuleName(61);
          case 36:
            return getModuleName(60);
          case 35:
            return getModuleName(59);
          case 34:
            return getModuleName(58);
          case 33:
            return getModuleName(57);
          case 32:
            return getModuleName(56);
          case 31:
            return getModuleName(55);
          case 30:
            return getModuleName(54);
          case 29:
            return getModuleName(53);
          case 28:
            return getModuleName(52);
          case 27:
            return getModuleName(51);
          case 26:
            return getModuleName(50);
          case 25:
            return getModuleName(49);
          case 24:
            return getModuleName(48);
          case 23:
            return getModuleName(47);
          case 22:
            return getModuleName(46);
          case 21:
            return getModuleName(45);
          case 20:
            return getModuleName(44);
          case 19:
            return getModuleName(43);
          case 18:
            return getModuleName(42);
          case 17:
            return getModuleName(41);
          case 16:
            return getModuleName(40);
          case 15:
            return getModuleName(39);
          case 14:
            return getModuleName(38);
          case 13:
            return getModuleName(37);
          case 12:
            return getModuleName(36);
          case 11:
            return getModuleName(35);
          case 10:
            return getModuleName(34);
          case 9:
            return getModuleName(33);
          case 8:
            return getModuleName(32);
          case 7:
            return getModuleName(31);
          case 6:
            return getModuleName(30);
          case 2:
          case 92:
          case 93:
            return getModuleName(26);
          case 1:
          case 3:
          case 4:
          case 5:
          case 91:
          case 94:
            return getModuleName(117);
          case 0:
            break;
        } 
        return getModuleName(124);
      case 2129759024:
        if (paramString.equals("X.Xf2"))
          b = 94; 
      case 737924575:
        if (paramString.equals("X.X85"))
          b = 93; 
      case 72618:
        if (paramString.equals("J.N"))
          b = 92; 
      case -123498407:
        if (paramString.equals("X.Xez"))
          b = 91; 
      case -196387178:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nZuZa"))
          b = 90; 
      case -196399835:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nZhTw"))
          b = 89; 
      case -196400219:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nZhHk"))
          b = 88; 
      case -196400371:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nZhCn"))
          b = 87; 
      case -196482521:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nWoSn"))
          b = 86; 
      case -196517985:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nViVn"))
          b = 85; 
      case -196531458:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nUzUz"))
          b = 84; 
      case -196539316:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nUrPk"))
          b = 83; 
      case -196545898:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nUkUa"))
          b = 82; 
      case -196568976:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nTrTr"))
          b = 81; 
      case -196574876:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nTlPh"))
          b = 80; 
      case -196575708:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nTkTm"))
          b = 79; 
      case -196578596:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nThTh"))
          b = 78; 
      case -196579555:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nTgTj"))
          b = 77; 
      case -196581814:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nTeIn"))
          b = 76; 
      case -196585658:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nTaIn"))
          b = 75; 
      case -196594254:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nSwKe"))
          b = 74; 
      case -196594967:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nSvSe"))
          b = 73; 
      case -196598828:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nSrRs"))
          b = 72; 
      case -196600323:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nSqAl"))
          b = 71; 
      case -196601684:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nSoSo"))
          b = 70; 
      case -196602420:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nSnZw"))
          b = 69; 
      case -196604573:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nSlSi"))
          b = 68; 
      case -196605532:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nSkSk"))
          b = 67; 
      case -196607671:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nSiLk"))
          b = 66; 
      case -196625734:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nRuRu"))
          b = 65; 
      case -196631506:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nRoRo"))
          b = 64; 
      case -196650883:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nQzMm"))
          b = 63; 
      case -196686340:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nPtPt"))
          b = 62; 
      case -196686776:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nPtBr"))
          b = 61; 
      case -196687780:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nPsAf"))
          b = 60; 
      case -196694036:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nPlPl"))
          b = 59; 
      case -196704822:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nPaIn"))
          b = 58; 
      case -196753680:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nNlNl"))
          b = 57; 
      case -196760403:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nNeNp"))
          b = 56; 
      case -196763287:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nNbNo"))
          b = 55; 
      case -196771008:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nMyMm"))
          b = 54; 
      case -196776762:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nMsMy"))
          b = 53; 
      case -196777858:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nMrIn"))
          b = 52; 
      case -196781578:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nMnMn"))
          b = 51; 
      case -196783624:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nMlIn"))
          b = 50; 
      case -196784464:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nMkMk"))
          b = 49; 
      case -196803704:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nLvLv"))
          b = 48; 
      case -196805628:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nLtLt"))
          b = 47; 
      case -196810452:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nLoLa"))
          b = 46; 
      case -196830658:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nKyKg"))
          b = 45; 
      case -196834212:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nKuTr"))
          b = 44; 
      case -196840257:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nKoKr"))
          b = 43; 
      case -196841284:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nKnIn"))
          b = 42; 
      case -196842189:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nKmKh"))
          b = 41; 
      case -196844093:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nKkKz"))
          b = 40; 
      case -196853848:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nKaGe"))
          b = 39; 
      case -196863397:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nJvId"))
          b = 38; 
      case -196883535:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nJaJp"))
          b = 37; 
      case -196895094:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nItIt"))
          b = 36; 
      case -196896056:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nIsIs"))
          b = 35; 
      case -196910486:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nIdId"))
          b = 34; 
      case -196920335:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nHyAm"))
          b = 33; 
      case -196923954:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nHuHu"))
          b = 32; 
      case -196926840:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nHrHr"))
          b = 31; 
      case -196935462:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nHiIn"))
          b = 30; 
      case -196939308:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nHeIl"))
          b = 29; 
      case -196953721:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nGuIn"))
          b = 28; 
      case -196986484:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nFrFr"))
          b = 27; 
      case -196995142:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nFiFi"))
          b = 26; 
      case -197001815:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nFbHa"))
          b = 25; 
      case -197002728:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nFaIr"))
          b = 24; 
      case -197014397:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nEtEe"))
          b = 23; 
      case -197015145:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nEsLa"))
          b = 22; 
      case -197015344:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nEsEs"))
          b = 21; 
      case -197020104:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nEnGb"))
          b = 20; 
      case -197022010:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nElGr"))
          b = 19; 
      case -197058634:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nDeDe"))
          b = 18; 
      case -197062472:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nDaDk"))
          b = 17; 
      case -197074981:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nCsCz"))
          b = 16; 
      case -197091141:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nCbIq"))
          b = 15; 
      case -197092224:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nCaEs"))
          b = 14; 
      case -197104828:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nBsBa"))
          b = 13; 
      case -197109403:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nBnIn"))
          b = 12; 
      case -197116354:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nBgBg"))
          b = 11; 
      case -197118258:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nBeBy"))
          b = 10; 
      case -197127898:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nAzAz"))
          b = 9; 
      case -197134389:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nAsIn"))
          b = 8; 
      case -197135594:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nArAr"))
          b = 7; 
      case -197146368:
        if (paramString.equals("com.facebook.fb4a.languagepacks.i18nAfZa"))
          b = 6; 
      case -471585089:
        if (paramString.equals("X.Xf0"))
          b = 5; 
      case -619293176:
        if (paramString.equals("X.Xf4"))
          b = 4; 
      case -1403335437:
        if (paramString.equals("X.Xf5"))
          b = 3; 
      case -1525572863:
        if (paramString.equals("X.X84"))
          b = 2; 
      case -1910988305:
        if (paramString.equals("X.Xf1"))
          b = 1; 
      case -2015396068:
        break;
    } 
    if (!paramString.equals("X.dNZ"));
    b = 0;
  }
  
  public static String A0T(String paramString) {
    paramString.hashCode();
    int i = paramString.hashCode();
    byte b = -1;
    switch (i) {
      default:
        switch (b) {
          default:
            return getModuleName(117);
          case 0:
          case 1:
          case 2:
          case 3:
          case 4:
          case 5:
          case 6:
          case 7:
          case 8:
          case 9:
          case 10:
          case 11:
          case 12:
          case 13:
          case 14:
          case 15:
          case 16:
          case 17:
          case 18:
            break;
        } 
        return null;
      case 1495479469:
        if (paramString.equals("UltralightPluginMetadatae24922cec6e9643d791dac7f8fe2e63a6dc444806778cc7593742e69ec4777b4"))
          b = 18; 
      case 924240265:
        if (paramString.equals("GeneratedAdsModule60d64e87"))
          b = 17; 
      case 797351095:
        if (paramString.equals("MC$fb4a_consumption_depth_logging"))
          b = 16; 
      case 649406393:
        if (paramString.equals("MC$fb4a_consumption_depth_logging_enabled"))
          b = 15; 
      case 493387138:
        if (paramString.equals("MC$fb_story_ads_delivery"))
          b = 14; 
      case 212299526:
        if (paramString.equals("AdsComponentsImpl"))
          b = 13; 
      case 200976466:
        if (paramString.equals("GeneratedMobileConfigStub_ads"))
          b = 12; 
      case 83330633:
        if (paramString.equals("MC$fb4a_watch_consumption_depth_logging_enabled"))
          b = 11; 
      case 1869679:
        if (paramString.equals("AdsLoggingImpl"))
          b = 10; 
      case 2454:
        if (paramString.equals("MC"))
          b = 9; 
      case -122711937:
        if (paramString.equals("MC$fb4a_stories_on_media_level_consumption_depth_logging_enabled"))
          b = 8; 
      case -126778675:
        if (paramString.equals("MC$fb4a_stories_consumption_depth_logging_enabled"))
          b = 7; 
      case -135349350:
        if (paramString.equals("MC$fb4a_stories_ads_client_ads_fetch"))
          b = 6; 
      case -609979476:
        if (paramString.equals("MC$fb4a_ads_platform_enabled"))
          b = 5; 
      case -929051081:
        if (paramString.equals("MC$fb4a_ads_platform_on_groups_tab_enabled"))
          b = 4; 
      case -1133987340:
        if (paramString.equals("AdsLoggingImpl$WhenMappings"))
          b = 3; 
      case -1289161998:
        if (paramString.equals("MC$fb4a_search_consumption_depth_logging_enabled"))
          b = 2; 
      case -1484519564:
        if (paramString.equals("MC$fb4a_groups_tab_consumption_depth_logging_enabled"))
          b = 1; 
      case -1570424135:
        break;
    } 
    if (!paramString.equals("MC$fb4a_video_channel_consumption_depth_logging_enabled"));
    b = 0;
  }
  
  public static String A0U(String paramString) {
    paramString.hashCode();
    int i = paramString.hashCode();
    byte b = -1;
    switch (i) {
      default:
        switch (b) {
          default:
            return null;
          case 0:
          case 1:
          case 2:
          case 3:
          case 4:
            break;
        } 
        return getModuleName(117);
      case 979128708:
        if (paramString.equals("ClientMessageDispatchHelper"))
          b = 4; 
      case -197506386:
        if (paramString.equals("AudienceNetworkExportedActivityApiImpl"))
          b = 3; 
      case -258613419:
        if (paramString.equals("AudienceNetworkRemoteServiceApiImpl"))
          b = 2; 
      case -273501109:
        if (paramString.equals("AdsRegistry$AdRecord"))
          b = 1; 
      case -1338637075:
        break;
    } 
    if (!paramString.equals("AdsRegistry"));
    b = 0;
  }
  
  public static String A0V(String paramString) {
    paramString.hashCode();
    int i = paramString.hashCode();
    byte b = -1;
    switch (i) {
      default:
        switch (b) {
          default:
            return null;
          case 2:
            return getModuleName(1);
          case 1:
          case 3:
            return getModuleName(126);
          case 0:
            break;
        } 
        return getModuleName(118);
      case 236657582:
        if (paramString.equals("ManualCreationAnalyticsLoggerEventForMigration"))
          b = 3; 
      case 75189745:
        if (paramString.equals("FeedAwesomizerLoggerEventForMigration"))
          b = 2; 
      case -105776647:
        if (paramString.equals("NewAppointmentDetailAnalyticsLoggerEventForMigration"))
          b = 1; 
      case -1083448860:
        break;
    } 
    if (!paramString.equals("WhitehatSettingsActivityLikeEventForMigration"));
    b = 0;
  }
  
  public static String A0W(String paramString) {
    paramString.hashCode();
    int i = paramString.hashCode();
    byte b = -1;
    switch (i) {
      default:
        switch (b) {
          default:
            return null;
          case 2:
          case 4:
          case 5:
            return getModuleName(116);
          case 0:
          case 1:
          case 3:
          case 6:
            break;
        } 
        return getModuleName(126);
      case 1878163078:
        if (paramString.equals("BizInboxReportedOutcomeType"))
          b = 6; 
      case 1691645641:
        if (paramString.equals("GamingCoplayLoggingEvents"))
          b = 5; 
      case 1650752509:
        if (paramString.equals("GamingCoplayLoggingSubSurface"))
          b = 4; 
      case 1453266321:
        if (paramString.equals("BusinessInboxSuggestedLabelType"))
          b = 3; 
      case 424676605:
        if (paramString.equals("GamingCoplayLoggingSurface"))
          b = 2; 
      case -1085104538:
        if (paramString.equals("BizInboxReportedOutcomeFlowStep"))
          b = 1; 
      case -1490281846:
        break;
    } 
    if (!paramString.equals("BizInboxReportedOutcomeEntryPoint"));
    b = 0;
  }
  
  public static String A0X(String paramString) {
    paramString.hashCode();
    int i = paramString.hashCode();
    short s = -1;
    switch (i) {
      default:
        switch (s) {
          default:
            return null;
          case 15:
          case 34:
          case 124:
            return getModuleName(17);
          case 3:
          case 9:
          case 12:
          case 22:
          case 26:
          case 29:
          case 30:
          case 31:
          case 35:
          case 37:
          case 40:
          case 42:
          case 43:
          case 47:
          case 48:
          case 51:
          case 52:
          case 54:
          case 55:
          case 58:
          case 59:
          case 62:
          case 65:
          case 67:
          case 68:
          case 70:
          case 72:
          case 75:
          case 77:
          case 78:
          case 84:
          case 85:
          case 92:
          case 93:
          case 94:
          case 95:
          case 96:
          case 98:
          case 99:
          case 107:
          case 110:
          case 114:
          case 116:
          case 121:
          case 125:
          case 126:
          case 129:
          case 131:
          case 132:
          case 133:
          case 134:
          case 136:
          case 138:
          case 139:
          case 141:
          case 144:
          case 146:
          case 148:
          case 149:
          case 152:
          case 153:
          case 154:
          case 160:
          case 162:
          case 163:
          case 165:
          case 169:
          case 172:
          case 173:
          case 174:
          case 175:
          case 176:
          case 179:
          case 180:
          case 184:
          case 186:
            return getModuleName(116);
          case 0:
          case 1:
          case 2:
          case 4:
          case 5:
          case 6:
          case 7:
          case 8:
          case 10:
          case 11:
          case 13:
          case 14:
          case 16:
          case 17:
          case 18:
          case 19:
          case 20:
          case 21:
          case 23:
          case 24:
          case 25:
          case 27:
          case 28:
          case 32:
          case 33:
          case 36:
          case 38:
          case 39:
          case 41:
          case 44:
          case 45:
          case 46:
          case 49:
          case 50:
          case 53:
          case 56:
          case 57:
          case 60:
          case 61:
          case 63:
          case 64:
          case 66:
          case 69:
          case 71:
          case 73:
          case 74:
          case 76:
          case 79:
          case 80:
          case 81:
          case 82:
          case 83:
          case 86:
          case 87:
          case 88:
          case 89:
          case 90:
          case 91:
          case 97:
          case 100:
          case 101:
          case 102:
          case 103:
          case 104:
          case 105:
          case 106:
          case 108:
          case 109:
          case 111:
          case 112:
          case 113:
          case 115:
          case 117:
          case 118:
          case 119:
          case 120:
          case 122:
          case 123:
          case 127:
          case 128:
          case 130:
          case 135:
          case 137:
          case 140:
          case 142:
          case 143:
          case 145:
          case 147:
          case 150:
          case 151:
          case 155:
          case 156:
          case 157:
          case 158:
          case 159:
          case 161:
          case 164:
          case 166:
          case 167:
          case 168:
          case 170:
          case 171:
          case 177:
          case 178:
          case 181:
          case 182:
          case 183:
          case 185:
          case 187:
          case 188:
          case 189:
            break;
        } 
        return getModuleName(126);
      case 2129823194:
        if (paramString.equals("BusinessInboxReportedOutcomeOptInEnterFlow$Loggable"))
          s = 189; 
      case 2097869746:
        if (paramString.equals("ServicesNewAppointmentDetailTapEditButton$Referrer"))
          s = 188; 
      case 2085489169:
        if (paramString.equals("BusinessInboxSuggestedLabelClick"))
          s = 187; 
      case 2077711327:
        if (paramString.equals("ClientCreateInstantgameiapFail$ActualEventTime"))
          s = 186; 
      case 2045413035:
        if (paramString.equals("BusinessInboxReceiptClick$Loggable"))
          s = 185; 
      case 1986188937:
        if (paramString.equals("ClientEditInstantgameiapSuccess"))
          s = 184; 
      case 1943326630:
        if (paramString.equals("BusinessInboxReceiptImpression$Loggable"))
          s = 183; 
      case 1934072378:
        if (paramString.equals("BusinessInboxReportedOutcomeOptOutSubmitFlow$EventData"))
          s = 182; 
      case 1932640347:
        if (paramString.equals("BusinessInboxReceiptImpression$EventData"))
          s = 181; 
      case 1922528781:
        if (paramString.equals("ClientLoadInstantgameiapFail$Loggable"))
          s = 180; 
      case 1917157022:
        if (paramString.equals("ClientEditInstantgameiapFail$Factory"))
          s = 179; 
      case 1903336033:
        if (paramString.equals("ServicesBookingApptManualCreateViewImpr$Factory"))
          s = 178; 
      case 1810602951:
        if (paramString.equals("BusinessInboxReportedOutcomeOptInEnterFlow"))
          s = 177; 
      case 1789474412:
        if (paramString.equals("ClientLoadInstantgameiapInit$Factory"))
          s = 176; 
      case 1789304541:
        if (paramString.equals("ClientCreateInstantgameiapSuccess$Factory"))
          s = 175; 
      case 1776684291:
        if (paramString.equals("ClientLoadInstantgameiapFail$Platform"))
          s = 174; 
      case 1739377673:
        if (paramString.equals("ClientLoadInstantgameiapFail$ActualEventTime"))
          s = 173; 
      case 1718408010:
        if (paramString.equals("ClientCreateInstantgameiapFailImpl"))
          s = 172; 
      case 1659429491:
        if (paramString.equals("BusinessInboxActivityImpression$InboxPlatform"))
          s = 171; 
      case 1656138114:
        if (paramString.equals("BusinessInboxReportedOutcomeOptInFlowStepImpressionImpl"))
          s = 170; 
      case 1655252061:
        if (paramString.equals("ClientEditInstantgameiapFail$ProductType"))
          s = 169; 
      case 1616235470:
        if (paramString.equals("ServicesBookingApptManualCreateSuccess$Loggable"))
          s = 168; 
      case 1561377815:
        if (paramString.equals("BusinessInboxReportedOutcomeOptInFlowStepImpression$InboxPlatform"))
          s = 167; 
      case 1535280860:
        if (paramString.equals("BusinessInboxReportedOutcomeOptInEnterFlow$InboxPlatform"))
          s = 166; 
      case 1519440879:
        if (paramString.equals("ClientEditInstantgameiapSuccess$EventPayload"))
          s = 165; 
      case 1501113254:
        if (paramString.equals("BusinessInboxSuggestedLabelClick$InboxPlatform"))
          s = 164; 
      case 1459098126:
        if (paramString.equals("ClientCreateInstantgameiapFail$EventPayload"))
          s = 163; 
      case 1394234828:
        if (paramString.equals("GamingCoplayFalcoEventImpl"))
          s = 162; 
      case 1335590035:
        if (paramString.equals("MbsAdsEventSharingNuxDismiss$Factory"))
          s = 161; 
      case 1311905852:
        if (paramString.equals("ClientCreateInstantgameiapInitImpl"))
          s = 160; 
      case 1311702331:
        if (paramString.equals("BusinessInboxReceiptImpressionImpl"))
          s = 159; 
      case 1277393580:
        if (paramString.equals("MbsAdsEventSharingNuxImpression$Factory"))
          s = 158; 
      case 1276681559:
        if (paramString.equals("ServicesBookingApptPersonalEventSuccessImpl"))
          s = 157; 
      case 1260931521:
        if (paramString.equals("BusinessInboxReceiptImpression$Factory"))
          s = 156; 
      case 1171227530:
        if (paramString.equals("ServicesNewAppointmentDetailTapMessengerIcon$Loggable"))
          s = 155; 
      case 1152729161:
        if (paramString.equals("ClientEditInstantgameiapSuccessImpl"))
          s = 154; 
      case 1148287067:
        if (paramString.equals("ClientLoadInstantgameiapInit$Loggable"))
          s = 153; 
      case 1143021066:
        if (paramString.equals("ClientCreateInstantgameiapSuccess$Loggable"))
          s = 152; 
      case 1133120848:
        if (paramString.equals("ServicesBookingApptManualCreateTapSaveImpl"))
          s = 151; 
      case 1130308908:
        if (paramString.equals("MbsAdsEventSharingNuxLearnMoreClick"))
          s = 150; 
      case 1121600770:
        if (paramString.equals("ClientLoadInstantgameiapSuccess$ActualEventTime"))
          s = 149; 
      case 1108881409:
        if (paramString.equals("ClientCreateInstantgameiapInit$ProductType"))
          s = 148; 
      case 1093371929:
        if (paramString.equals("BusinessInboxActivityClick$Factory"))
          s = 147; 
      case 1080388343:
        if (paramString.equals("ClientCreateInstantgameiapFail$Loggable"))
          s = 146; 
      case 1071807112:
        if (paramString.equals("BusinessInboxReportedOutcomeOptInFlowStepImpression$Factory"))
          s = 145; 
      case 1067079119:
        if (paramString.equals("ClientEditInstantgameiapSuccess$Factory"))
          s = 144; 
      case 1059741010:
        if (paramString.equals("ServicesBookingApptPersonalEventImprImpl"))
          s = 143; 
      case 1055536918:
        if (paramString.equals("BusinessInboxReceiptClickImpl"))
          s = 142; 
      case 1047329550:
        if (paramString.equals("ClientEditInstantgameiapSuccess$ProductType"))
          s = 141; 
      case 1043946574:
        if (paramString.equals("BusinessInboxActivityClick$Loggable"))
          s = 140; 
      case 1002442577:
        if (paramString.equals("ClientLoadInstantgameiapInit$Platform"))
          s = 139; 
      case 997176576:
        if (paramString.equals("ClientCreateInstantgameiapSuccess$Platform"))
          s = 138; 
      case 973285529:
        if (paramString.equals("ServicesBookingApptManualCreateSuccess$Factory"))
          s = 137; 
      case 934543853:
        if (paramString.equals("ClientCreateInstantgameiapFail$Platform"))
          s = 136; 
      case 860581841:
        if (paramString.equals("BusinessInboxSuggestedLabelClickImpl"))
          s = 135; 
      case 858652622:
        if (paramString.equals("ClientEditInstantgameiapInit$EventPayload"))
          s = 134; 
      case 834063730:
        if (paramString.equals("ClientLoadInstantgameiapInit$EventPayload"))
          s = 133; 
      case 811480681:
        if (paramString.equals("ClientEditInstantgameiapFail$Loggable"))
          s = 132; 
      case 806990452:
        if (paramString.equals("ClientLoadInstantgameiapFailImpl"))
          s = 131; 
      case 802351606:
        if (paramString.equals("BusinessInboxReceiptClick$EventData"))
          s = 130; 
      case 769499437:
        if (paramString.equals("ClientLoadInstantgameiapSuccess"))
          s = 129; 
      case 721656040:
        if (paramString.equals("BusinessInboxActivityClick$InboxPlatform"))
          s = 128; 
      case 719906937:
        if (paramString.equals("BizappDeeplinkHandleUrl$Factory"))
          s = 127; 
      case 699581905:
        if (paramString.equals("ClientCreateInstantgameiapInit$ActualEventTime"))
          s = 126; 
      case 665636191:
        if (paramString.equals("ClientEditInstantgameiapFail$Platform"))
          s = 125; 
      case 635393038:
        if (paramString.equals("CloudGamingWebrtcStatsImpl"))
          s = 124; 
      case 597365116:
        if (paramString.equals("BusinessInboxReportedOutcomeOptInSubmitFlow$Loggable"))
          s = 123; 
      case 572709730:
        if (paramString.equals("BusinessInboxReportedOutcomeOptInFlowStepImpression$EventData"))
          s = 122; 
      case 567523962:
        if (paramString.equals("ClientLoadInstantgameiapFail$Factory"))
          s = 121; 
      case 545999120:
        if (paramString.equals("ServicesNewAppointmentDetailTapEditButton$Loggable"))
          s = 120; 
      case 524776747:
        if (paramString.equals("BusinessInboxReportedOutcomeOptInSubmitFlow$Factory"))
          s = 119; 
      case 447770021:
        if (paramString.equals("BusinessInboxReportedOutcomeOptInSubmitFlowImpl"))
          s = 118; 
      case 446699092:
        if (paramString.equals("ServicesBookingApptPersonalEventTapSave"))
          s = 117; 
      case 400488294:
        if (paramString.equals("ClientLoadInstantgameiapInitImpl"))
          s = 116; 
      case 394209171:
        if (paramString.equals("BusinessInboxActivityClickImpl"))
          s = 115; 
      case 383258007:
        if (paramString.equals("ClientCreateInstantgameiapSuccess"))
          s = 114; 
      case 383030022:
        if (paramString.equals("ServicesBookingApptManualCreateViewImpr$Loggable"))
          s = 113; 
      case 377014673:
        if (paramString.equals("ServicesNewAppointmentDetailTapEditButtonImpl"))
          s = 112; 
      case 375437247:
        if (paramString.equals("BusinessInboxReportedOutcomeOptInFlowStepImpression$Loggable"))
          s = 111; 
      case 361248251:
        if (paramString.equals("ClientLoadInstantgameiapInit$ActualEventTime"))
          s = 110; 
      case 349942579:
        if (paramString.equals("BizappDeeplinkHandleUrl"))
          s = 109; 
      case 310235870:
        if (paramString.equals("BusinessInboxActivityImpressionImpl"))
          s = 108; 
      case 306146629:
        if (paramString.equals("ClientCreateInstantgameiapInit$Loggable"))
          s = 107; 
      case 304371372:
        if (paramString.equals("MbsAdsEventSharingNuxManageClick$Factory"))
          s = 106; 
      case 297958544:
        if (paramString.equals("BusinessInboxReceiptImpression$InboxPlatform"))
          s = 105; 
      case 297612935:
        if (paramString.equals("BusinessInboxReportedOutcomeOptInEnterFlowImpl"))
          s = 104; 
      case 280804839:
        if (paramString.equals("BusinessInboxReportedOutcomeOptOutSubmitFlow$Loggable"))
          s = 103; 
      case 280593585:
        if (paramString.equals("ServicesBookingApptManualCreateTapSave$Loggable"))
          s = 102; 
      case 253623198:
        if (paramString.equals("BusinessInboxActivityImpression"))
          s = 101; 
      case 249082138:
        if (paramString.equals("BusinessInboxReportedOutcomeOptOutSubmitFlow"))
          s = 100; 
      case 238287938:
        if (paramString.equals("ClientCreateInstantgameiapInit$Factory"))
          s = 99; 
      case 228869464:
        if (paramString.equals("ClientEditInstantgameiapSuccess$Loggable"))
          s = 98; 
      case 213628915:
        if (paramString.equals("BizappDeeplinkHandleUrlImpl"))
          s = 97; 
      case 194729807:
        if (paramString.equals("ClientEditInstantgameiapInit$ProductType"))
          s = 96; 
      case 160302139:
        if (paramString.equals("ClientCreateInstantgameiapInit$Platform"))
          s = 95; 
      case 157368926:
        if (paramString.equals("ClientEditInstantgameiapSuccess$ActualEventTime"))
          s = 94; 
      case 150080796:
        if (paramString.equals("ClientCreateInstantgameiapSuccess$ProductType"))
          s = 93; 
      case 131243372:
        if (paramString.equals("ClientCreateInstantgameiapSuccess$ActualEventTime"))
          s = 92; 
      case 123911701:
        if (paramString.equals("MbsAdsEventSharingNuxLearnMoreClick$Loggable"))
          s = 91; 
      case 120253079:
        if (paramString.equals("ServicesBookingApptPersonalEventSuccess"))
          s = 90; 
      case 108250178:
        if (paramString.equals("BusinessInboxReportedOutcomeOptInFlowStepImpression"))
          s = 89; 
      case 107477783:
        if (paramString.equals("ServicesNewAppointmentDetailTapEditButton$Factory"))
          s = 88; 
      case 102054870:
        if (paramString.equals("BusinessInboxReceiptClick"))
          s = 87; 
      case 90677908:
        if (paramString.equals("ServicesBookingApptPersonalEventTapSaveImpl"))
          s = 86; 
      case 83024974:
        if (paramString.equals("ClientEditInstantgameiapSuccess$Platform"))
          s = 85; 
      case 37238967:
        if (paramString.equals("ClientEditInstantgameiapInit$Loggable"))
          s = 84; 
      case -37226732:
        if (paramString.equals("MbsAdsEventSharingNuxDismiss$Loggable"))
          s = 83; 
      case -39631018:
        if (paramString.equals("ServicesBookingApptManualCreateTapSave$Factory"))
          s = 82; 
      case -41267473:
        if (paramString.equals("BusinessInboxReportedOutcomeOptOutSubmitFlow$InboxPlatform"))
          s = 81; 
      case -53707811:
        if (paramString.equals("ServicesBookingApptPersonalEventSuccess$Factory"))
          s = 80; 
      case -84044316:
        if (paramString.equals("BusinessInboxActivityImpression$Factory"))
          s = 79; 
      case -108605523:
        if (paramString.equals("ClientEditInstantgameiapInit$Platform"))
          s = 78; 
      case -130340712:
        if (paramString.equals("ClientEditInstantgameiapFailImpl"))
          s = 77; 
      case -155786998:
        if (paramString.equals("ServicesBookingApptPersonalEventSuccess$Loggable"))
          s = 76; 
      case -172348371:
        if (paramString.equals("ClientEditInstantgameiapFail$ActualEventTime"))
          s = 75; 
      case -178337613:
        if (paramString.equals("BusinessInboxActivityClick$EventData"))
          s = 74; 
      case -287995555:
        if (paramString.equals("ServicesNewAppointmentDetailTapMessengerIcon$Factory"))
          s = 73; 
      case -340842059:
        if (paramString.equals("GamingCoplayFalcoEvent$Loggable"))
          s = 72; 
      case -391738672:
        if (paramString.equals("BusinessInboxSuggestedLabelClick$Loggable"))
          s = 71; 
      case -423751111:
        if (paramString.equals("ClientLoadInstantgameiapFail$ProductType"))
          s = 70; 
      case -447347610:
        if (paramString.equals("MbsAdsEventSharingNuxManageClick"))
          s = 69; 
      case -484990980:
        if (paramString.equals("ClientCreateInstantgameiapInit"))
          s = 68; 
      case -485092854:
        if (paramString.equals("ClientCreateInstantgameiapFail"))
          s = 67; 
      case -508673071:
        if (paramString.equals("ServicesNewAppointmentDetailTapEditButton"))
          s = 66; 
      case -525466719:
        if (paramString.equals("ClientCreateInstantgameiapSuccess$EventPayload"))
          s = 65; 
      case -533404177:
        if (paramString.equals("ServicesBookingApptPersonalEventImpr$Loggable"))
          s = 64; 
      case -533765973:
        if (paramString.equals("BusinessInboxReceiptClick$InboxPlatform"))
          s = 63; 
      case -536842870:
        if (paramString.equals("ClientEditInstantgameiapInitImpl"))
          s = 62; 
      case -547872049:
        if (paramString.equals("MbsAdsEventSharingNuxImpression$ConsumerId"))
          s = 61; 
      case -594948837:
        if (paramString.equals("ServicesBookingApptManualCreateViewImpr"))
          s = 60; 
      case -662553485:
        if (paramString.equals("ClientLoadInstantgameiapSuccess$Factory"))
          s = 59; 
      case -691922707:
        if (paramString.equals("ClientLoadInstantgameiapSuccessImpl"))
          s = 58; 
      case -720053125:
        if (paramString.equals("BusinessInboxReceiptImpression"))
          s = 57; 
      case -732360864:
        if (paramString.equals("BusinessInboxReportedOutcomeOptOutSubmitFlow$Factory"))
          s = 56; 
      case -863800373:
        if (paramString.equals("ClientLoadInstantgameiapSuccess$EventPayload"))
          s = 55; 
      case -867418788:
        if (paramString.equals("ClientCreateInstantgameiapInit$EventPayload"))
          s = 54; 
      case -875900761:
        if (paramString.equals("BusinessInboxReportedOutcomeOptInEnterFlow$EventData"))
          s = 53; 
      case -912874458:
        if (paramString.equals("ClientLoadInstantgameiapInit"))
          s = 52; 
      case -912976332:
        if (paramString.equals("ClientLoadInstantgameiapFail"))
          s = 51; 
      case -941420059:
        if (paramString.equals("BusinessInboxReportedOutcomeOptInSubmitFlow"))
          s = 50; 
      case -945464410:
        if (paramString.equals("MbsAdsEventSharingNuxImpressionImpl"))
          s = 49; 
      case -983662512:
        if (paramString.equals("ClientCreateInstantgameiapFail$Factory"))
          s = 48; 
      case -1029508654:
        if (paramString.equals("GamingCoplayFalcoEvent$Factory"))
          s = 47; 
      case -1066624358:
        if (paramString.equals("ServicesBookingApptPersonalEventTapSave$Factory"))
          s = 46; 
      case -1088357107:
        if (paramString.equals("BusinessInboxReportedOutcomeOptInEnterFlow$Factory"))
          s = 45; 
      case -1096218653:
        if (paramString.equals("BusinessInboxActivityImpression$Loggable"))
          s = 44; 
      case -1107759182:
        if (paramString.equals("ClientLoadInstantgameiapSuccess$ProductType"))
          s = 43; 
      case -1109797760:
        if (paramString.equals("ClientEditInstantgameiapFail$EventPayload"))
          s = 42; 
      case -1118189873:
        if (paramString.equals("MbsAdsEventSharingNuxManageClick$ConsumerId"))
          s = 41; 
      case -1134386652:
        if (paramString.equals("ClientLoadInstantgameiapFail$EventPayload"))
          s = 40; 
      case -1137460923:
        if (paramString.equals("BusinessInboxReportedOutcomeOptInSubmitFlow$EventData"))
          s = 39; 
      case -1144755497:
        if (paramString.equals("ServicesNewAppointmentDetailTapMessengerIconImpl"))
          s = 38; 
      case -1155859824:
        if (paramString.equals("ClientEditInstantgameiapInit$Factory"))
          s = 37; 
      case -1166369317:
        if (paramString.equals("ServicesBookingApptManualCreateViewImprImpl"))
          s = 36; 
      case -1201855092:
        if (paramString.equals("GamingCoplayFalcoEvent"))
          s = 35; 
      case -1269852978:
        if (paramString.equals("CloudGamingWebrtcStats"))
          s = 34; 
      case -1277593577:
        if (paramString.equals("ServicesNewAppointmentDetailTapMessengerIcon"))
          s = 33; 
      case -1321386224:
        if (paramString.equals("ServicesBookingApptManualCreateTapSave"))
          s = 32; 
      case -1434697641:
        if (paramString.equals("ClientCreateInstantgameiapSuccessImpl"))
          s = 31; 
      case -1458516918:
        if (paramString.equals("ClientEditInstantgameiapInit"))
          s = 30; 
      case -1458618792:
        if (paramString.equals("ClientEditInstantgameiapFail"))
          s = 29; 
      case -1491428883:
        if (paramString.equals("ServicesBookingApptPersonalEventTapSave$Loggable"))
          s = 28; 
      case -1511395206:
        if (paramString.equals("BusinessInboxReportedOutcomeOptInSubmitFlow$InboxPlatform"))
          s = 27; 
      case -1550477793:
        if (paramString.equals("ClientEditInstantgameiapInit$ActualEventTime"))
          s = 26; 
      case -1565955494:
        if (paramString.equals("BusinessInboxReportedOutcomeOptOutSubmitFlowImpl"))
          s = 25; 
      case -1571869140:
        if (paramString.equals("ServicesNewAppointmentDetailTapMessengerIcon$Referrer"))
          s = 24; 
      case -1647832237:
        if (paramString.equals("ServicesBookingApptManualCreateSuccess"))
          s = 23; 
      case -1725563633:
        if (paramString.equals("ClientCreateInstantgameiapFail$ProductType"))
          s = 22; 
      case -1734907279:
        if (paramString.equals("BusinessInboxSuggestedLabelClick$EventData"))
          s = 21; 
      case -1748857271:
        if (paramString.equals("MbsAdsEventSharingNuxLearnMoreClick$ConsumerId"))
          s = 20; 
      case -1783816676:
        if (paramString.equals("BusinessInboxReceiptClick$Factory"))
          s = 19; 
      case -1794641197:
        if (paramString.equals("BusinessInboxActivityClick"))
          s = 18; 
      case -1816106739:
        if (paramString.equals("MbsAdsEventSharingNuxDismissImpl"))
          s = 17; 
      case -1833359258:
        if (paramString.equals("MbsAdsEventSharingNuxImpression"))
          s = 16; 
      case -1839530220:
        if (paramString.equals("CloudGamingWebrtcStats$Factory"))
          s = 15; 
      case -1841316837:
        if (paramString.equals("MbsAdsEventSharingNuxImpression$Loggable"))
          s = 14; 
      case -1845800590:
        if (paramString.equals("MbsAdsEventSharingNuxLearnMoreClick$Factory"))
          s = 13; 
      case -1850133708:
        if (paramString.equals("ClientLoadInstantgameiapSuccess$Loggable"))
          s = 12; 
      case -1862434473:
        if (paramString.equals("BusinessInboxSuggestedLabelClick$Factory"))
          s = 11; 
      case -1867004328:
        if (paramString.equals("ServicesBookingApptPersonalEventImpr$Factory"))
          s = 10; 
      case -1884273365:
        if (paramString.equals("ClientLoadInstantgameiapInit$ProductType"))
          s = 9; 
      case -1913004014:
        if (paramString.equals("ServicesBookingApptPersonalEventImpr"))
          s = 8; 
      case -1916206771:
        if (paramString.equals("MbsAdsEventSharingNuxDismiss"))
          s = 7; 
      case -1940234213:
        if (paramString.equals("MbsAdsEventSharingNuxManageClick$Loggable"))
          s = 6; 
      case -1975842797:
        if (paramString.equals("ServicesBookingApptManualCreateSuccessImpl"))
          s = 5; 
      case -1984068728:
        if (paramString.equals("MbsAdsEventSharingNuxDismiss$ConsumerId"))
          s = 4; 
      case -1995978198:
        if (paramString.equals("ClientLoadInstantgameiapSuccess$Platform"))
          s = 3; 
      case -2005649498:
        if (paramString.equals("MbsAdsEventSharingNuxManageClickImpl"))
          s = 2; 
      case -2016180884:
        if (paramString.equals("MbsAdsEventSharingNuxLearnMoreClickImpl"))
          s = 1; 
      case -2098950210:
        break;
    } 
    if (!paramString.equals("BusinessInboxActivityImpression$EventData"));
    s = 0;
  }
  
  public static String A0Y(String paramString) {
    paramString.hashCode();
    int i = paramString.hashCode();
    byte b = -1;
    switch (i) {
      default:
        switch (b) {
          default:
            return null;
          case 1:
          case 11:
          case 28:
            return getModuleName(116);
          case 0:
          case 2:
          case 3:
          case 4:
          case 5:
          case 6:
          case 7:
          case 8:
          case 9:
          case 10:
          case 12:
          case 13:
          case 14:
          case 15:
          case 16:
          case 17:
          case 18:
          case 19:
          case 20:
          case 21:
          case 22:
          case 23:
          case 24:
          case 25:
          case 26:
          case 27:
          case 29:
          case 30:
          case 31:
            break;
        } 
        return getModuleName(126);
      case 2132607557:
        if (paramString.equals("BusinessInboxReportedOutcomeOptInSubmitFlowEventData$Factory"))
          b = 31; 
      case 2121229442:
        if (paramString.equals("BusinessInboxReportedOutcomeOptInFlowStepImpressionEventDataImpl"))
          b = 30; 
      case 2107187822:
        if (paramString.equals("BusinessInboxSuggestedLabelClickEventData$LabelName"))
          b = 29; 
      case 2022976864:
        if (paramString.equals("UPLEventInstantGameIAPPayload"))
          b = 28; 
      case 1637524433:
        if (paramString.equals("BusinessInboxActivityClickEventData"))
          b = 27; 
      case 1499454830:
        if (paramString.equals("BusinessInboxReceiptClickEventDataImpl"))
          b = 26; 
      case 1387737321:
        if (paramString.equals("BusinessInboxReceiptImpressionEventDataImpl"))
          b = 25; 
      case 1329371071:
        if (paramString.equals("BusinessInboxReportedOutcomeOptInSubmitFlowEventDataImpl"))
          b = 24; 
      case 1190942975:
        if (paramString.equals("BusinessInboxReportedOutcomeOptInSubmitFlowEventData"))
          b = 23; 
      case 1149454099:
        if (paramString.equals("BusinessInboxSuggestedLabelClickEventDataImpl"))
          b = 22; 
      case 1099699882:
        if (paramString.equals("BusinessInboxReportedOutcomeOptOutSubmitFlowEventDataImpl"))
          b = 21; 
      case 969015106:
        if (paramString.equals("BusinessInboxReportedOutcomeOptInFlowStepImpressionEventData"))
          b = 20; 
      case 874382698:
        if (paramString.equals("BusinessInboxReportedOutcomeOptOutSubmitFlowEventData"))
          b = 19; 
      case 738919078:
        if (paramString.equals("BusinessInboxActivityImpressionEventDataImpl"))
          b = 18; 
      case 660447660:
        if (paramString.equals("BusinessInboxActivityImpressionEventData$Factory"))
          b = 17; 
      case 201839187:
        if (paramString.equals("BusinessInboxSuggestedLabelClickEventData"))
          b = 16; 
      case 180729224:
        if (paramString.equals("BusinessInboxReportedOutcomeOptInFlowStepImpressionEventData$Factory"))
          b = 15; 
      case 154478993:
        if (paramString.equals("BusinessInboxActivityClickEventDataImpl"))
          b = 14; 
      case 135522201:
        if (paramString.equals("BusinessInboxSuggestedLabelClickEventData$Factory"))
          b = 13; 
      case 115423395:
        if (paramString.equals("BusinessInboxReportedOutcomeOptInEnterFlowEventData$Factory"))
          b = 12; 
      case 59696550:
        if (paramString.equals("UPLEventInstantGameIAPPayload$Factory"))
          b = 11; 
      case -502640794:
        if (paramString.equals("BusinessInboxActivityImpressionEventData"))
          b = 10; 
      case -708370820:
        if (paramString.equals("BusinessInboxSuggestedLabelClickEventData$SuggestedLabelType"))
          b = 9; 
      case -1368583248:
        if (paramString.equals("BusinessInboxReportedOutcomeOptOutSubmitFlowEventData$Factory"))
          b = 8; 
      case -1544358289:
        if (paramString.equals("BusinessInboxReceiptImpressionEventData$Factory"))
          b = 7; 
      case -1571566243:
        if (paramString.equals("BusinessInboxReportedOutcomeOptInEnterFlowEventData"))
          b = 6; 
      case -1655976402:
        if (paramString.equals("BusinessInboxReceiptClickEventData"))
          b = 5; 
      case -1758062807:
        if (paramString.equals("BusinessInboxReceiptImpressionEventData"))
          b = 4; 
      case -1783113612:
        if (paramString.equals("BusinessInboxReceiptClickEventData$Factory"))
          b = 3; 
      case -1897485027:
        if (paramString.equals("BusinessInboxReportedOutcomeOptInEnterFlowEventDataImpl"))
          b = 2; 
      case -1910418528:
        if (paramString.equals("UPLEventInstantGameIAPPayloadImpl"))
          b = 1; 
      case -2081137897:
        break;
    } 
    if (!paramString.equals("BusinessInboxActivityClickEventData$Factory"));
    b = 0;
  }
  
  public static String A0Z(String paramString) {
    paramString.hashCode();
    return (!paramString.equals("HeliumHotfixes") && !paramString.equals("HeliumRevision")) ? null : getModuleName(118);
  }
  
  public static String A0a(String paramString) {
    paramString.hashCode();
    int i = paramString.hashCode();
    byte b = -1;
    switch (i) {
      default:
        switch (b) {
          default:
            return getModuleName(0);
          case 0:
          case 1:
          case 2:
          case 3:
            break;
        } 
        return null;
      case 1612199772:
        if (paramString.equals("WorldTrackerSlamFactoryProviderModule"))
          b = 3; 
      case 1145020324:
        if (paramString.equals("WorldTrackerSlamFactoryProviderModule$Companion"))
          b = 2; 
      case -59330007:
        if (paramString.equals("WorldTrackerV2DataProviderModule"))
          b = 1; 
      case -1150239183:
        break;
    } 
    if (!paramString.equals("WorldTrackerV2DataProviderModule$Companion"));
    b = 0;
  }
  
  public static String A0b(String paramString) {
    paramString.hashCode();
    return (!paramString.equals("FrameEvent") && !paramString.equals("FrameEvent$Companion")) ? getModuleName(147) : null;
  }
  
  public static String A0c(String paramString) {
    paramString.hashCode();
    int i = paramString.hashCode();
    byte b = -1;
    switch (i) {
      default:
        switch (b) {
          default:
            return null;
          case 1:
          case 2:
            return getModuleName(118);
          case 0:
            break;
        } 
        return getModuleName(126);
      case 1601945747:
        if (paramString.equals("FBReactLinks_InternalSettingsRoutes"))
          b = 2; 
      case 647944843:
        if (paramString.equals("FBReactLinks_LocationShareRoutes"))
          b = 1; 
      case 485751621:
        break;
    } 
    if (!paramString.equals("FBReactLinks_BizAppDataSharingRoutes"));
    b = 0;
  }
  
  public static String A0d(String paramString) {
    paramString.hashCode();
    return !paramString.equals("NativeAutoUpdaterSpec") ? null : getModuleName(29);
  }
  
  public static String A0e(String paramString) {
    paramString.hashCode();
    return (!paramString.equals("HermesSnapshotExecutor") && !paramString.equals("HermesSnapshotExecutorFactory")) ? null : getModuleName(28);
  }
  
  public static String A0f(String paramString) {
    paramString.hashCode();
    int i = paramString.hashCode();
    byte b = -1;
    switch (i) {
      default:
        switch (b) {
          default:
            return getModuleName(124);
          case 0:
          case 1:
          case 2:
          case 3:
          case 4:
          case 5:
            break;
        } 
        return null;
      case 1970820076:
        if (paramString.equals("QEGKDefinitions$GatekeeperDef"))
          b = 5; 
      case 941972332:
        if (paramString.equals("QEGKDefinitions$ExperimentDef"))
          b = 4; 
      case -38747868:
        if (paramString.equals("QEGKDefinitions$UniverseDef"))
          b = 3; 
      case -213701356:
        if (paramString.equals("QEGKDefinitions$ParamDef"))
          b = 2; 
      case -878759454:
        if (paramString.equals("QEGKDefinitions$GroupDef"))
          b = 1; 
      case -945990552:
        break;
    } 
    if (!paramString.equals("QEGKDefinitions"));
    b = 0;
  }
  
  public static String A0g(String paramString) {
    paramString.hashCode();
    return !paramString.equals("LongTailPlaceholder") ? null : getModuleName(120);
  }
  
  public static String A0h(String paramString) {
    paramString.hashCode();
    int i = paramString.hashCode();
    byte b = -1;
    switch (i) {
      default:
        switch (b) {
          default:
            return null;
          case 0:
          case 1:
          case 2:
          case 3:
          case 4:
          case 5:
          case 6:
          case 7:
            break;
        } 
        return getModuleName(117);
      case 1963514552:
        if (paramString.equals("SimpleExoPlayer$ComponentListener"))
          b = 7; 
      case 1728091725:
        if (paramString.equals("ExoPlayerFactory"))
          b = 6; 
      case 690710012:
        if (paramString.equals("DefaultRenderersFactory$ExtensionRendererMode"))
          b = 5; 
      case 478132456:
        if (paramString.equals("DefaultRenderersFactory$1"))
          b = 4; 
      case 235175862:
        if (paramString.equals("SimpleExoPlayer$VideoListener"))
          b = 3; 
      case 159939179:
        if (paramString.equals("SimpleExoPlayer"))
          b = 2; 
      case -917270472:
        if (paramString.equals("SimpleExoPlayer$1"))
          b = 1; 
      case -2113466597:
        break;
    } 
    if (!paramString.equals("DefaultRenderersFactory"));
    b = 0;
  }
  
  public static String A0i(String paramString) {
    paramString.hashCode();
    int i = paramString.hashCode();
    byte b = -1;
    switch (i) {
      default:
        switch (b) {
          default:
            return null;
          case 0:
          case 1:
          case 2:
          case 3:
          case 4:
          case 5:
          case 6:
          case 7:
          case 8:
          case 9:
          case 10:
          case 11:
          case 12:
          case 13:
          case 14:
          case 15:
            break;
        } 
        return getModuleName(117);
      case 1645778437:
        if (paramString.equals("VorbisUtil$CodeBook"))
          b = 15; 
      case 1115868330:
        if (paramString.equals("DefaultExtractorsFactory$ExtensionLoader$ConstructorSupplier"))
          b = 14; 
      case 969396858:
        if (paramString.equals("FlacMetadataReader"))
          b = 13; 
      case 728473467:
        if (paramString.equals("FlacFrameReader$SampleNumberHolder"))
          b = 12; 
      case 457443369:
        if (paramString.equals("FlacStreamMetadata$SeekTable"))
          b = 11; 
      case 323559543:
        if (paramString.equals("FlacStreamMetadata"))
          b = 10; 
      case 12458582:
        if (paramString.equals("FlacSeekTableSeekMap"))
          b = 9; 
      case -84826486:
        if (paramString.equals("VorbisUtil$VorbisIdHeader"))
          b = 8; 
      case -624475155:
        if (paramString.equals("FlacMetadataReader$FlacStreamMetadataHolder"))
          b = 7; 
      case -811577166:
        if (paramString.equals("VorbisUtil$Mode"))
          b = 6; 
      case -921801697:
        if (paramString.equals("VorbisBitArray"))
          b = 5; 
      case -1162894435:
        if (paramString.equals("VorbisUtil$CommentHeader"))
          b = 4; 
      case -1195026552:
        if (paramString.equals("DefaultExtractorsFactory$ExtensionLoader"))
          b = 3; 
      case -1642458342:
        if (paramString.equals("DefaultExtractorsFactory"))
          b = 2; 
      case -1771399083:
        if (paramString.equals("VorbisUtil"))
          b = 1; 
      case -1921804312:
        break;
    } 
    if (!paramString.equals("FlacFrameReader"));
    b = 0;
  }
  
  public static String A0j(String paramString) {
    paramString.hashCode();
    return !paramString.equals("BloksCASDBLBizAppStartAuthAsyncControllerAction") ? null : getModuleName(126);
  }
  
  public static String A0k(String paramString) {
    paramString.hashCode();
    int i = paramString.hashCode();
    byte b = -1;
    switch (i) {
      default:
        switch (b) {
          default:
            return null;
          case 3:
            return getModuleName(25);
          case 0:
          case 1:
          case 2:
            break;
        } 
        return getModuleName(126);
      case 1959391215:
        if (paramString.equals("BloksGroupsAdminActivityLogControllerScreen"))
          b = 3; 
      case 931962722:
        if (paramString.equals("LeadsCenterToSBloksScreenControllerScreen$1"))
          b = 2; 
      case 103762965:
        if (paramString.equals("LeadsCenterToSBloksScreenControllerScreen"))
          b = 1; 
      case -766141278:
        break;
    } 
    if (!paramString.equals("MessengerSellerCenterAppControllerScreen"));
    b = 0;
  }
  
  public static String A0l(String paramString) {
    paramString.hashCode();
    int i = paramString.hashCode();
    short s = -1;
    switch (i) {
      default:
        switch (s) {
          default:
            return getModuleName(135);
          case 0:
          case 1:
          case 2:
          case 3:
          case 4:
          case 5:
          case 6:
          case 7:
          case 8:
          case 9:
          case 10:
          case 11:
          case 12:
          case 13:
          case 14:
          case 15:
          case 16:
          case 17:
          case 18:
          case 19:
          case 20:
          case 21:
          case 22:
          case 23:
          case 24:
          case 25:
          case 26:
          case 27:
          case 28:
          case 29:
          case 30:
          case 31:
          case 32:
          case 33:
          case 34:
          case 35:
          case 36:
          case 37:
          case 38:
          case 39:
          case 40:
          case 41:
          case 42:
          case 43:
          case 44:
          case 45:
          case 46:
          case 47:
          case 48:
          case 49:
          case 50:
          case 51:
          case 52:
          case 53:
          case 54:
          case 55:
          case 56:
          case 57:
          case 58:
          case 59:
          case 60:
          case 61:
          case 62:
          case 63:
          case 64:
          case 65:
          case 66:
          case 67:
          case 68:
          case 69:
          case 70:
          case 71:
          case 72:
          case 73:
          case 74:
          case 75:
          case 76:
          case 77:
          case 78:
          case 79:
          case 80:
          case 81:
          case 82:
          case 83:
          case 84:
          case 85:
          case 86:
          case 87:
          case 88:
          case 89:
          case 90:
          case 91:
          case 92:
          case 93:
          case 94:
          case 95:
          case 96:
          case 97:
          case 98:
          case 99:
          case 100:
          case 101:
          case 102:
          case 103:
          case 104:
          case 105:
          case 106:
          case 107:
          case 108:
          case 109:
          case 110:
          case 111:
          case 112:
          case 113:
          case 114:
          case 115:
          case 116:
          case 117:
          case 118:
          case 119:
          case 120:
          case 121:
          case 122:
          case 123:
          case 124:
          case 125:
          case 126:
          case 127:
          case 128:
          case 129:
          case 130:
          case 131:
          case 132:
          case 133:
          case 134:
          case 135:
          case 136:
          case 137:
          case 138:
          case 139:
          case 140:
          case 141:
          case 142:
          case 143:
          case 144:
          case 145:
            break;
        } 
        return null;
      case 2135057063:
        if (paramString.equals("GlUtil"))
          s = 145; 
      case 2109498763:
        if (paramString.equals("EglBase14Impl$1"))
          s = 144; 
      case 2085172637:
        if (paramString.equals("Loggable"))
          s = 143; 
      case 2069954003:
        if (paramString.equals("EglRenderer$FrameListenerAndParams"))
          s = 142; 
      case 2040872062:
        if (paramString.equals("EglBase10$EglConnection"))
          s = 141; 
      case 2039822211:
        if (paramString.equals("EglThread$ReleaseMonitor"))
          s = 140; 
      case 2006934335:
        if (paramString.equals("Logging"))
          s = 139; 
      case 1981125465:
        if (paramString.equals("VideoEncoder$Capabilities"))
          s = 138; 
      case 1977822279:
        if (paramString.equals("VideoEncoder$EncodeInfo"))
          s = 137; 
      case 1904534085:
        if (paramString.equals("WrappedNativeVideoDecoder"))
          s = 136; 
      case 1860150027:
        if (paramString.equals("GlUtil$GlOutOfMemoryException"))
          s = 135; 
      case 1856641206:
        if (paramString.equals("EglRenderer$ErrorCallback"))
          s = 134; 
      case 1714553439:
        if (paramString.equals("EglThread$HandlerWithExceptionCallbacks"))
          s = 133; 
      case 1705633506:
        if (paramString.equals("Logging$Severity"))
          s = 132; 
      case 1685151626:
        if (paramString.equals("EglRenderer$FrameListener"))
          s = 131; 
      case 1680294281:
        if (paramString.equals("VideoEncoderFactory"))
          s = 130; 
      case 1620927644:
        if (paramString.equals("TimestampAligner"))
          s = 129; 
      case 1616902293:
        if (paramString.equals("TextureBufferImpl$RefCountMonitor"))
          s = 128; 
      case 1588893406:
        if (paramString.equals("WebRtcClassLoader"))
          s = 127; 
      case 1559597929:
        if (paramString.equals("VideoDecoder"))
          s = 126; 
      case 1534938730:
        if (paramString.equals("VideoEncoder$BitrateAllocation"))
          s = 125; 
      case 1534051387:
        if (paramString.equals("VideoFrame$I420Buffer"))
          s = 124; 
      case 1469741615:
        if (paramString.equals("EglThread$RenderUpdate"))
          s = 123; 
      case 1423656110:
        if (paramString.equals("RendererCommon"))
          s = 122; 
      case 1413831239:
        if (paramString.equals("VideoEncoder$ScalingSettings"))
          s = 121; 
      case 1408482668:
        if (paramString.equals("VideoEncoder$CodecSpecificInfoVP9"))
          s = 120; 
      case 1408482667:
        if (paramString.equals("VideoEncoder$CodecSpecificInfoVP8"))
          s = 119; 
      case 1366468771:
        if (paramString.equals("GlGenericDrawer"))
          s = 118; 
      case 1345021658:
        if (paramString.equals("GlRectDrawer"))
          s = 117; 
      case 1299480617:
        if (paramString.equals("EglBase14$Context"))
          s = 116; 
      case 1290325929:
        if (paramString.equals("TextureBufferImpl$2"))
          s = 115; 
      case 1290325928:
        if (paramString.equals("TextureBufferImpl$1"))
          s = 114; 
      case 1272213762:
        if (paramString.equals("CapturerObserver"))
          s = 113; 
      case 1272018018:
        if (paramString.equals("ContextUtils"))
          s = 112; 
      case 1258112873:
        if (paramString.equals("EglBase14Impl$Context"))
          s = 111; 
      case 1219718119:
        if (paramString.equals("VideoEncoder$EncoderInfo"))
          s = 110; 
      case 1194101020:
        if (paramString.equals("SurfaceTextureHelper"))
          s = 109; 
      case 1186964352:
        if (paramString.equals("GlGenericDrawer$ShaderType"))
          s = 108; 
      case 1123707600:
        if (paramString.equals("EglBase$ConfigBuilder"))
          s = 107; 
      case 1058583729:
        if (paramString.equals("ThreadUtils$1Result"))
          s = 106; 
      case 1057101427:
        if (paramString.equals("VideoEncoder$CodecSpecificInfo"))
          s = 105; 
      case 1031415022:
        if (paramString.equals("ThreadUtils$ThreadChecker"))
          s = 104; 
      case 1014988524:
        if (paramString.equals("SurfaceTextureHelper$FrameRefMonitor"))
          s = 103; 
      case 1002696562:
        if (paramString.equals("VideoFrame$Buffer"))
          s = 102; 
      case 985953882:
        if (paramString.equals("EncodedImage$1"))
          s = 101; 
      case 985434238:
        if (paramString.equals("EglBase14Impl"))
          s = 100; 
      case 981740154:
        if (paramString.equals("EglBase10Impl"))
          s = 99; 
      case 917805331:
        if (paramString.equals("YuvConverter$1"))
          s = 98; 
      case 830021511:
        if (paramString.equals("VideoFrameDrawer$YuvUploader"))
          s = 97; 
      case 809265015:
        if (paramString.equals("ThreadUtils$4"))
          s = 96; 
      case 809265014:
        if (paramString.equals("ThreadUtils$3"))
          s = 95; 
      case 809265013:
        if (paramString.equals("ThreadUtils$2"))
          s = 94; 
      case 809265012:
        if (paramString.equals("ThreadUtils$1"))
          s = 93; 
      case 799385155:
        if (paramString.equals("VideoEncoderFallback"))
          s = 92; 
      case 774813355:
        if (paramString.equals("SurfaceTextureHelper$3"))
          s = 91; 
      case 774813354:
        if (paramString.equals("SurfaceTextureHelper$2"))
          s = 90; 
      case 774813353:
        if (paramString.equals("SurfaceTextureHelper$1"))
          s = 89; 
      case 727332363:
        if (paramString.equals("CalledByNative"))
          s = 88; 
      case 712843803:
        if (paramString.equals("VideoEncoder$CodecSpecificInfoH264"))
          s = 87; 
      case 655935895:
        if (paramString.equals("Predicate"))
          s = 86; 
      case 552598244:
        if (paramString.equals("EncodedImage$Builder"))
          s = 85; 
      case 534425677:
        if (paramString.equals("VideoCodecStatus"))
          s = 84; 
      case 531512673:
        if (paramString.equals("VideoDecoderFactory"))
          s = 83; 
      case 514481447:
        if (paramString.equals("NV21Buffer"))
          s = 82; 
      case 482352999:
        if (paramString.equals("VideoCapturer"))
          s = 81; 
      case 416582480:
        if (paramString.equals("EncodedImage$FrameType"))
          s = 80; 
      case 395279435:
        if (paramString.equals("RendererCommon$ScalingType"))
          s = 79; 
      case 393948132:
        if (paramString.equals("Logging$TraceLevel"))
          s = 78; 
      case 352458194:
        if (paramString.equals("VideoFrame"))
          s = 77; 
      case 327803371:
        if (paramString.equals("JavaI420Buffer"))
          s = 76; 
      case 277522773:
        if (paramString.equals("VideoFrame$TextureBuffer$Type"))
          s = 75; 
      case 223581196:
        if (paramString.equals("Logging$1"))
          s = 74; 
      case 200196011:
        if (paramString.equals("YuvConverter$ShaderCallbacks"))
          s = 73; 
      case 154651404:
        if (paramString.equals("VideoFrameBufferType"))
          s = 72; 
      case 128419184:
        if (paramString.equals("ApplicationContextProvider"))
          s = 71; 
      case 89650834:
        if (paramString.equals("RendererCommon$RendererEvents"))
          s = 70; 
      case 72717586:
        if (paramString.equals("VideoEncoderWrapper"))
          s = 69; 
      case 54973915:
        if (paramString.equals("TextureBufferImpl"))
          s = 68; 
      case 47779120:
        if (paramString.equals("VideoFrameDrawer$1"))
          s = 67; 
      case 33851718:
        if (paramString.equals("VideoEncoder$Settings"))
          s = 66; 
      case 11425945:
        if (paramString.equals("EglRenderer$EglSurfaceCreation"))
          s = 65; 
      case 10705187:
        if (paramString.equals("CalledByNativeUnchecked"))
          s = 64; 
      case 2577441:
        if (paramString.equals("Size"))
          s = 63; 
      case -60636123:
        if (paramString.equals("EglBase10$Context"))
          s = 62; 
      case -64281105:
        if (paramString.equals("RendererCommon$VideoLayoutMeasure"))
          s = 61; 
      case -136149541:
        if (paramString.equals("EglBase"))
          s = 60; 
      case -138678498:
        if (paramString.equals("VideoDecoder$Settings"))
          s = 59; 
      case -147426495:
        if (paramString.equals("EglRenderer$RenderListener"))
          s = 58; 
      case -171211771:
        if (paramString.equals("WrappedNativeI420Buffer"))
          s = 57; 
      case -219341593:
        if (paramString.equals("GlRectDrawer$1"))
          s = 56; 
      case -220110435:
        if (paramString.equals("EglBase10Impl$1FakeSurfaceHolder"))
          s = 55; 
      case -231861876:
        if (paramString.equals("RendererCommon$GlDrawer"))
          s = 54; 
      case -253722355:
        if (paramString.equals("EncodedImage"))
          s = 53; 
      case -263475173:
        if (paramString.equals("EglRenderer$2"))
          s = 52; 
      case -263475174:
        if (paramString.equals("EglRenderer$1"))
          s = 51; 
      case -395156216:
        if (paramString.equals("YuvHelper"))
          s = 50; 
      case -396048097:
        if (paramString.equals("ThreadUtils$1CaughtException"))
          s = 49; 
      case -398510635:
        if (paramString.equals("ThreadUtils$BlockingOperation"))
          s = 48; 
      case -453106325:
        if (paramString.equals("VideoDecoderFallback"))
          s = 47; 
      case -463874560:
        if (paramString.equals("RenderSynchronizer$Listener"))
          s = 46; 
      case -518855294:
        if (paramString.equals("EglBase14$EglConnection"))
          s = 45; 
      case -563402035:
        if (paramString.equals("EglRenderer"))
          s = 44; 
      case -565829308:
        if (paramString.equals("Histogram"))
          s = 43; 
      case -591358463:
        if (paramString.equals("RefCountDelegate"))
          s = 42; 
      case -694688284:
        if (paramString.equals("VideoEncoder$RateControlParameters"))
          s = 41; 
      case -705302361:
        if (paramString.equals("ThreadUtils"))
          s = 40; 
      case -706229150:
        if (paramString.equals("EglRenderer$ListenerManager"))
          s = 39; 
      case -715381256:
        if (paramString.equals("RenderSynchronizer"))
          s = 38; 
      case -902218558:
        if (paramString.equals("EglBase14Impl$EglConnection"))
          s = 37; 
      case -958082674:
        if (paramString.equals("VideoSink"))
          s = 36; 
      case -963060279:
        if (paramString.equals("VideoFrame$TextureBuffer"))
          s = 35; 
      case -1005796250:
        if (paramString.equals("Predicate$3"))
          s = 34; 
      case -1005796251:
        if (paramString.equals("Predicate$2"))
          s = 33; 
      case -1005796252:
        if (paramString.equals("Predicate$1"))
          s = 32; 
      case -1052864440:
        if (paramString.equals("GlGenericDrawer$ShaderCallbacks"))
          s = 31; 
      case -1076064022:
        if (paramString.equals("VideoDecoderWrapper"))
          s = 30; 
      case -1098000901:
        if (paramString.equals("RefCounted"))
          s = 29; 
      case -1100816956:
        if (paramString.equals("Priority"))
          s = 28; 
      case -1208900330:
        if (paramString.equals("VideoEncoder$ResolutionBitrateLimits"))
          s = 27; 
      case -1220935553:
        if (paramString.equals("GlRectDrawer$ShaderCallbacks"))
          s = 26; 
      case -1245267171:
        if (paramString.equals("WrappedNativeVideoEncoder"))
          s = 25; 
      case -1245970938:
        if (paramString.equals("YuvConverter"))
          s = 24; 
      case -1273113270:
        if (paramString.equals("GlShader"))
          s = 23; 
      case -1315526765:
        if (paramString.equals("JniHelper"))
          s = 22; 
      case -1331223561:
        if (paramString.equals("VideoDecoder$DecodeInfo"))
          s = 21; 
      case -1440515961:
        if (paramString.equals("EglBase10Impl$1"))
          s = 20; 
      case -1444489291:
        if (paramString.equals("SurfaceViewRenderer"))
          s = 19; 
      case -1449410096:
        if (paramString.equals("JniCommon"))
          s = 18; 
      case -1468927340:
        if (paramString.equals("EglThread"))
          s = 17; 
      case -1572999832:
        if (paramString.equals("VideoEncoder$Callback"))
          s = 16; 
      case -1590203327:
        if (paramString.equals("VideoEncoder"))
          s = 15; 
      case -1621748897:
        if (paramString.equals("EglBase$EglConnection"))
          s = 14; 
      case -1745530048:
        if (paramString.equals("VideoDecoder$Callback"))
          s = 13; 
      case -1809801271:
        if (paramString.equals("VideoCodecInfo"))
          s = 12; 
      case -1819298370:
        if (paramString.equals("EglBase10Impl$EglConnection"))
          s = 11; 
      case -1836696544:
        if (paramString.equals("SurfaceEglRenderer"))
          s = 10; 
      case -1836878975:
        if (paramString.equals("EglRenderer$FrameDrawnListenerWithContext"))
          s = 9; 
      case -1850566714:
        if (paramString.equals("EglBase$Context"))
          s = 8; 
      case -1863242395:
        if (paramString.equals("EglBase10Impl$Context"))
          s = 7; 
      case -1917266589:
        if (paramString.equals("VideoFrameDrawer"))
          s = 6; 
      case -1961044549:
        if (paramString.equals("RendererCommon$1"))
          s = 5; 
      case -1963280517:
        if (paramString.equals("VideoEncoderFactory$VideoEncoderSelector"))
          s = 4; 
      case -1990688450:
        if (paramString.equals("EglBase14"))
          s = 3; 
      case -1990688454:
        if (paramString.equals("EglBase10"))
          s = 2; 
      case -2090165143:
        if (paramString.equals("H264Utils"))
          s = 1; 
      case -2141178409:
        break;
    } 
    if (!paramString.equals("GlTextureFrameBuffer"));
    s = 0;
  }
  
  public static String A0m(String paramString, int paramInt) {
    switch (A00(paramString)) {
      default:
        0pd.A0H("VoltronModuleMetadata", 0XK.A0b("Unexpected module name: ", paramString));
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
      case 8:
      case 9:
      case 10:
      case 11:
      case 12:
      case 13:
      case 14:
      case 15:
      case 19:
      case 20:
      case 21:
      case 22:
      case 23:
      case 24:
      case 25:
      case 26:
      case 27:
      case 28:
      case 30:
      case 31:
      case 32:
      case 33:
      case 34:
      case 35:
      case 36:
      case 37:
      case 38:
      case 39:
      case 40:
      case 41:
      case 42:
      case 43:
      case 44:
      case 45:
      case 46:
      case 47:
      case 48:
      case 49:
      case 50:
      case 51:
      case 52:
      case 53:
      case 54:
      case 55:
      case 56:
      case 57:
      case 58:
      case 59:
      case 60:
      case 61:
      case 62:
      case 63:
      case 64:
      case 65:
      case 66:
      case 67:
      case 68:
      case 69:
      case 70:
      case 71:
      case 72:
      case 73:
      case 74:
      case 75:
      case 76:
      case 77:
      case 78:
      case 79:
      case 80:
      case 81:
      case 82:
      case 83:
      case 84:
      case 85:
      case 86:
      case 87:
      case 88:
      case 89:
      case 90:
      case 91:
      case 92:
      case 93:
      case 94:
      case 95:
      case 96:
      case 97:
      case 98:
      case 99:
      case 100:
      case 101:
      case 102:
      case 103:
      case 104:
      case 105:
      case 106:
      case 107:
      case 108:
      case 109:
      case 110:
      case 111:
      case 112:
      case 113:
      case 114:
      case 117:
      case 119:
      case 120:
      case 122:
      case 123:
      case 124:
      case 125:
      case 126:
      case 132:
      case 133:
      case 134:
      case 135:
      case 136:
      case 137:
      case 138:
      case 139:
      case 140:
      case 141:
      case 142:
      case 143:
      case 148:
      case 149:
      case 150:
        return null;
      case 145:
      case 146:
        if (paramInt != 0) {
          if (paramInt == 1)
            return "s_smartcropnative_smartplacementnative"; 
        } else {
          return "pytorch";
        } 
        if (paramInt == 2)
          return "s_smartcropnative_smartplacementnative_smarttrim"; 
      case 147:
        if (paramInt != 0) {
          if (paramInt != 1)
            if (paramInt == 2)
              return "s_smartcropnative_smartplacementnative_smarttrim";  
          return "s_magicmontage_smarttrim";
        } 
        return "pytorch";
      case 0:
      case 144:
        if (paramInt == 0)
          return "s_arservicesoptional_slam"; 
      case 118:
        if (paramInt == 0)
          return "securitycheckup"; 
      case 116:
        if (paramInt != 0) {
          if (paramInt != 1)
            if (paramInt == 2)
              return "instantgamesads";  
          return "cgwebrtc";
        } 
        return "cgnativeplayer";
      case 17:
      case 29:
        if (paramInt == 0)
          return "s_cgwebrtc_horizon"; 
      case 151:
        return (paramInt != 0) ? ((paramInt != 1) ? ((paramInt != 2) ? ((paramInt != 3) ? null : "s_papayatorch_torchedlooper") : "s_papayaanalyticstorch_papayatorch_torchedlooper") : "s_papaya_torchedlooper") : "pytorch";
      case 18:
      case 115:
      case 130:
      case 131:
        return (paramInt != 0) ? null : "pytorch";
      case 129:
        if (paramInt != 0) {
          if (paramInt != 1)
            return (paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? null : "s_papayatorch_torchedlooper") : "s_papayaanalyticstorch_papayatorch_torchedlooper") : "s_papayaanalyticstorch_papayatorch"; 
        } else {
          return "papaya";
        } 
        return "pytorch";
      case 128:
        if (paramInt != 0) {
          if (paramInt != 1)
            return (paramInt != 2) ? ((paramInt != 3) ? null : "s_papayaanalyticstorch_papayatorch_torchedlooper") : "s_papayaanalyticstorch_papayatorch"; 
        } else {
          return "papaya";
        } 
        return "pytorch";
      case 127:
        return (paramInt != 0) ? null : "s_papaya_torchedlooper";
      case 121:
        return (paramInt != 0) ? null : "s_magicmontage_smarttrim";
      case 16:
        break;
    } 
    return (paramInt != 0) ? null : "cgwebrtc";
  }
  
  public static boolean A0n(String paramString) {
    switch (A00(paramString)) {
      default:
        return false;
      case 30:
      case 31:
      case 32:
      case 33:
      case 34:
      case 35:
      case 36:
      case 37:
      case 38:
      case 39:
      case 40:
      case 41:
      case 42:
      case 43:
      case 44:
      case 45:
      case 46:
      case 47:
      case 48:
      case 49:
      case 50:
      case 51:
      case 52:
      case 53:
      case 54:
      case 55:
      case 56:
      case 57:
      case 58:
      case 59:
      case 60:
      case 61:
      case 62:
      case 63:
      case 64:
      case 65:
      case 66:
      case 67:
      case 68:
      case 69:
      case 70:
      case 71:
      case 72:
      case 73:
      case 74:
      case 75:
      case 76:
      case 77:
      case 78:
      case 79:
      case 80:
      case 81:
      case 82:
      case 83:
      case 84:
      case 85:
      case 86:
      case 87:
      case 88:
      case 89:
      case 90:
      case 91:
      case 92:
      case 93:
      case 94:
      case 95:
      case 96:
      case 97:
      case 98:
      case 99:
      case 100:
      case 101:
      case 102:
      case 103:
      case 104:
      case 105:
      case 106:
      case 107:
      case 108:
      case 109:
      case 110:
      case 111:
      case 112:
      case 113:
      case 114:
        break;
    } 
    return true;
  }
  
  public static String getModuleName(int paramInt) {
    switch (paramInt) {
      default:
        0pd.A0H("VoltronModuleMetadata", 0XK.A0Z("Unexpected module index: ", paramInt));
        return null;
      case 151:
        return "torchedlooper";
      case 150:
        return "testmodule";
      case 149:
        return "surveyplatformremixnt";
      case 148:
        return "supmediastreamcontroller";
      case 147:
        return "smarttrim";
      case 146:
        return "smartplacementnative";
      case 145:
        return "smartcropnative";
      case 144:
        return "slam";
      case 143:
        return "securitycheckup";
      case 142:
        return "s_smartcropnative_smartplacementnative_smarttrim";
      case 141:
        return "s_smartcropnative_smartplacementnative";
      case 140:
        return "s_papayatorch_torchedlooper";
      case 139:
        return "s_papayaanalyticstorch_papayatorch_torchedlooper";
      case 138:
        return "s_papayaanalyticstorch_papayatorch";
      case 137:
        return "s_papaya_torchedlooper";
      case 136:
        return "s_magicmontage_smarttrim";
      case 135:
        return "s_cgwebrtc_horizon";
      case 134:
        return "s_arservicesoptional_slam";
      case 133:
        return "rtcdeps";
      case 132:
        return "pytorch";
      case 131:
        return "pvdcontextprediction";
      case 130:
        return "photo3djni";
      case 129:
        return "papayatorch";
      case 128:
        return "papayaanalyticstorch";
      case 127:
        return "papaya";
      case 126:
        return "pages";
      case 125:
        return "nrib";
      case 124:
        return "mobileconfig";
      case 123:
        return "mlplayground";
      case 122:
        return "metaaivoiceclient";
      case 121:
        return "magicmontage";
      case 120:
        return "longtail";
      case 119:
        return "location";
      case 118:
        return "internsettings";
      case 117:
        return "instantgamesads";
      case 116:
        return "instantgames";
      case 115:
        return "iddetectorpytorch";
      case 114:
        return "i18n_zu_ZA";
      case 113:
        return "i18n_zh_TW";
      case 112:
        return "i18n_zh_HK";
      case 111:
        return "i18n_zh_CN";
      case 110:
        return "i18n_wo_SN";
      case 109:
        return "i18n_vi_VN";
      case 108:
        return "i18n_uz_UZ";
      case 107:
        return "i18n_ur_PK";
      case 106:
        return "i18n_uk_UA";
      case 105:
        return "i18n_tr_TR";
      case 104:
        return "i18n_tl_PH";
      case 103:
        return "i18n_tk_TM";
      case 102:
        return "i18n_th_TH";
      case 101:
        return "i18n_tg_TJ";
      case 100:
        return "i18n_te_IN";
      case 99:
        return "i18n_ta_IN";
      case 98:
        return "i18n_sw_KE";
      case 97:
        return "i18n_sv_SE";
      case 96:
        return "i18n_sr_RS";
      case 95:
        return "i18n_sq_AL";
      case 94:
        return "i18n_so_SO";
      case 93:
        return "i18n_sn_ZW";
      case 92:
        return "i18n_sl_SI";
      case 91:
        return "i18n_sk_SK";
      case 90:
        return "i18n_si_LK";
      case 89:
        return "i18n_ru_RU";
      case 88:
        return "i18n_ro_RO";
      case 87:
        return "i18n_qz_MM";
      case 86:
        return "i18n_pt_PT";
      case 85:
        return "i18n_pt_BR";
      case 84:
        return "i18n_ps_AF";
      case 83:
        return "i18n_pl_PL";
      case 82:
        return "i18n_pa_IN";
      case 81:
        return "i18n_nl_NL";
      case 80:
        return "i18n_ne_NP";
      case 79:
        return "i18n_nb_NO";
      case 78:
        return "i18n_my_MM";
      case 77:
        return "i18n_ms_MY";
      case 76:
        return "i18n_mr_IN";
      case 75:
        return "i18n_mn_MN";
      case 74:
        return "i18n_ml_IN";
      case 73:
        return "i18n_mk_MK";
      case 72:
        return "i18n_lv_LV";
      case 71:
        return "i18n_lt_LT";
      case 70:
        return "i18n_lo_LA";
      case 69:
        return "i18n_ky_KG";
      case 68:
        return "i18n_ku_TR";
      case 67:
        return "i18n_ko_KR";
      case 66:
        return "i18n_kn_IN";
      case 65:
        return "i18n_km_KH";
      case 64:
        return "i18n_kk_KZ";
      case 63:
        return "i18n_ka_GE";
      case 62:
        return "i18n_jv_ID";
      case 61:
        return "i18n_ja_JP";
      case 60:
        return "i18n_it_IT";
      case 59:
        return "i18n_is_IS";
      case 58:
        return "i18n_id_ID";
      case 57:
        return "i18n_hy_AM";
      case 56:
        return "i18n_hu_HU";
      case 55:
        return "i18n_hr_HR";
      case 54:
        return "i18n_hi_IN";
      case 53:
        return "i18n_he_IL";
      case 52:
        return "i18n_gu_IN";
      case 51:
        return "i18n_fr_FR";
      case 50:
        return "i18n_fi_FI";
      case 49:
        return "i18n_fb_HA";
      case 48:
        return "i18n_fa_IR";
      case 47:
        return "i18n_et_EE";
      case 46:
        return "i18n_es_LA";
      case 45:
        return "i18n_es_ES";
      case 44:
        return "i18n_en_GB";
      case 43:
        return "i18n_el_GR";
      case 42:
        return "i18n_de_DE";
      case 41:
        return "i18n_da_DK";
      case 40:
        return "i18n_cs_CZ";
      case 39:
        return "i18n_cb_IQ";
      case 38:
        return "i18n_ca_ES";
      case 37:
        return "i18n_bs_BA";
      case 36:
        return "i18n_bn_IN";
      case 35:
        return "i18n_bg_BG";
      case 34:
        return "i18n_be_BY";
      case 33:
        return "i18n_az_AZ";
      case 32:
        return "i18n_as_IN";
      case 31:
        return "i18n_ar_AR";
      case 30:
        return "i18n_af_ZA";
      case 29:
        return "horizon";
      case 28:
        return "hermessnapshot";
      case 27:
        return "heliumiabexp";
      case 26:
        return "heliumiab";
      case 25:
        return "groupsadminactivity";
      case 24:
        return "groupsadmin";
      case 23:
        return "executorch";
      case 22:
        return "eventsguestlist";
      case 21:
        return "diverse";
      case 20:
        return "d_native_raw_v5";
      case 19:
        return "d2_native_ab_test_libdav1dexo_test_142_upgrade";
      case 18:
        return "creditcardscanner";
      case 17:
        return "cgwebrtc";
      case 16:
        return "cgnativeplayer";
      case 15:
        return "baseline_profiles_9_11_vdex_stored_in_dm";
      case 14:
        return "baseline_profiles_9_11_vdex_stored_cntrl_in_dm";
      case 13:
        return "baseline_profiles_9_11_vdex_in_dm";
      case 12:
        return "baseline_profiles_9_11_reels_scroll";
      case 11:
        return "baseline_profiles_9_11_no_sv";
      case 10:
        return "baseline_profiles_9_11_no_gm";
      case 9:
        return "baseline_profiles_9_11";
      case 8:
        return "baseline_profiles_12_plus_vdex_stored_in_dm";
      case 7:
        return "baseline_profiles_12_plus_vdex_stored_cntrl_in_dm";
      case 6:
        return "baseline_profiles_12_plus_vdex_in_dm";
      case 5:
        return "baseline_profiles_12_plus_reels_scroll";
      case 4:
        return "baseline_profiles_12_plus_no_sv";
      case 3:
        return "baseline_profiles_12_plus_no_gm";
      case 2:
        return "baseline_profiles_12_plus";
      case 1:
        return "awesomizer";
      case 0:
        break;
    } 
    return "arservicesoptional";
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\02Y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */