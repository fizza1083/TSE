package X;

import androidx.fragment.app.Fragment;

public abstract class 08s extends RuntimeException {
  public final Fragment fragment;
  
  public 08s(String paramString, Fragment paramFragment) {
    super(paramString);
    this.fragment = paramFragment;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */