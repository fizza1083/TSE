package X;

import android.content.Context;
import android.content.IntentFilter;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

@Deprecated
public abstract class 01W extends 01X {
  public IntentFilter A00;
  
  public Collection A01;
  
  public final 0Xi A02;
  
  public 01W(03H param03H1, 03H param03H2, 03H param03H3) {
    0Xi 0Xi1 = new 0Xi(3);
    this.A02 = 0Xi1;
    0Xi1.put("android.net.wifi.supplicant.CONNECTION_CHANGE", param03H1);
    0Xi1.put("android.net.wifi.STATE_CHANGE", param03H2);
    0Xi1.put("android.net.conn.CONNECTIVITY_CHANGE", param03H3);
  }
  
  public 01W(03H param03H1, 03H param03H2, 03H param03H3, 03H param03H4, String paramString1, String paramString2, String paramString3, String paramString4) {
    0Xi 0Xi1 = new 0Xi(4);
    this.A02 = 0Xi1;
    01X.A00(paramString1);
    0Xi1.put(paramString1, param03H1);
    01X.A00(paramString2);
    0Xi1.put(paramString2, param03H2);
    01X.A00(paramString3);
    0Xi1.put(paramString3, param03H3);
    01X.A00(paramString4);
    0Xi1.put(paramString4, param03H4);
  }
  
  public 01W(03H param03H1, 03H param03H2, String paramString1, String paramString2) {
    0Xi 0Xi1 = new 0Xi(2);
    this.A02 = 0Xi1;
    01X.A00(param03H1);
    0Xi1.put(paramString1, param03H1);
    01X.A00(param03H2);
    0Xi1.put(paramString2, param03H2);
  }
  
  public 01W(03H param03H, String paramString) {
    0Xi 0Xi1 = new 0Xi(1);
    this.A02 = 0Xi1;
    01X.A00(paramString);
    0Xi1.put(paramString, param03H);
  }
  
  public 01W(Iterator<Map.Entry> paramIterator) {
    01X.A00(paramIterator);
    this.A02 = new 0Xi(0);
    while (paramIterator.hasNext()) {
      Map.Entry entry = paramIterator.next();
      if (this.A02.put(entry.getKey(), entry.getValue()) != null)
        throw 0XK.A07("action ", 001.A0r(entry), " found more than once in action map"); 
    } 
    if (!this.A02.isEmpty())
      return; 
    throw 001.A0O("Must include an entry for at least one action");
  }
  
  public final 03H A01(Context paramContext, String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield A02 : LX/0Xi;
    //   6: aload_2
    //   7: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   10: checkcast X/03H
    //   13: astore_1
    //   14: aload_0
    //   15: monitorexit
    //   16: aload_1
    //   17: areturn
    //   18: astore_1
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_1
    //   22: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	18	finally
  }
  
  public final boolean A05(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield A01 : Ljava/util/Collection;
    //   6: astore #4
    //   8: aload #4
    //   10: ifnull -> 28
    //   13: aload #4
    //   15: aload_1
    //   16: invokeinterface contains : (Ljava/lang/Object;)Z
    //   21: istore_3
    //   22: iconst_1
    //   23: istore_2
    //   24: iload_3
    //   25: ifne -> 30
    //   28: iconst_0
    //   29: istore_2
    //   30: aload_0
    //   31: monitorexit
    //   32: iload_2
    //   33: ireturn
    //   34: astore_1
    //   35: aload_0
    //   36: monitorexit
    //   37: aload_1
    //   38: athrow
    // Exception table:
    //   from	to	target	type
    //   2	8	34	finally
    //   13	22	34	finally
  }
  
  public final IntentFilter A06() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield A00 : Landroid/content/IntentFilter;
    //   6: ifnonnull -> 59
    //   9: aload_0
    //   10: new android/content/IntentFilter
    //   13: dup
    //   14: invokespecial <init> : ()V
    //   17: putfield A00 : Landroid/content/IntentFilter;
    //   20: iconst_0
    //   21: istore_1
    //   22: aload_0
    //   23: getfield A02 : LX/0Xi;
    //   26: astore_3
    //   27: aload_3
    //   28: invokevirtual size : ()I
    //   31: istore_2
    //   32: iload_1
    //   33: iload_2
    //   34: if_icmpge -> 59
    //   37: aload_0
    //   38: getfield A00 : Landroid/content/IntentFilter;
    //   41: aload_3
    //   42: iload_1
    //   43: invokevirtual A05 : (I)Ljava/lang/Object;
    //   46: checkcast java/lang/String
    //   49: invokevirtual addAction : (Ljava/lang/String;)V
    //   52: iload_1
    //   53: iconst_1
    //   54: iadd
    //   55: istore_1
    //   56: goto -> 32
    //   59: aload_0
    //   60: getfield A00 : Landroid/content/IntentFilter;
    //   63: astore_3
    //   64: aload_0
    //   65: monitorexit
    //   66: aload_3
    //   67: areturn
    //   68: astore_3
    //   69: aload_0
    //   70: monitorexit
    //   71: aload_3
    //   72: athrow
    // Exception table:
    //   from	to	target	type
    //   2	20	68	finally
    //   22	32	68	finally
    //   37	52	68	finally
    //   59	64	68	finally
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01W.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */