package X;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class 01g {
  public int A00;
  
  public ArrayList A01;
  
  public List A02;
  
  public 01g() {
    ArrayList<?> arrayList = new ArrayList();
    this.A01 = arrayList;
    this.A02 = Collections.unmodifiableList(arrayList);
  }
  
  public final List A00() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield A02 : Ljava/util/List;
    //   6: astore_1
    //   7: aload_0
    //   8: aload_0
    //   9: getfield A00 : I
    //   12: iconst_1
    //   13: iadd
    //   14: putfield A00 : I
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_1
    //   20: areturn
    //   21: astore_1
    //   22: aload_0
    //   23: monitorexit
    //   24: aload_1
    //   25: athrow
    // Exception table:
    //   from	to	target	type
    //   2	17	21	finally
  }
  
  public final void A01() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield A00 : I
    //   6: ifle -> 29
    //   9: invokestatic A0y : ()Ljava/util/ArrayList;
    //   12: astore_1
    //   13: aload_0
    //   14: aload_1
    //   15: putfield A01 : Ljava/util/ArrayList;
    //   18: aload_0
    //   19: aload_1
    //   20: invokestatic unmodifiableList : (Ljava/util/List;)Ljava/util/List;
    //   23: putfield A02 : Ljava/util/List;
    //   26: goto -> 36
    //   29: aload_0
    //   30: getfield A01 : Ljava/util/ArrayList;
    //   33: invokevirtual clear : ()V
    //   36: aload_0
    //   37: monitorexit
    //   38: return
    //   39: astore_1
    //   40: aload_0
    //   41: monitorexit
    //   42: aload_1
    //   43: athrow
    // Exception table:
    //   from	to	target	type
    //   2	26	39	finally
    //   29	36	39	finally
  }
  
  public final void A02() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_0
    //   4: getfield A00 : I
    //   7: iconst_1
    //   8: isub
    //   9: putfield A00 : I
    //   12: aload_0
    //   13: monitorexit
    //   14: return
    //   15: astore_1
    //   16: aload_0
    //   17: monitorexit
    //   18: aload_1
    //   19: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	15	finally
  }
  
  public final void A03(Object paramObject) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield A00 : I
    //   6: ifle -> 76
    //   9: aload_0
    //   10: getfield A01 : Ljava/util/ArrayList;
    //   13: astore #4
    //   15: aload #4
    //   17: invokevirtual size : ()I
    //   20: istore_3
    //   21: new java/util/ArrayList
    //   24: dup
    //   25: iload_3
    //   26: iconst_1
    //   27: iadd
    //   28: invokespecial <init> : (I)V
    //   31: astore #5
    //   33: aload_0
    //   34: aload #5
    //   36: putfield A01 : Ljava/util/ArrayList;
    //   39: aload_0
    //   40: aload #5
    //   42: invokestatic unmodifiableList : (Ljava/util/List;)Ljava/util/List;
    //   45: putfield A02 : Ljava/util/List;
    //   48: iconst_0
    //   49: istore_2
    //   50: iload_2
    //   51: iload_3
    //   52: if_icmpge -> 76
    //   55: aload_0
    //   56: getfield A01 : Ljava/util/ArrayList;
    //   59: aload #4
    //   61: iload_2
    //   62: invokevirtual get : (I)Ljava/lang/Object;
    //   65: invokevirtual add : (Ljava/lang/Object;)Z
    //   68: pop
    //   69: iload_2
    //   70: iconst_1
    //   71: iadd
    //   72: istore_2
    //   73: goto -> 50
    //   76: aload_0
    //   77: getfield A01 : Ljava/util/ArrayList;
    //   80: aload_1
    //   81: invokevirtual add : (Ljava/lang/Object;)Z
    //   84: pop
    //   85: aload_0
    //   86: monitorexit
    //   87: return
    //   88: astore_1
    //   89: aload_0
    //   90: monitorexit
    //   91: aload_1
    //   92: athrow
    // Exception table:
    //   from	to	target	type
    //   2	48	88	finally
    //   55	69	88	finally
    //   76	85	88	finally
  }
  
  public final void A04(Object paramObject) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield A01 : Ljava/util/ArrayList;
    //   6: aload_1
    //   7: invokevirtual contains : (Ljava/lang/Object;)Z
    //   10: ifne -> 18
    //   13: aload_0
    //   14: aload_1
    //   15: invokevirtual A03 : (Ljava/lang/Object;)V
    //   18: aload_0
    //   19: monitorexit
    //   20: return
    //   21: astore_1
    //   22: aload_0
    //   23: monitorexit
    //   24: aload_1
    //   25: athrow
    // Exception table:
    //   from	to	target	type
    //   2	18	21	finally
  }
  
  public final void A05(Object paramObject) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield A00 : I
    //   6: ifgt -> 21
    //   9: aload_0
    //   10: getfield A01 : Ljava/util/ArrayList;
    //   13: aload_1
    //   14: invokevirtual remove : (Ljava/lang/Object;)Z
    //   17: pop
    //   18: goto -> 102
    //   21: aload_0
    //   22: getfield A01 : Ljava/util/ArrayList;
    //   25: aload_1
    //   26: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   29: istore_3
    //   30: iconst_0
    //   31: istore_2
    //   32: iload_3
    //   33: iflt -> 102
    //   36: aload_0
    //   37: getfield A01 : Ljava/util/ArrayList;
    //   40: astore_1
    //   41: aload_1
    //   42: invokevirtual size : ()I
    //   45: istore #4
    //   47: new java/util/ArrayList
    //   50: dup
    //   51: iload #4
    //   53: iconst_1
    //   54: isub
    //   55: invokespecial <init> : (I)V
    //   58: astore #5
    //   60: aload_0
    //   61: aload #5
    //   63: putfield A01 : Ljava/util/ArrayList;
    //   66: aload_0
    //   67: aload #5
    //   69: invokestatic unmodifiableList : (Ljava/util/List;)Ljava/util/List;
    //   72: putfield A02 : Ljava/util/List;
    //   75: iload_2
    //   76: iload #4
    //   78: if_icmpge -> 102
    //   81: iload_2
    //   82: iload_3
    //   83: if_icmpeq -> 110
    //   86: aload_0
    //   87: getfield A01 : Ljava/util/ArrayList;
    //   90: aload_1
    //   91: iload_2
    //   92: invokevirtual get : (I)Ljava/lang/Object;
    //   95: invokevirtual add : (Ljava/lang/Object;)Z
    //   98: pop
    //   99: goto -> 110
    //   102: aload_0
    //   103: monitorexit
    //   104: return
    //   105: astore_1
    //   106: aload_0
    //   107: monitorexit
    //   108: aload_1
    //   109: athrow
    //   110: iload_2
    //   111: iconst_1
    //   112: iadd
    //   113: istore_2
    //   114: goto -> 75
    // Exception table:
    //   from	to	target	type
    //   2	18	105	finally
    //   21	30	105	finally
    //   36	75	105	finally
    //   86	99	105	finally
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */