package X;

public abstract class 04G implements 04H {
  public final 04R key;
  
  public 04G(04R param04R) {
    this.key = param04R;
  }
  
  public Object fold(Object paramObject, 053 param053) {
    16F.A0E(param053, 2);
    return param053.invoke(paramObject, this);
  }
  
  public 04H get(04R param04R) {
    return 04z.A00(this, param04R);
  }
  
  public 04R getKey() {
    return this.key;
  }
  
  public 04I minusKey(04R param04R) {
    return 04z.A01(this, param04R);
  }
  
  public 04I plus(04I param04I) {
    return 04z.A02(this, param04I);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\04G.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */