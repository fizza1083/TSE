package X;

import com.facebook.quicklog.QuickPerformanceLogger;

public interface 06J {
  void Dbv(int paramInt1, int paramInt2, String paramString, int paramInt3);
  
  void Dbw(int paramInt1, int paramInt2, String paramString1, String paramString2);
  
  void Dbx(int paramInt1, int paramInt2);
  
  void Dby(int paramInt1, int paramInt2);
  
  void Dbz(int paramInt1, int paramInt2, String paramString);
  
  void Dc0(int paramInt1, int paramInt2, boolean paramBoolean);
  
  void Dc1();
  
  void Dc2(int paramInt1, int paramInt2, boolean paramBoolean);
  
  void setQuickPerformanceLogger(QuickPerformanceLogger paramQuickPerformanceLogger);
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\06J.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */