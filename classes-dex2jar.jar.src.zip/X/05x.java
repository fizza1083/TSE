package X;

public abstract class 05x {
  public static final Object A00(Object paramObject, 05D param05D, 053 param053) {
    16F.A0E(param053, 0);
    04I 04I = param05D.B2c();
    if (04I == 050.A00) {
      param05D = new 0je(param05D);
      0AZ.A03(param053, 2);
      return param053.invoke(paramObject, param05D);
    } 
    param05D = new 0jP(param05D, 04I);
    0AZ.A03(param053, 2);
    return param053.invoke(paramObject, param05D);
  }
  
  public static final 05D A01(Object paramObject, 05D param05D, 053 param053) {
    16F.A0E(param053, 0);
    if (param053 instanceof 05C)
      return ((05C)param053).A0A(paramObject, param05D); 
    04I 04I = param05D.B2c();
    return (05D)((04I == 050.A00) ? new 0kA(paramObject, param05D, param053) : new 0jk(paramObject, param05D, 04I, param053));
  }
  
  public static final 05D A02(05D param05D) {
    16F.A0E(param05D, 0);
    05D 05D1 = param05D;
    if (param05D instanceof 05B) {
      05B 05B = (05B)param05D;
      05D1 = param05D;
      if (05B != null) {
        param05D = 05B.A00;
        05D1 = param05D;
        if (param05D == null) {
          04K 04K = (04K)05B.B2c().get(04K.A00);
          if (04K != null) {
            05D1 = new 05y(05B, (04F)04K);
          } else {
            05D1 = 05B;
          } 
          05B.A00 = 05D1;
        } 
      } 
    } 
    return 05D1;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\05x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */