package X;

public final class 02T implements 0qz {
  public 0qz A00;
  
  public final 0qi A01;
  
  public 02T(0rz param0rz, 186 param186) {
    0qi 0qi1 = param0rz.A00;
    0ah.A04(0qi1, "Did you call earlyInit()?");
    this.A01 = 0qi1;
  }
  
  private 0qz A00() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield A00 : LX/0qz;
    //   6: ifnonnull -> 34
    //   9: aload_0
    //   10: getfield A01 : LX/0qi;
    //   13: ldc X/0jr
    //   15: invokevirtual getDetectorByClass : (Ljava/lang/Class;)Ljava/lang/Object;
    //   18: checkcast X/0jr
    //   21: astore_1
    //   22: aload_1
    //   23: ifnull -> 34
    //   26: aload_0
    //   27: aload_1
    //   28: getfield A0F : LX/0qz;
    //   31: putfield A00 : LX/0qz;
    //   34: aload_0
    //   35: getfield A00 : LX/0qz;
    //   38: astore_1
    //   39: aload_0
    //   40: monitorexit
    //   41: aload_1
    //   42: areturn
    //   43: astore_1
    //   44: aload_0
    //   45: monitorexit
    //   46: aload_1
    //   47: athrow
    // Exception table:
    //   from	to	target	type
    //   2	22	43	finally
    //   26	34	43	finally
    //   34	39	43	finally
  }
  
  public final void D3h() {
    0qz 0qz1 = A00();
    if (0qz1 != null)
      0qz1.D3h(); 
  }
  
  public final void D3i() {
    0qz 0qz1 = A00();
    if (0qz1 != null)
      0qz1.D3i(); 
  }
  
  public final void DDD() {
    0qz 0qz1 = A00();
    if (0qz1 != null)
      0qz1.DDD(); 
  }
  
  public final void onSigquit() {
    0qz 0qz1 = A00();
    if (0qz1 != null)
      0qz1.onSigquit(); 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\02T.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */