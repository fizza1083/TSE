package X;

import android.view.View;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;

public final class 08z {
  public float A00;
  
  public int A01;
  
  public int A02;
  
  public int A03;
  
  public int A04;
  
  public int A05;
  
  public View A06;
  
  public 090 A07;
  
  public 090 A08;
  
  public Boolean A09;
  
  public Boolean A0A;
  
  public Object A0B = null;
  
  public Object A0C;
  
  public Object A0D;
  
  public Object A0E;
  
  public Object A0F;
  
  public Object A0G;
  
  public ArrayList A0H;
  
  public ArrayList A0I;
  
  public boolean A0J;
  
  public boolean A0K;
  
  public 08z() {
    Object object = Fragment.USE_DEFAULT_TRANSITION;
    this.A0E = object;
    this.A0C = null;
    this.A0D = object;
    this.A0F = null;
    this.A0G = object;
    this.A07 = null;
    this.A08 = null;
    this.A00 = 1.0F;
    this.A06 = null;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */