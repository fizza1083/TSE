package X;

import android.view.View;
import android.view.WindowInsets;

public final class 083 implements View.OnApplyWindowInsetsListener {
  public 07N A00 = null;
  
  public 083(View paramView, 081 param081) {}
  
  public final WindowInsets onApplyWindowInsets(View paramView, WindowInsets paramWindowInsets) {
    07N 07N1 = 07N.A00(paramView, paramWindowInsets);
    this.A00 = 07N1;
    return this.A02.CRQ(paramView, 07N1).A05();
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\083.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */