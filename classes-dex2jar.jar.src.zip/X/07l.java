package X;

public interface 07l {
  07l AFl(String paramString, double paramDouble);
  
  07l AFm(String paramString, int paramInt);
  
  07l AFn(String paramString, long paramLong);
  
  07l AFo(String paramString1, String paramString2);
  
  07l AFp(String paramString, boolean paramBoolean);
  
  07l AFq(String paramString, String[] paramArrayOfString);
  
  07l Dne(Throwable paramThrowable);
  
  boolean isSampled();
  
  void report();
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */