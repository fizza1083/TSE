package X;

import android.view.View;
import android.view.ViewTreeObserver;
import java.util.WeakHashMap;

public final class 07z implements View.OnAttachStateChangeListener, ViewTreeObserver.OnGlobalLayoutListener {
  public final WeakHashMap A00 = new WeakHashMap<Object, Object>();
  
  public final void onGlobalLayout() {}
  
  public final void onViewAttachedToWindow(View paramView) {
    paramView.getViewTreeObserver().addOnGlobalLayoutListener(this);
  }
  
  public final void onViewDetachedFromWindow(View paramView) {}
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */