package X;

public interface 07x {
  0ap D5r(0ap param0ap);
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */