package X;

import java.util.concurrent.Semaphore;

public final class 00s {
  public int A00 = 1;
  
  public final Semaphore A01 = new Semaphore(1);
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */