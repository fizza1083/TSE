package X;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

public class 04y {
  public static final 04y A00(04y param04y) {
    04y 04y1;
    label30: while (true) {
      AtomicReferenceFieldUpdater<04y, 04y> atomicReferenceFieldUpdater = A01;
      04y 04y2 = atomicReferenceFieldUpdater.get(param04y);
      04y1 = 04y2;
      label29: while (true) {
        04y 04y3 = null;
        while (true) {
          AtomicReferenceFieldUpdater<04y, Object> atomicReferenceFieldUpdater1 = A00;
          04y 04y4 = (04y)atomicReferenceFieldUpdater1.get(04y1);
          if (04y4 == param04y) {
            if (04y2 != 04y1 && !05v.A00(param04y, 04y2, 04y1, atomicReferenceFieldUpdater))
              continue label30; 
            break;
          } 
          if (param04y.A03())
            return null; 
          if (04y4 != null) {
            if (04y4 instanceof 05u) {
              ((05u)04y4).A00(04y1);
              continue label30;
            } 
            if (04y4 instanceof 0Iq) {
              if (04y3 != null) {
                if (05v.A00(04y3, 04y1, ((0Iq)04y4).A00, atomicReferenceFieldUpdater1)) {
                  04y1 = 04y3;
                  continue label29;
                } 
                continue label30;
              } 
              04y1 = atomicReferenceFieldUpdater.get(04y1);
              continue;
            } 
            04y 04y5 = 04y4;
            04y3 = 04y1;
            04y1 = 04y5;
            continue;
          } 
          break;
        } 
        break;
      } 
      break;
    } 
    return 04y1;
  }
  
  public final Object A01() {
    AtomicReferenceFieldUpdater<04y, Object> atomicReferenceFieldUpdater = A00;
    while (true) {
      05u 05u = (05u)atomicReferenceFieldUpdater.get(this);
      if (!(05u instanceof 05u))
        return 05u; 
      ((05u)05u).A00(this);
    } 
  }
  
  public final 04y A02() {
    Object object = A01();
    if (object instanceof 0Iq) {
      0Iq 0Iq = (0Iq)object;
      if (0Iq != null) {
        04y 04y2 = 0Iq.A00;
        04y 04y1 = 04y2;
        if (04y2 == null) {
          16F.A0I(object, "null cannot be cast to non-null type kotlinx.coroutines.internal.LockFreeLinkedListNode{ kotlinx.coroutines.internal.LockFreeLinkedListKt.Node }");
          return (04y)object;
        } 
        return 04y1;
      } 
    } 
    16F.A0I(object, "null cannot be cast to non-null type kotlinx.coroutines.internal.LockFreeLinkedListNode{ kotlinx.coroutines.internal.LockFreeLinkedListKt.Node }");
    return (04y)object;
  }
  
  public boolean A03() {
    return A01() instanceof 0Iq;
  }
  
  public String toString() {
    StringBuilder stringBuilder = 001.A0s();
    stringBuilder.append(new 0Y9(this));
    stringBuilder.append('@');
    002.A0w(stringBuilder, this);
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\04y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */