package X;

import com.facebook.quicklog.LightweightQuickPerformanceLogger;
import java.util.List;
import java.util.concurrent.TimeUnit;

public abstract class 00h {
  public 00c A00;
  
  public 00f A01;
  
  public boolean A02;
  
  public static LightweightQuickPerformanceLogger A00(00h param00h) {
    00f 00f1 = param00h.A01;
    return (00f1 == null) ? null : (LightweightQuickPerformanceLogger)00f1.A00.get();
  }
  
  private void A01(String paramString) {
    if (this.A02 && A00(this) != null)
      A00(this).markerPoint(157825012, paramString); 
  }
  
  private final void A02(Throwable paramThrowable) {
    0pd.A0J("Fixie", "exception in FixieInitializer", paramThrowable);
    00f 00f1 = this.A01;
    if (00f1 != null && 00f1.A01.get() != null) {
      03w 03w;
      00f1 = this.A01;
      if (00f1 == null) {
        00f1 = null;
      } else {
        03w = (03w)00f1.A01.get();
      } 
      07l 07l = 03w.ALK(001.A0L(), "FixieInitializer", 817901561);
      07l.Dne(paramThrowable);
      07l.report();
    } 
  }
  
  public abstract List A03(00c param00c, Integer paramInteger);
  
  public final void A04(00o param00o) {
    try {
      String str = param00o.getName();
      A01(0XK.A0b(str, "_start"));
      00f 00f1 = this.A01;
      if (00f1 != null)
        ((00n)param00o).A00 = 00f1; 
      return;
    } finally {
      param00o = null;
      A02((Throwable)param00o);
    } 
  }
  
  public final void A05(Integer paramInteger) {
    try {
      if (!this.A02) {
        this.A02 = true;
        if (A00(this) != null) {
          long l;
          LightweightQuickPerformanceLogger lightweightQuickPerformanceLogger = A00(this);
          if (0qK.A05 == null) {
            l = 0L;
          } else {
            l = 0qK.A05.A00;
          } 
          lightweightQuickPerformanceLogger.markerStart(157825012, 0, l, TimeUnit.MILLISECONDS);
        } 
      } 
      List list = A03(this.A00, paramInteger);
    } finally {
      paramInteger = null;
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */