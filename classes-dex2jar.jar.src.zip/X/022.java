package X;

import java.io.File;

public final class 022 extends 0in {
  public final 0qe A01(0r7 param0r7) {
    0jQ 0jQ = 0jQ.A00();
    0in.A00(0qV.A6w, 0jQ, param0r7.prefix, "javascript");
    return 0jQ;
  }
  
  public final 0sj A02() {
    return 0sj.A0D;
  }
  
  public final Integer A03() {
    return 0Xy.A01;
  }
  
  public final void A04(0r7 param0r7, File paramFile1, File paramFile2) {
    if (param0r7 == 0r7.A02)
      super.A04(param0r7, paramFile1, paramFile2); 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\022.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */