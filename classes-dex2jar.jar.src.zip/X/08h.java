package X;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public abstract class 08h extends BroadcastReceiver implements 01Y {
  public 08l mScope;
  
  private final boolean verifyOnReceiveShouldContinue(Context paramContext, Intent paramIntent) {
    String str = paramIntent.getAction();
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (str != null) {
      Object object = getEndpointObject(str);
      bool1 = bool2;
      if (09g.A03().A02(paramContext, paramIntent, object)) {
        bool1 = bool2;
        if (verifyReceiverScope(paramContext, paramIntent))
          bool1 = true; 
      } 
    } 
    return bool1;
  }
  
  public String getEndpointName(Context paramContext) {
    return 0XK.A0d(paramContext.getPackageName(), getClass().getName(), '/');
  }
  
  public abstract Object getEndpointObject(String paramString);
  
  public 09r getIntentLogger() {
    return 09p.A00;
  }
  
  public 08l getIntentScope() {
    return this.mScope;
  }
  
  public abstract String getTag();
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    int i = 0Eb.A01(-1791394330);
    boolean bool = verifyOnReceiveShouldContinue(paramContext, paramIntent);
    09q 09q = 09p.A00;
    String str = getEndpointName(paramContext);
    if (bool) {
      09q.A00(paramIntent, str, null, "allow");
      0Eb.A0D(1434617652, i, paramIntent);
      return;
    } 
    09q.A00(paramIntent, str, null, "deny");
    SecurityException securityException = new SecurityException("The received intent failed one or more security checks, so no further action is allowed.");
    0Eb.A0D(2092530903, i, paramIntent);
    throw securityException;
  }
  
  public final boolean verifyReceiverScope(Context paramContext, Intent paramIntent) {
    08l 08l1 = this.mScope;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (08l1 != null) {
      bool1 = bool2;
      if (08l1.AkD(this, paramContext, paramIntent, null) != null)
        bool1 = true; 
    } 
    return bool1;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */