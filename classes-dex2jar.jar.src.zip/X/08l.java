package X;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import java.util.List;

public interface 08l {
  Intent Ak9(Context paramContext, Intent paramIntent, String paramString);
  
  List AkA(Context paramContext, Intent paramIntent, String paramString);
  
  Intent AkD(BroadcastReceiver paramBroadcastReceiver, Context paramContext, Intent paramIntent, String paramString);
  
  Intent AkE(Context paramContext, Intent paramIntent, String paramString);
  
  0RE BfO();
  
  boolean Bhk();
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */