package X;

import android.view.WindowInsets;
import java.util.Arrays;

public class 07T {
  public static final 07N A01;
  
  public final 07N A00;
  
  static {
    new 07N();
    WindowInsets windowInsets = (new WindowInsets.Builder()).build();
    windowInsets.getClass();
    A01 = (((new 07N(windowInsets)).A00.A06()).A00.A07()).A00.A08();
  }
  
  public 07T(07N param07N) {
    this.A00 = param07N;
  }
  
  public 07U A01() {
    return A04();
  }
  
  public 07U A02() {
    return 07U.A04;
  }
  
  public 07U A03() {
    return A04();
  }
  
  public 07U A04() {
    return 07U.A04;
  }
  
  public 09L A05() {
    return null;
  }
  
  public 07N A06() {
    return this.A00;
  }
  
  public 07N A07() {
    return this.A00;
  }
  
  public 07N A08() {
    return this.A00;
  }
  
  public 07N A09(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return A01;
  }
  
  public void A0A(07N param07N) {}
  
  public boolean A0B() {
    return false;
  }
  
  public boolean A0C() {
    return false;
  }
  
  public 07U A0D(int paramInt) {
    return 07U.A04;
  }
  
  public 07U A0E(int paramInt) {
    return 07U.A04;
  }
  
  public boolean A0F(int paramInt) {
    return true;
  }
  
  public boolean equals(Object paramObject) {
    boolean bool = true;
    if (this != paramObject) {
      if (!(paramObject instanceof 07T))
        return false; 
      paramObject = paramObject;
      if (A0C() == paramObject.A0C() && A0B() == paramObject.A0B() && 0B3.A00(A04(), paramObject.A04()) && 0B3.A00(A02(), paramObject.A02()) && 0B3.A00(A05(), paramObject.A05()))
        return true; 
      bool = false;
    } 
    return bool;
  }
  
  public int hashCode() {
    return Arrays.hashCode(new Object[] { Boolean.valueOf(A0C()), Boolean.valueOf(A0B()), A04(), A02(), A05() });
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07T.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */