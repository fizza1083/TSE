package X;

import android.os.SystemClock;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class 03r {
  public static final Set A00;
  
  public static final AtomicInteger A01 = new AtomicInteger();
  
  public static final Set A02;
  
  static {
    A00 = 001.A12();
    A02 = new CopyOnWriteArraySet();
  }
  
  public static 0hr A00(String paramString) {
    Set<0hr> set;
    Iterator<03q> iterator;
    SystemClock.uptimeMillis();
    null = new 0hr(paramString);
    synchronized (A00) {
      set.add(null);
      0hn.A00(null);
      iterator = A02.iterator();
      while (iterator.hasNext())
        ((03q)iterator.next()).Ch7(null); 
      return null;
    } 
  }
  
  public static void A01(03q param03q) {
    A02.add(param03q);
    synchronized (A00) {
      Iterator<0hr> iterator = null.iterator();
      while (iterator.hasNext())
        param03q.Ch7(iterator.next()); 
      return;
    } 
  }
  
  public static void A02(0hr param0hr) {
    Set set;
    Iterator<03q> iterator;
    synchronized (A00) {
      set.remove(param0hr);
      0hn.A01(param0hr);
      iterator = A02.iterator();
      while (iterator.hasNext())
        ((03q)iterator.next()).CiL(param0hr); 
      return;
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\03r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */