package X;

import android.os.Process;
import com.facebook.common.dextricks.DalvikInternals;

public final class 00I implements Runnable {
  public static final String __redex_internal_original_name = "MprotectAppInit$2";
  
  public 00I(String[] paramArrayOfString) {}
  
  public final void run() {
    int i = Process.getThreadPriority(Process.myTid());
    Process.setThreadPriority(-14);
    DalvikInternals.mprotectExecAll(this.A00);
    Process.setThreadPriority(i);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00I.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */