package X;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;

public final class 01E {
  public final BroadcastReceiver A00;
  
  public 01E(Context paramContext) {
    1BN 1BN = new 1BN(this, 1);
    this.A00 = 1BN;
    01J.A02(1BN, paramContext, new IntentFilter(0XK.A0b(paramContext.getPackageName(), ".FBSYSTRACE_CONFIG_CHANGE")), null, "android.permission.DUMP", false);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01E.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */