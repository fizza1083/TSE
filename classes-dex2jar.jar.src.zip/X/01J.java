package X;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Handler;

public abstract class 01J {
  public static final void A00(BroadcastReceiver paramBroadcastReceiver, Context paramContext, IntentFilter paramIntentFilter) {
    16F.A0F(paramContext, 0, paramIntentFilter);
    paramContext.registerReceiver(paramBroadcastReceiver, paramIntentFilter);
  }
  
  public static final void A01(BroadcastReceiver paramBroadcastReceiver, Context paramContext, IntentFilter paramIntentFilter) {
    16F.A0E(paramContext, 0);
    if (Build.VERSION.SDK_INT >= 34) {
      01K.A00(paramBroadcastReceiver, paramContext, paramIntentFilter);
      return;
    } 
    paramContext.registerReceiver(paramBroadcastReceiver, paramIntentFilter);
  }
  
  public static final void A02(BroadcastReceiver paramBroadcastReceiver, Context paramContext, IntentFilter paramIntentFilter, Handler paramHandler, String paramString, boolean paramBoolean) {
    16F.A0E(paramContext, 0);
    16F.A0E(paramBroadcastReceiver, 1);
    16F.A0E(paramIntentFilter, 2);
    if (Build.VERSION.SDK_INT >= 34) {
      01K.A01(paramBroadcastReceiver, paramContext, paramIntentFilter, paramHandler, paramString, paramBoolean);
      return;
    } 
    paramContext.registerReceiver(paramBroadcastReceiver, paramIntentFilter, paramString, paramHandler);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01J.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */