package X;

public interface 06E {
  void CJE(String paramString, long paramLong);
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\06E.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */