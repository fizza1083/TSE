package X;

import java.io.File;

public interface 047 {
  boolean CAv(File paramFile);
  
  void E5q(File paramFile, boolean paramBoolean);
  
  void E7N(File paramFile);
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\047.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */