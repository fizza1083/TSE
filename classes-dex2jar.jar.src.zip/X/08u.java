package X;

import androidx.fragment.app.Fragment;

public final class 08u {
  public int A00;
  
  public int A01;
  
  public int A02;
  
  public int A03;
  
  public int A04;
  
  public Fragment A05;
  
  public 0cr A06;
  
  public 0cr A07;
  
  public boolean A08;
  
  public 08u() {}
  
  public 08u(Fragment paramFragment, int paramInt) {
    this.A00 = paramInt;
    this.A05 = paramFragment;
    this.A08 = false;
    0cr 0cr1 = 0cr.A04;
    this.A07 = 0cr1;
    this.A06 = 0cr1;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */