package X;

import android.graphics.Insets;
import android.view.View;
import android.view.WindowInsets;

public final class 07N {
  public static final 07N A01 = 07O.A00;
  
  public final 07T A00 = new 07T(this);
  
  public 07N() {}
  
  public 07N(WindowInsets paramWindowInsets) {}
  
  public static 07N A00(View paramView, WindowInsets paramWindowInsets) {
    paramWindowInsets.getClass();
    07N 07N1 = new 07N(paramWindowInsets);
    if (paramView != null && paramView.isAttachedToWindow()) {
      07N 07N2 = 09K.A00(paramView);
      07N1.A00.A0A(07N2);
      paramView.getRootView();
    } 
    return 07N1;
  }
  
  @Deprecated
  public final int A01() {
    return (this.A00.A04()).A00;
  }
  
  @Deprecated
  public final int A02() {
    return (this.A00.A04()).A01;
  }
  
  @Deprecated
  public final int A03() {
    return (this.A00.A04()).A02;
  }
  
  @Deprecated
  public final int A04() {
    return (this.A00.A04()).A03;
  }
  
  public final WindowInsets A05() {
    07T 07T1 = this.A00;
    return (07T1 instanceof 07S) ? ((07S)07T1).A02 : null;
  }
  
  public final 07U A06(int paramInt) {
    return this.A00.A0D(paramInt);
  }
  
  @Deprecated
  public final 07N A07(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    WindowInsets windowInsets2 = A05();
    if (windowInsets2 != null) {
      WindowInsets.Builder builder1 = new WindowInsets.Builder(windowInsets2);
      07U 07U1 = 07U.A00(paramInt1, paramInt2, paramInt3, paramInt4);
      builder1.setSystemWindowInsets(Insets.of(07U1.A01, 07U1.A03, 07U1.A02, 07U1.A00));
      WindowInsets windowInsets = builder1.build();
      windowInsets.getClass();
      return new 07N(windowInsets);
    } 
    WindowInsets.Builder builder = new WindowInsets.Builder();
    07U 07U = 07U.A00(paramInt1, paramInt2, paramInt3, paramInt4);
    builder.setSystemWindowInsets(Insets.of(07U.A01, 07U.A03, 07U.A02, 07U.A00));
    WindowInsets windowInsets1 = builder.build();
    windowInsets1.getClass();
    return new 07N(windowInsets1);
  }
  
  public final boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof 07N))
      return false; 
    paramObject = paramObject;
    return 0B3.A00(this.A00, ((07N)paramObject).A00);
  }
  
  public final int hashCode() {
    return 002.A04(this.A00);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07N.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */