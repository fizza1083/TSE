package X;

import java.util.regex.Pattern;
import org.json.JSONObject;

public final class 07b {
  public final Pattern A00;
  
  public final boolean A01;
  
  public 07b() {
    this(Pattern.compile(""), false);
  }
  
  public 07b(Pattern paramPattern, boolean paramBoolean) {
    this.A00 = paramPattern;
    this.A01 = paramBoolean;
  }
  
  public static 07b A00(Object paramObject) {
    Pattern pattern = Pattern.compile("");
    boolean bool = paramObject instanceof JSONObject;
    boolean bool1 = false;
    if (bool) {
      Object object;
      JSONObject jSONObject = (JSONObject)paramObject;
      bool = bool1;
      if (jSONObject.has("pattern")) {
        paramObject = Pattern.compile(jSONObject.getString("pattern"), 32);
        bool = bool1;
        object = paramObject;
        if (jSONObject.has("negation")) {
          bool = bool1;
          object = paramObject;
          if (jSONObject.getString("negation").equalsIgnoreCase("true")) {
            bool = true;
            object = paramObject;
          } 
        } 
      } 
      return new 07b((Pattern)object, bool);
    } 
    bool = bool1;
    if (paramObject instanceof String) {
      pattern = Pattern.compile((String)paramObject, 32);
      bool = bool1;
    } 
    return new 07b(pattern, bool);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */