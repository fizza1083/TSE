package X;

import java.util.concurrent.atomic.AtomicReferenceArray;

public final class 05Y {
  public volatile AtomicReferenceArray array;
  
  public final Object A00(int paramInt) {
    AtomicReferenceArray atomicReferenceArray = this.array;
    return (paramInt < atomicReferenceArray.length()) ? atomicReferenceArray.get(paramInt) : null;
  }
  
  public final void A01(int paramInt, Object paramObject) {
    AtomicReferenceArray<Object> atomicReferenceArray1 = this.array;
    int m = atomicReferenceArray1.length();
    if (paramInt < m) {
      atomicReferenceArray1.set(paramInt, paramObject);
      return;
    } 
    int j = paramInt + 1;
    int k = m * 2;
    int i = j;
    if (j < k)
      i = k; 
    AtomicReferenceArray<Object> atomicReferenceArray2 = new AtomicReferenceArray(i);
    for (i = 0; i < m; i++)
      atomicReferenceArray2.set(i, atomicReferenceArray1.get(i)); 
    atomicReferenceArray2.set(paramInt, paramObject);
    this.array = atomicReferenceArray2;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\05Y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */