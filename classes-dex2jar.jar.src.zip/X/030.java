package X;

public final class 030 {
  public 030() {
    07W 07W = 07V.A00;
    if (!07W.A02.getAndSet(true)) {
      07W.A00.close();
      07W.A01.execute(new 07X(07W));
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\030.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */