package X;

public abstract class 01i {
  public static final String[] A00 = new String[] { "VmPeak:", "VmSize:", "VmHWM:", "VmRSS:", "VmLib:", "VmStk:", "VmData:", "VmSwap:" };
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */