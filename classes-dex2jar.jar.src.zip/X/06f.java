package X;

public final class 06f extends 06g implements 06h {
  public static final 06f A00;
  
  static {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: \r\n\tat com.googlecode.dex2jar.ir.ts.NewTransformer.transform(NewTransformer.java:134)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:148)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public 06f(int paramInt1, int paramInt2) {
    super(paramInt1, paramInt2, 1);
  }
  
  public final boolean A00(int paramInt) {
    if (super.A00 <= paramInt) {
      int i = this.A01;
      boolean bool = true;
      return (paramInt > i) ? false : bool;
    } 
    return false;
  }
  
  public final boolean equals(Object paramObject) {
    if (paramObject instanceof 06f)
      if (!super.isEmpty() || !((06g)paramObject).isEmpty()) {
        int i = super.A00;
        paramObject = paramObject;
        if (i == ((06g)paramObject).A00 && this.A01 == ((06g)paramObject).A01)
          return true; 
      } else {
        return true;
      }  
    return false;
  }
  
  public final int hashCode() {
    return super.isEmpty() ? -1 : (super.A00 * 31 + this.A01);
  }
  
  public final boolean isEmpty() {
    int i = super.A00;
    int j = this.A01;
    boolean bool = false;
    if (i > j)
      bool = true; 
    return bool;
  }
  
  public final String toString() {
    return 0XK.A0E(super.A00, this.A01, "..");
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\06f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */