package X;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

public abstract class 07e {
  public final PackageManager A00;
  
  public final ApplicationInfo A01;
  
  public 07e(PackageManager paramPackageManager, ApplicationInfo paramApplicationInfo) {
    this.A00 = paramPackageManager;
    this.A01 = paramApplicationInfo;
  }
  
  public static final ApplicationInfo A00(07e param07e, String paramString) {
    try {
      return param07e.A00.getApplicationInfo(paramString, 0);
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      return null;
    } catch (RuntimeException runtimeException) {
      if (!001.A1Z(runtimeException))
        throw runtimeException; 
      return null;
    } 
  }
  
  public final PackageInfo A01(String paramString, int paramInt) {
    PackageInfo packageInfo = A02(paramString, paramInt);
    return (packageInfo != null && isSameSignature(packageInfo.applicationInfo)) ? packageInfo : null;
  }
  
  public final PackageInfo A02(String paramString, int paramInt) {
    try {
      return this.A00.getPackageInfo(paramString, paramInt);
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      return null;
    } catch (RuntimeException runtimeException) {
      if (!001.A1Z(runtimeException))
        throw runtimeException; 
      return null;
    } 
  }
  
  public boolean isSameSignature(ApplicationInfo paramApplicationInfo) {
    int i = this.A01.uid;
    int j = paramApplicationInfo.uid;
    if (i != j) {
      i = this.A00.checkSignatures(i, j);
      boolean bool = false;
      return (i == 0) ? true : bool;
    } 
    return true;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */