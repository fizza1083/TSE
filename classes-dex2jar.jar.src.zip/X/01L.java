package X;

import com.facebook.fury.context.ReqContext;
import java.util.Iterator;

public final class 01L implements ReqContext {
  public final ReqContext A00;
  
  public 01L(ReqContext paramReqContext) {
    ReqContext reqContext = paramReqContext;
    if (paramReqContext instanceof 01L)
      reqContext = ((01L)paramReqContext).A00; 
    this.A00 = reqContext;
  }
  
  public final void close() {}
  
  public final boolean getBoolean(int paramInt1, boolean paramBoolean, int paramInt2) {
    return this.A00.getBoolean(paramInt1, paramBoolean, paramInt2);
  }
  
  public final int getCurrentSeqId() {
    return this.A00.getCurrentSeqId();
  }
  
  public final long getCurrentTid() {
    return this.A00.getCurrentTid();
  }
  
  public final int getInt(int paramInt1, int paramInt2, int paramInt3) {
    return this.A00.getInt(paramInt1, paramInt2, paramInt3);
  }
  
  public final long getLong(int paramInt1, long paramLong, int paramInt2) {
    return this.A00.getLong(paramInt1, paramLong, paramInt2);
  }
  
  public final Object getObject(int paramInt1, int paramInt2) {
    return this.A00.getObject(paramInt1, paramInt2);
  }
  
  public final int getParentSeqId() {
    return this.A00.getParentSeqId();
  }
  
  public final long getParentTid() {
    return this.A00.getParentTid();
  }
  
  public final String getString(int paramInt1, int paramInt2) {
    return this.A00.getString(paramInt1, paramInt2);
  }
  
  public final String getTag() {
    return this.A00.getTag();
  }
  
  public final int getType() {
    return this.A00.getType();
  }
  
  public final Iterator globalProps() {
    return this.A00.globalProps();
  }
  
  public final boolean hasParent() {
    return this.A00.hasParent();
  }
  
  public final boolean hasSameProps(ReqContext paramReqContext) {
    return this.A00.hasSameProps(paramReqContext);
  }
  
  public final boolean isFlagOn(int paramInt) {
    return this.A00.isFlagOn(paramInt);
  }
  
  public final Iterator localProps() {
    return this.A00.localProps();
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01L.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */