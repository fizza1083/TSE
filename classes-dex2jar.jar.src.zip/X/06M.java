package X;

import java.util.Iterator;
import java.util.NoSuchElementException;

public final class 06M implements Iterator, 16M {
  public int A00;
  
  public final Object[] A01;
  
  public 06M(Object[] paramArrayOfObject) {
    this.A01 = paramArrayOfObject;
  }
  
  public final boolean hasNext() {
    int i = this.A00;
    int j = this.A01.length;
    boolean bool = false;
    if (i < j)
      bool = true; 
    return bool;
  }
  
  public final Object next() {
    try {
      Object[] arrayOfObject = this.A01;
      int i = this.A00;
      this.A00 = i + 1;
      return arrayOfObject[i];
    } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
      this.A00--;
      throw new NoSuchElementException(arrayIndexOutOfBoundsException.getMessage());
    } 
  }
  
  public final void remove() {
    throw 002.A0b();
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\06M.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */