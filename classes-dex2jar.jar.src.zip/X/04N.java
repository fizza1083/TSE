package X;

public final class 04N extends 04P {
  public 04N() {
    super(04K.A00, 04V.A00);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\04N.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */