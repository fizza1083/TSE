package X;

import android.content.Context;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.regex.Pattern;

public final class 05T {
  public static 061 A03;
  
  public static final Pattern A04 = Pattern.compile("^[0-9]+L$");
  
  public final 05S A00;
  
  public final String A01;
  
  public final Context A02;
  
  public 05T(Context paramContext, 05S param05S) {
    this.A02 = paramContext;
    param05S.getClass();
    this.A00 = param05S;
    this.A01 = paramContext.getPackageName();
  }
  
  public static final 061 A00(05T param05T, String paramString) {
    05S 05S1 = param05T.A00;
    String str2 = 05S1.A00("com.facebook.versioncontrol.revision", paramString);
    String str1 = str2;
    if (str2 == null)
      str1 = ""; 
    String str3 = 05S1.A00("com.facebook.versioncontrol.branch", paramString);
    str2 = str3;
    if (str3 == null)
      str2 = ""; 
    str3 = 05S1.A00("com.facebook.build_time", paramString);
    paramString = str3;
    if (str3 == null)
      paramString = ""; 
    if (A04.matcher(paramString).matches()) {
      long l1 = Long.parseLong(paramString.substring(0, paramString.length() - 1));
      DateFormat dateFormat = DateFormat.getDateTimeInstance(1, 0, Locale.US);
      dateFormat.setTimeZone(TimeZone.getTimeZone("PST8PDT"));
      String str = dateFormat.format(new Date(l1));
      return new 061(l1, str1, str2, str);
    } 
    long l = 0L;
    paramString = "";
    return new 061(l, str1, str2, paramString);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\05T.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */