package X;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

public abstract class 04Q {
  public static void A00(Bitmap paramBitmap) {
    if (paramBitmap != null)
      04S.A00().A01(04Y.A03, paramBitmap, paramBitmap.getAllocationByteCount()); 
  }
  
  public static void A01(Bitmap paramBitmap, BitmapFactory.Options paramOptions) {
    if (paramBitmap != null && (paramOptions == null || paramOptions.inBitmap != paramBitmap))
      A00(paramBitmap); 
  }
  
  public static void A02(BitmapFactory.Options paramOptions, String paramString) {
    A01(BitmapFactory.decodeFile(paramString, paramOptions), paramOptions);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\04Q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */