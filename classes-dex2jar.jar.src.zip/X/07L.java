package X;

public abstract class 07L {
  public static volatile long A00 = -1L;
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07L.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */