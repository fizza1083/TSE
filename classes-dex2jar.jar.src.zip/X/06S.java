package X;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class 06S {
  public int A00;
  
  public int A01;
  
  public int A02;
  
  public int A03;
  
  public int A04;
  
  public int A05;
  
  public final 06U A06;
  
  public final 06T A07;
  
  public 06S(int paramInt) {}
  
  private final int A00(Object paramObject1, Object paramObject2) {
    int i = A02(paramObject1, paramObject2);
    if (i >= 0)
      return i; 
    StringBuilder stringBuilder = 001.A0s();
    stringBuilder.append("Negative size: ");
    stringBuilder.append(paramObject1);
    stringBuilder.append('=');
    paramObject1 = 001.A0i(paramObject2, stringBuilder);
    16F.A0E(paramObject1, 0);
    throw 001.A0S(paramObject1);
  }
  
  public static final void A01(06S param06S, int paramInt) {
    while (true) {
      synchronized (param06S.A06) {
        int i = param06S.A05;
        if (i >= 0) {
          LinkedHashMap linkedHashMap = param06S.A07.A00;
          if (!linkedHashMap.isEmpty() || i == 0) {
            if (i > paramInt && !linkedHashMap.isEmpty()) {
              Set set = linkedHashMap.entrySet();
              16F.A0A(set);
              Map.Entry entry = (Map.Entry)0Xa.A08(set);
              if (entry != null) {
                set = (Set)entry.getKey();
                entry = (Map.Entry)entry.getValue();
                16F.A0E(set, 0);
                linkedHashMap.remove(set);
                param06S.A05 -= param06S.A00(set, entry);
                param06S.A00++;
                param06S.A06(true, set, entry, null);
                continue;
              } 
            } 
            return;
          } 
        } 
        throw 001.A0S("LruCache.sizeOf() is reporting inconsistent results!");
      } 
    } 
  }
  
  public int A02(Object paramObject1, Object paramObject2) {
    return 1;
  }
  
  public final Object A03(Object paramObject) {
    16F.A0E(paramObject, 0);
    synchronized (this.A06) {
      paramObject = this.A07.A00.get(paramObject);
      if (paramObject != null) {
        this.A01++;
        return paramObject;
      } 
      this.A03++;
      return null;
    } 
  }
  
  public final Object A04(Object paramObject) {
    16F.A0E(paramObject, 0);
    synchronized (this.A06) {
      Object object = this.A07.A00.remove(paramObject);
      if (object != null)
        this.A05 -= A00(paramObject, object); 
      if (object != null)
        A06(false, paramObject, object, null); 
      return object;
    } 
  }
  
  public final void A05(Object paramObject1, Object paramObject2) {
    16F.A0E(paramObject1, 0);
    16F.A0E(paramObject2, 1);
    synchronized (this.A06) {
      this.A04++;
      this.A05 += A00(paramObject1, paramObject2);
      Object object = this.A07.A00.put(paramObject1, paramObject2);
      if (object != null)
        this.A05 -= A00(paramObject1, object); 
      if (object != null)
        A06(false, paramObject1, object, paramObject2); 
      A01(this, this.A02);
      return;
    } 
  }
  
  public void A06(boolean paramBoolean, Object paramObject1, Object paramObject2, Object paramObject3) {}
  
  public final String toString() {
    synchronized (this.A06) {
      int j = this.A01;
      int k = this.A03;
      int i = k + j;
      if (i != 0) {
        i = j * 100 / i;
      } else {
        i = 0;
      } 
      StringBuilder stringBuilder = 001.A0s();
      stringBuilder.append("LruCache[maxSize=");
      stringBuilder.append(this.A02);
      stringBuilder.append(",hits=");
      stringBuilder.append(j);
      stringBuilder.append(",misses=");
      stringBuilder.append(k);
      stringBuilder.append(",hitRate=");
      stringBuilder.append(i);
      return 001.A0l("%]", stringBuilder);
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\06S.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */