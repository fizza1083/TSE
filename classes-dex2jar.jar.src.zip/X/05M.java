package X;

import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;

public final class 05M extends 04E {
  public static final 05M A01 = new 05M();
  
  public 05U A00;
  
  public 05M() {
    this.A00 = new 05U(i, j, l, str);
  }
  
  public final 04F A02(int paramInt) {
    05k.A00(paramInt);
    if (paramInt < 05N.A01) {
      05k.A00(paramInt);
      return new 05l(this, paramInt);
    } 
    return this;
  }
  
  public final void A03(Runnable paramRunnable, 04I param04I) {
    05U 05U1 = this.A00;
    AtomicLongFieldUpdater atomicLongFieldUpdater = 05U.A0A;
    05U1.A04(paramRunnable, 05N.A07, true);
  }
  
  public final void A05(Runnable paramRunnable, 04I param04I) {
    05U 05U1 = this.A00;
    AtomicLongFieldUpdater atomicLongFieldUpdater = 05U.A0A;
    05U1.A04(paramRunnable, 05N.A07, false);
  }
  
  public final Executor A06() {
    return this.A00;
  }
  
  public final void close() {
    throw 001.A0x("Dispatchers.Default cannot be closed");
  }
  
  public final String toString() {
    return "Dispatchers.Default";
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\05M.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */