package X;

public abstract class 01Z {
  public static final String A00(int paramInt) {
    return (paramInt != -1) ? ((paramInt != 0) ? ((paramInt != 1) ? ((paramInt != 2) ? ((paramInt != 3) ? "INVALID" : "HOT") : "WARM") : "COLD") : "UNTRACKED") : "UNKNOWN";
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01Z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */