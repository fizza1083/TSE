package X;

import androidx.fragment.app.Fragment;

public final class 08x implements 0Cw {
  public 08x(Fragment paramFragment, 0Cy param0Cy) {}
  
  public final void CRr(Fragment paramFragment, 0Cy param0Cy) {
    this.A00.onAttachFragment(paramFragment);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */