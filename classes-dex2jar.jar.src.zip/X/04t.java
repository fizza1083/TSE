package X;

public interface 04t extends 04s {
  boolean AO7(Throwable paramThrowable);
  
  04l BVX();
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\04t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */