package X;

public final class 02j {
  public static final 02j A01;
  
  public static final 02j A02 = new 02j(0);
  
  public final int A00;
  
  static {
    new 02j(2);
    A01 = new 02j(64);
  }
  
  public 02j(int paramInt) {
    if ((paramInt - 1 & paramInt) == 0) {
      this.A00 = paramInt;
      return;
    } 
    throw 0XK.A05("Only one flag must be set for a listener, ", " passed", paramInt);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\02j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */