package X;

import android.os.IBinder;
import android.os.RemoteException;
import android.os.ServiceManager;

public final class 03b implements IBinder.DeathRecipient {
  public static 03b A01;
  
  public final 0tW A00;
  
  public 03b(0tW param0tW) {
    this.A00 = param0tW;
    A00("activity");
    A00("SurfaceFlinger");
  }
  
  private void A00(String paramString) {
    IBinder iBinder = ServiceManager.getService(paramString);
    if (iBinder != null)
      try {
        iBinder.linkToDeath(this, 0);
        return;
      } catch (RemoteException remoteException) {
        0pd.A0I("SystemBinderDiedDetector", "linkToDeath failed", (Throwable)remoteException);
        0tB.A00().Ci5("SysBinderLinkToDeath", (Throwable)remoteException, null);
      }  
  }
  
  public final void binderDied() {
    null = this.A00.A05;
    0ah.A03(null);
    synchronized (null.A02) {
      null.A01.A00.put(206, (byte)49);
      0dR.A02(null);
      return;
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\03b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */