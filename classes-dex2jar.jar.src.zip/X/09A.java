package X;

import android.os.Looper;
import java.util.concurrent.TimeUnit;

public final class 09A {
  public final int A00;
  
  public final long A01;
  
  public final String A02;
  
  public final String A03;
  
  public final boolean A04;
  
  public final boolean A05;
  
  public final boolean A06;
  
  public 09A(String paramString1, String paramString2, int paramInt, boolean paramBoolean) {
    this.A03 = paramString1;
    this.A02 = paramString2;
    this.A00 = paramInt;
    this.A05 = paramBoolean;
    this.A01 = TimeUnit.NANOSECONDS.toMillis(System.nanoTime());
    Thread thread1 = Thread.currentThread();
    Thread thread2 = Looper.getMainLooper().getThread();
    paramBoolean = true;
    this.A06 = 001.A1Y(thread1, thread2);
    if (0Ea.A05.A01 == 0)
      paramBoolean = false; 
    this.A04 = paramBoolean;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\09A.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */