package X;

public interface 08K {
  void Czb(int paramInt);
  
  void Czc(int paramInt1, float paramFloat, int paramInt2);
  
  void Cze(int paramInt);
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08K.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */