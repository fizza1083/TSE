package X;

import android.content.Context;
import android.os.BatteryManager;
import com.facebook.errorreporting.lacrima.collector.critical.BatteryInfoCollector;

public final class 03l implements 0qd {
  public Context A00;
  
  public final Integer BR8() {
    return 0Xy.A13;
  }
  
  public final void DUA(0qe param0qe, 0r7 param0r7) {
    BatteryManager batteryManager = BatteryInfoCollector.Api21Utils.getBatteryManager(this.A00);
    if (batteryManager != null) {
      BatteryInfoCollector.Api21Utils.setApi21Properties(batteryManager, param0qe);
      BatteryInfoCollector.Api26Utils.setApi26Properties(batteryManager, param0qe);
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\03l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */