package X;

public final class 06C {
  public final int A00;
  
  public final Object A01;
  
  public final String A02;
  
  public 06C(String paramString, Object paramObject, int paramInt) {
    this.A00 = paramInt;
    this.A02 = paramString;
    this.A01 = paramObject;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\06C.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */