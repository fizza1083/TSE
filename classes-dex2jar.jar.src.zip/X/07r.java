package X;

import androidx.viewpager.widget.ViewPager;

public final class 07r implements Runnable {
  public static final String __redex_internal_original_name = "ViewPager$3";
  
  public 07r(ViewPager paramViewPager) {}
  
  public final void run() {
    ViewPager viewPager = this.A00;
    viewPager.A0I(0);
    ViewPager.A09(viewPager, viewPager.A04);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */