package X;

import android.view.View;

public abstract class 082 {
  public static void A00(View paramView, 081 param081) {
    View.OnApplyWindowInsetsListener onApplyWindowInsetsListener;
    if (param081 == null) {
      onApplyWindowInsetsListener = (View.OnApplyWindowInsetsListener)paramView.getTag(2131370842);
    } else {
      onApplyWindowInsetsListener = new 083(paramView, (081)onApplyWindowInsetsListener);
    } 
    paramView.setOnApplyWindowInsetsListener(onApplyWindowInsetsListener);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\082.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */