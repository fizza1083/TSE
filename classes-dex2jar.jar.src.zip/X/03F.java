package X;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import java.util.ArrayList;
import java.util.HashMap;

@Deprecated
public final class 03F {
  public static 03F A05;
  
  public static final Object A06 = 001.A0W();
  
  public final Context A00;
  
  public final ArrayList A01 = 001.A0y();
  
  public final HashMap A02 = 001.A11();
  
  public final Handler A03;
  
  public final HashMap A04 = 001.A11();
  
  public 03F(Context paramContext) {
    this.A00 = paramContext;
    this.A03 = new 03G(paramContext.getMainLooper(), this);
  }
  
  public static 03F A00(Context paramContext) {
    synchronized (A06) {
      03F 03F2 = A05;
      03F 03F1 = 03F2;
      if (03F2 == null) {
        03F1 = new 03F(paramContext.getApplicationContext());
        A05 = 03F1;
      } 
      return 03F1;
    } 
  }
  
  public final void A01(BroadcastReceiver paramBroadcastReceiver) {
    synchronized (this.A02) {
      ArrayList<03M> arrayList = (ArrayList)null.remove(paramBroadcastReceiver);
      if (arrayList != null)
        for (int i = arrayList.size() - 1;; i--) {
          if (i >= 0) {
            03M 03M = arrayList.get(i);
            03M.A01 = true;
            for (int j = 0; j < 03M.A03.countActions(); j++) {
              String str = 03M.A03.getAction(j);
              HashMap hashMap = this.A04;
              ArrayList<03M> arrayList1 = (ArrayList)hashMap.get(str);
              if (arrayList1 != null) {
                int k;
                for (k = arrayList1.size() - 1;; k--) {
                  if (k >= 0) {
                    03M 03M1 = arrayList1.get(k);
                    if (03M1.A02 == paramBroadcastReceiver) {
                      03M1.A01 = true;
                      arrayList1.remove(k);
                    } 
                  } else {
                    if (arrayList1.size() <= 0)
                      hashMap.remove(str); 
                    break;
                  } 
                } 
              } 
            } 
            continue;
          } 
          return;
        }  
      return;
    } 
  }
  
  public final void A02(BroadcastReceiver paramBroadcastReceiver, IntentFilter paramIntentFilter) {
    synchronized (this.A02) {
      03M 03M = new 03M(paramBroadcastReceiver, paramIntentFilter);
      ArrayList<03M> arrayList2 = (ArrayList)null.get(paramBroadcastReceiver);
      ArrayList<03M> arrayList1 = arrayList2;
      if (arrayList2 == null) {
        arrayList1 = new ArrayList(1);
        null.put(paramBroadcastReceiver, arrayList1);
      } 
      arrayList1.add(03M);
      for (int i = 0; i < paramIntentFilter.countActions(); i++) {
        String str = paramIntentFilter.getAction(i);
        HashMap<String, ArrayList<03M>> hashMap = this.A04;
        arrayList1 = (ArrayList<03M>)hashMap.get(str);
        ArrayList<03M> arrayList = arrayList1;
        if (arrayList1 == null) {
          arrayList = new ArrayList<03M>(1);
          hashMap.put(str, arrayList);
        } 
        arrayList.add(03M);
      } 
      return;
    } 
  }
  
  public final void A03(Intent paramIntent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield A02 : Ljava/util/HashMap;
    //   4: astore #5
    //   6: aload #5
    //   8: monitorenter
    //   9: aload_1
    //   10: invokevirtual getAction : ()Ljava/lang/String;
    //   13: astore #6
    //   15: aload_1
    //   16: aload_0
    //   17: getfield A00 : Landroid/content/Context;
    //   20: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
    //   23: invokevirtual resolveTypeIfNeeded : (Landroid/content/ContentResolver;)Ljava/lang/String;
    //   26: astore #7
    //   28: aload_1
    //   29: invokevirtual getData : ()Landroid/net/Uri;
    //   32: astore #8
    //   34: aload_1
    //   35: invokevirtual getScheme : ()Ljava/lang/String;
    //   38: astore #9
    //   40: aload_1
    //   41: invokevirtual getCategories : ()Ljava/util/Set;
    //   44: astore #10
    //   46: aload_1
    //   47: invokevirtual getFlags : ()I
    //   50: pop
    //   51: aload_0
    //   52: getfield A04 : Ljava/util/HashMap;
    //   55: aload_1
    //   56: invokevirtual getAction : ()Ljava/lang/String;
    //   59: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   62: checkcast java/util/ArrayList
    //   65: astore #11
    //   67: aload #11
    //   69: ifnull -> 229
    //   72: aconst_null
    //   73: astore_3
    //   74: iconst_0
    //   75: istore_2
    //   76: iload_2
    //   77: aload #11
    //   79: invokevirtual size : ()I
    //   82: if_icmpge -> 249
    //   85: aload #11
    //   87: iload_2
    //   88: invokevirtual get : (I)Ljava/lang/Object;
    //   91: checkcast X/03M
    //   94: astore #12
    //   96: aload_3
    //   97: astore #4
    //   99: aload #12
    //   101: getfield A00 : Z
    //   104: ifne -> 239
    //   107: aload_3
    //   108: astore #4
    //   110: aload #12
    //   112: getfield A03 : Landroid/content/IntentFilter;
    //   115: aload #6
    //   117: aload #7
    //   119: aload #9
    //   121: aload #8
    //   123: aload #10
    //   125: ldc 'LocalBroadcastManager'
    //   127: invokevirtual match : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/net/Uri;Ljava/util/Set;Ljava/lang/String;)I
    //   130: iflt -> 239
    //   133: aload_3
    //   134: astore #4
    //   136: aload_3
    //   137: ifnonnull -> 149
    //   140: new java/util/ArrayList
    //   143: dup
    //   144: invokespecial <init> : ()V
    //   147: astore #4
    //   149: aload #4
    //   151: aload #12
    //   153: invokevirtual add : (Ljava/lang/Object;)Z
    //   156: pop
    //   157: aload #12
    //   159: iconst_1
    //   160: putfield A00 : Z
    //   163: goto -> 239
    //   166: iload_2
    //   167: aload_3
    //   168: invokevirtual size : ()I
    //   171: if_icmpge -> 193
    //   174: aload_3
    //   175: iload_2
    //   176: invokevirtual get : (I)Ljava/lang/Object;
    //   179: checkcast X/03M
    //   182: iconst_0
    //   183: putfield A00 : Z
    //   186: iload_2
    //   187: iconst_1
    //   188: iadd
    //   189: istore_2
    //   190: goto -> 166
    //   193: aload_0
    //   194: getfield A01 : Ljava/util/ArrayList;
    //   197: new X/0FQ
    //   200: dup
    //   201: aload_1
    //   202: aload_3
    //   203: invokespecial <init> : (Landroid/content/Intent;Ljava/util/ArrayList;)V
    //   206: invokevirtual add : (Ljava/lang/Object;)Z
    //   209: pop
    //   210: aload_0
    //   211: getfield A03 : Landroid/os/Handler;
    //   214: astore_1
    //   215: aload_1
    //   216: iconst_1
    //   217: invokevirtual hasMessages : (I)Z
    //   220: ifne -> 229
    //   223: aload_1
    //   224: iconst_1
    //   225: invokevirtual sendEmptyMessage : (I)Z
    //   228: pop
    //   229: aload #5
    //   231: monitorexit
    //   232: return
    //   233: astore_1
    //   234: aload #5
    //   236: monitorexit
    //   237: aload_1
    //   238: athrow
    //   239: iload_2
    //   240: iconst_1
    //   241: iadd
    //   242: istore_2
    //   243: aload #4
    //   245: astore_3
    //   246: goto -> 76
    //   249: aload_3
    //   250: ifnull -> 229
    //   253: iconst_0
    //   254: istore_2
    //   255: goto -> 166
    // Exception table:
    //   from	to	target	type
    //   9	67	233	finally
    //   76	96	233	finally
    //   99	107	233	finally
    //   110	133	233	finally
    //   140	149	233	finally
    //   149	163	233	finally
    //   166	186	233	finally
    //   193	229	233	finally
    //   229	232	233	finally
    //   234	237	233	finally
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\03F.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */