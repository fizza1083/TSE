package X;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public abstract class 025 extends 026 {
  public static final HashSet A00(Object... paramVarArgs) {
    16F.A0E(paramVarArgs, 0);
    int j = paramVarArgs.length;
    HashSet<Object> hashSet = new HashSet(01m.A0D(j));
    for (int i = 0; i < j; i++)
      hashSet.add(paramVarArgs[i]); 
    return hashSet;
  }
  
  public static final Set A01(Object... paramVarArgs) {
    int j = paramVarArgs.length;
    LinkedHashSet<Object> linkedHashSet = new LinkedHashSet(01m.A0D(j));
    for (int i = 0; i < j; i++)
      linkedHashSet.add(paramVarArgs[i]); 
    return linkedHashSet;
  }
  
  public static final Set A02(Object... paramVarArgs) {
    16F.A0E(paramVarArgs, 0);
    return 027.A0D(paramVarArgs);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\025.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */