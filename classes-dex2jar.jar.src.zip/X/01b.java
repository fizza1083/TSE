package X;

import com.facebook.acra.criticaldata.CriticalAppData;
import com.facebook.acra.criticaldata.UserChangeListener;

public final class 01b implements 0si, UserChangeListener {
  public final 0qi A00;
  
  public 01b(0qi param0qi) {
    this.A00 = param0qi;
  }
  
  public final 0sj getName() {
    return 0sj.A0W;
  }
  
  public final void start() {
    CriticalAppData.sUserChangeListener = this;
  }
  
  public final void userHasChanged() {
    0jQ 0jQ = 0jQ.A00();
    0qi 0qi1 = this.A00;
    0qi1.A08(0jQ, 0r7.A01, this);
    0qi1.A08(0jQ, 0r7.A02, this);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */