package X;

import android.content.ContentProviderResult;
import android.content.ContentValues;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.content.res.Configuration;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import java.util.ArrayList;

public abstract class 06Y {
  public final 11U A00;
  
  public 06Y(11U param11U) {
    11V.A00();
    this.A00 = param11U;
  }
  
  public void A05() {}
  
  public abstract int A06(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString);
  
  public abstract int A07(Uri paramUri, String paramString, String[] paramArrayOfString);
  
  public int A08(Uri paramUri, ContentValues[] paramArrayOfContentValues) {
    return this.A00.A03(paramUri, paramArrayOfContentValues);
  }
  
  public AssetFileDescriptor A09(Uri paramUri, String paramString) {
    return this.A00.A04(paramUri, paramString);
  }
  
  public AssetFileDescriptor A0A(Uri paramUri, String paramString, Bundle paramBundle) {
    return this.A00.A05(paramUri, paramString, paramBundle);
  }
  
  public abstract Cursor A0B(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2);
  
  public Cursor A0C(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2, CancellationSignal paramCancellationSignal) {
    return A0B(paramUri, paramArrayOfString1, paramString1, paramArrayOfString2, paramString2);
  }
  
  public abstract Uri A0D(Uri paramUri, ContentValues paramContentValues);
  
  public Bundle A0E(String paramString1, String paramString2, Bundle paramBundle) {
    return this.A00.A06(paramString1, paramString2, paramBundle);
  }
  
  public ParcelFileDescriptor A0F(Uri paramUri, String paramString) {
    return this.A00.A07(paramUri, paramString);
  }
  
  public abstract String A0G(Uri paramUri);
  
  public void A0H() {
    this.A00.A08();
  }
  
  public void A0I() {
    this.A00.A09();
  }
  
  public void A0J(int paramInt) {
    this.A00.A0A(paramInt);
  }
  
  public void A0K(Configuration paramConfiguration) {
    this.A00.A0C(paramConfiguration);
  }
  
  public boolean A0L() {
    return this.A00.A0E();
  }
  
  public ContentProviderResult[] A0M(ArrayList paramArrayList) {
    return this.A00.A0F(paramArrayList);
  }
  
  public String[] A0N(Uri paramUri, String paramString) {
    return this.A00.A0G(paramUri, paramString);
  }
  
  public final Context getContext() {
    return this.A00.getContext();
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\06Y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */