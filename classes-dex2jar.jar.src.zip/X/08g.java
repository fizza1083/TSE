package X;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import java.util.ArrayList;

public abstract class 08g extends 08h {
  public final ArrayList A00 = 001.A0y();
  
  public final 0Xi A01 = 0Xi.A02();
  
  public 08g(08e... paramVarArgs) {
    int j = paramVarArgs.length;
    for (int i = 0; i < j; i++) {
      08e 08e1 = paramVarArgs[i];
      for (IntentFilter intentFilter : 08e1.getIntentFilters()) {
        this.A00.add(intentFilter);
        int m = intentFilter.countActions();
        for (int k = 0; k < m; k++) {
          String str = intentFilter.getAction(k);
          0Xi 0Xi1 = this.A01;
          str.getClass();
          0Xi1.put(str, 08e1);
        } 
      } 
    } 
  }
  
  public abstract Integer A00();
  
  public final Object getEndpointObject(String paramString) {
    Object object = this.A01.get(paramString);
    object.getClass();
    return object;
  }
  
  public final String getTag() {
    return "DynamicBroadcastReceiverBase";
  }
  
  public final void onReceive(Context paramContext, Intent paramIntent) {
    int j = 0Eb.A01(1837733310);
    String str = paramIntent.getAction();
    str.getClass();
    08e 08e = (08e)getEndpointObject(str);
    if (08e != null) {
      try {
        super.onReceive(paramContext, paramIntent);
      } catch (SecurityException securityException) {
        09p.A00.A00(paramIntent, getEndpointName(paramContext), null, "deny");
        boolean bool = securityException instanceof 09s;
        int k = -880590552;
        if (bool) {
          0Eb.A0D(-1748760256, j, paramIntent);
          throw securityException;
        } 
      } 
      securityException.onReceive(paramContext, paramIntent, this);
      09p.A00.A00(paramIntent, getEndpointName(paramContext), null, "allow");
    } 
    int i = -559286012;
    0Eb.A0D(i, j, paramIntent);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */