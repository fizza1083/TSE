package X;

import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

public class 05W {
  public final int A00() {
    Object object = A00.get(this);
    long l = 05X.A05.get(object);
    int i = (int)((0x3FFFFFFFL & l) >> 0L);
    return 0x3FFFFFFF & (int)((l & 0xFFFFFFFC0000000L) >> 30L) - i;
  }
  
  public final Object A01() {
    AtomicReferenceFieldUpdater<05W, 05X> atomicReferenceFieldUpdater = A00;
    while (true) {
      05X 05X = atomicReferenceFieldUpdater.get(this);
      Object object = 05X.A02();
      if (object != 05X.A04)
        return object; 
      05v.A00(this, 05X, 05X.A03(), atomicReferenceFieldUpdater);
    } 
  }
  
  public final void A02() {
    AtomicReferenceFieldUpdater<05W, 05X> atomicReferenceFieldUpdater = A00;
    label12: while (true) {
      05X 05X = atomicReferenceFieldUpdater.get(this);
      AtomicLongFieldUpdater<05X> atomicLongFieldUpdater = 05X.A05;
      while (true) {
        long l = atomicLongFieldUpdater.get(05X);
        if ((l & 0x2000000000000000L) == 0L) {
          if ((0x1000000000000000L & l) != 0L) {
            05v.A00(this, 05X, 05X.A03(), atomicReferenceFieldUpdater);
            continue label12;
          } 
          if (atomicLongFieldUpdater.compareAndSet(05X, l, l | 0x2000000000000000L))
            break; 
          continue;
        } 
        break;
      } 
      break;
    } 
  }
  
  public final boolean A03(Object paramObject) {
    AtomicReferenceFieldUpdater<05W, 05X> atomicReferenceFieldUpdater = A00;
    while (true) {
      05X 05X = atomicReferenceFieldUpdater.get(this);
      int i = 05X.A01(paramObject);
      boolean bool = true;
      if (i != 0) {
        if (i != 1)
          return false; 
      } else {
        return bool;
      } 
      05v.A00(this, 05X, 05X.A03(), atomicReferenceFieldUpdater);
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\05W.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */