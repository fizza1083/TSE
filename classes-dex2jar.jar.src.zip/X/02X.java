package X;

import java.io.File;

public final class 02X extends 0in {
  public final 0qe A01(0r7 param0r7) {
    0jQ 0jQ = 0jQ.A00();
    0jQ.DXk(0qV.A4x, "anr");
    0in.A00(0qV.A6w, 0jQ, param0r7.prefix, "anr");
    return 0jQ;
  }
  
  public final 0sj A02() {
    return 0sj.A02;
  }
  
  public final Integer A03() {
    return 0Xy.A01;
  }
  
  public final void A04(0r7 param0r7, File paramFile1, File paramFile2) {
    // Byte code:
    //   0: aload_1
    //   1: getstatic X/0r7.A02 : LX/0r7;
    //   4: if_acmpne -> 37
    //   7: ldc X/0pa
    //   9: monitorenter
    //   10: getstatic X/0pa.A0D : Z
    //   13: istore #4
    //   15: ldc X/0pa
    //   17: monitorexit
    //   18: iload #4
    //   20: ifne -> 37
    //   23: aload_0
    //   24: aload_1
    //   25: aload_2
    //   26: aload_3
    //   27: invokespecial A04 : (LX/0r7;Ljava/io/File;Ljava/io/File;)V
    //   30: return
    //   31: astore_1
    //   32: ldc X/0pa
    //   34: monitorexit
    //   35: aload_1
    //   36: athrow
    //   37: return
    // Exception table:
    //   from	to	target	type
    //   10	15	31	finally
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\02X.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */