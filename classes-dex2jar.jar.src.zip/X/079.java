package X;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Map;

public abstract class 079 {
  public static final String A00(Class<?> paramClass) {
    boolean bool = paramClass.isAnonymousClass();
    String str = null;
    null = str;
    if (!bool) {
      null = str;
      if (!paramClass.isLocalClass()) {
        String str1;
        if (paramClass.isArray()) {
          paramClass = paramClass.getComponentType();
          if (paramClass.isPrimitive()) {
            str1 = (String)06l.A01.get(paramClass.getName());
            if (str1 != null) {
              str1 = 0XK.A0b(str1, "Array");
              null = str1;
              return (str1 == null) ? "kotlin.Array" : null;
            } 
          } 
        } else {
          str = (String)06l.A01.get(str1.getName());
          null = str;
          return (str == null) ? str1.getCanonicalName() : null;
        } 
      } else {
        return null;
      } 
    } else {
      return null;
    } 
    return "kotlin.Array";
  }
  
  public static final String A01(Class paramClass) {
    String str1;
    boolean bool = paramClass.isAnonymousClass();
    String str2 = "Array";
    Method method = null;
    if (!bool) {
      Constructor<?> constructor;
      if (paramClass.isLocalClass()) {
        str2 = paramClass.getSimpleName();
        Method method1 = paramClass.getEnclosingMethod();
        method = method1;
        if (method1 == null) {
          constructor = paramClass.getEnclosingConstructor();
          Constructor<?> constructor1 = constructor;
          if (constructor == null) {
            16F.A0D(str2);
            16F.A0E(str2, 0);
            int i = 0Xm.A03(str2, '$', 0);
            str1 = str2;
            if (i != -1) {
              str1 = str2.substring(i + 1, str2.length());
              16F.A0A(str1);
            } 
            return str1;
          } 
        } 
      } else {
        String str;
        if (constructor.isArray()) {
          Class<?> clazz = constructor.getComponentType();
          str1 = str2;
          if (clazz.isPrimitive()) {
            Map map = 06l.A03;
            str = 001.A0j(clazz.getName(), map);
            String str3 = str2;
            if (str != null) {
              str = 0XK.A0b(str, "Array");
              str3 = str;
              return (str == null) ? "Array" : str3;
            } 
          } 
        } else {
          str2 = (String)06l.A03.get(str.getName());
          str1 = str2;
          if (str2 == null)
            return str.getSimpleName(); 
        } 
        return str1;
      } 
    } else {
      return str1;
    } 
    16F.A0D(str2);
    return 0Xm.A0I(str2, 0XK.A0D('$', str1.getName()), str2);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\079.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */