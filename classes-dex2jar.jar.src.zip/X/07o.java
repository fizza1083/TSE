package X;

import android.view.animation.Interpolator;

public final class 07o implements Interpolator {
  public final float getInterpolation(float paramFloat) {
    paramFloat--;
    return paramFloat * paramFloat * paramFloat * paramFloat * paramFloat + 1.0F;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */