package X;

import android.app.ActivityManager;
import com.facebook.errorreporting.lacrima.collector.critical.LmkImportanceCollector;

public final class 03P implements 0qd {
  public 14q A00;
  
  public final Integer BR8() {
    return 0Xy.A0s;
  }
  
  public final boolean Bxl(Integer paramInteger) {
    return 001.A1Y(paramInteger, 0Xy.A00);
  }
  
  public final void DUA(0qe param0qe, 0r7 param0r7) {
    ActivityManager.RunningAppProcessInfo runningAppProcessInfo = new ActivityManager.RunningAppProcessInfo();
    ((0te)this.A00.get()).A01(runningAppProcessInfo);
    param0qe.DXi(0qV.A29, runningAppProcessInfo.importance);
    param0qe.DXi(0qV.A2A, LmkImportanceCollector.Api16Utils.getLastTrimLevel(runningAppProcessInfo));
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\03P.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */