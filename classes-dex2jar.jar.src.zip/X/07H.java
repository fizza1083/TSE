package X;

public abstract class 07H extends 07I implements 02I, 02H {
  public final void A01() {
    ((07H)A00()).A01();
    throw null;
  }
  
  public abstract void A02(Object paramObject1, Object paramObject2);
  
  public final 0b0 BEQ() {
    ((02I)A00()).BEQ();
    throw null;
  }
  
  public final 0BI computeReflected() {
    return this;
  }
  
  public final Object invoke(Object paramObject) {
    return get(paramObject);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07H.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */