package X;

public abstract class 05w {
  public static final void A00(Object paramObject, 05D param05D, 053 param053) {
    try {
      paramObject = 05x.A02(05x.A01(paramObject, param05D, param053));
      return;
    } finally {
      param05D.DiG(new 068((Throwable)paramObject));
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\05w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */