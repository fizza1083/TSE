package X;

public final class 01d implements 0si {
  public final 0qi A00;
  
  public final 0tW A01;
  
  public 01d(0qi param0qi, 0tW param0tW) {
    this.A01 = param0tW;
    this.A00 = param0qi;
  }
  
  public final 0sj getName() {
    return 0sj.A0H;
  }
  
  public final void start() {
    0jQ 0jQ = 0jQ.A00();
    0jQ.DXk(0qV.A4V, this.A01.A0A);
    0qi 0qi1 = this.A00;
    002.A0o(0jQ, 0qi1, this);
    0r7 0r7 = 0r7.A02;
    0qi1.A0D(0r7, this);
    0qi1.A07(0jQ, 0r7, this);
    0qi1.A0C(0r7, this);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */