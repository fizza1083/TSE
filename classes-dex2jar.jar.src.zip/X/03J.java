package X;

import android.content.Context;
import android.content.Intent;

public abstract class 03J {
  public static final 03J A00 = new 03K();
  
  public static final 03J A01 = new 03L();
  
  public abstract boolean A00(Context paramContext, Intent paramIntent, 11P param11P, Object paramObject);
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\03J.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */