package X;

public final class 05h extends 04F {
  public static final 05h A00;
  
  static {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: \r\n\tat com.googlecode.dex2jar.ir.ts.NewTransformer.transform(NewTransformer.java:134)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:148)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public final 04F A02(int paramInt) {
    05k.A00(paramInt);
    if (paramInt < 05N.A02) {
      05k.A00(paramInt);
      return new 05l(this, paramInt);
    } 
    return this;
  }
  
  public final void A03(Runnable paramRunnable, 04I param04I) {
    param04I = 05M.A01;
    05R 05R = 05N.A06;
    ((05M)param04I).A00.A04(paramRunnable, 05R, true);
  }
  
  public final void A05(Runnable paramRunnable, 04I param04I) {
    param04I = 05M.A01;
    05R 05R = 05N.A06;
    ((05M)param04I).A00.A04(paramRunnable, 05R, false);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\05h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */