package X;

import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;
import java.io.FileDescriptor;

public final class 01T {
  public FileDescriptor A00;
  
  public long A01;
  
  public final byte[] A02;
  
  public final String A03;
  
  public final boolean A04;
  
  public 01T(String paramString, int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
    this.A03 = paramString;
    this.A02 = new byte[paramInt];
    this.A04 = paramBoolean2;
    if (paramBoolean1)
      this.A00 = A08(this); 
  }
  
  public static int A00(01T param01T, int paramInt) {
    if (!param01T.A04)
      return paramInt + 1; 
    long l2 = System.currentTimeMillis() - param01T.A01;
    long l1 = l2;
    if (l2 > 2147483647L)
      l1 = 2147483647L; 
    int i = (int)l1;
    return A05(param01T.A02, i, paramInt);
  }
  
  public static int A01(01T param01T, int paramInt1, int paramInt2) {
    paramInt1 = (param01T.A02.length - paramInt1 + 4) / paramInt2 - 1;
    return (paramInt1 >= 0) ? paramInt1 : 0;
  }
  
  public static int A02(CharSequence paramCharSequence, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    if (paramCharSequence == null) {
      paramArrayOfbyte[paramInt1] = 0;
      return paramInt1 + 1;
    } 
    int i = Integer.MAX_VALUE;
    if (paramInt2 >= 0)
      i = paramInt2 + paramInt1; 
    paramInt2 = paramInt1;
    int j = 0;
    while (paramInt2 < paramCharSequence.length() + paramInt1 && paramInt2 < i) {
      paramArrayOfbyte[paramInt2] = (byte)paramCharSequence.charAt(paramInt2 - paramInt1);
      j++;
      paramInt2++;
    } 
    paramInt1 = j + paramInt1;
    paramArrayOfbyte[paramInt1] = 0;
    return paramInt1 + 1;
  }
  
  public static int A03(StringBuilder paramStringBuilder, byte[] paramArrayOfbyte, int paramInt) {
    int j = paramArrayOfbyte.length;
    int i = paramInt;
    if (paramInt >= j)
      return paramInt; 
    while (true) {
      paramInt = paramArrayOfbyte[i];
      if (paramInt != 0) {
        paramStringBuilder.append((char)paramInt);
        paramInt = i + 1;
        i = paramInt;
        if (paramInt == j)
          return paramInt; 
        continue;
      } 
      return i + 1;
    } 
  }
  
  public static int A04(byte[] paramArrayOfbyte, int paramInt) {
    int i = paramInt + 1;
    paramInt = paramArrayOfbyte[paramInt];
    int j = i + 1;
    return ((paramInt & 0xFF) << 24) + ((paramArrayOfbyte[i] & 0xFF) << 16) + ((paramArrayOfbyte[j] & 0xFF) << 8) + (paramArrayOfbyte[j + 1] & 0xFF);
  }
  
  public static int A05(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    paramArrayOfbyte[paramInt2] = (byte)(paramInt1 >>> 24 & 0xFF);
    paramArrayOfbyte[paramInt2 + 1] = (byte)(paramInt1 >>> 16 & 0xFF);
    paramArrayOfbyte[paramInt2 + 2] = (byte)(paramInt1 >>> 8 & 0xFF);
    paramArrayOfbyte[paramInt2 + 3] = (byte)(paramInt1 & 0xFF);
    return paramInt2 + 4;
  }
  
  public static int A06(byte[] paramArrayOfbyte, int paramInt, long paramLong) {
    paramArrayOfbyte[paramInt] = (byte)(int)(paramLong >>> 56L & 0xFFL);
    paramArrayOfbyte[paramInt + 1] = (byte)(int)(paramLong >>> 48L & 0xFFL);
    paramArrayOfbyte[paramInt + 2] = (byte)(int)(paramLong >>> 40L & 0xFFL);
    paramArrayOfbyte[paramInt + 3] = (byte)(int)(paramLong >>> 32L & 0xFFL);
    paramArrayOfbyte[paramInt + 4] = (byte)(int)(paramLong >>> 24L & 0xFFL);
    paramArrayOfbyte[paramInt + 5] = (byte)(int)(paramLong >>> 16L & 0xFFL);
    paramArrayOfbyte[paramInt + 6] = (byte)(int)(paramLong >>> 8L & 0xFFL);
    paramArrayOfbyte[paramInt + 7] = (byte)(int)(paramLong & 0xFFL);
    return paramInt + 8;
  }
  
  public static long A07(byte[] paramArrayOfbyte, int paramInt) {
    int i = paramInt + 1;
    long l1 = (paramArrayOfbyte[paramInt] & 0xFF);
    paramInt = i + 1;
    long l2 = (paramArrayOfbyte[i] & 0xFF);
    i = paramInt + 1;
    long l3 = (paramArrayOfbyte[paramInt] & 0xFF);
    paramInt = i + 1;
    long l4 = (paramArrayOfbyte[i] & 0xFF);
    i = paramInt + 1;
    long l5 = (paramArrayOfbyte[paramInt] & 0xFF);
    paramInt = i + 1;
    return (l1 << 56L) + (l2 << 48L) + (l3 << 40L) + (l4 << 32L) + (l5 << 24L) + ((paramArrayOfbyte[i] & 0xFF) << 16) + ((paramArrayOfbyte[paramInt] & 0xFF) << 8) + (paramArrayOfbyte[paramInt + 1] & 0xFF);
  }
  
  public static FileDescriptor A08(01T param01T) {
    FileDescriptor fileDescriptor = null;
    try {
      FileDescriptor fileDescriptor1 = Os.open(param01T.A03, OsConstants.O_CREAT | OsConstants.O_WRONLY | OsConstants.O_SYNC, OsConstants.S_IWUSR | OsConstants.S_IRUSR);
      fileDescriptor = fileDescriptor1;
      if (param01T.A04 && fileDescriptor1 != null) {
        fileDescriptor = fileDescriptor1;
        byte[] arrayOfByte = param01T.A02;
        arrayOfByte[0] = -1;
        fileDescriptor = fileDescriptor1;
        long l = System.currentTimeMillis();
        fileDescriptor = fileDescriptor1;
        param01T.A01 = l;
        fileDescriptor = fileDescriptor1;
        A06(arrayOfByte, 1, l);
        fileDescriptor = fileDescriptor1;
        Os.write(fileDescriptor1, arrayOfByte, 0, 9);
      } 
      return fileDescriptor1;
    } catch (ErrnoException|java.io.InterruptedIOException errnoException) {
      return fileDescriptor;
    } 
  }
  
  public final void A09(CharSequence paramCharSequence1, CharSequence paramCharSequence2, String paramString1, String paramString2, byte paramByte) {
    if (this.A00 != null) {
      byte[] arrayOfByte = this.A02;
      arrayOfByte[0] = paramByte;
      int i = A01(this, 1, 4);
      i = A00(this, A02(paramCharSequence2, arrayOfByte, A02(paramString2, arrayOfByte, A02(paramCharSequence1, arrayOfByte, A02(paramString1, arrayOfByte, 1, i), i), i), i));
      try {
        Os.write(this.A00, arrayOfByte, 0, i);
        return;
      } catch (ErrnoException|java.io.InterruptedIOException errnoException) {
        return;
      } 
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01T.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */