package X;

public interface 04I {
  Object fold(Object paramObject, 053 param053);
  
  04H get(04R param04R);
  
  04I minusKey(04R param04R);
  
  04I plus(04I param04I);
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\04I.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */