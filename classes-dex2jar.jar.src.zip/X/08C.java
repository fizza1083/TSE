package X;

import java.util.AbstractSet;
import java.util.Iterator;
import java.util.Map;

public final class 08C extends AbstractSet<Map.Entry<K, V>> {
  public 08C(00Z param00Z) {}
  
  public final Iterator iterator() {
    return new 08E(this.A00);
  }
  
  public final int size() {
    return this.A00.size();
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08C.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */