package X;

import java.io.File;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public final class 03O implements 0si {
  public final long A00;
  
  public final 0qi A01;
  
  public final 0sj A02;
  
  public final 0tW A03;
  
  public final ScheduledExecutorService A04;
  
  public 03O(0qi param0qi, 0sj param0sj, 0tW param0tW, ScheduledExecutorService paramScheduledExecutorService, long paramLong) {
    this.A02 = param0sj;
    this.A03 = param0tW;
    this.A01 = param0qi;
    this.A04 = paramScheduledExecutorService;
    this.A00 = paramLong;
  }
  
  public final int getHealthEventSamplingRate() {
    return 50000000;
  }
  
  public final 0sj getName() {
    return this.A02;
  }
  
  public void onTriggered() {
    synchronized (this.A02) {
      0qi 0qi1 = this.A01;
      File file = 0qi1.A02.A07;
      0ah.A04(file, "Did you call SessionManager.init()?");
      if (!file.exists())
        this.A04.shutdown(); 
      if (0qK.A09()) {
        0dR 0dR = this.A03.A05;
        0ah.A04(0dR, "Did you call SessionManager.init()?");
        long l = System.currentTimeMillis();
        synchronized (0dR.A02) {
          0dR.A04(0dR, Long.toString(l), 180, 15);
        } 
        0jQ 0jQ = new 0jQ(null);
        0qi1.A08(0jQ, 0r7.A01, this);
        0qi1.A08(0jQ, 0r7.A02, this);
      } 
      return;
    } 
  }
  
  public final void start() {
    long l = this.A00;
    if (l > 0L)
      this.A04.scheduleWithFixedDelay(new 03Q(this), l, l, TimeUnit.SECONDS); 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\03O.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */