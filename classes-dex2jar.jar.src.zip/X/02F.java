package X;

public abstract class 02F extends 02G implements 02I {
  public final 0b0 BEQ() {
    ((02I)A00()).BEQ();
    throw 0GH.createAndThrow();
  }
  
  public final 0BI computeReflected() {
    return this;
  }
  
  public final Object invoke(Object paramObject) {
    return get(paramObject);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\02F.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */