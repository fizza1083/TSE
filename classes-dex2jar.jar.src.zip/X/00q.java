package X;

import android.os.Message;
import java.lang.reflect.Method;

public abstract class 00q implements 00r {
  public void AA2(Message paramMessage, 0RH param0RH, String paramString) {}
  
  public 01p AyX(014 param014, String paramString, Method paramMethod, Object[] paramArrayOfObject) {
    return null;
  }
  
  public void Ci8(Object paramObject, String paramString, Method paramMethod, Object[] paramArrayOfObject, long paramLong) {}
  
  public boolean Cv1(Message paramMessage, 0RH param0RH, String paramString) {
    return false;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */