package X;

import android.app.ActivityClient;
import android.content.Context;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public final class 00y extends 00w {
  public 00y() {
    super("activity_client_controller", null, null, null);
  }
  
  public final void A01(Context paramContext, 013 param013) {
    Method method = param013.A04(ActivityClient.class, "getActivityClientController", null);
    if (method != null) {
      try {
        method.invoke(null, null);
      } catch (Exception exception) {}
      Field field = param013.A03(ActivityClient.class, "INTERFACE_SINGLETON");
      if (field != null)
        try {
          Object object = field.get(null);
          if (object != null) {
            Class clazz = param013.A01("android.util.Singleton");
            if (clazz != null) {
              Field field1 = param013.A03(clazz, "mInstance");
              if (field1 != null) {
                Object object1 = field1.get(object);
                if (object1 != null) {
                  Class clazz1 = param013.A01("android.app.IActivityClientController");
                  if (clazz1 != null) {
                    Object object2 = 00w.A00(this, clazz1, object1);
                    field1.set(object, object2);
                  } 
                } 
              } 
            } 
          } 
          return;
        } catch (Exception exception) {
          return;
        }  
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */