package X;

import android.graphics.Rect;
import android.view.View;
import androidx.viewpager.widget.ViewPager;

public final class 080 implements 081 {
  public final Rect A00 = new Rect();
  
  public 080(ViewPager paramViewPager) {}
  
  public final 07N CRQ(View paramView, 07N param07N) {
    param07N = 07v.A04(paramView, param07N);
    07N 07N1 = param07N;
    if (!param07N.A00.A0B()) {
      Rect rect = this.A00;
      rect.left = param07N.A02();
      rect.top = param07N.A04();
      rect.right = param07N.A03();
      rect.bottom = param07N.A01();
      int i = 0;
      ViewPager viewPager = this.A01;
      int j = viewPager.getChildCount();
      while (i < j) {
        07N 07N2 = 07v.A03(viewPager.getChildAt(i), param07N);
        rect.left = Math.min(07N2.A02(), rect.left);
        rect.top = Math.min(07N2.A04(), rect.top);
        rect.right = Math.min(07N2.A03(), rect.right);
        rect.bottom = Math.min(07N2.A01(), rect.bottom);
        i++;
      } 
      07N1 = param07N.A07(rect.left, rect.top, rect.right, rect.bottom);
    } 
    return 07N1;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\080.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */