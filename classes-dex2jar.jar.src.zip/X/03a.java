package X;

public class 03a implements 03c {
  public int A00;
  
  public final Object[] A01;
  
  public 03a(int paramInt) {
    if (paramInt > 0) {
      this.A01 = new Object[paramInt];
      return;
    } 
    throw 001.A0O("The max pool size must be > 0");
  }
  
  public Object AAG() {
    int i = this.A00;
    if (i > 0) {
      i--;
      Object[] arrayOfObject = this.A01;
      Object object = arrayOfObject[i];
      16F.A0I(object, "null cannot be cast to non-null type T of androidx.core.util.Pools.SimplePool");
      arrayOfObject[i] = null;
      this.A00--;
      return object;
    } 
    return null;
  }
  
  public boolean Dbd(Object paramObject) {
    16F.A0E(paramObject, 0);
    int j = this.A00;
    for (int i = 0; i < j; i++) {
      if (this.A01[i] == paramObject)
        throw 001.A0S("Already in the pool!"); 
    } 
    Object[] arrayOfObject = this.A01;
    if (j < arrayOfObject.length) {
      arrayOfObject[j] = paramObject;
      this.A00 = j + 1;
      return true;
    } 
    return false;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\03a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */