package X;

public final class 031 {
  public final int A00;
  
  public final int A01;
  
  public final String A02;
  
  public 031(int paramInt1, int paramInt2, String paramString) {
    this.A00 = paramInt1;
    this.A01 = paramInt2;
    this.A02 = paramString;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\031.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */