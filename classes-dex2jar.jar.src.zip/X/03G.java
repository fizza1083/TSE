package X;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import java.util.ArrayList;
import java.util.HashMap;

public final class 03G extends Handler {
  public 03G(Looper paramLooper, 03F param03F) {
    super(paramLooper);
  }
  
  public final void handleMessage(Message paramMessage) {
    int i = 0BO.A01.internalBeginTrack(1740347142);
    if (paramMessage.what != 1) {
      super.handleMessage(paramMessage);
    } else {
      03F 03F1 = this.A00;
      label29: while (true) {
        HashMap hashMap;
        0FQ 0FQ;
        synchronized (03F1.A02) {
          ArrayList arrayList = 03F1.A01;
          int j = arrayList.size();
          if (j <= 0) {
          
          } else {
            0FQ[] arrayOf0FQ = new 0FQ[j];
            arrayList.toArray((Object[])arrayOf0FQ);
            arrayList.clear();
            int k = 0;
            while (true) {
              0FQ = arrayOf0FQ[k];
              int n = 0FQ.A01.size();
              for (int m = 0; m < n; m++) {
                03M 03M = 0FQ.A01.get(m);
                if (!03M.A01)
                  03M.A02.onReceive(03F1.A00, 0FQ.A00); 
              } 
              if (++k < j)
                continue; 
              continue label29;
            } 
            break;
          } 
          0BO.A01(i);
          return;
        } 
      } 
    } 
    0BO.A01(i);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\03G.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */