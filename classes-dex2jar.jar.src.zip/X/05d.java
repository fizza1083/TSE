package X;

import java.util.concurrent.Executor;

public final class 05d extends 04E implements Executor {
  public static final 04F A00;
  
  public static final 05d A01;
  
  static {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: \r\n\tat com.googlecode.dex2jar.ir.ts.NewTransformer.transform(NewTransformer.java:134)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:148)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public final 04F A02(int paramInt) {
    return 05h.A00.A02(paramInt);
  }
  
  public final void A03(Runnable paramRunnable, 04I param04I) {
    A00.A03(paramRunnable, param04I);
  }
  
  public final void A05(Runnable paramRunnable, 04I param04I) {
    A00.A05(paramRunnable, param04I);
  }
  
  public final Executor A06() {
    return this;
  }
  
  public final void close() {
    throw 001.A0S("Cannot be invoked on Dispatchers.IO");
  }
  
  public final void execute(Runnable paramRunnable) {
    050 050 = 050.A00;
    A00.A05(paramRunnable, 050);
  }
  
  public final String toString() {
    return "Dispatchers.IO";
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\05d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */