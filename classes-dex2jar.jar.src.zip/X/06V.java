package X;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.text.TextUtils;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public abstract class 06V {
  public static int A00 = 30;
  
  public static Handler A01;
  
  public static boolean A02;
  
  public static final ConcurrentHashMap A03;
  
  public static final Set A04;
  
  static {
    HashSet<String> hashSet = new HashSet(19);
    int i = 0;
    while (true) {
      (new String[19])[0] = "Pixel";
      (new String[19])[1] = "Pixel 2";
      (new String[19])[2] = "Pixel 2 XL";
      (new String[19])[3] = "Pixel 3";
      (new String[19])[4] = "Pixel 3 XL";
      (new String[19])[5] = "Pixel 3a";
      (new String[19])[6] = "Pixel 3a XL";
      (new String[19])[7] = "Pixel 4";
      (new String[19])[8] = "Pixel 4 XL";
      (new String[19])[9] = "Pixel 4a";
      (new String[19])[10] = "Pixel 4a (5G)";
      (new String[19])[11] = "Pixel 5";
      (new String[19])[12] = "Pixel 5a";
      (new String[19])[13] = "Pixel 6";
      (new String[19])[14] = "Pixel 6 Pro";
      (new String[19])[15] = "Pixel 6a";
      (new String[19])[16] = "Pixel 7";
      (new String[19])[17] = "Pixel 7 Pro";
      (new String[19])[18] = "Pixel C";
      String str = (new String[19])[i];
      str.getClass();
      if (hashSet.add(str)) {
        int j = i + 1;
        i = j;
        if (j >= 19) {
          A04 = Collections.unmodifiableSet(hashSet);
          A03 = new ConcurrentHashMap<Object, Object>();
          return;
        } 
        continue;
      } 
      throw 002.A0J(str, "duplicate element: ", 001.A0s());
    } 
  }
  
  public static void A00(PackageInfo paramPackageInfo, String paramString) {
    // Byte code:
    //   0: getstatic X/06V.A02 : Z
    //   3: ifeq -> 82
    //   6: getstatic X/06V.A03 : Ljava/util/concurrent/ConcurrentHashMap;
    //   9: astore #4
    //   11: aload #4
    //   13: aload_1
    //   14: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   17: ifne -> 82
    //   20: aload_0
    //   21: getfield applicationInfo : Landroid/content/pm/ApplicationInfo;
    //   24: astore_0
    //   25: aload_0
    //   26: ifnull -> 40
    //   29: aload_0
    //   30: getfield enabled : Z
    //   33: istore_3
    //   34: iconst_2
    //   35: istore_2
    //   36: iload_3
    //   37: ifne -> 42
    //   40: iconst_3
    //   41: istore_2
    //   42: aload #4
    //   44: aload_1
    //   45: iload_2
    //   46: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   49: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   52: pop
    //   53: getstatic X/06V.A01 : Landroid/os/Handler;
    //   56: astore_0
    //   57: aload_0
    //   58: ifnull -> 82
    //   61: aload_0
    //   62: new X/0p6
    //   65: dup
    //   66: aload_1
    //   67: invokespecial <init> : (Ljava/lang/String;)V
    //   70: getstatic X/06V.A00 : I
    //   73: i2l
    //   74: ldc2_w 1000
    //   77: lmul
    //   78: invokevirtual postDelayed : (Ljava/lang/Runnable;J)Z
    //   81: pop
    //   82: return
  }
  
  public static void A01(String paramString) {
    if (A02) {
      ConcurrentHashMap<String, Integer> concurrentHashMap = A03;
      if (!concurrentHashMap.containsKey(paramString)) {
        concurrentHashMap.put(paramString, Integer.valueOf(1));
        Handler handler = A01;
        if (handler != null)
          handler.postDelayed(new 0p5(paramString), A00 * 1000L); 
      } 
    } 
  }
  
  public static boolean A02() {
    String str = Build.FINGERPRINT;
    if (!str.startsWith("generic") && !str.startsWith("unknown") && !Build.MODEL.contains("google_sdk")) {
      str = Build.MODEL;
      if (!str.contains("Emulator") && !str.contains("Android SDK built for x86") && !Build.MANUFACTURER.contains("Genymotion") && (!Build.BRAND.startsWith("generic") || !Build.DEVICE.startsWith("generic"))) {
        boolean bool1 = "google_sdk".equals(Build.PRODUCT);
        boolean bool = false;
        return bool1 ? true : bool;
      } 
    } 
    return true;
  }
  
  public static boolean A03(Context paramContext, String paramString, int paramInt) {
    boolean bool = false;
    try {
      PackageManager packageManager = paramContext.getPackageManager();
      boolean bool1 = bool;
      if (packageManager != null) {
        PackageInfo packageInfo = packageManager.getPackageInfo(paramString, 0);
        bool1 = bool;
        if (packageInfo != null) {
          bool1 = bool;
          if (!TextUtils.isEmpty(packageInfo.versionName)) {
            bool1 = bool;
            if (Integer.parseInt(packageInfo.versionName.split("\\.", 2)[0]) >= paramInt)
              bool1 = true; 
          } 
        } 
      } 
      return bool1;
    } catch (android.content.pm.PackageManager.NameNotFoundException|NumberFormatException nameNotFoundException) {
      return false;
    } 
  }
  
  public static boolean A04(PackageManager paramPackageManager, String paramString) {
    boolean bool = false;
    if (A02) {
      Number number = (Number)A03.get(paramString);
      if (number != null) {
        boolean bool1 = bool;
        return (number.intValue() == 2) ? true : bool1;
      } 
    } 
    try {
      PackageInfo packageInfo = paramPackageManager.getPackageInfo(paramString, 128);
      A00(packageInfo, paramString);
      ApplicationInfo applicationInfo = packageInfo.applicationInfo;
      boolean bool1 = bool;
      if (applicationInfo != null) {
        bool1 = bool;
        if (applicationInfo.enabled)
          return true; 
      } 
      return bool1;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      A01(paramString);
      return false;
    } catch (RuntimeException runtimeException) {
      if (001.A1Z(runtimeException)) {
        A01(paramString);
        return false;
      } 
      throw runtimeException;
    } 
  }
  
  public static boolean A05(PackageManager paramPackageManager, String paramString) {
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (paramPackageManager != null) {
      Number number;
      if (A02) {
        number = (Number)A03.get(paramString);
      } else {
        number = null;
      } 
      if (number != null) {
        bool1 = bool2;
        if (number.intValue() != 1)
          bool1 = true; 
        return bool1;
      } 
    } else {
      return bool1;
    } 
    int i = 2;
    try {
      while (true) {
        A00(paramPackageManager.getPackageInfo(paramString, 128), paramString);
        return true;
      } 
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      A01(paramString);
      return false;
    } catch (RuntimeException runtimeException) {
      if (001.A1Z(runtimeException)) {
        A01(paramString);
        return false;
      } 
      if (i != 0) {
        int j = i - 1;
        i = j;
        if (j < 0) {
          runtimeException = 001.A0S("should be unreachable");
          throw runtimeException;
        } 
      } else {
        throw runtimeException;
      } 
      while (true) {
        A00(nameNotFoundException.getPackageInfo(paramString, 128), paramString);
        return true;
      } 
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\06V.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */