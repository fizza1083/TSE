package X;

import java.util.Arrays;

public final class 017 implements Cloneable {
  public 017() {
    this(10);
  }
  
  public 017(int paramInt) {
    Object[] arrayOfObject;
    if (paramInt == 0) {
      this.A02 = 0Xj.A01;
      arrayOfObject = 0Xj.A02;
    } else {
      int i;
      int j = paramInt * 8;
      paramInt = 4;
      while (true) {
        int k = (1 << paramInt) - 12;
        i = k;
        if (j > k) {
          i = paramInt + 1;
          paramInt = i;
          if (i >= 32) {
            i = j;
            break;
          } 
          continue;
        } 
        break;
      } 
      paramInt = i / 8;
      this.A02 = new long[paramInt];
      arrayOfObject = new Object[paramInt];
    } 
    this.A03 = arrayOfObject;
  }
  
  public static void A00(Object paramObject, long[] paramArrayOflong, Object[] paramArrayOfObject, int paramInt1, int paramInt2) {
    if (paramInt1 != paramInt2) {
      paramArrayOflong[paramInt2] = paramArrayOflong[paramInt1];
      paramArrayOfObject[paramInt2] = paramObject;
      paramArrayOfObject[paramInt1] = null;
    } 
  }
  
  public final int A01() {
    if (this.A01) {
      int k = this.A00;
      long[] arrayOfLong = this.A02;
      Object[] arrayOfObject = this.A03;
      int i = 0;
      int j;
      for (j = 0; i < k; j = m) {
        Object object = arrayOfObject[i];
        int m = j;
        if (object != 0A9.A00) {
          if (i != j) {
            arrayOfLong[j] = arrayOfLong[i];
            arrayOfObject[j] = object;
            arrayOfObject[i] = null;
          } 
          m = j + 1;
        } 
        i++;
      } 
      this.A01 = false;
      this.A00 = j;
    } 
    return this.A00;
  }
  
  public final int A02(long paramLong) {
    if (this.A01) {
      int k = this.A00;
      long[] arrayOfLong = this.A02;
      Object[] arrayOfObject = this.A03;
      int i = 0;
      int j;
      for (j = 0; i < k; j = m) {
        Object object = arrayOfObject[i];
        int m = j;
        if (object != 0A9.A00) {
          A00(object, arrayOfLong, arrayOfObject, i, j);
          m = j + 1;
        } 
        i++;
      } 
      this.A01 = false;
      this.A00 = j;
    } 
    return 0Xj.A01(this.A02, this.A00, paramLong);
  }
  
  public final long A03(int paramInt) {
    if (paramInt >= 0) {
      int i = this.A00;
      if (paramInt < i) {
        if (this.A01) {
          long[] arrayOfLong = this.A02;
          Object[] arrayOfObject = this.A03;
          int j = 0;
          int k = 0;
          while (true) {
            Object object = arrayOfObject[j];
            int m = k;
            if (object != 0A9.A00) {
              A00(object, arrayOfLong, arrayOfObject, j, k);
              m = k + 1;
            } 
            int n = j + 1;
            k = m;
            j = n;
            if (n >= i) {
              this.A01 = false;
              this.A00 = m;
              break;
            } 
          } 
        } 
        return this.A02[paramInt];
      } 
    } 
    0XK.A1I(paramInt);
    throw 0GH.createAndThrow();
  }
  
  public final 017 A04() {
    Object object = super.clone();
    16F.A0I(object, "null cannot be cast to non-null type androidx.collection.LongSparseArray<E of androidx.collection.LongSparseArray>");
    object = object;
    ((017)object).A02 = (long[])this.A02.clone();
    ((017)object).A03 = (Object[])this.A03.clone();
    return (017)object;
  }
  
  public final Object A05(int paramInt) {
    if (paramInt >= 0) {
      int i = this.A00;
      if (paramInt < i) {
        if (this.A01) {
          long[] arrayOfLong = this.A02;
          Object[] arrayOfObject = this.A03;
          int j = 0;
          int k = 0;
          while (true) {
            Object object = arrayOfObject[j];
            int m = k;
            if (object != 0A9.A00) {
              A00(object, arrayOfLong, arrayOfObject, j, k);
              m = k + 1;
            } 
            int n = j + 1;
            k = m;
            j = n;
            if (n >= i) {
              this.A01 = false;
              this.A00 = m;
              break;
            } 
          } 
        } 
        return this.A03[paramInt];
      } 
    } 
    0XK.A1I(paramInt);
    throw 0GH.createAndThrow();
  }
  
  public final Object A06(long paramLong) {
    int i = 0Xj.A01(this.A02, this.A00, paramLong);
    if (i >= 0) {
      Object object2 = this.A03[i];
      Object object1 = object2;
      return (object2 == 0A9.A00) ? null : object1;
    } 
    return null;
  }
  
  public final Object A07(long paramLong, Object paramObject) {
    int i = 0Xj.A01(this.A02, this.A00, paramLong);
    if (i >= 0) {
      Object object = this.A03[i];
      if (object != 0A9.A00)
        return object; 
    } 
    return paramObject;
  }
  
  public final void A08() {
    int j = this.A00;
    Object[] arrayOfObject = this.A03;
    for (int i = 0; i < j; i++)
      arrayOfObject[i] = null; 
    this.A00 = 0;
    this.A01 = false;
  }
  
  public final void A09(int paramInt) {
    Object[] arrayOfObject = this.A03;
    Object object1 = arrayOfObject[paramInt];
    Object object2 = 0A9.A00;
    if (object1 != object2) {
      arrayOfObject[paramInt] = object2;
      this.A01 = true;
    } 
  }
  
  public final void A0A(int paramInt, Object paramObject) {
    if (paramInt >= 0) {
      int i = this.A00;
      if (paramInt < i) {
        if (this.A01) {
          long[] arrayOfLong = this.A02;
          Object[] arrayOfObject = this.A03;
          int j = 0;
          int k = 0;
          while (true) {
            Object object = arrayOfObject[j];
            int m = k;
            if (object != 0A9.A00) {
              A00(object, arrayOfLong, arrayOfObject, j, k);
              m = k + 1;
            } 
            int n = j + 1;
            k = m;
            j = n;
            if (n >= i) {
              this.A01 = false;
              this.A00 = m;
              break;
            } 
          } 
        } 
        this.A03[paramInt] = paramObject;
        return;
      } 
    } 
    0XK.A1I(paramInt);
    throw 0GH.createAndThrow();
  }
  
  public final void A0B(long paramLong) {
    int i = 0Xj.A01(this.A02, this.A00, paramLong);
    if (i >= 0) {
      Object[] arrayOfObject = this.A03;
      Object object1 = arrayOfObject[i];
      Object object2 = 0A9.A00;
      if (object1 != object2) {
        arrayOfObject[i] = object2;
        this.A01 = true;
      } 
    } 
  }
  
  public final void A0C(long paramLong, Object paramObject) {
    int i = 0Xj.A01(this.A02, this.A00, paramLong);
    int j = i;
    if (i < 0) {
      j = i ^ 0xFFFFFFFF;
      int k = this.A00;
      if (j < k && this.A03[j] == 0A9.A00) {
        this.A02[j] = paramLong;
      } else {
        i = j;
        if (this.A01) {
          long[] arrayOfLong1 = this.A02;
          i = j;
          if (k >= arrayOfLong1.length) {
            Object[] arrayOfObject = this.A03;
            i = 0;
            for (j = 0; i < k; j = m) {
              Object object = arrayOfObject[i];
              int m = j;
              if (object != 0A9.A00) {
                if (i != j) {
                  arrayOfLong1[j] = arrayOfLong1[i];
                  arrayOfObject[j] = object;
                  arrayOfObject[i] = null;
                } 
                m = j + 1;
              } 
              i++;
            } 
            this.A01 = false;
            this.A00 = j;
            i = 0Xj.A01(arrayOfLong1, j, paramLong) ^ 0xFFFFFFFF;
          } 
        } 
        j = this.A00;
        long[] arrayOfLong = this.A02;
        if (j >= arrayOfLong.length) {
          int m;
          k = (j + 1) * 8;
          j = 4;
          while (true) {
            int n = (1 << j) - 12;
            m = n;
            if (k > n) {
              m = j + 1;
              j = m;
              if (m >= 32) {
                m = k;
                break;
              } 
              continue;
            } 
            break;
          } 
          j = m / 8;
          arrayOfLong = Arrays.copyOf(arrayOfLong, j);
          16F.A0A(arrayOfLong);
          this.A02 = arrayOfLong;
          arrayOfLong = Arrays.copyOf((long[])this.A03, j);
          16F.A0A(arrayOfLong);
          this.A03 = (Object[])arrayOfLong;
        } 
        j = this.A00;
        if (j - i != 0) {
          arrayOfLong = this.A02;
          int m = i + 1;
          16F.A0E(arrayOfLong, 0);
          System.arraycopy(arrayOfLong, i, arrayOfLong, m, j - i);
          Object[] arrayOfObject = this.A03;
          155.A0M(arrayOfObject, arrayOfObject, m, i, this.A00);
        } 
        this.A02[i] = paramLong;
        this.A03[i] = paramObject;
        this.A00++;
        return;
      } 
    } 
    this.A03[j] = paramObject;
  }
  
  public final String toString() {
    if (A01() <= 0)
      return "{}"; 
    int j = this.A00;
    StringBuilder stringBuilder = 001.A0t(j * 28);
    stringBuilder.append('{');
    for (int i = 0; i < j; i++) {
      if (i > 0)
        001.A1P(stringBuilder); 
      stringBuilder.append(A03(i));
      stringBuilder.append('=');
      Object object = A05(i);
      if (object != stringBuilder) {
        stringBuilder.append(object);
      } else {
        stringBuilder.append("(this Map)");
      } 
    } 
    String str = 002.A0X(stringBuilder);
    16F.A0A(str);
    return str;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\017.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */