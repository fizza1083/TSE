package X;

import android.content.BroadcastReceiver;
import android.os.Bundle;

public interface 01Y {
  int getResultCode();
  
  String getResultData();
  
  Bundle getResultExtras(boolean paramBoolean);
  
  BroadcastReceiver.PendingResult goAsync();
  
  boolean isInitialStickyBroadcast();
  
  void setResult(int paramInt, String paramString, Bundle paramBundle);
  
  void setResultCode(int paramInt);
  
  void setResultData(String paramString);
  
  void setResultExtras(Bundle paramBundle);
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01Y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */