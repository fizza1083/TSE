package X;

import android.os.Environment;
import android.os.StatFs;
import android.os.SystemClock;
import java.io.File;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public final class 049 {
  public static 049 A07;
  
  public static final long A08 = TimeUnit.MINUTES.toMillis(2L);
  
  public long A00;
  
  public final Lock A01 = new ReentrantLock();
  
  public volatile StatFs A02 = null;
  
  public volatile StatFs A03 = null;
  
  public volatile File A04;
  
  public volatile File A05;
  
  public volatile boolean A06 = false;
  
  public static StatFs A00(StatFs paramStatFs, File paramFile) {
    if (paramFile != null && paramFile.exists()) {
      if (paramStatFs == null)
        try {
          return new StatFs(paramFile.getAbsolutePath());
        } catch (IllegalArgumentException illegalArgumentException) {
          return null;
        } finally {
          paramStatFs = null;
          0np.A00((Throwable)paramStatFs);
        }  
      paramStatFs.restat(paramFile.getAbsolutePath());
      return paramStatFs;
    } 
    return null;
  }
  
  public static 049 A01() {
    // Byte code:
    //   0: ldc X/049
    //   2: monitorenter
    //   3: getstatic X/049.A07 : LX/049;
    //   6: astore_1
    //   7: aload_1
    //   8: astore_0
    //   9: aload_1
    //   10: ifnonnull -> 25
    //   13: new X/049
    //   16: dup
    //   17: invokespecial <init> : ()V
    //   20: astore_0
    //   21: aload_0
    //   22: putstatic X/049.A07 : LX/049;
    //   25: ldc X/049
    //   27: monitorexit
    //   28: aload_0
    //   29: areturn
    //   30: astore_0
    //   31: ldc X/049
    //   33: monitorexit
    //   34: aload_0
    //   35: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	30	finally
    //   13	25	30	finally
  }
  
  private void A02() {
    this.A03 = A00(this.A03, this.A05);
    this.A02 = A00(this.A02, this.A04);
    this.A00 = SystemClock.uptimeMillis();
  }
  
  public static void A03(049 param049) {
    if (!param049.A06) {
      Lock lock = param049.A01;
      lock.lock();
      try {
        if (!param049.A06) {
          param049.A05 = Environment.getDataDirectory();
          param049.A04 = Environment.getExternalStorageDirectory();
          param049.A02();
          param049.A06 = true;
        } 
      } finally {
        lock.unlock();
      } 
    } 
  }
  
  public static void A04(049 param049) {
    Lock lock = param049.A01;
    if (lock.tryLock())
      try {
        if (SystemClock.uptimeMillis() - param049.A00 > A08)
          param049.A02(); 
      } finally {
        lock.unlock();
      }  
  }
  
  public final long A05() {
    A03(this);
    A04(this);
    StatFs statFs = this.A03;
    return (statFs != null) ? (statFs.getBlockSizeLong() * statFs.getFreeBlocksLong()) : -1L;
  }
  
  public final long A06(Integer paramInteger) {
    StatFs statFs;
    A03(this);
    A04(this);
    if (paramInteger == 0Xy.A00) {
      statFs = this.A03;
    } else {
      statFs = this.A02;
    } 
    return (statFs != null) ? (statFs.getBlockSizeLong() * statFs.getAvailableBlocksLong()) : 0L;
  }
  
  public final void A07() {
    Lock lock = this.A01;
    if (lock.tryLock())
      try {
        A03(this);
        A02();
      } finally {
        lock.unlock();
      }  
  }
  
  public final boolean A08(Integer paramInteger, long paramLong) {
    A03(this);
    long l = A06(paramInteger);
    boolean bool2 = true;
    boolean bool1 = bool2;
    if (l > 0L) {
      bool1 = bool2;
      if (l >= paramLong)
        bool1 = false; 
    } 
    return bool1;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\049.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */