package X;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public abstract class 08Z {
  public Map A00 = new HashMap<Object, Object>();
  
  public final void A04(07A param07A, String paramString) {
    Map<String, Object> map = this.A00;
    Object object = param07A;
    if (param07A != null)
      object = param07A.getValue(); 
    map.put(paramString, object);
  }
  
  public final void A05(08Z param08Z, String paramString) {
    Map map;
    08Z 08Z1 = param08Z;
    if (param08Z != null)
      map = param08Z.A00; 
    this.A00.put(paramString, map);
  }
  
  public final void A06(String paramString, Boolean paramBoolean) {
    this.A00.put(paramString, paramBoolean);
  }
  
  public final void A07(String paramString, Double paramDouble) {
    this.A00.put(paramString, paramDouble);
  }
  
  public final void A08(String paramString, Integer paramInteger) {
    this.A00.put(paramString, paramInteger);
  }
  
  public final void A09(String paramString, Long paramLong) {
    this.A00.put(paramString, paramLong);
  }
  
  public final void A0A(String paramString1, String paramString2) {
    this.A00.put(paramString1, paramString2);
  }
  
  public final void A0B(String paramString, List paramList) {
    this.A00.put(paramString, paramList);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08Z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */