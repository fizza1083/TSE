package X;

public abstract class 04x extends 04y implements 0BQ {
  public abstract void A04(Throwable paramThrowable);
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\04x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */