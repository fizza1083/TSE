package X;

import kotlin.enums.EnumEntries;

public enum 02w {
  A02, A03, A04;
  
  static {
    02w 02w1 = new 02w("SYNCHRONIZED", 0);
    A04 = 02w1;
    02w 02w2 = new 02w("PUBLICATION", 1);
    A03 = 02w2;
    02w 02w3 = new 02w("NONE", 2);
    A02 = 02w3;
    02w[] arrayOf02w = new 02w[3];
    arrayOf02w[0] = 02w1;
    arrayOf02w[1] = 02w2;
    arrayOf02w[2] = 02w3;
    A01 = arrayOf02w;
    A00 = 00S.A00((Enum[])arrayOf02w);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\02w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */