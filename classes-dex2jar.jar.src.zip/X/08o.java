package X;

public abstract class 08o {
  public abstract void A00();
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */