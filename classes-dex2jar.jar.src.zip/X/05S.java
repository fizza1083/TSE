package X;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageItemInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;

public final class 05S {
  public final Context A00;
  
  public 05S(Context paramContext) {
    this.A00 = paramContext;
  }
  
  public final String A00(String paramString1, String paramString2) {
    try {
      ApplicationInfo applicationInfo = this.A00.getPackageManager().getApplicationInfo(paramString2, 128);
      if (applicationInfo != null) {
        Bundle bundle = ((PackageItemInfo)applicationInfo).metaData;
        if (bundle != null) {
          Object object = bundle.get(paramString1);
          if (object != null)
            return object.toString(); 
        } 
      } 
      return null;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      Log.e(05S.class.getName(), "Error reading <meta-data> from AndroidManifest.xml.", (Throwable)nameNotFoundException);
      return null;
    } catch (RuntimeException runtimeException) {
      if (001.A1Z(runtimeException)) {
        Log.e(05S.class.getName(), "Error reading <meta-data> from AndroidManifest.xml.", runtimeException);
        return null;
      } 
      throw runtimeException;
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\05S.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */