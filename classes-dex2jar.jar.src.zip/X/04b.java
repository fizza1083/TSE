package X;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import com.facebook.profilo.ipc.TraceContext;
import java.util.HashSet;
import java.util.Random;

public final class 04b extends Handler {
  public final 04c A00;
  
  public final 0F3 A01;
  
  public final 0Es A02;
  
  public final HashSet A03;
  
  public final Random A04;
  
  public 04b(Looper paramLooper, 0F3 param0F3, 0Es param0Es) {
    super(paramLooper);
    this.A01 = param0F3;
    this.A02 = param0Es;
    this.A03 = 001.A12();
    this.A00 = new 04c();
    this.A04 = new Random();
  }
  
  public final void A00(TraceContext paramTraceContext) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield A03 : Ljava/util/HashSet;
    //   6: astore_2
    //   7: aload_2
    //   8: aload_1
    //   9: getfield A06 : J
    //   12: invokestatic valueOf : (J)Ljava/lang/Long;
    //   15: invokevirtual contains : (Ljava/lang/Object;)Z
    //   18: ifeq -> 44
    //   21: aload_0
    //   22: aload_0
    //   23: iconst_3
    //   24: aload_1
    //   25: invokevirtual obtainMessage : (ILjava/lang/Object;)Landroid/os/Message;
    //   28: invokevirtual sendMessage : (Landroid/os/Message;)Z
    //   31: pop
    //   32: aload_2
    //   33: aload_1
    //   34: getfield A06 : J
    //   37: invokestatic valueOf : (J)Ljava/lang/Long;
    //   40: invokevirtual remove : (Ljava/lang/Object;)Z
    //   43: pop
    //   44: aload_0
    //   45: monitorexit
    //   46: return
    //   47: astore_1
    //   48: aload_0
    //   49: monitorexit
    //   50: aload_1
    //   51: athrow
    // Exception table:
    //   from	to	target	type
    //   2	44	47	finally
  }
  
  public final void A01(TraceContext paramTraceContext) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield A03 : Ljava/util/HashSet;
    //   6: astore_2
    //   7: aload_2
    //   8: aload_1
    //   9: getfield A06 : J
    //   12: invokestatic valueOf : (J)Ljava/lang/Long;
    //   15: invokevirtual contains : (Ljava/lang/Object;)Z
    //   18: ifeq -> 44
    //   21: aload_0
    //   22: aload_0
    //   23: iconst_2
    //   24: aload_1
    //   25: invokevirtual obtainMessage : (ILjava/lang/Object;)Landroid/os/Message;
    //   28: invokevirtual sendMessage : (Landroid/os/Message;)Z
    //   31: pop
    //   32: aload_2
    //   33: aload_1
    //   34: getfield A06 : J
    //   37: invokestatic valueOf : (J)Ljava/lang/Long;
    //   40: invokevirtual remove : (Ljava/lang/Object;)Z
    //   43: pop
    //   44: aload_0
    //   45: monitorexit
    //   46: return
    //   47: astore_1
    //   48: aload_0
    //   49: monitorexit
    //   50: aload_1
    //   51: athrow
    // Exception table:
    //   from	to	target	type
    //   2	44	47	finally
  }
  
  public final void handleMessage(Message paramMessage) {
    // Byte code:
    //   0: aload_1
    //   1: getfield what : I
    //   4: istore_2
    //   5: iload_2
    //   6: bipush #7
    //   8: if_icmpeq -> 893
    //   11: aload_1
    //   12: getfield obj : Ljava/lang/Object;
    //   15: checkcast com/facebook/profilo/ipc/TraceContext
    //   18: astore #12
    //   20: iload_2
    //   21: tableswitch default -> 64, 0 -> 65, 1 -> 142, 2 -> 657, 3 -> 113, 4 -> 627, 5 -> 220, 6 -> 300
    //   64: return
    //   65: aload #12
    //   67: getfield A06 : J
    //   70: lstore #8
    //   72: getstatic X/0FA.A0C : LX/0FA;
    //   75: astore_1
    //   76: aload_1
    //   77: ifnull -> 876
    //   80: aload_1
    //   81: lload #8
    //   83: invokestatic A01 : (LX/0FA;J)Lcom/facebook/profilo/ipc/TraceContext;
    //   86: astore #12
    //   88: aload #12
    //   90: ifnull -> 64
    //   93: aload #12
    //   95: aload #12
    //   97: getfield A09 : Lcom/facebook/profilo/mmapbuf/core/Buffer;
    //   100: bipush #41
    //   102: invokestatic A0p : (Lcom/facebook/profilo/ipc/TraceContext;Lcom/facebook/profilo/mmapbuf/core/Buffer;I)V
    //   105: aload_1
    //   106: lload #8
    //   108: iconst_4
    //   109: invokevirtual A0B : (JI)V
    //   112: return
    //   113: aload_0
    //   114: monitorenter
    //   115: aload_0
    //   116: iconst_0
    //   117: aload #12
    //   119: invokevirtual removeMessages : (ILjava/lang/Object;)V
    //   122: aload_0
    //   123: monitorexit
    //   124: aload_0
    //   125: getfield A01 : LX/0F3;
    //   128: astore_1
    //   129: aload_1
    //   130: ifnull -> 64
    //   133: aload_1
    //   134: aload #12
    //   136: invokeinterface onTraceAbort : (Lcom/facebook/profilo/ipc/TraceContext;)V
    //   141: return
    //   142: aload #12
    //   144: getfield A03 : I
    //   147: iconst_2
    //   148: iand
    //   149: ifne -> 202
    //   152: aload #12
    //   154: getfield A0G : LX/04h;
    //   157: ifnull -> 887
    //   160: aload #12
    //   162: getfield A0G : LX/04h;
    //   165: invokevirtual start : ()V
    //   168: aload #12
    //   170: getfield A08 : Lcom/facebook/profilo/ipc/TraceConfigExtras;
    //   173: ldc 'trace_config.logger_priority'
    //   175: iconst_5
    //   176: invokevirtual A00 : (Ljava/lang/String;I)I
    //   179: istore_2
    //   180: aload #12
    //   182: getfield A09 : Lcom/facebook/profilo/mmapbuf/core/Buffer;
    //   185: bipush #6
    //   187: bipush #98
    //   189: lconst_0
    //   190: iconst_0
    //   191: iload_2
    //   192: iconst_0
    //   193: aload #12
    //   195: getfield A06 : J
    //   198: invokestatic writeStandardEntry : (Lcom/facebook/profilo/mmapbuf/core/Buffer;IIJIIIJ)I
    //   201: pop
    //   202: aload_0
    //   203: getfield A01 : LX/0F3;
    //   206: astore_1
    //   207: aload_1
    //   208: ifnull -> 64
    //   211: aload_1
    //   212: aload #12
    //   214: invokeinterface DLH : (Lcom/facebook/profilo/ipc/TraceContext;)V
    //   219: return
    //   220: aload_1
    //   221: getfield arg1 : I
    //   224: i2l
    //   225: lstore #8
    //   227: aload_0
    //   228: getfield A00 : LX/04c;
    //   231: astore_1
    //   232: aload #12
    //   234: getfield A06 : J
    //   237: lstore #10
    //   239: aload_1
    //   240: monitorenter
    //   241: aload_1
    //   242: getfield A00 : Landroid/util/LongSparseArray;
    //   245: lload #10
    //   247: invokevirtual get : (J)Ljava/lang/Object;
    //   250: checkcast X/04e
    //   253: astore #12
    //   255: aload #12
    //   257: ifnull -> 290
    //   260: aload #12
    //   262: getfield A01 : LX/0FU;
    //   265: astore #12
    //   267: aload #12
    //   269: ifnull -> 290
    //   272: lload #8
    //   274: aload #12
    //   276: getfield A00 : J
    //   279: lcmp
    //   280: ifle -> 290
    //   283: aload #12
    //   285: lload #8
    //   287: putfield A00 : J
    //   290: aload_1
    //   291: monitorexit
    //   292: return
    //   293: astore #12
    //   295: aload_1
    //   296: monitorexit
    //   297: aload #12
    //   299: athrow
    //   300: aload_0
    //   301: getfield A00 : LX/04c;
    //   304: astore_1
    //   305: aload #12
    //   307: getfield A06 : J
    //   310: lstore #8
    //   312: aload_1
    //   313: monitorenter
    //   314: aload_1
    //   315: getfield A00 : Landroid/util/LongSparseArray;
    //   318: astore #13
    //   320: aload #13
    //   322: lload #8
    //   324: invokevirtual get : (J)Ljava/lang/Object;
    //   327: checkcast X/04e
    //   330: astore #15
    //   332: aload #15
    //   334: ifnull -> 505
    //   337: aload #15
    //   339: getfield A00 : LX/0FV;
    //   342: astore #16
    //   344: aload #16
    //   346: ifnull -> 410
    //   349: aload #16
    //   351: getfield A02 : Ljava/util/HashSet;
    //   354: astore #14
    //   356: aload #14
    //   358: monitorenter
    //   359: aload #16
    //   361: getfield A01 : LX/0vk;
    //   364: aload #14
    //   366: aload #16
    //   368: getfield A03 : [Ljava/lang/String;
    //   371: invokeinterface Aky : (Ljava/util/HashSet;[Ljava/lang/String;)Z
    //   376: ifeq -> 385
    //   379: aload #14
    //   381: monitorexit
    //   382: goto -> 410
    //   385: aload #14
    //   387: monitorexit
    //   388: aload #16
    //   390: getfield A00 : I
    //   393: istore_3
    //   394: iload_3
    //   395: iconst_1
    //   396: if_icmpeq -> 410
    //   399: goto -> 507
    //   402: astore #12
    //   404: aload #14
    //   406: monitorexit
    //   407: aload #12
    //   409: athrow
    //   410: aload #15
    //   412: getfield A01 : LX/0FU;
    //   415: astore #14
    //   417: aload #14
    //   419: ifnull -> 505
    //   422: iconst_0
    //   423: istore #4
    //   425: iconst_0
    //   426: istore_2
    //   427: iconst_m1
    //   428: istore #5
    //   430: aload #14
    //   432: getfield A01 : [I
    //   435: astore #15
    //   437: iload_2
    //   438: istore_3
    //   439: iload #4
    //   441: aload #15
    //   443: arraylength
    //   444: if_icmpge -> 507
    //   447: aload #14
    //   449: getfield A00 : J
    //   452: lstore #8
    //   454: aload #15
    //   456: iload #4
    //   458: iaload
    //   459: istore #7
    //   461: iload_2
    //   462: istore_3
    //   463: iload #5
    //   465: istore #6
    //   467: lload #8
    //   469: iload #7
    //   471: i2l
    //   472: lcmp
    //   473: ifle -> 1000
    //   476: iload_2
    //   477: istore_3
    //   478: iload #5
    //   480: istore #6
    //   482: iload #7
    //   484: iload #5
    //   486: if_icmple -> 1000
    //   489: aload #14
    //   491: getfield A02 : [I
    //   494: iload #4
    //   496: iaload
    //   497: istore_3
    //   498: iload #7
    //   500: istore #6
    //   502: goto -> 1000
    //   505: iconst_1
    //   506: istore_3
    //   507: aload_1
    //   508: monitorexit
    //   509: iload_3
    //   510: ifeq -> 577
    //   513: aload_0
    //   514: getfield A04 : Ljava/util/Random;
    //   517: iload_3
    //   518: invokevirtual nextInt : (I)I
    //   521: ifne -> 577
    //   524: aload #12
    //   526: getfield A09 : Lcom/facebook/profilo/mmapbuf/core/Buffer;
    //   529: astore #14
    //   531: aload #14
    //   533: bipush #6
    //   535: bipush #99
    //   537: lconst_0
    //   538: iconst_0
    //   539: iconst_0
    //   540: iconst_0
    //   541: iload_3
    //   542: i2l
    //   543: invokestatic writeStandardEntry : (Lcom/facebook/profilo/mmapbuf/core/Buffer;IIJIIIJ)I
    //   546: pop
    //   547: aload #14
    //   549: bipush #6
    //   551: bipush #61
    //   553: lconst_0
    //   554: iconst_0
    //   555: iconst_0
    //   556: iconst_0
    //   557: aload #12
    //   559: getfield A06 : J
    //   562: invokestatic writeStandardEntry : (Lcom/facebook/profilo/mmapbuf/core/Buffer;IIJIIIJ)I
    //   565: pop
    //   566: aload_0
    //   567: aload #12
    //   569: invokevirtual A01 : (Lcom/facebook/profilo/ipc/TraceContext;)V
    //   572: aload_1
    //   573: monitorenter
    //   574: goto -> 607
    //   577: aload #12
    //   579: aload #12
    //   581: getfield A09 : Lcom/facebook/profilo/mmapbuf/core/Buffer;
    //   584: bipush #37
    //   586: invokestatic A0p : (Lcom/facebook/profilo/ipc/TraceContext;Lcom/facebook/profilo/mmapbuf/core/Buffer;I)V
    //   589: aload_0
    //   590: new com/facebook/profilo/ipc/TraceContext
    //   593: dup
    //   594: aload #12
    //   596: bipush #6
    //   598: invokespecial <init> : (Lcom/facebook/profilo/ipc/TraceContext;I)V
    //   601: invokevirtual A00 : (Lcom/facebook/profilo/ipc/TraceContext;)V
    //   604: goto -> 572
    //   607: aload #13
    //   609: aload #12
    //   611: getfield A06 : J
    //   614: invokevirtual delete : (J)V
    //   617: aload_1
    //   618: monitorexit
    //   619: return
    //   620: astore #12
    //   622: aload_1
    //   623: monitorexit
    //   624: aload #12
    //   626: athrow
    //   627: aload_0
    //   628: getfield A01 : LX/0F3;
    //   631: astore_1
    //   632: aload_1
    //   633: ifnull -> 644
    //   636: aload_1
    //   637: aload #12
    //   639: invokeinterface onTraceStop : (Lcom/facebook/profilo/ipc/TraceContext;)V
    //   644: aload #12
    //   646: aload #12
    //   648: getfield A09 : Lcom/facebook/profilo/mmapbuf/core/Buffer;
    //   651: bipush #38
    //   653: invokestatic A0p : (Lcom/facebook/profilo/ipc/TraceContext;Lcom/facebook/profilo/mmapbuf/core/Buffer;I)V
    //   656: return
    //   657: aload_0
    //   658: monitorenter
    //   659: aload_0
    //   660: iconst_0
    //   661: aload #12
    //   663: invokevirtual removeMessages : (ILjava/lang/Object;)V
    //   666: aload #12
    //   668: getfield A03 : I
    //   671: iconst_2
    //   672: iand
    //   673: ifeq -> 768
    //   676: aload #12
    //   678: getfield A0G : LX/04h;
    //   681: ifnull -> 863
    //   684: aload #12
    //   686: getfield A0G : LX/04h;
    //   689: invokevirtual start : ()V
    //   692: aload #12
    //   694: getfield A08 : Lcom/facebook/profilo/ipc/TraceConfigExtras;
    //   697: ldc 'trace_config.logger_priority'
    //   699: iconst_5
    //   700: invokevirtual A00 : (Ljava/lang/String;I)I
    //   703: istore_2
    //   704: aload #12
    //   706: getfield A09 : Lcom/facebook/profilo/mmapbuf/core/Buffer;
    //   709: bipush #6
    //   711: bipush #98
    //   713: lconst_0
    //   714: iconst_0
    //   715: iload_2
    //   716: iconst_0
    //   717: aload #12
    //   719: getfield A06 : J
    //   722: invokestatic writeStandardEntry : (Lcom/facebook/profilo/mmapbuf/core/Buffer;IIJIIIJ)I
    //   725: pop
    //   726: aload #12
    //   728: getfield A0G : LX/04h;
    //   731: getfield A01 : Lcom/facebook/profilo/writer/NativeTraceWriter;
    //   734: astore_1
    //   735: aload #12
    //   737: getfield A09 : Lcom/facebook/profilo/mmapbuf/core/Buffer;
    //   740: astore #13
    //   742: aload #12
    //   744: getfield A06 : J
    //   747: lstore #8
    //   749: aload_1
    //   750: aload #13
    //   752: lload #8
    //   754: bipush #40
    //   756: iconst_0
    //   757: aload #12
    //   759: getfield A03 : I
    //   762: lload #8
    //   764: invokestatic writeAndWakeupTraceWriter : (Lcom/facebook/profilo/writer/NativeTraceWriter;Lcom/facebook/profilo/mmapbuf/core/Buffer;JIIIJ)I
    //   767: pop
    //   768: aload #12
    //   770: getfield A08 : Lcom/facebook/profilo/ipc/TraceConfigExtras;
    //   773: ldc 'trace_config.post_trace_extension_ms'
    //   775: iconst_0
    //   776: invokevirtual A00 : (Ljava/lang/String;I)I
    //   779: istore_2
    //   780: aload_0
    //   781: aload_0
    //   782: iconst_4
    //   783: aload #12
    //   785: invokevirtual obtainMessage : (ILjava/lang/Object;)Landroid/os/Message;
    //   788: iload_2
    //   789: i2l
    //   790: invokevirtual sendMessageDelayed : (Landroid/os/Message;J)Z
    //   793: pop
    //   794: iload_2
    //   795: ifle -> 860
    //   798: aload_0
    //   799: getfield A01 : LX/0F3;
    //   802: astore_1
    //   803: aload_1
    //   804: ifnull -> 860
    //   807: aload_1
    //   808: checkcast X/0F2
    //   811: astore #12
    //   813: aload #12
    //   815: monitorenter
    //   816: aload #12
    //   818: getfield A05 : [LX/0vl;
    //   821: astore_1
    //   822: aload #12
    //   824: getfield A06 : [LX/0vl;
    //   827: astore #13
    //   829: aload #12
    //   831: monitorexit
    //   832: aload_1
    //   833: arraylength
    //   834: istore #4
    //   836: iconst_0
    //   837: istore_3
    //   838: iconst_0
    //   839: istore_2
    //   840: goto -> 1015
    //   843: aload #13
    //   845: arraylength
    //   846: istore #4
    //   848: iload_3
    //   849: istore_2
    //   850: goto -> 1028
    //   853: astore_1
    //   854: aload #12
    //   856: monitorexit
    //   857: goto -> 869
    //   860: aload_0
    //   861: monitorexit
    //   862: return
    //   863: ldc 'Trace stopped but never started'
    //   865: invokestatic A0S : (Ljava/lang/String;)Ljava/lang/IllegalStateException;
    //   868: astore_1
    //   869: aload_1
    //   870: athrow
    //   871: astore_1
    //   872: aload_0
    //   873: monitorexit
    //   874: aload_1
    //   875: athrow
    //   876: ldc 'TraceControl not initialized'
    //   878: invokestatic A0S : (Ljava/lang/String;)Ljava/lang/IllegalStateException;
    //   881: athrow
    //   882: astore_1
    //   883: aload_0
    //   884: monitorexit
    //   885: aload_1
    //   886: athrow
    //   887: ldc 'Worker thread not initialized'
    //   889: invokestatic A0S : (Ljava/lang/String;)Ljava/lang/IllegalStateException;
    //   892: athrow
    //   893: aload_1
    //   894: getfield obj : Ljava/lang/Object;
    //   897: checkcast X/0vs
    //   900: astore_1
    //   901: aload_1
    //   902: getfield A00 : Lcom/facebook/profilo/ipc/TraceContext;
    //   905: astore #13
    //   907: aload_1
    //   908: getfield A01 : Ljava/lang/String;
    //   911: astore #12
    //   913: aload_0
    //   914: getfield A00 : LX/04c;
    //   917: astore_1
    //   918: aload #13
    //   920: getfield A06 : J
    //   923: lstore #8
    //   925: aload_1
    //   926: monitorenter
    //   927: aload_1
    //   928: getfield A00 : Landroid/util/LongSparseArray;
    //   931: lload #8
    //   933: invokevirtual get : (J)Ljava/lang/Object;
    //   936: checkcast X/04e
    //   939: astore #13
    //   941: aload #13
    //   943: ifnull -> 990
    //   946: aload #13
    //   948: getfield A00 : LX/0FV;
    //   951: astore #13
    //   953: aload #13
    //   955: ifnull -> 990
    //   958: aload #13
    //   960: getfield A02 : Ljava/util/HashSet;
    //   963: astore #13
    //   965: aload #13
    //   967: monitorenter
    //   968: aload #13
    //   970: aload #12
    //   972: invokevirtual add : (Ljava/lang/Object;)Z
    //   975: pop
    //   976: aload #13
    //   978: monitorexit
    //   979: goto -> 990
    //   982: astore #12
    //   984: aload #13
    //   986: monitorexit
    //   987: aload #12
    //   989: athrow
    //   990: aload_1
    //   991: monitorexit
    //   992: return
    //   993: astore #12
    //   995: aload_1
    //   996: monitorexit
    //   997: aload #12
    //   999: athrow
    //   1000: iload #4
    //   1002: iconst_1
    //   1003: iadd
    //   1004: istore #4
    //   1006: iload_3
    //   1007: istore_2
    //   1008: iload #6
    //   1010: istore #5
    //   1012: goto -> 430
    //   1015: iload_2
    //   1016: iload #4
    //   1018: if_icmpge -> 843
    //   1021: iload_2
    //   1022: iconst_1
    //   1023: iadd
    //   1024: istore_2
    //   1025: goto -> 1015
    //   1028: iload_2
    //   1029: iload #4
    //   1031: if_icmpge -> 860
    //   1034: iload_2
    //   1035: iconst_1
    //   1036: iadd
    //   1037: istore_2
    //   1038: goto -> 1028
    // Exception table:
    //   from	to	target	type
    //   115	124	882	finally
    //   241	255	293	finally
    //   260	267	293	finally
    //   272	290	293	finally
    //   314	332	620	finally
    //   337	344	620	finally
    //   349	359	620	finally
    //   359	382	402	finally
    //   385	388	402	finally
    //   388	394	620	finally
    //   404	407	402	finally
    //   407	410	620	finally
    //   410	417	620	finally
    //   430	437	620	finally
    //   439	454	620	finally
    //   489	498	620	finally
    //   607	617	620	finally
    //   659	768	871	finally
    //   768	794	871	finally
    //   798	803	871	finally
    //   807	816	871	finally
    //   816	832	853	finally
    //   832	836	871	finally
    //   843	848	871	finally
    //   854	857	853	finally
    //   863	869	871	finally
    //   869	871	871	finally
    //   883	885	882	finally
    //   927	941	993	finally
    //   946	953	993	finally
    //   958	968	993	finally
    //   968	979	982	finally
    //   984	987	982	finally
    //   987	990	993	finally
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\04b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */