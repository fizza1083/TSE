package X;

public abstract class 05q extends 04F {
  public long A00;
  
  public 0DS A01;
  
  public boolean A02;
  
  public final 04F A02(int paramInt) {
    05k.A00(paramInt);
    return this;
  }
  
  public abstract long A06();
  
  public abstract void A07();
  
  public final void A08(05z param05z) {
    0DS 0DS2 = this.A01;
    0DS 0DS1 = 0DS2;
    if (0DS2 == null) {
      0DS1 = new 0DS();
      this.A01 = 0DS1;
    } 
    0DS1.addLast(param05z);
  }
  
  public final void A09(boolean paramBoolean) {
    long l2 = this.A00;
    if (paramBoolean) {
      l1 = 4294967296L;
    } else {
      l1 = 1L;
    } 
    long l1 = l2 - l1;
    this.A00 = l1;
    if (l1 <= 0L && this.A02)
      A07(); 
  }
  
  public final boolean A0A() {
    0DS 0DS1 = this.A01;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (0DS1 != null) {
      if (0DS1.isEmpty()) {
        0DS1 = null;
      } else {
        object = 0DS1.removeFirst();
      } 
      Object object = object;
      bool1 = bool2;
      if (object != null) {
        object.run();
        bool1 = true;
      } 
    } 
    return bool1;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\05q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */