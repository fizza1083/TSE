package X;

import android.app.ActivityManager;
import android.content.Context;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.IOException;

public abstract class 088 {
  public static final FileFilter A00 = new 1C3(0);
  
  public static int A00() {
    Object object;
    int i = 0;
    byte b = -1;
    while (true) {
      try {
        int j;
        if (i < A01()) {
          File file = new File(0XK.A0k("/sys/devices/system/cpu/cpu", "/cpufreq/cpuinfo_max_freq", i));
          Object object1 = object;
          if (file.exists()) {
            object1 = object;
            if (file.canRead()) {
              byte[] arrayOfByte = new byte[128];
              null = new FileInputStream(file);
              FileInputStream fileInputStream = null;
              try {
                null.read(arrayOfByte);
                int k = 0;
                while (true) {
                  fileInputStream = null;
                  if (Character.isDigit(arrayOfByte[k]) && k < 128) {
                    k++;
                    continue;
                  } 
                  break;
                } 
                fileInputStream = null;
                j = Integer.parseInt(new String(arrayOfByte, 0, k));
                Object object2 = object;
                if (j > object)
                  int m = j; 
              } catch (NumberFormatException numberFormatException) {
                object1 = object;
              } finally {
                numberFormatException.close();
              } 
            } 
          } 
          continue;
        } 
        if (object == -1) {
          int k;
          FileInputStream fileInputStream2 = new FileInputStream("/proc/cpuinfo");
          FileInputStream fileInputStream1 = fileInputStream2;
          byte[] arrayOfByte = new byte[1024];
          fileInputStream1 = fileInputStream2;
          try {
            k = fileInputStream2.read(arrayOfByte);
            i = 0;
          } catch (IOException|NumberFormatException iOException) {
            Object object1 = object;
            fileInputStream2.close();
            return object1;
          } 
          while (true) {
            Object object1 = object;
            i = j + 1;
          } 
        } 
      } catch (IOException iOException) {
        return -1;
      } 
      return object;
      i++;
      object = SYNTHETIC_LOCAL_VARIABLE_1;
    } 
  }
  
  public static int A01() {
    int i;
    try {
      int j = A02("/sys/devices/system/cpu/possible");
      i = j;
      if (j == -1)
        i = A02("/sys/devices/system/cpu/present"); 
      if (i == -1)
        return (001.A0F("/sys/devices/system/cpu/").listFiles(A00)).length; 
    } catch (SecurityException|NullPointerException securityException) {
      return -1;
    } 
    return i;
  }
  
  public static int A02(String paramString) {
    BufferedReader bufferedReader = null;
    try {
      FileInputStream fileInputStream = new FileInputStream(paramString);
      try {
        byte b1;
        bufferedReader = 002.A0F(fileInputStream);
        String str = bufferedReader.readLine();
        bufferedReader.close();
        if (str != null && str.matches("0-[\\d]+$")) {
          b1 = Integer.valueOf(str.substring(2)).intValue() + 1;
        } else {
          b1 = -1;
        } 
      } catch (IOException iOException1) {
      
      } finally {
        BufferedReader bufferedReader1;
        bufferedReader = null;
        try {
          iOException.close();
          throw bufferedReader;
        } catch (IOException iOException1) {
          bufferedReader1 = bufferedReader;
        } 
      } 
    } catch (IOException iOException) {
      BufferedReader bufferedReader1 = bufferedReader;
    } finally {}
    byte b = -1;
    if (paramString != null)
      paramString.close(); 
    return -1;
  }
  
  public static long A03(Context paramContext) {
    ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
    ((ActivityManager)paramContext.getSystemService("activity")).getMemoryInfo(memoryInfo);
    return memoryInfo.totalMem;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\088.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */