package X;

import java.util.Iterator;

public abstract class 06k implements Iterator, 16M {
  public abstract int A00();
  
  public final void remove() {
    throw 002.A0b();
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\06k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */