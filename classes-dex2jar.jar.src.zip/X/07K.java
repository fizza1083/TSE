package X;

public interface 07K {
  Object BsP(Object paramObject, 02H param02H);
  
  void DxA(Object paramObject1, Object paramObject2, 02H param02H);
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07K.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */