package X;

import java.util.Map;
import java.util.Set;

public interface 07j {
  public static final Set A00 = new 0xi();
  
  void CEr(String paramString);
  
  void CEs(String paramString1, String paramString2);
  
  void CEv(String paramString, Map paramMap);
  
  void DwM(0FZ param0FZ);
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */