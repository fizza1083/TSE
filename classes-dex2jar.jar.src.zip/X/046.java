package X;

import java.util.Random;

public abstract class 046 {
  public static final Random A00 = new Random();
  
  public static final long A00(String paramString) {
    int j = paramString.length();
    long l = 0L;
    int i = 0;
    while (i < j) {
      int k = 0Xm.A03("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", paramString.charAt(i), 0);
      if (k >= 0) {
        l = (l << 6L) + k;
        i++;
        continue;
      } 
      throw 0XK.A04("Invalid encoded integer ", paramString);
    } 
    return l;
  }
  
  public static final String A01() {
    while (true) {
      long l = Math.abs(A00.nextLong());
      if (l > 0L)
        return A02(l); 
    } 
  }
  
  public static final String A02(long paramLong) {
    if (paramLong >= 0L) {
      if (paramLong <= (1L << Math.min(63, 66)) - 1L) {
        StringBuilder stringBuilder1 = 001.A0s();
        int i = 0;
        while (true) {
          stringBuilder1.append("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".charAt((int)(paramLong % 64L)));
          long l = paramLong >> 6L;
          int j = i + 1;
          i = j;
          paramLong = l;
          if (j >= 11) {
            if (l <= 0L) {
              stringBuilder1.reverse();
              return 16F.A04(stringBuilder1);
            } 
            throw 001.A0O("Number won't fit in string");
          } 
        } 
      } 
      StringBuilder stringBuilder = 001.A0s();
      stringBuilder.append("Cannot internalEncode integer ");
      stringBuilder.append(paramLong);
      stringBuilder.append(" in ");
      stringBuilder.append(11);
      throw 002.A0K(" chars", stringBuilder);
    } 
    throw 001.A0O(0XK.A0a("Cannot internalEncode negative integer ", paramLong));
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\046.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */