package X;

import android.view.View;

public final class 09B {
  public static final Integer A00(int paramInt) {
    if (paramInt != 0) {
      if (paramInt != 4) {
        if (paramInt == 8)
          return 0Xy.A0C; 
        throw 0XK.A03("Unknown visibility ", paramInt);
      } 
      return 0Xy.A0N;
    } 
    return 0Xy.A01;
  }
  
  public final Integer A01(View paramView) {
    return (paramView.getAlpha() == 0.0F && paramView.getVisibility() == 0) ? 0Xy.A0N : A00(paramView.getVisibility());
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\09B.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */