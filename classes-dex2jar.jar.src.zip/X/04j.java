package X;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

public class 04j extends 04k implements 04l {
  public final boolean A00;
  
  public 04j(04l param04l) {
    this._state$volatile = 04n.A00;
    A0K(param04l);
    AtomicReferenceFieldUpdater<04j, 04t> atomicReferenceFieldUpdater = 04k.A00;
    04t 04t = atomicReferenceFieldUpdater.get(this);
    if (04t instanceof 04u) {
      04w 04w = (04w)04t;
    } else {
      04t = null;
    } 
    boolean bool = false;
    while (true) {
      boolean bool1 = bool;
      if (04t != null) {
        04k 04k1 = 04t.A05();
        if (04k1.A0L()) {
          bool1 = true;
        } else {
          04t 04t1 = atomicReferenceFieldUpdater.get(04k1);
          bool1 = bool;
          if (04t1 instanceof 04u) {
            04w 04w = (04w)04t1;
            continue;
          } 
        } 
      } 
      this.A00 = bool1;
      return;
    } 
  }
  
  public final boolean A0L() {
    return this.A00;
  }
  
  public final boolean A0M() {
    return true;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\04j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */