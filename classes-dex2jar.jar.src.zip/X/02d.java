package X;

import android.content.Context;
import android.os.Handler;
import java.io.File;
import java.io.IOException;

public final class 02d {
  public 02a A00;
  
  public boolean A01;
  
  public final int A02;
  
  public final int A03;
  
  public final int A04;
  
  public final int A05;
  
  public final int A06;
  
  public final int A07;
  
  public final Context A08;
  
  public final Handler A09;
  
  public final 02W A0A;
  
  public final String A0B;
  
  public final String A0C;
  
  public final String A0D;
  
  public final String A0E;
  
  public final String A0F;
  
  public final boolean A0G;
  
  public final boolean A0H;
  
  public final boolean A0I;
  
  public final boolean A0J;
  
  public final boolean A0K;
  
  public final boolean A0L;
  
  public final boolean A0M;
  
  public final boolean A0N;
  
  public 02d(Context paramContext, Handler paramHandler, 02a param02a, 02W param02W, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5, boolean paramBoolean6, boolean paramBoolean7, boolean paramBoolean8, boolean paramBoolean9) {
    this.A08 = paramContext;
    this.A0D = paramString1;
    this.A0A = param02W;
    this.A00 = param02a;
    this.A09 = paramHandler;
    this.A03 = paramInt1;
    this.A0H = paramBoolean1;
    this.A0N = paramBoolean2;
    this.A0L = paramBoolean3;
    this.A0K = paramBoolean4;
    this.A07 = paramInt2;
    this.A0M = paramBoolean5;
    this.A0G = paramBoolean6;
    this.A0B = paramString2;
    this.A0C = paramString3;
    this.A0F = paramString4;
    this.A0E = paramString5;
    this.A04 = paramInt3;
    this.A0I = paramBoolean7;
    this.A0J = paramBoolean8;
    this.A05 = paramInt4;
    this.A02 = paramInt5;
    this.A06 = paramInt6;
    this.A01 = paramBoolean9;
  }
  
  public 02d(Context paramContext, String paramString, 02W param02W, 02a param02a, Handler paramHandler, int paramInt, boolean paramBoolean) {
    this(paramContext, paramHandler, param02a, param02W, paramString, "1", "1", ".", "anr", paramInt, -1, 0, 500, 0, 0, paramBoolean, false, false, false, false, false, false, false, false);
  }
  
  public final String A00() {
    File file = 13c.A00(this.A08, 194178138);
    String str = this.A0D.replace('.', '_').replace(':', '_');
    try {
      return 001.A0E(file, str).getCanonicalPath();
    } catch (IOException iOException) {
      0tB.A00().Ci5("SigquitTimeFilePath", iOException, null);
      return null;
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\02d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */