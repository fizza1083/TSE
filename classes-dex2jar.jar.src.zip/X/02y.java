package X;

import android.content.Context;

public final class 02y {
  public static 02y A01;
  
  public final 0pM A00;
  
  public 02y(Context paramContext) {
    this.A00 = (new 0pP(paramContext)).A00().A00("overtheair_prefs");
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\02y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */