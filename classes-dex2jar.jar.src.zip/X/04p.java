package X;

public final class 04p implements 04q {
  public final boolean A00;
  
  public 04p(boolean paramBoolean) {
    this.A00 = paramBoolean;
  }
  
  public final 0Io BM0() {
    return null;
  }
  
  public final boolean C2C() {
    return this.A00;
  }
  
  public final String toString() {
    if (this.A00) {
      String str1 = "Active";
      return 0XK.A0c("Empty{", str1, '}');
    } 
    String str = "New";
    return 0XK.A0c("Empty{", str, '}');
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\04p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */