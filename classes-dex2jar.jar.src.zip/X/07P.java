package X;

import android.view.WindowInsets;

public abstract class 07P extends 07Q {
  public 07U A00;
  
  public 07U A01;
  
  public final 07U A01() {
    07U 07U2 = this.A00;
    07U 07U1 = 07U2;
    if (07U2 == null) {
      07U1 = 07U.A01(this.A02.getMandatorySystemGestureInsets());
      this.A00 = 07U1;
    } 
    return 07U1;
  }
  
  public final 07U A03() {
    07U 07U2 = this.A01;
    07U 07U1 = 07U2;
    if (07U2 == null) {
      07U1 = 07U.A01(this.A02.getSystemGestureInsets());
      this.A01 = 07U1;
    } 
    return 07U1;
  }
  
  public final 07N A09(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    WindowInsets windowInsets = this.A02.inset(paramInt1, paramInt2, paramInt3, paramInt4);
    07N 07N = 07N.A01;
    windowInsets.getClass();
    return new 07N(windowInsets);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07P.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */