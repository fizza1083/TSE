package X;

import java.util.concurrent.RejectedExecutionException;

public final class 05n extends 05o implements Runnable {
  public static final 05n A00;
  
  public static final long A01;
  
  public static final String __redex_internal_original_name = "DefaultExecutor";
  
  public static volatile Thread _thread;
  
  public static volatile int debugStatus;
  
  static {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: \r\n\tat com.googlecode.dex2jar.ir.ts.NewTransformer.transform(NewTransformer.java:134)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:148)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  private final void A00() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: getstatic X/05n.debugStatus : I
    //   5: istore_1
    //   6: iload_1
    //   7: iconst_2
    //   8: if_icmpeq -> 16
    //   11: iload_1
    //   12: iconst_3
    //   13: if_icmpne -> 40
    //   16: iconst_3
    //   17: putstatic X/05n.debugStatus : I
    //   20: getstatic X/05o.A02 : Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;
    //   23: aload_0
    //   24: aconst_null
    //   25: invokevirtual set : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   28: getstatic X/05o.A01 : Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;
    //   31: aload_0
    //   32: aconst_null
    //   33: invokevirtual set : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   36: aload_0
    //   37: invokevirtual notifyAll : ()V
    //   40: aload_0
    //   41: monitorexit
    //   42: return
    //   43: astore_2
    //   44: aload_0
    //   45: monitorexit
    //   46: aload_2
    //   47: athrow
    // Exception table:
    //   from	to	target	type
    //   2	6	43	finally
    //   16	40	43	finally
  }
  
  public final void A07() {
    debugStatus = 4;
    super.A07();
  }
  
  public final Thread A0B() {
    // Byte code:
    //   0: getstatic X/05n._thread : Ljava/lang/Thread;
    //   3: astore_2
    //   4: aload_2
    //   5: astore_1
    //   6: aload_2
    //   7: ifnonnull -> 64
    //   10: aload_0
    //   11: monitorenter
    //   12: getstatic X/05n._thread : Ljava/lang/Thread;
    //   15: astore_2
    //   16: aload_2
    //   17: astore_1
    //   18: aload_2
    //   19: ifnonnull -> 62
    //   22: new java/lang/Thread
    //   25: dup
    //   26: aload_0
    //   27: ldc 'X.05n'
    //   29: invokespecial <init> : (Ljava/lang/Runnable;Ljava/lang/String;)V
    //   32: astore_1
    //   33: aload_1
    //   34: putstatic X/05n._thread : Ljava/lang/Thread;
    //   37: aload_1
    //   38: aload_0
    //   39: invokestatic A0M : (Ljava/lang/Object;)Ljava/lang/ClassLoader;
    //   42: invokevirtual setContextClassLoader : (Ljava/lang/ClassLoader;)V
    //   45: aload_1
    //   46: iconst_1
    //   47: invokevirtual setDaemon : (Z)V
    //   50: aload_1
    //   51: invokevirtual start : ()V
    //   54: goto -> 62
    //   57: astore_1
    //   58: aload_0
    //   59: monitorexit
    //   60: aload_1
    //   61: athrow
    //   62: aload_0
    //   63: monitorexit
    //   64: aload_1
    //   65: areturn
    // Exception table:
    //   from	to	target	type
    //   12	16	57	finally
    //   22	54	57	finally
  }
  
  public final void A0C(0Qc param0Qc, long paramLong) {
    throw new RejectedExecutionException("DefaultExecutor was shut down. This error indicates that Dispatchers.shutdown() was invoked prior to completion of exiting coroutines, leaving coroutines in incomplete state. Please refer to Dispatchers.shutdown documentation for more details");
  }
  
  public final void A0D(Runnable paramRunnable) {
    if (debugStatus == 4)
      throw new RejectedExecutionException("DefaultExecutor was shut down. This error indicates that Dispatchers.shutdown() was invoked prior to completion of exiting coroutines, leaving coroutines in incomplete state. Please refer to Dispatchers.shutdown documentation for more details"); 
    super.A0D(paramRunnable);
  }
  
  public final 04s C25(Runnable paramRunnable, 04I param04I, long paramLong) {
    long l = 0L;
    if (paramLong > 0L) {
      if (paramLong < 9223372036854L) {
        l = 1000000L * paramLong;
        if (l < 4611686018427387903L) {
          paramLong = System.nanoTime();
          paramRunnable = new 0QR(paramRunnable, l + paramLong);
          A0E((0Qc)paramRunnable, paramLong);
          return (04s)paramRunnable;
        } 
      } 
      return 04r.A00;
    } 
    paramLong = System.nanoTime();
    paramRunnable = new 0QR(paramRunnable, l + paramLong);
    A0E((0Qc)paramRunnable, paramLong);
    return (04s)paramRunnable;
  }
  
  public final void run() {
    // Byte code:
    //   0: getstatic X/0IP.A00 : Ljava/lang/ThreadLocal;
    //   3: aload_0
    //   4: invokevirtual set : (Ljava/lang/Object;)V
    //   7: aload_0
    //   8: monitorenter
    //   9: getstatic X/05n.debugStatus : I
    //   12: istore_1
    //   13: iload_1
    //   14: iconst_2
    //   15: if_icmpeq -> 36
    //   18: iload_1
    //   19: iconst_3
    //   20: if_icmpeq -> 36
    //   23: iconst_1
    //   24: istore_1
    //   25: iconst_1
    //   26: putstatic X/05n.debugStatus : I
    //   29: aload_0
    //   30: invokevirtual notifyAll : ()V
    //   33: goto -> 38
    //   36: iconst_0
    //   37: istore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: iload_1
    //   41: ifeq -> 133
    //   44: ldc2_w 9223372036854775807
    //   47: lstore #4
    //   49: invokestatic interrupted : ()Z
    //   52: pop
    //   53: aload_0
    //   54: invokevirtual A06 : ()J
    //   57: lstore #10
    //   59: lload #10
    //   61: ldc2_w 9223372036854775807
    //   64: lcmp
    //   65: ifne -> 186
    //   68: invokestatic nanoTime : ()J
    //   71: lstore #6
    //   73: lload #4
    //   75: lstore_2
    //   76: lload #4
    //   78: ldc2_w 9223372036854775807
    //   81: lcmp
    //   82: ifne -> 198
    //   85: getstatic X/05n.A01 : J
    //   88: lload #6
    //   90: ladd
    //   91: lstore_2
    //   92: goto -> 198
    //   95: lload #6
    //   97: lstore #4
    //   99: lload #8
    //   101: lconst_0
    //   102: lcmp
    //   103: ifle -> 49
    //   106: getstatic X/05n.debugStatus : I
    //   109: istore_1
    //   110: iload_1
    //   111: iconst_2
    //   112: if_icmpeq -> 133
    //   115: iload_1
    //   116: iconst_3
    //   117: if_icmpeq -> 133
    //   120: aload_0
    //   121: lload #8
    //   123: invokestatic parkNanos : (Ljava/lang/Object;J)V
    //   126: lload #6
    //   128: lstore #4
    //   130: goto -> 49
    //   133: aconst_null
    //   134: putstatic X/05n._thread : Ljava/lang/Thread;
    //   137: aload_0
    //   138: invokespecial A00 : ()V
    //   141: aload_0
    //   142: invokevirtual A0F : ()Z
    //   145: ifne -> 153
    //   148: aload_0
    //   149: invokevirtual A0B : ()Ljava/lang/Thread;
    //   152: pop
    //   153: return
    //   154: astore #12
    //   156: aload_0
    //   157: monitorexit
    //   158: aload #12
    //   160: athrow
    //   161: astore #12
    //   163: aconst_null
    //   164: putstatic X/05n._thread : Ljava/lang/Thread;
    //   167: aload_0
    //   168: invokespecial A00 : ()V
    //   171: aload_0
    //   172: invokevirtual A0F : ()Z
    //   175: ifne -> 183
    //   178: aload_0
    //   179: invokevirtual A0B : ()Ljava/lang/Thread;
    //   182: pop
    //   183: aload #12
    //   185: athrow
    //   186: ldc2_w 9223372036854775807
    //   189: lstore #6
    //   191: lload #10
    //   193: lstore #8
    //   195: goto -> 95
    //   198: lload_2
    //   199: lload #6
    //   201: lsub
    //   202: lstore #4
    //   204: lload #4
    //   206: lconst_0
    //   207: lcmp
    //   208: ifle -> 133
    //   211: lload #10
    //   213: lstore #8
    //   215: lload_2
    //   216: lstore #6
    //   218: lload #10
    //   220: lload #4
    //   222: lcmp
    //   223: ifle -> 95
    //   226: lload #4
    //   228: lstore #8
    //   230: lload_2
    //   231: lstore #6
    //   233: goto -> 95
    // Exception table:
    //   from	to	target	type
    //   7	9	161	finally
    //   9	13	154	finally
    //   25	33	154	finally
    //   38	40	161	finally
    //   49	59	161	finally
    //   68	73	161	finally
    //   85	92	161	finally
    //   106	110	161	finally
    //   120	126	161	finally
    //   156	161	161	finally
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\05n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */