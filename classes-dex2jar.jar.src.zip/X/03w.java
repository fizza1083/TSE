package X;

public interface 03w {
  07l ALJ(String paramString, int paramInt);
  
  07l ALK(Boolean paramBoolean, String paramString, int paramInt);
  
  void DfE(int paramInt, String paramString);
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\03w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */