package X;

public abstract class 07J implements 07K {
  public Object A00;
  
  public 07J(Object paramObject) {
    this.A00 = paramObject;
  }
  
  public boolean A01(Object paramObject1, Object paramObject2, 02H param02H) {
    return true;
  }
  
  public void A02(Object paramObject1, Object paramObject2, 02H param02H) {}
  
  public final Object BsP(Object paramObject, 02H param02H) {
    return this.A00;
  }
  
  public final void DxA(Object paramObject1, Object paramObject2, 02H param02H) {
    16F.A0E(param02H, 1);
    paramObject1 = this.A00;
    if (A01(paramObject1, paramObject2, param02H)) {
      this.A00 = paramObject2;
      A02(paramObject1, paramObject2, param02H);
    } 
  }
  
  public final String toString() {
    StringBuilder stringBuilder = 001.A0s();
    stringBuilder.append("ObservableProperty(value=");
    return 002.A0U(this.A00, stringBuilder);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07J.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */