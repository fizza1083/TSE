package X;

public final class 01y implements 0si {
  public final 0qi A00;
  
  public final 10G A01;
  
  public 01y(0qi param0qi, 10G param10G) {
    this.A00 = param0qi;
    this.A01 = param10G;
  }
  
  public final 0sj getName() {
    return 0sj.A0A;
  }
  
  public final void start() {
    10G 10G1 = this.A01;
    if (10G1 != null) {
      null = 10G1.A02;
      0qi 0qi1 = this.A00;
      0r7 0r7 = 0r7.A01;
      0qi1.A08(0jQ.A00(), 0r7, this);
      synchronized (null.A0B) {
        null.A07 = this;
        return;
      } 
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */