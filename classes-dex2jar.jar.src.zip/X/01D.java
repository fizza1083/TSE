package X;

import com.facebook.fury.context.ReqContext;
import java.util.Iterator;

public final class 01D implements ReqContext {
  public static final ReqContext A00;
  
  static {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: \r\n\tat com.googlecode.dex2jar.ir.ts.NewTransformer.transform(NewTransformer.java:134)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:148)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public final void close() {}
  
  public final boolean getBoolean(int paramInt1, boolean paramBoolean, int paramInt2) {
    return paramBoolean;
  }
  
  public final int getCurrentSeqId() {
    return -1;
  }
  
  public final long getCurrentTid() {
    return -1L;
  }
  
  public final int getInt(int paramInt1, int paramInt2, int paramInt3) {
    return paramInt2;
  }
  
  public final long getLong(int paramInt1, long paramLong, int paramInt2) {
    return paramLong;
  }
  
  public final Object getObject(int paramInt1, int paramInt2) {
    return null;
  }
  
  public final int getParentSeqId() {
    return -1;
  }
  
  public final long getParentTid() {
    return -1L;
  }
  
  public final String getString(int paramInt1, int paramInt2) {
    return null;
  }
  
  public final String getTag() {
    return "";
  }
  
  public final int getType() {
    return 0;
  }
  
  public final Iterator globalProps() {
    return 16j.A00.props();
  }
  
  public final boolean hasParent() {
    return false;
  }
  
  public final boolean hasSameProps(ReqContext paramReqContext) {
    return false;
  }
  
  public final boolean isFlagOn(int paramInt) {
    return false;
  }
  
  public final Iterator localProps() {
    return 16i.A00.props();
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */