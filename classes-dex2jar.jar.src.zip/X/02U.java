package X;

import android.app.Application;

public final class 02U {
  public static final Object A0E = 001.A0W();
  
  public final int A00;
  
  public final int A01;
  
  public final int A02;
  
  public final int A03;
  
  public final int A04;
  
  public final Application A05;
  
  public final 0qz A06;
  
  public final boolean A07;
  
  public final boolean A08;
  
  public final boolean A09;
  
  public final boolean A0A;
  
  public final boolean A0B;
  
  public final boolean A0C;
  
  public final boolean A0D;
  
  public 02U(Application paramApplication, 0qz param0qz, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5, boolean paramBoolean6, boolean paramBoolean7) {
    this.A05 = paramApplication;
    this.A0D = paramBoolean1;
    this.A0A = paramBoolean2;
    this.A08 = paramBoolean3;
    this.A07 = paramBoolean4;
    this.A09 = paramBoolean5;
    this.A06 = param0qz;
    this.A0C = paramBoolean6;
    this.A04 = paramInt1;
    this.A01 = paramInt2;
    this.A03 = paramInt3;
    this.A00 = paramInt4;
    this.A02 = paramInt5;
    this.A0B = paramBoolean7;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\02U.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */