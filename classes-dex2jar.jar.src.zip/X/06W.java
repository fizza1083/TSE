package X;

import java.util.ArrayList;

public final class 06W {
  public static 06W A03;
  
  public static final Object A04 = 001.A0W();
  
  public final ArrayList A00 = 001.A0y();
  
  public final ArrayList A01 = 001.A0y();
  
  public final ArrayList A02 = 001.A0y();
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\06W.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */