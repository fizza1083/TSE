package X;

import java.util.Set;

public interface 01t {
  01t AON();
  
  boolean APn(int paramInt);
  
  01t DXz(String paramString, boolean paramBoolean);
  
  01t DY3(String paramString, double paramDouble);
  
  01t DY9(String paramString, float paramFloat);
  
  01t DYB(String paramString, int paramInt);
  
  01t DYE(String paramString, long paramLong);
  
  01t DYI(String paramString1, String paramString2);
  
  01t DYM(String paramString, Set paramSet);
  
  01t Dce(String paramString);
  
  void apply();
  
  boolean commit();
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */