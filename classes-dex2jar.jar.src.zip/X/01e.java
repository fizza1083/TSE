package X;

import android.app.Application;
import android.content.Context;

public final class 01e implements 0qd {
  public final Application A00;
  
  public 01e(Application paramApplication) {
    this.A00 = paramApplication;
  }
  
  public final Integer BR8() {
    return 0Xy.A0q;
  }
  
  public final void DUA(0qe param0qe, 0r7 param0r7) {
    16F.A0E(param0qe, 0);
    synchronized (01f.A00((Context)this.A00)) {
      String str = null.A00;
      16F.A0A(str);
      param0qe.DXk(0qV.A8w, str);
      return;
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */