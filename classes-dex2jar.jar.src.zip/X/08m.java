package X;

import androidx.fragment.app.Fragment;

public final class 08m implements Runnable {
  public static final String __redex_internal_original_name = "Fragment$1";
  
  public 08m(Fragment paramFragment) {}
  
  public final void run() {
    this.A00.startPostponedEnterTransition();
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */