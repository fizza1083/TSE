package X;

public final class 057 implements 058 {
  public final 04I A00;
  
  public 057(04I param04I) {
    this.A00 = param04I;
  }
  
  public final 04I B32() {
    return this.A00;
  }
  
  public final String toString() {
    StringBuilder stringBuilder = 001.A0s();
    stringBuilder.append("CoroutineScope(coroutineContext=");
    return 002.A0U(this.A00, stringBuilder);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\057.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */