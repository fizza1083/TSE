package X;

import android.content.ContentProviderClient;
import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.PackageItemInfo;
import android.content.pm.ProviderInfo;
import android.net.Uri;
import android.os.Binder;
import android.os.Process;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class 02N {
  public final Map A00;
  
  public final Set A01;
  
  public 02N(Map paramMap) {
    HashSet<Object> hashSet = 001.A12();
    HashMap<?, ?> hashMap = 001.A11();
    Iterator<Map.Entry> iterator = 001.A16(paramMap);
    while (iterator.hasNext()) {
      Map.Entry entry = iterator.next();
      Object object = entry.getKey();
      Set set = (Set)entry.getValue();
      if (set != null && set.contains("*|all_packages|*")) {
        hashSet.add(object);
        continue;
      } 
      if (!hashMap.containsKey(object))
        hashMap.put(object, new HashSet()); 
      ((Set)hashMap.get(object)).addAll(set);
    } 
    this.A01 = Collections.unmodifiableSet(hashSet);
    this.A00 = Collections.unmodifiableMap(hashMap);
  }
  
  @Deprecated
  public static 0Hx A00(Context paramContext, int paramInt) {
    List<?> list = Collections.unmodifiableList(Arrays.asList((Object[])0Hv.A06(paramContext, paramInt)));
    return new 0Hx(null, null, list, Collections.singletonList(0Hv.A02(paramContext, (String)list.get(0))), paramInt);
  }
  
  public static String A01(Context paramContext, Uri paramUri, 02N param02N) {
    String str = paramUri.getAuthority();
    if (str == null)
      return null; 
    try {
      ProviderInfo providerInfo = 11Q.A01(paramContext, str, 0);
      if (providerInfo != null) {
        0Hx 0Hx = 0Hx.fromPackageName(paramContext, ((PackageItemInfo)providerInfo).packageName, true);
        if (param02N.isAppIdentityTrusted(0Hx, 0Hv.A03(paramContext)))
          return str; 
        StringBuilder stringBuilder = 001.A0s();
        stringBuilder.append("The provider for uri '");
        stringBuilder.append(str);
        throw 001.A0c(002.A0T(0Hx, "' is not trusted: ", stringBuilder));
      } 
      throw 001.A0c(0XK.A0b("Unable to get providerInfo for authority ", str));
    } catch (SecurityException securityException) {
      return null;
    } 
  }
  
  public static boolean A02(Context paramContext) {
    02B 02B = 0Hv.A02(paramContext, paramContext.getPackageName());
    if (!0OT.A0d.contains(02B)) {
      boolean bool1 = 0OT.A0k.contains(02B);
      boolean bool = false;
      return bool1 ? true : bool;
    } 
    return true;
  }
  
  public static boolean appIdentitySignatureMatch(02B param02B1, 02B param02B2, boolean paramBoolean) {
    if (!param02B1.equals(param02B2)) {
      if (paramBoolean) {
        Set set2 = 0OT.A0d;
        16F.A0E(param02B2, 0);
        set2 = (Set)0OT.A0c.get(param02B2);
        Set set1 = set2;
        if (set2 == null)
          set1 = 16F.A06(0OT.A00); 
        if (set1.contains(param02B1))
          return true; 
      } 
    } else {
      return true;
    } 
    return false;
  }
  
  public final ContentProviderClient A03(Context paramContext, Uri paramUri) {
    String str = A01(paramContext, paramUri, this);
    if (str == null)
      return null; 
    ContentResolver contentResolver = paramContext.getContentResolver();
    0RQ.A00(str, -635758405, 0Xy.A00);
    return contentResolver.acquireUnstableContentProviderClient(str);
  }
  
  @Deprecated
  public final boolean A04(Context paramContext) {
    if (paramContext == null)
      return false; 
    if (Binder.getCallingPid() != Process.myPid()) {
      int i = Binder.getCallingUidOrThrow();
      Binder.getCallingPid();
      return isAppIdentityTrusted(A00(paramContext, i), 0Hv.A03(paramContext));
    } 
    throw 001.A0c("This method must be called on behalf of an IPC transaction from binder thread.");
  }
  
  public final boolean equals(Object paramObject) {
    boolean bool = true;
    if (paramObject != this) {
      boolean bool1;
      if (!(paramObject instanceof 02N))
        return false; 
      paramObject = paramObject;
      Set set1 = ((02N)paramObject).A01;
      Set set2 = this.A01;
      if (set1 != null) {
        bool = set1.equals(set2);
      } else {
        bool = 002.A19(set2);
      } 
      paramObject = ((02N)paramObject).A00;
      Map map = this.A00;
      if (paramObject != null) {
        bool1 = paramObject.equals(map);
      } else {
        bool1 = 002.A19(map);
      } 
      if (bool && bool1)
        return true; 
      bool = false;
    } 
    return bool;
  }
  
  public final int hashCode() {
    return Arrays.hashCode(new Object[] { this.A01, this.A00 });
  }
  
  public boolean isAppIdentityTrusted(0Hx param0Hx, boolean paramBoolean) {
    if (param0Hx != null && param0Hx.A02() != null) {
      02B 02B = param0Hx.A02();
      if (02B != null) {
        Iterator<02B> iterator = this.A01.iterator();
        while (iterator.hasNext()) {
          if (appIdentitySignatureMatch(02B, iterator.next(), paramBoolean))
            return true; 
        } 
        Map map = this.A00;
        for (02B 02B1 : map.keySet()) {
          if (appIdentitySignatureMatch(02B, 02B1, paramBoolean))
            for (Object object : param0Hx.A03) {
              if (((Set)map.get(02B1)).contains(object))
                return true; 
            }  
        } 
      } 
    } 
    return false;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\02N.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */