package X;

public abstract class 05u {
  public abstract Object A00(Object paramObject);
  
  public final String toString() {
    return 0XK.A0d(001.A0g(this), Integer.toHexString(System.identityHashCode(this)), '@');
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\05u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */