package X;

import java.util.Arrays;

public final class 02g {
  public static final 02g A02 = new 02g(new int[] { -1 });
  
  public static final 02g A03 = new 02g(new int[] { -2 });
  
  public static final 02g A04 = new 02g(new int[0]);
  
  public final int[] A00;
  
  public final int[] A01;
  
  public 02g(int... paramVarArgs) {
    this.A01 = paramVarArgs;
    this.A00 = null;
  }
  
  public 02g(int[] paramArrayOfint1, int[] paramArrayOfint2) {
    this.A01 = paramArrayOfint1;
    this.A00 = paramArrayOfint2;
  }
  
  public final boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject != null && getClass() == paramObject.getClass()) {
        paramObject = paramObject;
        return !(!Arrays.equals(this.A01, ((02g)paramObject).A01) || !Arrays.equals(this.A00, ((02g)paramObject).A00));
      } 
    } else {
      return true;
    } 
    return false;
  }
  
  public final int hashCode() {
    return Arrays.hashCode(this.A01) * 31 + Arrays.hashCode(this.A00);
  }
  
  public final String toString() {
    return 0XK.A16("{normalMarkers: ", Arrays.toString(this.A01), ", metadataMarkers: ", Arrays.toString(this.A00), "}");
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\02g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */