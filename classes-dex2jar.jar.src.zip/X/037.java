package X;

public abstract class 037 {
  public static final long A00;
  
  public static final long A01 = A00(2147483647, 3, 1);
  
  static {
    A00 = A00(1, 7, 1);
  }
  
  public static long A00(int paramInt1, int paramInt2, int paramInt3) {
    long l = paramInt1;
    return paramInt2 << 48L | l & 0xFFFFFFFFL | paramInt3 << 32L;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\037.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */