package X;

import com.facebook.profilo.core.TriggerRegistry;
import com.facebook.profilo.ipc.TraceContext;
import com.facebook.quicklog.QuickPerformanceLogger;
import java.io.File;
import java.util.Iterator;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

public final class 05t extends 0FF {
  public final QuickPerformanceLogger A00;
  
  public 05t(QuickPerformanceLogger paramQuickPerformanceLogger) {
    this.A00 = paramQuickPerformanceLogger;
  }
  
  public static void A00(TraceContext paramTraceContext, TreeMap<String, String> paramTreeMap) {
    int i = paramTraceContext.A01;
    Iterator iterator = TriggerRegistry.A00.A03(i).iterator();
    while (iterator.hasNext())
      paramTreeMap.put("controller", iterator.next()); 
    i = paramTraceContext.A01;
    if (i == 16N.A01 || i == 0vd.A00 || i == 16Q.A01)
      paramTreeMap.put("markerid", Long.toString(paramTraceContext.A05 & 0xFFFFFFFFL)); 
    0Ex 0Ex = paramTraceContext.A07;
    if (0Ex != null)
      paramTreeMap.put("config_id", Long.toString(0Ex.getID())); 
  }
  
  private final void A01(File paramFile, int paramInt, short paramShort) {
    // Byte code:
    //   0: new java/util/TreeMap
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #4
    //   9: aload_1
    //   10: invokevirtual getName : ()Ljava/lang/String;
    //   13: astore #5
    //   15: aload #4
    //   17: ldc 'filename'
    //   19: aload #5
    //   21: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   24: pop
    //   25: iload_2
    //   26: iconst_1
    //   27: if_icmpeq -> 129
    //   30: iload_2
    //   31: iconst_2
    //   32: if_icmpeq -> 123
    //   35: iload_2
    //   36: iconst_3
    //   37: if_icmpeq -> 117
    //   40: iload_2
    //   41: iconst_5
    //   42: if_icmpne -> 57
    //   45: ldc 'request_failed_with_exception'
    //   47: astore_1
    //   48: aload #4
    //   50: ldc 'reason'
    //   52: aload_1
    //   53: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   56: pop
    //   57: aload #4
    //   59: ldc 'trace_id'
    //   61: aload #5
    //   63: bipush #45
    //   65: invokevirtual lastIndexOf : (I)I
    //   68: aload #5
    //   70: invokestatic A0e : (ILjava/lang/String;)Ljava/lang/String;
    //   73: ldc '(\.zip)?\.log'
    //   75: ldc ''
    //   77: invokevirtual replaceFirst : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   80: ldc '_p_'
    //   82: ldc '+'
    //   84: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   87: ldc '_s_'
    //   89: ldc '/'
    //   91: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   94: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   97: pop
    //   98: aload_0
    //   99: getfield A00 : Lcom/facebook/quicklog/QuickPerformanceLogger;
    //   102: ldc 8126469
    //   104: iload_3
    //   105: lconst_0
    //   106: getstatic java/util/concurrent/TimeUnit.MILLISECONDS : Ljava/util/concurrent/TimeUnit;
    //   109: aload #4
    //   111: invokeinterface markerGenerateWithAnnotations : (ISJLjava/util/concurrent/TimeUnit;Ljava/util/Map;)V
    //   116: return
    //   117: ldc 'no_bytes_remaining'
    //   119: astore_1
    //   120: goto -> 48
    //   123: ldc 'no_connection'
    //   125: astore_1
    //   126: goto -> 48
    //   129: ldc 'request_failed'
    //   131: astore_1
    //   132: goto -> 48
  }
  
  public final void CZx() {
    this.A00.updateListenerMarkers();
  }
  
  public final void DLF(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = paramInt1;
    while (true) {
      paramInt1 = paramInt2;
      if (i > 0) {
        this.A00.markerGenerate(8126471, (short)3, 0L, TimeUnit.MILLISECONDS);
        i--;
        continue;
      } 
      break;
    } 
    while (true) {
      paramInt2 = paramInt3;
      if (paramInt1 > 0) {
        this.A00.markerGenerate(8126472, (short)2, 0L, TimeUnit.MILLISECONDS);
        paramInt1--;
        continue;
      } 
      break;
    } 
    while (true) {
      paramInt1 = paramInt4;
      if (paramInt2 > 0) {
        this.A00.markerGenerate(8126473, (short)2, 0L, TimeUnit.MILLISECONDS);
        paramInt2--;
        continue;
      } 
      break;
    } 
    while (paramInt1 > 0) {
      this.A00.markerGenerate(8126474, (short)2, 0L, TimeUnit.MILLISECONDS);
      paramInt1--;
    } 
  }
  
  public final void DLG(TraceContext paramTraceContext) {
    TreeMap<Object, Object> treeMap = new TreeMap<Object, Object>();
    treeMap.put("trace_id", 046.A02(paramTraceContext.A06));
    this.A00.markerGenerateWithAnnotations(8126465, (short)2, 0L, TimeUnit.MILLISECONDS, treeMap);
  }
  
  public final void DO5(File paramFile, int paramInt) {
    A01(paramFile, paramInt, (short)3);
  }
  
  public final void DOB(File paramFile) {
    A01(paramFile, 0, (short)2);
  }
  
  public final void onTraceAbort(TraceContext paramTraceContext) {
    char c;
    if (paramTraceContext.A01 == 16Q.A01)
      super.onTraceStart(paramTraceContext); 
    TreeMap<Object, Object> treeMap = new TreeMap<Object, Object>();
    A00(paramTraceContext, treeMap);
    int i = paramTraceContext.A00;
    int j = i & Integer.MAX_VALUE;
    if ((i & Integer.MIN_VALUE) == Integer.MIN_VALUE) {
      treeMap.put("abort_reason", 0vp.A00(j));
      c = 'ǽ';
    } else {
      switch (j) {
        case 2:
          return;
        default:
          c = '\002';
          treeMap.put("trace_id", paramTraceContext.A0D);
          this.A00.markerGenerateWithAnnotations(8126466, c, 0L, TimeUnit.MILLISECONDS, treeMap);
        case 6:
          c = 'ˏ';
          treeMap.put("trace_id", paramTraceContext.A0D);
          this.A00.markerGenerateWithAnnotations(8126466, c, 0L, TimeUnit.MILLISECONDS, treeMap);
        case 5:
          c = 'o';
          treeMap.put("trace_id", paramTraceContext.A0D);
          this.A00.markerGenerateWithAnnotations(8126466, c, 0L, TimeUnit.MILLISECONDS, treeMap);
        case 4:
          c = 'q';
          treeMap.put("trace_id", paramTraceContext.A0D);
          this.A00.markerGenerateWithAnnotations(8126466, c, 0L, TimeUnit.MILLISECONDS, treeMap);
        case 3:
          c = 'p';
          treeMap.put("trace_id", paramTraceContext.A0D);
          this.A00.markerGenerateWithAnnotations(8126466, c, 0L, TimeUnit.MILLISECONDS, treeMap);
        case 1:
          break;
      } 
      c = '3';
    } 
    treeMap.put("trace_id", paramTraceContext.A0D);
    this.A00.markerGenerateWithAnnotations(8126466, c, 0L, TimeUnit.MILLISECONDS, treeMap);
  }
  
  public final void onTraceStart(TraceContext paramTraceContext) {
    TreeMap<Object, Object> treeMap = new TreeMap<Object, Object>();
    A00(paramTraceContext, treeMap);
    treeMap.put("trace_id", paramTraceContext.A0D);
    QuickPerformanceLogger quickPerformanceLogger = this.A00;
    int j = paramTraceContext.A03;
    int i = 8126523;
    if ((j & 0x2) == 0)
      i = 8126512; 
    quickPerformanceLogger.markerGenerateWithAnnotations(i, (short)2, 0L, TimeUnit.MILLISECONDS, treeMap);
  }
  
  public final void onTraceStop(TraceContext paramTraceContext) {
    if (paramTraceContext.A01 == 16Q.A01)
      super.onTraceStart(paramTraceContext); 
    TreeMap<Object, Object> treeMap = new TreeMap<Object, Object>();
    A00(paramTraceContext, treeMap);
    treeMap.put("trace_id", paramTraceContext.A0D);
    this.A00.markerGenerateWithAnnotations(8126516, (short)2, 0L, TimeUnit.MILLISECONDS, treeMap);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\05t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */