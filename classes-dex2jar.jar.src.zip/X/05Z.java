package X;

import android.content.Context;

public abstract class 05Z {
  public static void A00(Context paramContext, String paramString, boolean paramBoolean) {
    // Byte code:
    //   0: ldc X/05a
    //   2: monitorenter
    //   3: getstatic X/05a.A00 : LX/05a;
    //   6: ifnonnull -> 132
    //   9: iload_2
    //   10: ifeq -> 16
    //   13: goto -> 28
    //   16: new X/0bm
    //   19: dup
    //   20: aload_1
    //   21: invokespecial <init> : (Ljava/lang/String;)V
    //   24: astore_3
    //   25: goto -> 36
    //   28: new X/05b
    //   31: dup
    //   32: invokespecial <init> : ()V
    //   35: astore_3
    //   36: aload_3
    //   37: putstatic X/05a.A00 : LX/05a;
    //   40: ldc X/05a
    //   42: monitorexit
    //   43: aload_3
    //   44: invokevirtual A00 : ()LX/05j;
    //   47: astore #5
    //   49: aload #5
    //   51: aload_0
    //   52: new android/content/IntentFilter
    //   55: dup
    //   56: aload #5
    //   58: invokevirtual A02 : ()Ljava/lang/String;
    //   61: invokespecial <init> : (Ljava/lang/String;)V
    //   64: invokestatic A01 : (Landroid/content/BroadcastReceiver;Landroid/content/Context;Landroid/content/IntentFilter;)V
    //   67: aload #5
    //   69: invokevirtual A01 : ()Ljava/lang/String;
    //   72: invokestatic A09 : (Ljava/lang/String;)Landroid/content/Intent;
    //   75: astore #4
    //   77: aload #4
    //   79: ldc 'pid'
    //   81: invokestatic myPid : ()I
    //   84: invokevirtual putExtra : (Ljava/lang/String;I)Landroid/content/Intent;
    //   87: pop
    //   88: aload #5
    //   90: invokevirtual A00 : ()Lcom/facebook/profilo/multiprocess/ProfiloIPCParcelable;
    //   93: astore #5
    //   95: aload #5
    //   97: ifnull -> 110
    //   100: aload #4
    //   102: ldc 'parcel'
    //   104: aload #5
    //   106: invokevirtual putExtra : (Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;
    //   109: pop
    //   110: aload_0
    //   111: aload #4
    //   113: aload_1
    //   114: invokevirtual sendBroadcast : (Landroid/content/Intent;Ljava/lang/String;)V
    //   117: invokestatic A00 : ()LX/0F2;
    //   120: getfield A07 : LX/0F6;
    //   123: getfield A00 : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   126: aload_3
    //   127: invokevirtual add : (Ljava/lang/Object;)Z
    //   130: pop
    //   131: return
    //   132: ldc 'MultiProcessTraceManager already initialized'
    //   134: invokestatic A0S : (Ljava/lang/String;)Ljava/lang/IllegalStateException;
    //   137: athrow
    //   138: astore_0
    //   139: ldc X/05a
    //   141: monitorexit
    //   142: aload_0
    //   143: athrow
    // Exception table:
    //   from	to	target	type
    //   3	9	138	finally
    //   16	25	138	finally
    //   28	36	138	finally
    //   36	43	138	finally
    //   132	138	138	finally
    //   139	142	138	finally
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\05Z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */