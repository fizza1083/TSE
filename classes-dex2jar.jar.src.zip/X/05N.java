package X;

import java.util.concurrent.TimeUnit;

public abstract class 05N {
  public static 05Q A00;
  
  public static final int A01;
  
  public static final int A02;
  
  public static final long A03;
  
  public static final long A04;
  
  public static final String A05;
  
  public static final 05R A06;
  
  public static final 05R A07;
  
  static {
    String str = "DefaultDispatcher";
    try {
      String str1 = System.getProperty("kotlinx.coroutines.scheduler.default.name");
      if (str1 != null)
        str = str1; 
    } catch (SecurityException securityException) {}
    A05 = str;
    A04 = 05O.A00(100000L, "kotlinx.coroutines.scheduler.resolution.ns", Long.MAX_VALUE);
    int j = 05P.A00;
    int i = j;
    if (j < 2)
      i = 2; 
    A01 = (int)05O.A00(i, "kotlinx.coroutines.scheduler.core.pool.size", 2147483647L);
    A02 = (int)05O.A00(2097150L, "kotlinx.coroutines.scheduler.max.pool.size", 2097150L);
    A03 = TimeUnit.SECONDS.toNanos(05O.A00(60L, "kotlinx.coroutines.scheduler.keep.alive.sec", Long.MAX_VALUE));
    A00 = 05Q.A00;
    A07 = new 05R(0);
    A06 = new 05R(1);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\05N.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */