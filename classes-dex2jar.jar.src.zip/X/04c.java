package X;

import android.util.LongSparseArray;

public final class 04c {
  public LongSparseArray A00 = new LongSparseArray();
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\04c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */