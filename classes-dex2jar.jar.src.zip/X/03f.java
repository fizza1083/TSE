package X;

import android.content.Context;
import java.lang.reflect.Field;
import java.util.Map;

public final class 03f {
  public static 03f A02;
  
  public static 013 A03;
  
  public final Context A00;
  
  public final Map A01 = 001.A11();
  
  public 03f(Context paramContext) {
    this.A00 = paramContext.getApplicationContext();
  }
  
  public final Object A00(Object paramObject, String paramString) {
    Class<?> clazz = paramObject.getClass();
    Map<Class<?>, 0O0> map = this.A01;
    0O0 0O02 = (0O0)map.get(clazz);
    0O0 0O01 = 0O02;
    if (0O02 == null) {
      0O01 = new 0O0(this.A00, clazz);
      map.put(clazz, 0O01);
    } 
    Field field = (Field)0O01.A00.get(paramString);
    if (field != null)
      try {
        return field.get(paramObject);
      } finally {
        paramObject = null;
      }  
    return null;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\03f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */