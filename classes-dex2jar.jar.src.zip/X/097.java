package X;

import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

public abstract class 097 {
  public boolean A00;
  
  public boolean A01;
  
  public final ViewGroup A02;
  
  public final List A03;
  
  public final List A04;
  
  public 097(ViewGroup paramViewGroup) {
    this.A02 = paramViewGroup;
    this.A03 = 001.A0y();
    this.A04 = 001.A0y();
  }
  
  public static final 097 A00(ViewGroup paramViewGroup, 0Cy param0Cy) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: \r\n\tat com.googlecode.dex2jar.ir.ts.NewTransformer.transform(NewTransformer.java:134)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:148)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  private final void A01() {
    for (099 099 : this.A03) {
      if (099.A01 == 0Xy.A01)
        099.A03(09B.A00(099.A07.requireView().getVisibility()), 0Xy.A00); 
    } 
  }
  
  public static final void A02(View paramView, 098 param098, Map<String, View> paramMap) {
    String str = paramView.getTransitionName();
    if (str != null)
      paramMap.put(str, paramView); 
    if (paramView instanceof ViewGroup) {
      ViewGroup viewGroup = (ViewGroup)paramView;
      int j = viewGroup.getChildCount();
      for (int i = 0; i < j; i++) {
        View view = viewGroup.getChildAt(i);
        if (view.getVisibility() == 0)
          A02(view, param098, paramMap); 
      } 
    } 
  }
  
  public static final void A03(08v param08v, 097 param097, Integer paramInteger1, Integer paramInteger2) {
    // Byte code:
    //   0: aload_1
    //   1: getfield A03 : Ljava/util/List;
    //   4: astore #6
    //   6: aload #6
    //   8: monitorenter
    //   9: aload_0
    //   10: getfield A02 : Landroidx/fragment/app/Fragment;
    //   13: astore #7
    //   15: aload #6
    //   17: invokeinterface iterator : ()Ljava/util/Iterator;
    //   22: astore #5
    //   24: aload #5
    //   26: invokeinterface hasNext : ()Z
    //   31: ifeq -> 245
    //   34: aload #5
    //   36: invokeinterface next : ()Ljava/lang/Object;
    //   41: astore #4
    //   43: aload #4
    //   45: checkcast X/099
    //   48: astore #8
    //   50: aload #8
    //   52: getfield A07 : Landroidx/fragment/app/Fragment;
    //   55: aload #7
    //   57: invokestatic A0S : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   60: ifeq -> 24
    //   63: aload #8
    //   65: getfield A03 : Z
    //   68: ifne -> 24
    //   71: aload #4
    //   73: checkcast X/099
    //   76: astore #5
    //   78: goto -> 81
    //   81: aload #5
    //   83: astore #4
    //   85: aload #5
    //   87: ifnonnull -> 228
    //   90: aload #7
    //   92: getfield mTransitioning : Z
    //   95: ifeq -> 166
    //   98: aload_1
    //   99: getfield A04 : Ljava/util/List;
    //   102: invokeinterface iterator : ()Ljava/util/Iterator;
    //   107: astore #5
    //   109: aload #5
    //   111: invokeinterface hasNext : ()Z
    //   116: ifeq -> 251
    //   119: aload #5
    //   121: invokeinterface next : ()Ljava/lang/Object;
    //   126: astore #4
    //   128: aload #4
    //   130: checkcast X/099
    //   133: astore #8
    //   135: aload #8
    //   137: getfield A07 : Landroidx/fragment/app/Fragment;
    //   140: aload #7
    //   142: invokestatic A0S : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   145: ifeq -> 109
    //   148: aload #8
    //   150: getfield A03 : Z
    //   153: ifne -> 109
    //   156: aload #4
    //   158: checkcast X/099
    //   161: astore #4
    //   163: goto -> 257
    //   166: new X/099
    //   169: dup
    //   170: aload_0
    //   171: aload_2
    //   172: aload_3
    //   173: invokespecial <init> : (LX/08v;Ljava/lang/Integer;Ljava/lang/Integer;)V
    //   176: astore_0
    //   177: aload #6
    //   179: aload_0
    //   180: invokeinterface add : (Ljava/lang/Object;)Z
    //   185: pop
    //   186: new X/09C
    //   189: dup
    //   190: aload_0
    //   191: aload_1
    //   192: invokespecial <init> : (LX/099;LX/097;)V
    //   195: astore_2
    //   196: aload_0
    //   197: getfield A0A : Ljava/util/List;
    //   200: astore_3
    //   201: aload_3
    //   202: aload_2
    //   203: invokeinterface add : (Ljava/lang/Object;)Z
    //   208: pop
    //   209: aload_3
    //   210: new X/09D
    //   213: dup
    //   214: aload_0
    //   215: aload_1
    //   216: invokespecial <init> : (LX/099;LX/097;)V
    //   219: invokeinterface add : (Ljava/lang/Object;)Z
    //   224: pop
    //   225: goto -> 235
    //   228: aload #4
    //   230: aload_2
    //   231: aload_3
    //   232: invokevirtual A03 : (Ljava/lang/Integer;Ljava/lang/Integer;)V
    //   235: aload #6
    //   237: monitorexit
    //   238: return
    //   239: astore_0
    //   240: aload #6
    //   242: monitorexit
    //   243: aload_0
    //   244: athrow
    //   245: aconst_null
    //   246: astore #4
    //   248: goto -> 71
    //   251: aconst_null
    //   252: astore #4
    //   254: goto -> 156
    //   257: aload #4
    //   259: ifnull -> 166
    //   262: goto -> 228
    // Exception table:
    //   from	to	target	type
    //   9	24	239	finally
    //   24	71	239	finally
    //   71	78	239	finally
    //   90	109	239	finally
    //   109	156	239	finally
    //   156	163	239	finally
    //   166	225	239	finally
    //   228	235	239	finally
  }
  
  public static final void A04(097 param097, List<099> paramList) {
    16F.A0E(paramList, 0);
    ArrayList arrayList = 001.A0y();
    Iterator iterator = paramList.iterator();
    while (iterator.hasNext())
      0YE.A0x(((099)iterator.next()).A0B, arrayList); 
    List<0X9> list1 = 0Xa.A0V(0Xa.A0e(arrayList));
    int j = list1.size();
    boolean bool = false;
    int i;
    for (i = 0; i < j; i++)
      ((0X9)list1.get(i)).A05(param097.A02); 
    j = paramList.size();
    for (i = 0; i < j; i++)
      param097.A09(paramList.get(i)); 
    List<099> list = 0Xa.A0V(paramList);
    j = list.size();
    for (i = bool; i < j; i++) {
      099 099 = list.get(i);
      if (099.A0B.isEmpty())
        099.A00(); 
    } 
  }
  
  public static final void A05(097 param097, List<099> paramList) {
    int j = paramList.size();
    boolean bool = false;
    int i;
    for (i = 0; i < j; i++) {
      099 099 = paramList.get(i);
      if (!099.A06) {
        View view;
        08v 08v;
        099.A06 = true;
        Integer integer = 099.A01;
        if (integer == 0Xy.A01) {
          08v = 099.A08;
          Fragment fragment = 08v.A02;
          View view1 = fragment.mView.findFocus();
          if (view1 != null)
            fragment.setFocusedView(view1); 
          view = 099.A07.requireView();
          if (view.getParent() == null) {
            08v.A02();
            view.setAlpha(0.0F);
          } 
          if (view.getAlpha() == 0.0F && view.getVisibility() == 0)
            view.setVisibility(4); 
          view.setAlpha(fragment.getPostOnViewCreatedAlpha());
        } else if (08v == 0Xy.A0C) {
          view = ((099)view).A08.A02.requireView();
          if (0Cy.A0H(2))
            view.findFocus(); 
          view.clearFocus();
        } 
      } 
    } 
    ArrayList arrayList = new ArrayList();
    Iterator<099> iterator = paramList.iterator();
    while (iterator.hasNext())
      0YE.A0x(((099)iterator.next()).A0B, arrayList); 
    List<0X9> list = 0Xa.A0V(0Xa.A0e(arrayList));
    j = list.size();
    for (i = bool; i < j; i++) {
      0X9 0X9 = list.get(i);
      ViewGroup viewGroup = param097.A02;
      if (!0X9.A01)
        0X9.A03(viewGroup); 
      0X9.A01 = true;
    } 
  }
  
  public final void A06() {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: \r\n\tat com.googlecode.dex2jar.ir.ts.NewTransformer.transform(NewTransformer.java:134)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:148)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public final void A07() {
    null = this.A02;
    null.isAttachedToWindow();
    synchronized (this.A03) {
      A01();
      A05(this, null);
      List<?> list = this.A04;
      16F.A0E(list, 0);
      Iterator<?> iterator = (new ArrayList(list)).iterator();
      while (iterator.hasNext())
        ((099)iterator.next()).A01(null); 
      iterator = (new ArrayList(null)).iterator();
      while (iterator.hasNext())
        ((099)iterator.next()).A01(null); 
      return;
    } 
  }
  
  public final void A08() {
    synchronized (this.A03) {
      boolean bool;
      A01();
      ListIterator<Object> listIterator = null.listIterator(null.size());
      while (true) {
        boolean bool1 = listIterator.hasPrevious();
        bool = false;
        099 = null;
        if (bool1) {
          099 = (099)listIterator.previous();
          099 0991 = 099;
          09B 09B = 09E.A00;
          View view = 0991.A07.mView;
          16F.A09(view);
          Integer integer2 = 09B.A01(view);
          Integer integer1 = 0991.A00;
          Integer integer3 = 0Xy.A01;
          if (integer1 == integer3 && integer2 != integer3)
            break; 
          continue;
        } 
        break;
      } 
      099 099 = 099;
      if (099 != null)
        bool = 099.A07.isPostponed(); 
      this.A00 = bool;
      return;
    } 
  }
  
  public final void A09(099 param099) {
    16F.A0E(param099, 0);
    if (param099.A02) {
      Integer integer = param099.A00;
      09E.A00(param099.A07.requireView(), this.A02, integer);
      param099.A02 = false;
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\097.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */