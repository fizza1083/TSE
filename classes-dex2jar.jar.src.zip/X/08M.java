package X;

import android.view.animation.Interpolator;

public abstract class 08M implements Interpolator {
  public final float A00;
  
  public final float[] A01;
  
  public 08M(float[] paramArrayOffloat) {
    this.A01 = paramArrayOffloat;
    this.A00 = 1.0F / 200.0F;
  }
  
  public final float getInterpolation(float paramFloat) {
    float f = 1.0F;
    if (paramFloat < 1.0F) {
      f = 0.0F;
      if (paramFloat > 0.0F) {
        float[] arrayOfFloat = this.A01;
        int i = Math.min((int)(200.0F * paramFloat), 199);
        f = i;
        float f1 = this.A00;
        paramFloat = (paramFloat - f * f1) / f1;
        f = arrayOfFloat[i];
        f += paramFloat * (arrayOfFloat[i + 1] - f);
      } 
    } 
    return f;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08M.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */