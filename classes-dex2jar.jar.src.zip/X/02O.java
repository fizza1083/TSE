package X;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class 02O implements Serializable {
  public Set _options;
  
  public final Pattern nativePattern;
  
  public 02O(String paramString) {
    this(pattern);
  }
  
  public 02O(String paramString, 0Wt param0Wt) {
    this(pattern);
  }
  
  public 02O(String paramString, Set paramSet) {
    this(pattern);
  }
  
  public 02O(Pattern paramPattern) {
    this.nativePattern = paramPattern;
  }
  
  private final Object writeReplace() {
    String str = this.nativePattern.pattern();
    16F.A0A(str);
    return new 175(str, this.nativePattern.flags());
  }
  
  public final String A00(CharSequence paramCharSequence, String paramString) {
    16F.A0E(paramCharSequence, 0);
    16F.A0E(paramString, 1);
    paramCharSequence = this.nativePattern.matcher(paramCharSequence).replaceAll(paramString);
    16F.A0A(paramCharSequence);
    return (String)paramCharSequence;
  }
  
  public final String A01(CharSequence paramCharSequence, String paramString) {
    16F.A0E(paramCharSequence, 0);
    paramCharSequence = this.nativePattern.matcher(paramCharSequence).replaceFirst(paramString);
    16F.A0A(paramCharSequence);
    return (String)paramCharSequence;
  }
  
  public final String A02(CharSequence paramCharSequence, 0BQ param0BQ) {
    int j;
    16F.A0E(paramCharSequence, 0);
    int i = 0;
    0HU 0HU = A06(paramCharSequence, 0);
    if (0HU == null)
      return paramCharSequence.toString(); 
    int k = paramCharSequence.length();
    StringBuilder stringBuilder = 001.A0t(k);
    while (true) {
      stringBuilder.append(paramCharSequence, i, (0HU.A01()).A00);
      stringBuilder.append((CharSequence)param0BQ.invoke(0HU));
      j = (0HU.A01()).A01 + 1;
      0HU 0HU1 = 0HU.A02();
      if (j < k) {
        0HU = 0HU1;
        i = j;
        if (0HU1 == null)
          break; 
        continue;
      } 
      break;
    } 
    if (j < k)
      stringBuilder.append(paramCharSequence, j, k); 
    return 16F.A04(stringBuilder);
  }
  
  public final List A03(CharSequence paramCharSequence, int paramInt) {
    16F.A0E(paramCharSequence, 0);
    Matcher matcher = this.nativePattern.matcher(paramCharSequence);
    if (paramInt != 1 && matcher.find()) {
      int i = 10;
      if (paramInt > 0)
        i = paramInt; 
      ArrayList<String> arrayList = new ArrayList(i);
      i = 0;
      int j = paramInt - 1;
      paramInt = i;
      while (true) {
        arrayList.add(paramCharSequence.subSequence(paramInt, matcher.start()).toString());
        i = matcher.end();
        if (j < 0 || arrayList.size() != j) {
          paramInt = i;
          if (!matcher.find())
            break; 
          continue;
        } 
        break;
      } 
      arrayList.add(paramCharSequence.subSequence(i, paramCharSequence.length()).toString());
      return arrayList;
    } 
    List<String> list = Collections.singletonList(paramCharSequence.toString());
    16F.A0A(list);
    return list;
  }
  
  public final 0Dn A04(CharSequence paramCharSequence, int paramInt) {
    0fv 0fv;
    16F.A0E(paramCharSequence, 0);
    if (paramInt >= 0 && paramInt <= paramCharSequence.length()) {
      0fv = new 0fv(paramCharSequence, this, paramInt);
      0Yt 0Yt = 0Yt.A00;
      16F.A0E(0Yt, 1);
      return new 0Dn(0fv, 0Yt);
    } 
    throw new IndexOutOfBoundsException(0XK.A0F(paramInt, 0fv.length(), "Start index out of bounds: ", ", input length: "));
  }
  
  public final 0HU A05(CharSequence paramCharSequence) {
    Matcher matcher = this.nativePattern.matcher(paramCharSequence);
    16F.A0A(matcher);
    return !matcher.matches() ? null : new 0HU(paramCharSequence, matcher);
  }
  
  public final 0HU A06(CharSequence paramCharSequence, int paramInt) {
    16F.A0E(paramCharSequence, 0);
    Matcher matcher = this.nativePattern.matcher(paramCharSequence);
    16F.A0A(matcher);
    return !matcher.find(paramInt) ? null : new 0HU(paramCharSequence, matcher);
  }
  
  public final boolean A07(CharSequence paramCharSequence) {
    16F.A0E(paramCharSequence, 0);
    return this.nativePattern.matcher(paramCharSequence).find();
  }
  
  public final boolean A08(CharSequence paramCharSequence) {
    16F.A0E(paramCharSequence, 0);
    return this.nativePattern.matcher(paramCharSequence).matches();
  }
  
  public final String toString() {
    return 16F.A04(this.nativePattern);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\02O.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */