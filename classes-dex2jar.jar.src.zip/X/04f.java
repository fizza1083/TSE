package X;

import com.facebook.profilo.ipc.TraceContext;
import com.facebook.profilo.writer.NativeTraceWriterCallbacks;

public final class 04f implements NativeTraceWriterCallbacks {
  public 04f(04b param04b, TraceContext paramTraceContext) {}
  
  public final void onTraceWriteAbort(long paramLong, int paramInt) {
    this.A00.A02.DLL(this.A01, paramInt);
  }
  
  public final void onTraceWriteEnd(long paramLong) {
    this.A00.A02.DLM(this.A01);
  }
  
  public final void onTraceWriteException(long paramLong, Throwable paramThrowable) {
    this.A00.A02.DLN(this.A01, paramThrowable);
  }
  
  public final void onTraceWriteStart(long paramLong, int paramInt) {
    this.A00.A02.DLO(this.A01);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\04f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */