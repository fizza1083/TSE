package X;

import android.content.Context;

public final class 00A {
  public static 00B A00;
  
  public static 00B A00(Context paramContext) {
    // Byte code:
    //   0: ldc X/00A
    //   2: monitorenter
    //   3: getstatic X/00A.A00 : LX/00B;
    //   6: astore_2
    //   7: aload_2
    //   8: astore_1
    //   9: aload_2
    //   10: ifnonnull -> 26
    //   13: new X/00B
    //   16: dup
    //   17: aload_0
    //   18: invokespecial <init> : (Landroid/content/Context;)V
    //   21: astore_1
    //   22: aload_1
    //   23: putstatic X/00A.A00 : LX/00B;
    //   26: ldc X/00A
    //   28: monitorexit
    //   29: aload_1
    //   30: areturn
    //   31: astore_0
    //   32: ldc X/00A
    //   34: monitorexit
    //   35: aload_0
    //   36: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	31	finally
    //   13	26	31	finally
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00A.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */