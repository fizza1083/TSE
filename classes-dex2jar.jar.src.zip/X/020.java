package X;

import java.util.Map;

public final class 020 {
  public final int A00;
  
  public final int A01;
  
  public final long A02;
  
  public final long A03;
  
  public final Map A04 = 002.A0g();
  
  public final Map A05 = 002.A0g();
  
  public final Map A06 = 002.A0g();
  
  public final Map A07 = 002.A0g();
  
  public final Map A08 = 002.A0g();
  
  public 020(int paramInt1, int paramInt2, long paramLong1, long paramLong2) {
    this.A03 = paramLong1;
    this.A02 = paramLong2;
    this.A00 = paramInt1;
    this.A01 = paramInt2;
  }
  
  public long getHitCount(String paramString) {
    return 002.A09(paramString, this.A04);
  }
  
  public long getSentCount(String paramString) {
    return 002.A09(paramString, this.A07);
  }
  
  public long getSkipCount(String paramString) {
    return 002.A09(paramString, this.A08);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\020.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */