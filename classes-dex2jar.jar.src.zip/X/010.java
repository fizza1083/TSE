package X;

import android.content.Context;
import java.lang.reflect.Field;

public final class 010 extends 00w {
  public 010() {
    super("display", null, null, null);
  }
  
  public final void A01(Context paramContext, 013 param013) {
    Class clazz = param013.A01("android.hardware.display.DisplayManagerGlobal");
    if (clazz != null) {
      Field field = param013.A03(clazz, "sInstance");
      if (field != null)
        try {
          Object object = field.get(null);
          if (object != null) {
            Field field1 = param013.A03(clazz, "mDm");
            if (field1 != null) {
              Object object1 = field1.get(object);
              if (object1 != null) {
                Class clazz1 = param013.A01("android.hardware.display.IDisplayManager");
                if (clazz1 != null) {
                  Object object2 = 00w.A00(this, clazz1, object1);
                  field1.set(object, object2);
                } 
              } 
            } 
          } 
          return;
        } catch (Exception exception) {
          return;
        }  
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\010.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */