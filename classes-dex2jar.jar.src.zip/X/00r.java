package X;

import android.os.Message;
import java.lang.reflect.Method;

public interface 00r {
  void AA2(Message paramMessage, 0RH param0RH, String paramString);
  
  01p AyX(014 param014, String paramString, Method paramMethod, Object[] paramArrayOfObject);
  
  void Ci8(Object paramObject, String paramString, Method paramMethod, Object[] paramArrayOfObject, long paramLong);
  
  boolean Cv1(Message paramMessage, 0RH param0RH, String paramString);
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */