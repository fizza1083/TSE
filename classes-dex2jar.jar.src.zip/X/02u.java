package X;

public abstract class 02u {
  public static final boolean A00(char paramChar) {
    if (!Character.isWhitespace(paramChar)) {
      boolean bool1 = Character.isSpaceChar(paramChar);
      boolean bool = false;
      return bool1 ? true : bool;
    } 
    return true;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\02u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */