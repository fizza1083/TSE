package X;

import android.content.Context;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Set;
import java.util.concurrent.Executor;

public final class 00E {
  public static 00E A09;
  
  public boolean A00;
  
  public final ArrayList A01;
  
  public final BitSet A02;
  
  public final BitSet A03;
  
  public final BitSet A04;
  
  public final Set A05;
  
  public final 00F[] A06;
  
  public final Integer[] A07;
  
  public final String[] A08;
  
  public 00E() {
    int j;
    int i = 0;
    this.A00 = false;
    Integer[] arrayOfInteger = new Integer[152];
    this.A07 = arrayOfInteger;
    this.A04 = new BitSet(152);
    this.A03 = new BitSet(152);
    this.A02 = new BitSet(152);
    this.A05 = 001.A12();
    this.A08 = new String[152];
    this.A06 = new 00F[152];
    this.A01 = 001.A0y();
    do {
      arrayOfInteger[i] = 0Xy.A00;
      j = i + 1;
      i = j;
    } while (j < 152);
  }
  
  public static 00E A00() {
    // Byte code:
    //   0: ldc X/00E
    //   2: monitorenter
    //   3: getstatic X/00E.A09 : LX/00E;
    //   6: astore_1
    //   7: aload_1
    //   8: astore_0
    //   9: aload_1
    //   10: ifnonnull -> 25
    //   13: new X/00E
    //   16: dup
    //   17: invokespecial <init> : ()V
    //   20: astore_0
    //   21: aload_0
    //   22: putstatic X/00E.A09 : LX/00E;
    //   25: ldc X/00E
    //   27: monitorexit
    //   28: aload_0
    //   29: areturn
    //   30: astore_0
    //   31: ldc X/00E
    //   33: monitorexit
    //   34: aload_0
    //   35: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	30	finally
    //   13	25	30	finally
  }
  
  public static final Integer A01(00E param00E, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: iconst_0
    //   3: istore_2
    //   4: iload_1
    //   5: iflt -> 10
    //   8: iconst_1
    //   9: istore_2
    //   10: iload_2
    //   11: ifeq -> 24
    //   14: aload_0
    //   15: getfield A07 : [Ljava/lang/Integer;
    //   18: iload_1
    //   19: aaload
    //   20: astore_3
    //   21: goto -> 28
    //   24: getstatic X/0Xy.A01 : Ljava/lang/Integer;
    //   27: astore_3
    //   28: aload_0
    //   29: monitorexit
    //   30: aload_3
    //   31: areturn
    //   32: astore_3
    //   33: aload_0
    //   34: monitorexit
    //   35: aload_3
    //   36: athrow
    // Exception table:
    //   from	to	target	type
    //   14	21	32	finally
    //   24	28	32	finally
  }
  
  public static final boolean A02(00E param00E, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: iconst_0
    //   3: istore #4
    //   5: iload #4
    //   7: istore_3
    //   8: iload_1
    //   9: bipush #-3
    //   11: if_icmpeq -> 78
    //   14: iload #4
    //   16: istore_3
    //   17: iload_1
    //   18: bipush #-2
    //   20: if_icmpeq -> 78
    //   23: iload_1
    //   24: iconst_m1
    //   25: if_icmpeq -> 74
    //   28: iload #4
    //   30: istore_3
    //   31: iload_1
    //   32: invokestatic A02 : (I)Z
    //   35: ifeq -> 78
    //   38: iload_2
    //   39: iconst_1
    //   40: if_icmpeq -> 55
    //   43: aload_0
    //   44: getfield A03 : Ljava/util/BitSet;
    //   47: iload_1
    //   48: invokevirtual get : (I)Z
    //   51: istore_3
    //   52: goto -> 78
    //   55: aload_0
    //   56: getfield A04 : Ljava/util/BitSet;
    //   59: iload_1
    //   60: invokevirtual get : (I)Z
    //   63: istore_3
    //   64: goto -> 78
    //   67: astore #5
    //   69: aload_0
    //   70: monitorexit
    //   71: aload #5
    //   73: athrow
    //   74: aload_0
    //   75: monitorexit
    //   76: iconst_1
    //   77: ireturn
    //   78: aload_0
    //   79: monitorexit
    //   80: iload_3
    //   81: ireturn
    // Exception table:
    //   from	to	target	type
    //   31	38	67	finally
    //   43	52	67	finally
    //   55	64	67	finally
  }
  
  public final String A03(String paramString) {
    // Byte code:
    //   0: aload_1
    //   1: invokestatic A00 : (Ljava/lang/String;)I
    //   4: istore_2
    //   5: aload_0
    //   6: monitorenter
    //   7: aconst_null
    //   8: astore_3
    //   9: aload_3
    //   10: astore_1
    //   11: iload_2
    //   12: bipush #-3
    //   14: if_icmpeq -> 56
    //   17: aload_3
    //   18: astore_1
    //   19: iload_2
    //   20: bipush #-2
    //   22: if_icmpeq -> 56
    //   25: aload_3
    //   26: astore_1
    //   27: iload_2
    //   28: iconst_m1
    //   29: if_icmpeq -> 56
    //   32: aload_3
    //   33: astore_1
    //   34: iload_2
    //   35: invokestatic A02 : (I)Z
    //   38: ifeq -> 56
    //   41: aload_0
    //   42: getfield A08 : [Ljava/lang/String;
    //   45: iload_2
    //   46: aaload
    //   47: astore_1
    //   48: goto -> 56
    //   51: astore_1
    //   52: aload_0
    //   53: monitorexit
    //   54: aload_1
    //   55: athrow
    //   56: aload_0
    //   57: monitorexit
    //   58: aload_1
    //   59: areturn
    // Exception table:
    //   from	to	target	type
    //   34	48	51	finally
  }
  
  public final void A04(0QA param0QA, Executor paramExecutor) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new X/0Nc
    //   5: dup
    //   6: aload_1
    //   7: aload_2
    //   8: invokespecial <init> : (LX/0QA;Ljava/util/concurrent/Executor;)V
    //   11: astore_1
    //   12: aload_0
    //   13: getfield A01 : Ljava/util/ArrayList;
    //   16: aload_1
    //   17: invokevirtual add : (Ljava/lang/Object;)Z
    //   20: pop
    //   21: iconst_0
    //   22: istore_3
    //   23: iload_3
    //   24: invokestatic getModuleName : (I)Ljava/lang/String;
    //   27: astore_2
    //   28: aload_0
    //   29: getfield A07 : [Ljava/lang/Integer;
    //   32: astore #5
    //   34: aload #5
    //   36: iload_3
    //   37: aaload
    //   38: getstatic X/0Xy.A00 : Ljava/lang/Integer;
    //   41: if_acmpeq -> 70
    //   44: aload #5
    //   46: iload_3
    //   47: aaload
    //   48: astore #5
    //   50: aload_1
    //   51: getfield A01 : Ljava/util/concurrent/Executor;
    //   54: new X/0Nj
    //   57: dup
    //   58: aload_1
    //   59: aload #5
    //   61: aload_2
    //   62: invokespecial <init> : (LX/0Nc;Ljava/lang/Integer;Ljava/lang/String;)V
    //   65: invokeinterface execute : (Ljava/lang/Runnable;)V
    //   70: aload_0
    //   71: getfield A04 : Ljava/util/BitSet;
    //   74: iload_3
    //   75: invokevirtual get : (I)Z
    //   78: ifeq -> 99
    //   81: aload_1
    //   82: getfield A01 : Ljava/util/concurrent/Executor;
    //   85: new X/0Nq
    //   88: dup
    //   89: aload_1
    //   90: aload_2
    //   91: invokespecial <init> : (LX/0Nc;Ljava/lang/String;)V
    //   94: invokeinterface execute : (Ljava/lang/Runnable;)V
    //   99: iload_3
    //   100: iconst_1
    //   101: iadd
    //   102: istore #4
    //   104: iload #4
    //   106: istore_3
    //   107: iload #4
    //   109: sipush #152
    //   112: if_icmplt -> 23
    //   115: aload_0
    //   116: monitorexit
    //   117: return
    //   118: astore_1
    //   119: aload_0
    //   120: monitorexit
    //   121: aload_1
    //   122: athrow
    // Exception table:
    //   from	to	target	type
    //   2	21	118	finally
    //   23	44	118	finally
    //   50	70	118	finally
    //   70	99	118	finally
  }
  
  public final void A05(Integer paramInteger, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: iload_2
    //   3: invokestatic A02 : (I)Z
    //   6: ifeq -> 101
    //   9: aload_0
    //   10: getfield A07 : [Ljava/lang/Integer;
    //   13: astore_3
    //   14: aload_3
    //   15: iload_2
    //   16: aaload
    //   17: aload_1
    //   18: if_acmpeq -> 101
    //   21: aload_3
    //   22: iload_2
    //   23: aload_1
    //   24: aastore
    //   25: aload_0
    //   26: getfield A01 : Ljava/util/ArrayList;
    //   29: invokevirtual iterator : ()Ljava/util/Iterator;
    //   32: astore_3
    //   33: aload_3
    //   34: invokeinterface hasNext : ()Z
    //   39: ifeq -> 84
    //   42: aload_3
    //   43: invokeinterface next : ()Ljava/lang/Object;
    //   48: checkcast X/0Nc
    //   51: astore #4
    //   53: iload_2
    //   54: invokestatic getModuleName : (I)Ljava/lang/String;
    //   57: astore #5
    //   59: aload #4
    //   61: getfield A01 : Ljava/util/concurrent/Executor;
    //   64: new X/0Nj
    //   67: dup
    //   68: aload #4
    //   70: aload_1
    //   71: aload #5
    //   73: invokespecial <init> : (LX/0Nc;Ljava/lang/Integer;Ljava/lang/String;)V
    //   76: invokeinterface execute : (Ljava/lang/Runnable;)V
    //   81: goto -> 33
    //   84: getstatic X/0pd.A01 : LX/0oF;
    //   87: iconst_3
    //   88: invokeinterface C6r : (I)Z
    //   93: ifeq -> 101
    //   96: iload_2
    //   97: invokestatic getModuleName : (I)Ljava/lang/String;
    //   100: pop
    //   101: aload_0
    //   102: monitorexit
    //   103: return
    //   104: astore_1
    //   105: aload_0
    //   106: monitorexit
    //   107: aload_1
    //   108: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	104	finally
    //   25	33	104	finally
    //   33	81	104	finally
    //   84	101	104	finally
  }
  
  public final void A06(String paramString, Integer paramInteger) {
    A05(paramInteger, 0E9.A00(paramString));
  }
  
  public final boolean A07(Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield A00 : Z
    //   6: istore #5
    //   8: iconst_1
    //   9: istore #4
    //   11: iload #4
    //   13: istore_3
    //   14: iload #5
    //   16: ifne -> 951
    //   19: aload_1
    //   20: invokestatic A00 : (Landroid/content/Context;)Z
    //   23: ifne -> 37
    //   26: aload_0
    //   27: iconst_1
    //   28: putfield A00 : Z
    //   31: iload #4
    //   33: istore_3
    //   34: goto -> 951
    //   37: aload_1
    //   38: invokevirtual getAssets : ()Landroid/content/res/AssetManager;
    //   41: astore #11
    //   43: new android/util/JsonReader
    //   46: dup
    //   47: new java/io/InputStreamReader
    //   50: dup
    //   51: aload #11
    //   53: ldc 'app_modules.json'
    //   55: invokevirtual open : (Ljava/lang/String;)Ljava/io/InputStream;
    //   58: ldc 'UTF-8'
    //   60: invokespecial <init> : (Ljava/io/InputStream;Ljava/lang/String;)V
    //   63: invokespecial <init> : (Ljava/io/Reader;)V
    //   66: astore #12
    //   68: aload #12
    //   70: invokevirtual beginObject : ()V
    //   73: aconst_null
    //   74: astore #6
    //   76: aconst_null
    //   77: astore_1
    //   78: aload #12
    //   80: invokevirtual hasNext : ()Z
    //   83: ifeq -> 649
    //   86: aload #12
    //   88: invokevirtual nextName : ()Ljava/lang/String;
    //   91: astore #7
    //   93: aload #7
    //   95: ldc 'downloadable'
    //   97: invokestatic A0S : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   100: ifeq -> 394
    //   103: new java/lang/Object
    //   106: dup
    //   107: invokespecial <init> : ()V
    //   110: pop
    //   111: new java/util/ArrayList
    //   114: dup
    //   115: invokespecial <init> : ()V
    //   118: astore #10
    //   120: aload #12
    //   122: invokevirtual beginArray : ()V
    //   125: aload_1
    //   126: astore #7
    //   128: aload #10
    //   130: astore #8
    //   132: aload #12
    //   134: invokevirtual hasNext : ()Z
    //   137: ifeq -> 565
    //   140: aload_1
    //   141: astore #7
    //   143: aload #10
    //   145: astore #8
    //   147: aload #12
    //   149: invokevirtual peek : ()Landroid/util/JsonToken;
    //   152: getstatic android/util/JsonToken.BEGIN_OBJECT : Landroid/util/JsonToken;
    //   155: if_acmpne -> 565
    //   158: aload #12
    //   160: invokevirtual beginObject : ()V
    //   163: aconst_null
    //   164: astore #7
    //   166: aconst_null
    //   167: astore #8
    //   169: aconst_null
    //   170: astore #9
    //   172: aconst_null
    //   173: astore #6
    //   175: aload #12
    //   177: invokevirtual hasNext : ()Z
    //   180: ifeq -> 339
    //   183: aload #12
    //   185: invokevirtual nextName : ()Ljava/lang/String;
    //   188: astore #13
    //   190: aload #13
    //   192: ifnull -> 244
    //   195: aload #13
    //   197: invokevirtual hashCode : ()I
    //   200: lookupswitch default -> 960, 3195150 -> 318, 3373707 -> 298, 270940796 -> 275, 1385644488 -> 252
    //   244: ldc 'unknown key '
    //   246: aload #13
    //   248: invokestatic A09 : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/RuntimeException;
    //   251: athrow
    //   252: aload #13
    //   254: ldc 'requires_native'
    //   256: invokevirtual equals : (Ljava/lang/Object;)Z
    //   259: ifeq -> 244
    //   262: aload #12
    //   264: invokevirtual nextBoolean : ()Z
    //   267: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   270: astore #6
    //   272: goto -> 175
    //   275: aload #13
    //   277: ldc 'disabled'
    //   279: invokevirtual equals : (Ljava/lang/Object;)Z
    //   282: ifeq -> 244
    //   285: aload #12
    //   287: invokevirtual nextBoolean : ()Z
    //   290: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   293: astore #9
    //   295: goto -> 175
    //   298: aload #13
    //   300: ldc 'name'
    //   302: invokevirtual equals : (Ljava/lang/Object;)Z
    //   305: ifeq -> 244
    //   308: aload #12
    //   310: invokevirtual nextString : ()Ljava/lang/String;
    //   313: astore #7
    //   315: goto -> 175
    //   318: aload #13
    //   320: ldc_w 'hash'
    //   323: invokevirtual equals : (Ljava/lang/Object;)Z
    //   326: ifeq -> 244
    //   329: aload #12
    //   331: invokevirtual nextString : ()Ljava/lang/String;
    //   334: astore #8
    //   336: goto -> 175
    //   339: aload #12
    //   341: invokevirtual endObject : ()V
    //   344: aload #7
    //   346: ifnull -> 601
    //   349: aload #8
    //   351: ifnull -> 594
    //   354: aload #9
    //   356: ifnull -> 587
    //   359: aload #6
    //   361: ifnull -> 580
    //   364: aload #10
    //   366: new X/0iD
    //   369: dup
    //   370: aload #7
    //   372: aload #8
    //   374: aload #9
    //   376: invokevirtual booleanValue : ()Z
    //   379: aload #6
    //   381: invokevirtual booleanValue : ()Z
    //   384: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;ZZ)V
    //   387: invokevirtual add : (Ljava/lang/Object;)Z
    //   390: pop
    //   391: goto -> 125
    //   394: aload #7
    //   396: ldc_w 'built_in'
    //   399: invokestatic A0S : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   402: ifeq -> 628
    //   405: new java/lang/Object
    //   408: dup
    //   409: invokespecial <init> : ()V
    //   412: pop
    //   413: new java/util/ArrayList
    //   416: dup
    //   417: invokespecial <init> : ()V
    //   420: astore #9
    //   422: aload #12
    //   424: invokevirtual beginArray : ()V
    //   427: aload #9
    //   429: astore #7
    //   431: aload #6
    //   433: astore #8
    //   435: aload #12
    //   437: invokevirtual hasNext : ()Z
    //   440: ifeq -> 565
    //   443: aload #9
    //   445: astore #7
    //   447: aload #6
    //   449: astore #8
    //   451: aload #12
    //   453: invokevirtual peek : ()Landroid/util/JsonToken;
    //   456: getstatic android/util/JsonToken.BEGIN_OBJECT : Landroid/util/JsonToken;
    //   459: if_acmpne -> 565
    //   462: aload #12
    //   464: invokevirtual beginObject : ()V
    //   467: aconst_null
    //   468: astore #7
    //   470: aconst_null
    //   471: astore_1
    //   472: aload #12
    //   474: invokevirtual hasNext : ()Z
    //   477: ifeq -> 529
    //   480: aload #12
    //   482: invokevirtual nextName : ()Ljava/lang/String;
    //   485: astore #8
    //   487: aload #8
    //   489: ldc 'name'
    //   491: invokestatic A0S : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   494: ifeq -> 507
    //   497: aload #12
    //   499: invokevirtual nextString : ()Ljava/lang/String;
    //   502: astore #7
    //   504: goto -> 472
    //   507: aload #8
    //   509: ldc 'requires_native'
    //   511: invokestatic A0S : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   514: ifeq -> 639
    //   517: aload #12
    //   519: invokevirtual nextBoolean : ()Z
    //   522: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   525: astore_1
    //   526: goto -> 472
    //   529: aload #12
    //   531: invokevirtual endObject : ()V
    //   534: aload #7
    //   536: ifnull -> 618
    //   539: aload_1
    //   540: ifnull -> 611
    //   543: aload #9
    //   545: new X/0iI
    //   548: dup
    //   549: aload #7
    //   551: aload_1
    //   552: invokevirtual booleanValue : ()Z
    //   555: invokespecial <init> : (Ljava/lang/String;Z)V
    //   558: invokevirtual add : (Ljava/lang/Object;)Z
    //   561: pop
    //   562: goto -> 427
    //   565: aload #12
    //   567: invokevirtual endArray : ()V
    //   570: aload #7
    //   572: astore_1
    //   573: aload #8
    //   575: astore #6
    //   577: goto -> 78
    //   580: ldc_w 'Required value was null.'
    //   583: invokestatic A0S : (Ljava/lang/String;)Ljava/lang/IllegalStateException;
    //   586: athrow
    //   587: ldc_w 'Required value was null.'
    //   590: invokestatic A0S : (Ljava/lang/String;)Ljava/lang/IllegalStateException;
    //   593: athrow
    //   594: ldc_w 'Required value was null.'
    //   597: invokestatic A0S : (Ljava/lang/String;)Ljava/lang/IllegalStateException;
    //   600: athrow
    //   601: ldc_w 'Required value was null.'
    //   604: invokestatic A0S : (Ljava/lang/String;)Ljava/lang/IllegalStateException;
    //   607: astore_1
    //   608: goto -> 647
    //   611: ldc_w 'Required value was null.'
    //   614: invokestatic A0S : (Ljava/lang/String;)Ljava/lang/IllegalStateException;
    //   617: athrow
    //   618: ldc_w 'Required value was null.'
    //   621: invokestatic A0S : (Ljava/lang/String;)Ljava/lang/IllegalStateException;
    //   624: astore_1
    //   625: goto -> 647
    //   628: ldc 'unknown key '
    //   630: aload #7
    //   632: invokestatic A09 : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/RuntimeException;
    //   635: astore_1
    //   636: goto -> 647
    //   639: ldc 'unknown key '
    //   641: aload #8
    //   643: invokestatic A09 : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/RuntimeException;
    //   646: astore_1
    //   647: aload_1
    //   648: athrow
    //   649: aload #12
    //   651: invokevirtual endObject : ()V
    //   654: aload #6
    //   656: ifnull -> 884
    //   659: aload_1
    //   660: ifnull -> 877
    //   663: aload #12
    //   665: invokevirtual close : ()V
    //   668: aload #6
    //   670: invokevirtual iterator : ()Ljava/util/Iterator;
    //   673: astore #6
    //   675: aload #6
    //   677: invokeinterface hasNext : ()Z
    //   682: ifeq -> 815
    //   685: aload #6
    //   687: invokeinterface next : ()Ljava/lang/Object;
    //   692: checkcast X/0iD
    //   695: astore #7
    //   697: aload #7
    //   699: getfield A01 : Ljava/lang/String;
    //   702: astore #8
    //   704: aload #8
    //   706: invokestatic A00 : (Ljava/lang/String;)I
    //   709: istore_2
    //   710: aload #7
    //   712: getfield A00 : Ljava/lang/String;
    //   715: astore #9
    //   717: iload_2
    //   718: invokestatic A02 : (I)Z
    //   721: ifeq -> 749
    //   724: aload_0
    //   725: getfield A08 : [Ljava/lang/String;
    //   728: iload_2
    //   729: aload #9
    //   731: aastore
    //   732: getstatic X/0pd.A01 : LX/0oF;
    //   735: iconst_3
    //   736: invokeinterface C6r : (I)Z
    //   741: ifeq -> 749
    //   744: iload_2
    //   745: invokestatic A01 : (I)Ljava/lang/String;
    //   748: pop
    //   749: aload #7
    //   751: getfield A02 : Z
    //   754: istore_3
    //   755: iload_2
    //   756: invokestatic A02 : (I)Z
    //   759: ifeq -> 788
    //   762: aload_0
    //   763: getfield A02 : Ljava/util/BitSet;
    //   766: iload_2
    //   767: iload_3
    //   768: invokevirtual set : (IZ)V
    //   771: getstatic X/0pd.A01 : LX/0oF;
    //   774: iconst_3
    //   775: invokeinterface C6r : (I)Z
    //   780: ifeq -> 788
    //   783: iload_2
    //   784: invokestatic A01 : (I)Ljava/lang/String;
    //   787: pop
    //   788: aload #7
    //   790: getfield A03 : Z
    //   793: ifeq -> 675
    //   796: aload_0
    //   797: getfield A05 : Ljava/util/Set;
    //   800: aload #8
    //   802: invokeinterface add : (Ljava/lang/Object;)Z
    //   807: pop
    //   808: goto -> 675
    //   811: astore_1
    //   812: goto -> 936
    //   815: aload_1
    //   816: invokevirtual iterator : ()Ljava/util/Iterator;
    //   819: astore_1
    //   820: aload_1
    //   821: invokeinterface hasNext : ()Z
    //   826: ifeq -> 866
    //   829: aload_1
    //   830: invokeinterface next : ()Ljava/lang/Object;
    //   835: checkcast X/0iI
    //   838: astore #6
    //   840: aload #6
    //   842: getfield A01 : Z
    //   845: ifeq -> 820
    //   848: aload_0
    //   849: getfield A05 : Ljava/util/Set;
    //   852: aload #6
    //   854: getfield A00 : Ljava/lang/String;
    //   857: invokeinterface add : (Ljava/lang/Object;)Z
    //   862: pop
    //   863: goto -> 820
    //   866: aload_0
    //   867: iconst_1
    //   868: putfield A00 : Z
    //   871: iload #4
    //   873: istore_3
    //   874: goto -> 951
    //   877: ldc_w 'Required value was null.'
    //   880: invokestatic A0S : (Ljava/lang/String;)Ljava/lang/IllegalStateException;
    //   883: athrow
    //   884: ldc_w 'Required value was null.'
    //   887: invokestatic A0S : (Ljava/lang/String;)Ljava/lang/IllegalStateException;
    //   890: athrow
    //   891: astore_1
    //   892: aload #12
    //   894: invokevirtual close : ()V
    //   897: aload_1
    //   898: athrow
    //   899: astore_1
    //   900: new java/io/IOException
    //   903: dup
    //   904: getstatic java/util/Locale.US : Ljava/util/Locale;
    //   907: ldc_w 'app_modules.json not found, assets = %s'
    //   910: iconst_1
    //   911: anewarray java/lang/Object
    //   914: dup
    //   915: iconst_0
    //   916: aload #11
    //   918: ldc_w ''
    //   921: invokevirtual list : (Ljava/lang/String;)[Ljava/lang/String;
    //   924: invokestatic toString : ([Ljava/lang/Object;)Ljava/lang/String;
    //   927: aastore
    //   928: invokestatic format : (Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   931: aload_1
    //   932: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   935: astore_1
    //   936: aload_1
    //   937: athrow
    //   938: astore_1
    //   939: ldc_w 'AppModuleStateCache'
    //   942: aload_1
    //   943: ldc_w 'Error loading downloadable module metadata'
    //   946: invokestatic A0T : (Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V
    //   949: iconst_0
    //   950: istore_3
    //   951: aload_0
    //   952: monitorexit
    //   953: iload_3
    //   954: ireturn
    //   955: astore_1
    //   956: aload_0
    //   957: monitorexit
    //   958: aload_1
    //   959: athrow
    //   960: goto -> 244
    // Exception table:
    //   from	to	target	type
    //   2	8	955	finally
    //   19	31	955	finally
    //   37	43	938	java/io/IOException
    //   37	43	955	finally
    //   43	68	899	java/io/FileNotFoundException
    //   43	68	938	java/io/IOException
    //   43	68	955	finally
    //   68	73	891	finally
    //   78	125	891	finally
    //   132	140	891	finally
    //   147	163	891	finally
    //   175	190	891	finally
    //   195	244	891	finally
    //   244	252	891	finally
    //   252	272	891	finally
    //   275	295	891	finally
    //   298	315	891	finally
    //   318	336	891	finally
    //   339	344	891	finally
    //   364	391	891	finally
    //   394	427	891	finally
    //   435	443	891	finally
    //   451	467	891	finally
    //   472	504	891	finally
    //   507	526	891	finally
    //   529	534	891	finally
    //   543	562	891	finally
    //   565	570	891	finally
    //   580	587	891	finally
    //   587	594	891	finally
    //   594	601	891	finally
    //   601	608	891	finally
    //   611	618	891	finally
    //   618	625	891	finally
    //   628	636	891	finally
    //   639	647	891	finally
    //   647	649	891	finally
    //   649	654	891	finally
    //   663	668	899	java/io/FileNotFoundException
    //   663	668	938	java/io/IOException
    //   663	668	955	finally
    //   668	675	938	java/io/IOException
    //   668	675	955	finally
    //   675	717	938	java/io/IOException
    //   675	717	955	finally
    //   717	749	811	finally
    //   749	755	938	java/io/IOException
    //   749	755	955	finally
    //   755	788	811	finally
    //   788	808	938	java/io/IOException
    //   788	808	955	finally
    //   815	820	938	java/io/IOException
    //   815	820	955	finally
    //   820	863	938	java/io/IOException
    //   820	863	955	finally
    //   866	871	938	java/io/IOException
    //   866	871	955	finally
    //   877	884	891	finally
    //   884	891	891	finally
    //   892	899	899	java/io/FileNotFoundException
    //   892	899	938	java/io/IOException
    //   892	899	955	finally
    //   900	936	938	java/io/IOException
    //   900	936	955	finally
    //   936	938	938	java/io/IOException
    //   936	938	955	finally
    //   939	949	955	finally
  }
  
  public final boolean A08(String paramString) {
    return A02(this, 0E9.A00(paramString), 1);
  }
  
  public final boolean A09(String paramString) {
    return 001.A1Y(A01(this, 0E9.A00(paramString)), 0Xy.A0C);
  }
  
  public final boolean A0A(String paramString) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_3
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_1
    //   5: invokestatic A00 : (Ljava/lang/String;)I
    //   8: istore_2
    //   9: iload_2
    //   10: ifge -> 16
    //   13: goto -> 37
    //   16: aload_0
    //   17: getfield A08 : [Ljava/lang/String;
    //   20: iload_2
    //   21: aaload
    //   22: ifnull -> 39
    //   25: aload_0
    //   26: getfield A02 : Ljava/util/BitSet;
    //   29: iload_2
    //   30: invokevirtual get : (I)Z
    //   33: istore_3
    //   34: goto -> 39
    //   37: iconst_1
    //   38: istore_3
    //   39: aload_0
    //   40: monitorexit
    //   41: iload_3
    //   42: ireturn
    //   43: astore_1
    //   44: aload_1
    //   45: athrow
    //   46: astore_1
    //   47: aload_1
    //   48: athrow
    //   49: astore_1
    //   50: aload_0
    //   51: monitorexit
    //   52: aload_1
    //   53: athrow
    // Exception table:
    //   from	to	target	type
    //   4	9	49	finally
    //   16	25	43	finally
    //   25	34	49	finally
    //   44	46	46	finally
    //   47	49	49	finally
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00E.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */