package X;

public final class 04u extends 04v implements 04t {
  public final 04k A00;
  
  public 04u(04k param04k) {
    this.A00 = param04k;
  }
  
  public final void A04(Throwable paramThrowable) {
    this.A00.A0O(A05());
  }
  
  public final boolean AO7(Throwable paramThrowable) {
    return A05().A0Q(paramThrowable);
  }
  
  public final 04l BVX() {
    return A05();
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\04u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */