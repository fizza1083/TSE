package X;

public final class 00a implements 0BA {
  public Object A00;
  
  public 14q A01;
  
  public 00a(14q param14q) {
    this.A01 = param14q;
  }
  
  public final Object get() {
    // Byte code:
    //   0: aload_0
    //   1: getfield A01 : LX/14q;
    //   4: ifnull -> 43
    //   7: aload_0
    //   8: monitorenter
    //   9: aload_0
    //   10: getfield A01 : LX/14q;
    //   13: astore_1
    //   14: aload_1
    //   15: ifnull -> 33
    //   18: aload_0
    //   19: aload_1
    //   20: invokeinterface get : ()Ljava/lang/Object;
    //   25: putfield A00 : Ljava/lang/Object;
    //   28: aload_0
    //   29: aconst_null
    //   30: putfield A01 : LX/14q;
    //   33: aload_0
    //   34: monitorexit
    //   35: goto -> 43
    //   38: astore_1
    //   39: aload_0
    //   40: monitorexit
    //   41: aload_1
    //   42: athrow
    //   43: aload_0
    //   44: getfield A00 : Ljava/lang/Object;
    //   47: areturn
    // Exception table:
    //   from	to	target	type
    //   9	14	38	finally
    //   18	33	38	finally
    //   33	35	38	finally
    //   39	41	38	finally
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */