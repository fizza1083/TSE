package X;

import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import java.util.concurrent.locks.LockSupport;

public abstract class 05o extends 05p implements 04M {
  static {
    A01 = AtomicReferenceFieldUpdater.newUpdater(05o.class, Object.class, "_delayed$volatile");
    A00 = AtomicIntegerFieldUpdater.newUpdater(05o.class, "_isCompleted$volatile");
  }
  
  private final boolean A01(Runnable paramRunnable) {
    AtomicReferenceFieldUpdater<05o, Object> atomicReferenceFieldUpdater = A02;
    while (true) {
      05X 05X = (05X)atomicReferenceFieldUpdater.get(this);
      int j = A00.get(this);
      int i = 0;
      if (j != 0)
        i = 1; 
      if (!i) {
        boolean bool;
        if (05X == null) {
          bool = 05v.A00(this, null, paramRunnable, atomicReferenceFieldUpdater);
        } else {
          if (05X instanceof 05X) {
            05X 05X1 = 05X;
            i = 05X1.A01(paramRunnable);
            if (i != 0) {
              if (i == 1) {
                05v.A00(this, 05X, 05X1.A03(), atomicReferenceFieldUpdater);
                continue;
              } 
              break;
            } 
            return true;
          } 
          if (05X != 0QN.A00) {
            05X 05X1 = new 05X(8, true);
            05X1.A01(05X);
            05X1.A01(paramRunnable);
            bool = 05v.A00(this, 05X, 05X1, atomicReferenceFieldUpdater);
          } else {
            break;
          } 
        } 
        if (bool)
          return true; 
        continue;
      } 
      break;
    } 
    return false;
  }
  
  public final void A05(Runnable paramRunnable, 04I param04I) {
    A0D(paramRunnable);
  }
  
  public final long A06() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual A0A : ()Z
    //   4: ifne -> 430
    //   7: getstatic X/05o.A01 : Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;
    //   10: astore #8
    //   12: aload #8
    //   14: aload_0
    //   15: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   18: checkcast X/0QM
    //   21: astore #9
    //   23: aload #9
    //   25: ifnull -> 131
    //   28: getstatic X/0QM.A01 : Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;
    //   31: aload #9
    //   33: invokevirtual get : (Ljava/lang/Object;)I
    //   36: ifeq -> 131
    //   39: invokestatic nanoTime : ()J
    //   42: lstore_1
    //   43: aload #9
    //   45: monitorenter
    //   46: aload #9
    //   48: getfield A00 : [LX/0Qd;
    //   51: astore #5
    //   53: aload #5
    //   55: ifnull -> 432
    //   58: aload #5
    //   60: iconst_0
    //   61: aaload
    //   62: astore #6
    //   64: goto -> 67
    //   67: aconst_null
    //   68: astore #7
    //   70: aload #7
    //   72: astore #5
    //   74: aload #6
    //   76: ifnull -> 123
    //   79: aload #6
    //   81: checkcast X/0Qc
    //   84: astore #6
    //   86: aload #7
    //   88: astore #5
    //   90: lload_1
    //   91: aload #6
    //   93: getfield A01 : J
    //   96: lsub
    //   97: lconst_0
    //   98: lcmp
    //   99: iflt -> 123
    //   102: aload #7
    //   104: astore #5
    //   106: aload_0
    //   107: aload #6
    //   109: invokespecial A01 : (Ljava/lang/Runnable;)Z
    //   112: ifeq -> 123
    //   115: aload #9
    //   117: iconst_0
    //   118: invokevirtual A01 : (I)LX/0Qd;
    //   121: astore #5
    //   123: aload #9
    //   125: monitorexit
    //   126: aload #5
    //   128: ifnonnull -> 43
    //   131: getstatic X/05o.A02 : Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;
    //   134: astore #6
    //   136: aload #6
    //   138: aload_0
    //   139: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   142: astore #5
    //   144: aload #5
    //   146: ifnull -> 255
    //   149: aload #5
    //   151: instanceof X/05X
    //   154: ifeq -> 217
    //   157: aload #5
    //   159: checkcast X/05X
    //   162: astore #7
    //   164: aload #7
    //   166: invokevirtual A02 : ()Ljava/lang/Object;
    //   169: astore #9
    //   171: aload #9
    //   173: getstatic X/05X.A04 : LX/04o;
    //   176: if_acmpeq -> 200
    //   179: aload #9
    //   181: checkcast java/lang/Runnable
    //   184: astore #5
    //   186: aload #5
    //   188: ifnull -> 255
    //   191: aload #5
    //   193: invokeinterface run : ()V
    //   198: lconst_0
    //   199: lreturn
    //   200: aload_0
    //   201: aload #5
    //   203: aload #7
    //   205: invokevirtual A03 : ()LX/05X;
    //   208: aload #6
    //   210: invokestatic A00 : (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;)Z
    //   213: pop
    //   214: goto -> 136
    //   217: aload #5
    //   219: getstatic X/0QN.A00 : LX/04o;
    //   222: if_acmpeq -> 255
    //   225: aload_0
    //   226: aload #5
    //   228: aconst_null
    //   229: aload #6
    //   231: invokestatic A00 : (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;)Z
    //   234: ifeq -> 136
    //   237: aload #5
    //   239: checkcast java/lang/Runnable
    //   242: astore #5
    //   244: goto -> 186
    //   247: astore #5
    //   249: aload #9
    //   251: monitorexit
    //   252: aload #5
    //   254: athrow
    //   255: aload_0
    //   256: getfield A01 : LX/0DS;
    //   259: astore #5
    //   261: aload #5
    //   263: ifnull -> 274
    //   266: aload #5
    //   268: invokevirtual isEmpty : ()Z
    //   271: ifeq -> 430
    //   274: aload #6
    //   276: aload_0
    //   277: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   280: astore #5
    //   282: ldc2_w 9223372036854775807
    //   285: lstore_3
    //   286: aload #5
    //   288: ifnull -> 328
    //   291: aload #5
    //   293: instanceof X/05X
    //   296: ifeq -> 418
    //   299: getstatic X/05X.A05 : Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;
    //   302: aload #5
    //   304: invokevirtual get : (Ljava/lang/Object;)J
    //   307: lstore_1
    //   308: ldc2_w 1073741823
    //   311: lload_1
    //   312: land
    //   313: iconst_0
    //   314: lshr
    //   315: l2i
    //   316: lload_1
    //   317: ldc2_w 1152921503533105152
    //   320: land
    //   321: bipush #30
    //   323: lshr
    //   324: l2i
    //   325: if_icmpne -> 430
    //   328: aload #8
    //   330: aload_0
    //   331: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   334: checkcast X/0QM
    //   337: astore #6
    //   339: lload_3
    //   340: lstore_1
    //   341: aload #6
    //   343: ifnull -> 428
    //   346: aload #6
    //   348: monitorenter
    //   349: aload #6
    //   351: getfield A00 : [LX/0Qd;
    //   354: astore #5
    //   356: aload #5
    //   358: ifnull -> 370
    //   361: aload #5
    //   363: iconst_0
    //   364: aaload
    //   365: astore #5
    //   367: goto -> 373
    //   370: aconst_null
    //   371: astore #5
    //   373: aload #6
    //   375: monitorexit
    //   376: aload #5
    //   378: checkcast X/0Qc
    //   381: astore #5
    //   383: lload_3
    //   384: lstore_1
    //   385: aload #5
    //   387: ifnull -> 428
    //   390: aload #5
    //   392: getfield A01 : J
    //   395: invokestatic nanoTime : ()J
    //   398: lsub
    //   399: lstore_3
    //   400: lload_3
    //   401: lstore_1
    //   402: lload_3
    //   403: lconst_0
    //   404: lcmp
    //   405: ifge -> 428
    //   408: lconst_0
    //   409: lreturn
    //   410: astore #5
    //   412: aload #6
    //   414: monitorexit
    //   415: aload #5
    //   417: athrow
    //   418: aload #5
    //   420: getstatic X/0QN.A00 : LX/04o;
    //   423: if_acmpne -> 430
    //   426: lload_3
    //   427: lstore_1
    //   428: lload_1
    //   429: lreturn
    //   430: lconst_0
    //   431: lreturn
    //   432: aconst_null
    //   433: astore #6
    //   435: goto -> 67
    // Exception table:
    //   from	to	target	type
    //   46	53	247	finally
    //   79	86	247	finally
    //   90	102	247	finally
    //   106	123	247	finally
    //   349	356	410	finally
  }
  
  public void A07() {
    // Byte code:
    //   0: getstatic X/0IP.A00 : Ljava/lang/ThreadLocal;
    //   3: aconst_null
    //   4: invokevirtual set : (Ljava/lang/Object;)V
    //   7: getstatic X/05o.A00 : Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;
    //   10: aload_0
    //   11: iconst_1
    //   12: invokevirtual set : (Ljava/lang/Object;I)V
    //   15: getstatic X/05o.A02 : Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;
    //   18: astore #5
    //   20: aload #5
    //   22: aload_0
    //   23: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   26: astore #4
    //   28: aload #4
    //   30: ifnonnull -> 131
    //   33: aload_0
    //   34: aconst_null
    //   35: getstatic X/0QN.A00 : LX/04o;
    //   38: aload #5
    //   40: invokestatic A00 : (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;)Z
    //   43: istore_1
    //   44: iload_1
    //   45: ifeq -> 20
    //   48: aload_0
    //   49: invokevirtual A06 : ()J
    //   52: lconst_0
    //   53: lcmp
    //   54: ifle -> 48
    //   57: invokestatic nanoTime : ()J
    //   60: lstore_2
    //   61: getstatic X/05o.A01 : Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;
    //   64: aload_0
    //   65: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   68: checkcast X/0QM
    //   71: astore #5
    //   73: aload #5
    //   75: ifnull -> 241
    //   78: aload #5
    //   80: monitorenter
    //   81: getstatic X/0QM.A01 : Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;
    //   84: aload #5
    //   86: invokevirtual get : (Ljava/lang/Object;)I
    //   89: ifle -> 103
    //   92: aload #5
    //   94: iconst_0
    //   95: invokevirtual A01 : (I)LX/0Qd;
    //   98: astore #4
    //   100: goto -> 106
    //   103: aconst_null
    //   104: astore #4
    //   106: aload #5
    //   108: monitorexit
    //   109: aload #4
    //   111: checkcast X/0Qc
    //   114: astore #4
    //   116: aload #4
    //   118: ifnull -> 241
    //   121: aload_0
    //   122: aload #4
    //   124: lload_2
    //   125: invokevirtual A0C : (LX/0Qc;J)V
    //   128: goto -> 61
    //   131: aload #4
    //   133: instanceof X/05X
    //   136: ifeq -> 191
    //   139: getstatic X/05X.A05 : Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;
    //   142: astore #5
    //   144: aload #5
    //   146: aload #4
    //   148: invokevirtual get : (Ljava/lang/Object;)J
    //   151: lstore_2
    //   152: lload_2
    //   153: ldc2_w 2305843009213693952
    //   156: land
    //   157: lconst_0
    //   158: lcmp
    //   159: ifne -> 48
    //   162: ldc2_w 1152921504606846976
    //   165: lload_2
    //   166: land
    //   167: lconst_0
    //   168: lcmp
    //   169: ifne -> 48
    //   172: aload #5
    //   174: aload #4
    //   176: lload_2
    //   177: lload_2
    //   178: ldc2_w 2305843009213693952
    //   181: lor
    //   182: invokevirtual compareAndSet : (Ljava/lang/Object;JJ)Z
    //   185: ifeq -> 144
    //   188: goto -> 48
    //   191: aload #4
    //   193: getstatic X/0QN.A00 : LX/04o;
    //   196: if_acmpeq -> 48
    //   199: new X/05X
    //   202: dup
    //   203: bipush #8
    //   205: iconst_1
    //   206: invokespecial <init> : (IZ)V
    //   209: astore #6
    //   211: aload #6
    //   213: aload #4
    //   215: invokevirtual A01 : (Ljava/lang/Object;)I
    //   218: pop
    //   219: aload_0
    //   220: aload #4
    //   222: aload #6
    //   224: aload #5
    //   226: invokestatic A00 : (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;)Z
    //   229: istore_1
    //   230: goto -> 44
    //   233: astore #4
    //   235: aload #5
    //   237: monitorexit
    //   238: aload #4
    //   240: athrow
    //   241: return
    // Exception table:
    //   from	to	target	type
    //   81	100	233	finally
  }
  
  public void A0D(Runnable paramRunnable) {
    if (A01(paramRunnable)) {
      paramRunnable = A0B();
      if (Thread.currentThread() != paramRunnable)
        LockSupport.unpark((Thread)paramRunnable); 
      return;
    } 
    05n.A00.A0D(paramRunnable);
  }
  
  public final void A0E(0Qc param0Qc, long paramLong) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: \r\n\tat com.googlecode.dex2jar.ir.ts.NewTransformer.transform(NewTransformer.java:134)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:148)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public final boolean A0F() {
    boolean bool;
    0DS 0DS = super.A01;
    if (0DS != null) {
      bool = 0DS.isEmpty();
    } else {
      bool = true;
    } 
    if (bool) {
      0DS = A01.get(this);
      if (0DS == null || 0QM.A01.get(0DS) == 0) {
        0DS = A02.get(this);
        if (0DS != null) {
          if (0DS instanceof 05X) {
            long l = 05X.A05.get(0DS);
            bool = false;
            if ((int)((0x3FFFFFFFL & l) >> 0L) == (int)((l & 0xFFFFFFFC0000000L) >> 30L))
              bool = true; 
            return bool;
          } 
          if (0DS == 0QN.A00)
            return true; 
        } else {
          return true;
        } 
      } 
    } 
    return false;
  }
  
  public 04s C25(Runnable paramRunnable, 04I param04I, long paramLong) {
    return 05m.A00.C25(paramRunnable, param04I, paramLong);
  }
  
  public final void Djw(0IU param0IU, long paramLong) {
    long l = 0L;
    if (paramLong > 0L) {
      if (paramLong < 9223372036854L) {
        l = 1000000L * paramLong;
        if (l < 4611686018427387903L) {
          paramLong = System.nanoTime();
          10S 10S1 = new 10S(param0IU, this, l + paramLong);
          A0E(10S1, paramLong);
          0IT.A02(new 0Qe(10S1), (0IT)param0IU);
          return;
        } 
      } 
      return;
    } 
    paramLong = System.nanoTime();
    10S 10S = new 10S(param0IU, this, l + paramLong);
    A0E(10S, paramLong);
    0IT.A02(new 0Qe(10S), (0IT)param0IU);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\05o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */