package X;

import com.facebook.fury.context.ReqContext;
import com.facebook.fury.context.ReqContextsPlugin;
import com.facebook.fury.props.ReqChainProps;
import com.facebook.fury.props.ReqContextProps;
import java.util.Iterator;

public final class 01M implements ReqContext {
  public final int A00;
  
  public final int A01;
  
  public final int A02;
  
  public final int A03;
  
  public final long A04;
  
  public final long A05;
  
  public final ReqContextsPlugin A06;
  
  public final ReqChainProps A07;
  
  public final ReqContextProps A08;
  
  public final String A09;
  
  public 01M(ReqContextsPlugin paramReqContextsPlugin, ReqChainProps paramReqChainProps, ReqContextProps paramReqContextProps, String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2) {
    this.A09 = paramString;
    this.A05 = paramLong1;
    this.A02 = paramInt1;
    this.A04 = paramLong2;
    this.A00 = paramInt2;
    this.A01 = paramInt3;
    this.A07 = paramReqChainProps;
    this.A08 = paramReqContextProps;
    this.A03 = paramInt4;
    this.A06 = paramReqContextsPlugin;
  }
  
  public final void close() {
    this.A06.deactivate(this);
  }
  
  public final boolean equals(Object paramObject) {
    boolean bool2 = true;
    boolean bool1 = bool2;
    if (this != paramObject) {
      if (paramObject != null && getClass() == paramObject.getClass()) {
        paramObject = paramObject;
        if (this.A04 == ((01M)paramObject).A04) {
          bool1 = bool2;
          if (this.A00 != ((01M)paramObject).A00)
            bool1 = false; 
          return bool1;
        } 
      } 
    } else {
      return bool1;
    } 
    return false;
  }
  
  public final boolean getBoolean(int paramInt1, boolean paramBoolean, int paramInt2) {
    ReqChainProps reqChainProps;
    if (paramInt2 != 0) {
      if (paramInt2 != 1) {
        if (paramInt2 != 2) {
          if (paramInt2 != 3)
            return paramBoolean; 
        } else {
          boolean bool4 = this.A08.getBoolean(paramInt1, paramBoolean);
          boolean bool3 = bool4;
          if (bool4 == paramBoolean) {
            reqChainProps = this.A07;
          } else {
            return bool3;
          } 
          bool3 = reqChainProps.getBoolean(paramInt1, paramBoolean);
        } 
        boolean bool2 = this.A07.getBoolean(paramInt1, paramBoolean);
        boolean bool1 = bool2;
        if (bool2 == paramBoolean) {
          ReqContextProps reqContextProps = this.A08;
        } else {
          return bool1;
        } 
      } else {
        ReqContextProps reqContextProps = this.A08;
        return reqContextProps.getBoolean(paramInt1, paramBoolean);
      } 
    } else {
      reqChainProps = this.A07;
      return reqChainProps.getBoolean(paramInt1, paramBoolean);
    } 
    boolean bool = reqChainProps.getBoolean(paramInt1, paramBoolean);
  }
  
  public final int getCurrentSeqId() {
    return this.A00;
  }
  
  public final long getCurrentTid() {
    return this.A04;
  }
  
  public final int getInt(int paramInt1, int paramInt2, int paramInt3) {
    ReqChainProps reqChainProps;
    if (paramInt3 != 0) {
      if (paramInt3 != 1) {
        if (paramInt3 != 2) {
          if (paramInt3 != 3)
            return paramInt2; 
        } else {
          int j = this.A08.getInt(paramInt1, paramInt2);
          paramInt3 = j;
          if (j == paramInt2) {
            reqChainProps = this.A07;
          } else {
            return paramInt3;
          } 
          paramInt3 = reqChainProps.getInt(paramInt1, paramInt2);
        } 
        int i = this.A07.getInt(paramInt1, paramInt2);
        paramInt3 = i;
        if (i == paramInt2) {
          ReqContextProps reqContextProps = this.A08;
        } else {
          return paramInt3;
        } 
      } else {
        ReqContextProps reqContextProps = this.A08;
        return reqContextProps.getInt(paramInt1, paramInt2);
      } 
    } else {
      reqChainProps = this.A07;
      return reqChainProps.getInt(paramInt1, paramInt2);
    } 
    paramInt3 = reqChainProps.getInt(paramInt1, paramInt2);
  }
  
  public final long getLong(int paramInt1, long paramLong, int paramInt2) {
    ReqChainProps reqChainProps;
    if (paramInt2 != 0) {
      if (paramInt2 != 1) {
        if (paramInt2 != 2) {
          if (paramInt2 != 3)
            return paramLong; 
        } else {
          long l4 = this.A08.getLong(paramInt1, paramLong);
          long l3 = l4;
          if (l4 == paramLong) {
            reqChainProps = this.A07;
          } else {
            return l3;
          } 
          l3 = reqChainProps.getLong(paramInt1, paramLong);
        } 
        long l2 = this.A07.getLong(paramInt1, paramLong);
        long l1 = l2;
        if (l2 == paramLong) {
          ReqContextProps reqContextProps = this.A08;
        } else {
          return l1;
        } 
      } else {
        ReqContextProps reqContextProps = this.A08;
        return reqContextProps.getLong(paramInt1, paramLong);
      } 
    } else {
      reqChainProps = this.A07;
      return reqChainProps.getLong(paramInt1, paramLong);
    } 
    long l = reqChainProps.getLong(paramInt1, paramLong);
  }
  
  public final Object getObject(int paramInt1, int paramInt2) {
    if (paramInt2 != 0) {
      if (paramInt2 != 1) {
        if (paramInt2 != 2) {
          if (paramInt2 != 3)
            return null; 
        } else {
          Object object4 = this.A08.getObject(paramInt1);
          Object object3 = object4;
          if (object4 == null) {
            object3 = this.A07;
            return object3.getObject(paramInt1);
          } 
          return object3;
        } 
        Object object2 = this.A07.getObject(paramInt1);
        Object object1 = object2;
        if (object2 == null) {
          object1 = this.A08;
          return object1.getObject(paramInt1);
        } 
        return object1;
      } 
    } else {
      ReqChainProps reqChainProps = this.A07;
      return reqChainProps.getObject(paramInt1);
    } 
    ReqContextProps reqContextProps = this.A08;
    return reqContextProps.getObject(paramInt1);
  }
  
  public final int getParentSeqId() {
    return this.A02;
  }
  
  public final long getParentTid() {
    return this.A05;
  }
  
  public final String getString(int paramInt1, int paramInt2) {
    if (paramInt2 != 0) {
      if (paramInt2 != 1) {
        ReqContextProps reqContextProps1;
        if (paramInt2 != 2) {
          if (paramInt2 != 3)
            return null; 
        } else {
          ReqChainProps reqChainProps;
          String str4 = this.A08.getString(paramInt1);
          String str3 = str4;
          if (str4 == null) {
            reqChainProps = this.A07;
            return reqChainProps.getString(paramInt1);
          } 
          return (String)reqChainProps;
        } 
        String str2 = this.A07.getString(paramInt1);
        String str1 = str2;
        if (str2 == null) {
          reqContextProps1 = this.A08;
          return reqContextProps1.getString(paramInt1);
        } 
        return (String)reqContextProps1;
      } 
    } else {
      ReqChainProps reqChainProps = this.A07;
      return reqChainProps.getString(paramInt1);
    } 
    ReqContextProps reqContextProps = this.A08;
    return reqContextProps.getString(paramInt1);
  }
  
  public final String getTag() {
    return this.A09;
  }
  
  public final int getType() {
    return this.A03;
  }
  
  public final Iterator globalProps() {
    return this.A07.props();
  }
  
  public final boolean hasParent() {
    return 002.A11(this.A05 cmp -1L);
  }
  
  public final boolean hasSameProps(ReqContext paramReqContext) {
    boolean bool = paramReqContext instanceof 01M;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (bool) {
      ReqChainProps reqChainProps = this.A07;
      paramReqContext = paramReqContext;
      bool1 = bool2;
      if (reqChainProps.equals(((01M)paramReqContext).A07)) {
        bool1 = bool2;
        if (this.A08.equals(((01M)paramReqContext).A08))
          bool1 = true; 
      } 
    } 
    return bool1;
  }
  
  public final int hashCode() {
    return 002.A02(this.A04) + this.A00;
  }
  
  public final boolean isFlagOn(int paramInt) {
    return 002.A11(paramInt & this.A01);
  }
  
  public final Iterator localProps() {
    return this.A08.props();
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01M.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */