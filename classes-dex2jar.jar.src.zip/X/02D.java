package X;

import com.facebook.base.lwperf.traceutil.TraceUtil;
import java.util.concurrent.Callable;

public final class 02D implements Callable {
  public 02D(String paramString1, String paramString2, Callable paramCallable) {}
  
  public final Object call() {
    0j3.A00(0XK.A0q(this.A00, "(parent=AppInit_", this.A01, ')'));
    try {
      return this.A02.call();
    } finally {
      TraceUtil.Api18Utils.endSection();
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\02D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */