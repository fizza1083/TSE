package X;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

public abstract class 04w extends 04x implements 04s, 04q {
  public 04k A00;
  
  public final 04k A05() {
    04k 04k1 = this.A00;
    if (04k1 != null)
      return 04k1; 
    16F.A0M("job");
    throw 0GH.createAndThrow();
  }
  
  public final 0Io BM0() {
    return null;
  }
  
  public final boolean C2C() {
    return true;
  }
  
  public final void dispose() {
    04k 04k1 = A05();
    while (true) {
      Object object = 04k1.A0A();
      if (object instanceof 04w) {
        if (object == this) {
          AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = 04k.A01;
          if (05v.A00(04k1, object, 04n.A00, atomicReferenceFieldUpdater))
            continue; 
          continue;
        } 
        continue;
      } 
      if (object instanceof 04q) {
        if (((04q)object).BM0() != null) {
          while (true) {
            Object object1 = A01();
            if (!(object1 instanceof 0Iq) && object1 != this) {
              16F.A0I(object1, "null cannot be cast to non-null type kotlinx.coroutines.internal.LockFreeLinkedListNode{ kotlinx.coroutines.internal.LockFreeLinkedListKt.Node }");
              04y 04y = (04y)object1;
              AtomicReferenceFieldUpdater<04y, Object> atomicReferenceFieldUpdater = 04y.A02;
              object = atomicReferenceFieldUpdater.get(04y);
              Object object2 = object;
              if (object == null) {
                object2 = new 0Iq(04y);
                atomicReferenceFieldUpdater.set(04y, object2);
              } 
              if (05v.A00(this, object1, object2, 04y.A00)) {
                04y.A00(04y);
                return;
              } 
              continue;
            } 
            return;
          } 
          break;
        } 
        continue;
      } 
      continue;
    } 
  }
  
  public final String toString() {
    StringBuilder stringBuilder = 001.A0s();
    stringBuilder.append(001.A0g(this));
    stringBuilder.append('@');
    002.A0w(stringBuilder, this);
    stringBuilder.append("[job@");
    002.A0w(stringBuilder, A05());
    return 002.A0W(stringBuilder);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\04w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */