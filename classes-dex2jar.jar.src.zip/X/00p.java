package X;

import java.util.Map;

public final class 00p {
  public Map A00 = 001.A11();
  
  public static void A00(00p param00p, Object paramObject) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield A00 : Ljava/util/Map;
    //   6: astore_3
    //   7: aload_3
    //   8: aload_1
    //   9: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   14: checkcast X/00s
    //   17: astore #4
    //   19: aload #4
    //   21: invokestatic A00 : (Ljava/lang/Object;)V
    //   24: aload #4
    //   26: getfield A00 : I
    //   29: iconst_1
    //   30: isub
    //   31: istore_2
    //   32: aload #4
    //   34: iload_2
    //   35: putfield A00 : I
    //   38: iload_2
    //   39: ifne -> 50
    //   42: aload_3
    //   43: aload_1
    //   44: invokeinterface remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   49: pop
    //   50: aload_0
    //   51: monitorexit
    //   52: return
    //   53: astore_1
    //   54: aload_0
    //   55: monitorexit
    //   56: aload_1
    //   57: athrow
    // Exception table:
    //   from	to	target	type
    //   2	38	53	finally
    //   42	50	53	finally
  }
  
  public final void A01(Object paramObject) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield A00 : Ljava/util/Map;
    //   6: aload_1
    //   7: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   12: checkcast X/00s
    //   15: astore #4
    //   17: aload #4
    //   19: invokestatic A00 : (Ljava/lang/Object;)V
    //   22: aload #4
    //   24: getfield A01 : Ljava/util/concurrent/Semaphore;
    //   27: astore #4
    //   29: aload #4
    //   31: invokevirtual availablePermits : ()I
    //   34: istore_2
    //   35: iload_2
    //   36: invokestatic A12 : (I)Z
    //   39: istore_3
    //   40: iload_3
    //   41: invokestatic A02 : (Z)V
    //   44: aload #4
    //   46: invokevirtual release : ()V
    //   49: aload_0
    //   50: aload_1
    //   51: invokestatic A00 : (LX/00p;Ljava/lang/Object;)V
    //   54: aload_0
    //   55: monitorexit
    //   56: return
    //   57: astore_1
    //   58: aload_0
    //   59: monitorexit
    //   60: aload_1
    //   61: athrow
    // Exception table:
    //   from	to	target	type
    //   2	35	57	finally
    //   40	54	57	finally
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */