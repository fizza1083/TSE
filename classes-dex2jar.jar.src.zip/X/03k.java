package X;

public final class 03k implements 0El {
  public final 0El[] A00;
  
  public 03k(0El... paramVarArgs) {
    this.A00 = paramVarArgs;
  }
  
  public final 0uD Bq6() {
    0uD 0uD2;
    0uD 0uD1 = 0uD.A03;
    0El[] arrayOf0El = this.A00;
    int j = arrayOf0El.length;
    int i = 0;
    while (true) {
      0uD2 = 0uD1;
      if (i < j) {
        int k = arrayOf0El[i].Bq6().ordinal();
        if (k != 0) {
          if (k == 1)
            0uD1 = 0uD.A01; 
          i++;
          continue;
        } 
        0uD2 = 0uD.A02;
      } 
      break;
    } 
    return 0uD2;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\03k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */