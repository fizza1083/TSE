package X;

import java.util.Collection;
import java.util.Iterator;

public abstract class 00V<E> implements Collection<E>, 16M {
  public abstract int A08();
  
  public final boolean add(Object paramObject) {
    throw 002.A0b();
  }
  
  public final boolean addAll(Collection paramCollection) {
    throw 002.A0b();
  }
  
  public final void clear() {
    throw 002.A0b();
  }
  
  public boolean contains(Object paramObject) {
    if (!(this instanceof Collection) || !super.isEmpty()) {
      Iterator iterator = iterator();
      while (true) {
        if (iterator.hasNext()) {
          if (16F.A0S(iterator.next(), paramObject))
            return true; 
          continue;
        } 
        return false;
      } 
    } 
    return false;
  }
  
  public boolean containsAll(Collection paramCollection) {
    16F.A0E(paramCollection, 0);
    boolean bool = paramCollection.isEmpty();
    boolean bool2 = true;
    boolean bool1 = bool2;
    if (!bool) {
      Iterator iterator = paramCollection.iterator();
      while (true) {
        bool1 = bool2;
        if (iterator.hasNext()) {
          if (!contains(iterator.next())) {
            bool1 = false;
            break;
          } 
          continue;
        } 
        break;
      } 
    } 
    return bool1;
  }
  
  public boolean isEmpty() {
    return 002.A12(size());
  }
  
  public abstract Iterator iterator();
  
  public final boolean remove(Object paramObject) {
    throw 002.A0b();
  }
  
  public final boolean removeAll(Collection paramCollection) {
    throw 002.A0b();
  }
  
  public final boolean retainAll(Collection paramCollection) {
    throw 002.A0b();
  }
  
  public Object[] toArray() {
    return 0A7.A00(this);
  }
  
  public Object[] toArray(Object[] paramArrayOfObject) {
    16F.A0E(paramArrayOfObject, 0);
    return 0A7.A01(this, paramArrayOfObject);
  }
  
  public final String toString() {
    return 0Xa.A0K(", ", "[", "]", "...", this, new 0oi(this), -1);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00V.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */