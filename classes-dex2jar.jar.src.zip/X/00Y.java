package X;

import android.app.ActivityThread;
import android.content.Context;
import android.util.Log;
import java.io.IOException;

public final class 00Y {
  public final void A00(String paramString) {
    paramString = 02Y.A0R(paramString);
    if (paramString != null) {
      ActivityThread activityThread = 0k5.A00();
      if (activityThread != null) {
        Context context = activityThread.getApplication().getBaseContext();
        try {
          00G.A00(context, 009.A00(context), 00A.A00(context)).A03(paramString);
          return;
        } catch (IOException iOException) {
          Log.e("VoltronModuleLoader", 0XK.A0b("Error loading module ", paramString), iOException);
        } 
      } else {
        throw 001.A0Z("ActivityThread was null");
      } 
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00Y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */