package X;

public final class 08O implements 08P {
  public final String DjQ(String paramString) {
    try {
      return 127.A00(paramString).toString();
    } catch (0GD 0GD) {
      return 0GD.mParsedUri.A06();
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08O.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */