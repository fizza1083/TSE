package X;

public abstract class 00Q {
  public static volatile int A00;
  
  public static boolean A00() {
    // Byte code:
    //   0: getstatic X/00Q.A00 : I
    //   3: ifne -> 30
    //   6: ldc X/00Q
    //   8: monitorenter
    //   9: getstatic X/00Q.A00 : I
    //   12: ifne -> 19
    //   15: iconst_m1
    //   16: putstatic X/00Q.A00 : I
    //   19: ldc X/00Q
    //   21: monitorexit
    //   22: iconst_0
    //   23: ireturn
    //   24: astore_0
    //   25: ldc X/00Q
    //   27: monitorexit
    //   28: aload_0
    //   29: athrow
    //   30: iconst_0
    //   31: ireturn
    // Exception table:
    //   from	to	target	type
    //   9	19	24	finally
    //   19	22	24	finally
    //   25	28	24	finally
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00Q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */