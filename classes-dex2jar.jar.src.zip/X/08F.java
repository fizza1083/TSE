package X;

public abstract class 08F {
  public static final Object A00 = 001.A0W();
  
  public static final Object A00(08D param08D, int paramInt) {
    paramInt = 0Xj.A00(param08D.A02, param08D.A00, paramInt);
    if (paramInt >= 0) {
      Object object2 = param08D.A03[paramInt];
      Object object1 = object2;
      return (object2 == A00) ? null : object1;
    } 
    return null;
  }
  
  public static final void A01(08D param08D) {
    int k = param08D.A00;
    int[] arrayOfInt = param08D.A02;
    Object[] arrayOfObject = param08D.A03;
    int i = 0;
    int j;
    for (j = 0; i < k; j = m) {
      Object object = arrayOfObject[i];
      int m = j;
      if (object != A00) {
        if (i != j) {
          arrayOfInt[j] = arrayOfInt[i];
          arrayOfObject[j] = object;
          arrayOfObject[i] = null;
        } 
        m = j + 1;
      } 
      i++;
    } 
    param08D.A01 = false;
    param08D.A00 = j;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08F.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */