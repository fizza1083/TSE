package X;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.locks.Lock;

public abstract class 03v {
  public static final void A00(0qi param0qi) {
    ArrayList<03y> arrayList;
    0tW 0tW = param0qi.A02;
    null = 0tW.A07;
    0ah.A03(null);
    16F.A0A(null);
    02P 02P = 02P.A00();
    Lock lock = 02P.A05;
    lock.lock();
    try {
      02P.A00 = null;
      int i = 0;
      Iterator<06I> iterator = 02P.A04.keySet().iterator();
      while (iterator.hasNext()) {
        ((06I)iterator.next()).C0z(null, String.valueOf(i));
        i++;
      } 
      lock.unlock();
      String str = 0tW.A09;
      16F.A0A(str);
      File[] arrayOfFile = 0tW.A05(str);
      16F.A0A(arrayOfFile);
      ArrayList<File> arrayList1 = 001.A0y();
      int j = arrayOfFile.length;
      for (i = 0; i < j; i++) {
        File file = arrayOfFile[i];
        if ((16F.A0S(file.getAbsolutePath(), null.getAbsolutePath()) ^ true) != 0)
          arrayList1.add(file); 
      } 
      arrayList = 154.A15(arrayList1);
      for (File file : arrayList1) {
        Integer integer;
        0rC 0rC = 0rC.A00(0tW, false, false, false);
        String str1 = 0rC.A02();
        char c = 0rC.A01;
        if (0rD.A02(0rE.A02, c) || 0rD.A02(0rE.A03, c) || 0rC.A03() || (0rC.A05 && 0rC.A04())) {
          integer = 0Xy.A01;
        } else {
          integer = 0Xy.A00;
        } 
        arrayList.add(new 03y(file, integer, str1, 0rC.A05));
      } 
    } finally {
      arrayList.unlock();
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\03v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */