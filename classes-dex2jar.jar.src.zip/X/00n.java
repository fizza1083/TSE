package X;

import com.facebook.quicklog.LightweightQuickPerformanceLogger;

public abstract class 00n implements 00o {
  public 00f A00;
  
  public final 00c A01;
  
  public 00n(00c param00c) {
    this.A01 = param00c;
  }
  
  private final LightweightQuickPerformanceLogger A00() {
    00f 00f1 = this.A00;
    return (00f1 == null) ? null : (LightweightQuickPerformanceLogger)00f1.A00.get();
  }
  
  public final 00c A05(Class paramClass) {
    00c 00c2 = this.A01;
    00c 00c1 = 00c2;
    if (!paramClass.isInstance(00c2))
      00c1 = null; 
    return 00c1;
  }
  
  public final 03w A06() {
    00f 00f1 = this.A00;
    return (00f1 == null) ? null : (03w)00f1.A01.get();
  }
  
  public final void A07() {
    if (A00() != null)
      A00().markerAnnotate(157825012, 0XK.A0b(getName(), "_enabled"), true); 
  }
  
  public final void A08(String paramString) {
    if (A00() != null)
      A00().markerAnnotate(157825012, 0XK.A0b(getName(), "_disabled"), paramString); 
  }
  
  public final void A09(String paramString) {
    if (A06() != null) {
      07l 07l;
      03w 03w = A06();
      String str = getName();
      03w.ALJ(str, 817901561);
      if (A06() == null) {
        03w = null;
      } else {
        07l = A06().ALJ(str, 817901561);
      } 
      07l.AFo("message", paramString);
      07l.report();
    } 
  }
  
  public final void A0A(String paramString) {
    if (A00() != null) {
      A00().markerAnnotate(157825012, 0XK.A0p(getName(), "_enabled_", paramString), true);
      A07();
    } 
  }
  
  public final void A0B(Throwable paramThrowable) {
    paramThrowable.getMessage();
    if (A06() != null) {
      03w 03w = A06();
      String str = getName();
      07l 07l = 03w.ALK(001.A0L(), str, 817901561);
      07l.Dne(paramThrowable);
      07l.report();
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */