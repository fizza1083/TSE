package X;

import com.facebook.fury.context.ReqContext;
import com.facebook.fury.context.ReqContextExtensions;
import com.facebook.fury.context.ReqContextLifecycleCallbacks;
import com.facebook.fury.context.ReqContextsCallbacks;
import com.facebook.fury.context.ReqContextsPlugin;
import com.facebook.fury.context.StackExt;
import java.util.concurrent.atomic.AtomicInteger;

public final class 019 implements ReqContextsPlugin {
  public final ReqContextsCallbacks A00;
  
  public final ThreadLocal A01 = new ThreadLocal();
  
  public final AtomicInteger A02 = new AtomicInteger();
  
  public 019(ReqContextsCallbacks paramReqContextsCallbacks) {
    this.A00 = paramReqContextsCallbacks;
  }
  
  private final 01M A00(01M param01M, String paramString, int paramInt1, int paramInt2) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: \r\n\tat com.googlecode.dex2jar.ir.ts.NewTransformer.transform(NewTransformer.java:134)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:148)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  private final void A01(01M param01M) {
    ThreadLocal<StackExt> threadLocal = this.A01;
    StackExt stackExt2 = threadLocal.get();
    StackExt stackExt1 = stackExt2;
    if (stackExt2 == null) {
      stackExt1 = new 0Gw();
      threadLocal.set(stackExt1);
    } 
    stackExt1.push(param01M);
    ReqContextLifecycleCallbacks reqContextLifecycleCallbacks = this.A00.provideLifecycleCallbacks();
    if (reqContextLifecycleCallbacks != null)
      reqContextLifecycleCallbacks.onActivate(param01M); 
  }
  
  public final boolean accepts(ReqContext paramReqContext) {
    return paramReqContext instanceof 01M;
  }
  
  public final void reset() {}
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\019.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */