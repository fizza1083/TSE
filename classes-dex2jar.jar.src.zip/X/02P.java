package X;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public final class 02P {
  public static volatile 02P A06;
  
  public File A00;
  
  public 14q A01;
  
  public 03y[] A02;
  
  public boolean A03;
  
  public final Map A04 = 001.A18();
  
  public final Lock A05 = new ReentrantLock(true);
  
  public static 02P A00() {
    // Byte code:
    //   0: getstatic X/02P.A06 : LX/02P;
    //   3: ifnonnull -> 37
    //   6: ldc X/02P
    //   8: monitorenter
    //   9: getstatic X/02P.A06 : LX/02P;
    //   12: ifnonnull -> 25
    //   15: new X/02P
    //   18: dup
    //   19: invokespecial <init> : ()V
    //   22: putstatic X/02P.A06 : LX/02P;
    //   25: ldc X/02P
    //   27: monitorexit
    //   28: goto -> 37
    //   31: astore_0
    //   32: ldc X/02P
    //   34: monitorexit
    //   35: aload_0
    //   36: athrow
    //   37: getstatic X/02P.A06 : LX/02P;
    //   40: areturn
    // Exception table:
    //   from	to	target	type
    //   9	25	31	finally
    //   25	28	31	finally
    //   32	35	31	finally
  }
  
  public static final 0C4[] A01(0BZ param0BZ, RandomAccessFile paramRandomAccessFile, long paramLong1, long paramLong2) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: \r\n\tat com.googlecode.dex2jar.ir.ts.NewTransformer.transform(NewTransformer.java:134)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:148)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public static 0C4[] readOrangeBoxImpl(File paramFile, 0BZ param0BZ) {
    // Byte code:
    //   0: invokestatic A0y : ()Ljava/util/ArrayList;
    //   3: astore #17
    //   5: iconst_0
    //   6: istore_3
    //   7: new X/0BZ
    //   10: dup
    //   11: invokespecial <init> : ()V
    //   14: astore #18
    //   16: iload_3
    //   17: invokestatic valueOf : (I)Ljava/lang/String;
    //   20: astore #15
    //   22: new java/util/ArrayList
    //   25: dup
    //   26: invokespecial <init> : ()V
    //   29: astore #19
    //   31: ldc 'qpl_resilience_storage'
    //   33: aload #15
    //   35: invokestatic A0b : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   38: astore #13
    //   40: new java/util/ArrayList
    //   43: dup
    //   44: invokespecial <init> : ()V
    //   47: astore #20
    //   49: new java/io/File
    //   52: dup
    //   53: aload_0
    //   54: aload #13
    //   56: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   59: astore #14
    //   61: aload #14
    //   63: invokevirtual exists : ()Z
    //   66: istore #8
    //   68: aconst_null
    //   69: astore #16
    //   71: aload #16
    //   73: astore #13
    //   75: iload #8
    //   77: ifeq -> 347
    //   80: aload #18
    //   82: iconst_1
    //   83: putfield A0C : Z
    //   86: new X/0BZ
    //   89: dup
    //   90: invokespecial <init> : ()V
    //   93: astore #22
    //   95: new java/io/RandomAccessFile
    //   98: dup
    //   99: aload #14
    //   101: ldc 'r'
    //   103: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   106: astore #21
    //   108: aload #21
    //   110: invokevirtual readInt : ()I
    //   113: istore #4
    //   115: iload #4
    //   117: newarray int
    //   119: astore #23
    //   121: iload #4
    //   123: newarray int
    //   125: astore #24
    //   127: iload #4
    //   129: newarray long
    //   131: astore #25
    //   133: iconst_0
    //   134: istore_2
    //   135: iload_2
    //   136: iload #4
    //   138: if_icmpge -> 915
    //   141: aload #25
    //   143: iload_2
    //   144: aload #21
    //   146: invokevirtual readLong : ()J
    //   149: lastore
    //   150: aload #23
    //   152: iload_2
    //   153: aload #21
    //   155: invokevirtual readInt : ()I
    //   158: iastore
    //   159: aload #24
    //   161: iload_2
    //   162: aload #21
    //   164: invokevirtual readInt : ()I
    //   167: iastore
    //   168: iload_2
    //   169: iconst_1
    //   170: iadd
    //   171: istore_2
    //   172: goto -> 135
    //   175: aload #21
    //   177: invokevirtual length : ()J
    //   180: lstore #9
    //   182: goto -> 960
    //   185: aload #14
    //   187: astore #13
    //   189: iload #6
    //   191: iconst_3
    //   192: if_icmpne -> 260
    //   195: aload #22
    //   197: aload #21
    //   199: lload #11
    //   201: lload #9
    //   203: invokestatic A03 : (LX/0BZ;Ljava/io/RandomAccessFile;JJ)[LX/0C4;
    //   206: astore #13
    //   208: goto -> 260
    //   211: aload #14
    //   213: astore #13
    //   215: iload #5
    //   217: iconst_1
    //   218: if_icmpne -> 260
    //   221: aload #14
    //   223: astore #13
    //   225: iload #6
    //   227: iconst_1
    //   228: if_icmpne -> 260
    //   231: aload #22
    //   233: aload #21
    //   235: lload #11
    //   237: lload #9
    //   239: invokestatic A01 : (LX/0BZ;Ljava/io/RandomAccessFile;JJ)[LX/0C4;
    //   242: astore #13
    //   244: goto -> 260
    //   247: aload #22
    //   249: aload #21
    //   251: lload #11
    //   253: lload #9
    //   255: invokestatic A02 : (LX/0BZ;Ljava/io/RandomAccessFile;JJ)[LX/0C4;
    //   258: astore #13
    //   260: aload #20
    //   262: aload #13
    //   264: invokestatic asList : ([Ljava/lang/Object;)Ljava/util/List;
    //   267: invokevirtual addAll : (Ljava/util/Collection;)Z
    //   270: pop
    //   271: aload #18
    //   273: aload #22
    //   275: invokevirtual A03 : (LX/0BZ;)V
    //   278: aload #13
    //   280: astore #14
    //   282: goto -> 920
    //   285: aload #20
    //   287: iconst_0
    //   288: anewarray X/0C4
    //   291: invokevirtual toArray : ([Ljava/lang/Object;)[Ljava/lang/Object;
    //   294: checkcast [LX/0C4;
    //   297: astore #13
    //   299: aload #21
    //   301: invokevirtual close : ()V
    //   304: goto -> 347
    //   307: astore #13
    //   309: aload #21
    //   311: invokevirtual close : ()V
    //   314: goto -> 326
    //   317: astore #14
    //   319: aload #13
    //   321: aload #14
    //   323: invokestatic A00 : (Ljava/lang/Throwable;Ljava/lang/Throwable;)V
    //   326: aload #13
    //   328: athrow
    //   329: astore #13
    //   331: aload #18
    //   333: aload #13
    //   335: invokestatic A00 : (LX/0BZ;Ljava/lang/Throwable;)V
    //   338: aload #20
    //   340: invokevirtual clear : ()V
    //   343: aload #16
    //   345: astore #13
    //   347: aload #13
    //   349: ifnull -> 802
    //   352: aload #19
    //   354: aload #13
    //   356: invokestatic asList : ([Ljava/lang/Object;)Ljava/util/List;
    //   359: invokevirtual addAll : (Ljava/util/Collection;)Z
    //   362: pop
    //   363: iconst_1
    //   364: istore_2
    //   365: iconst_0
    //   366: istore #5
    //   368: iload_2
    //   369: istore #4
    //   371: iload #5
    //   373: istore_2
    //   374: aload #15
    //   376: astore #13
    //   378: aload #15
    //   380: invokevirtual isEmpty : ()Z
    //   383: ifeq -> 785
    //   386: iload_2
    //   387: invokestatic valueOf : (I)Ljava/lang/String;
    //   390: astore #13
    //   392: new java/io/File
    //   395: dup
    //   396: aload_0
    //   397: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   400: ldc '/'
    //   402: ldc 'qpl_v2_'
    //   404: aload #13
    //   406: invokestatic A11 : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   409: invokespecial <init> : (Ljava/lang/String;)V
    //   412: astore #14
    //   414: aload #14
    //   416: invokevirtual exists : ()Z
    //   419: istore #8
    //   421: iconst_0
    //   422: istore #5
    //   424: iload #8
    //   426: ifeq -> 473
    //   429: iconst_1
    //   430: istore #5
    //   432: aload #18
    //   434: iconst_1
    //   435: putfield A0C : Z
    //   438: new X/0BZ
    //   441: dup
    //   442: invokespecial <init> : ()V
    //   445: astore #16
    //   447: aload #19
    //   449: aload #16
    //   451: aload #14
    //   453: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   456: invokestatic A03 : (LX/0BZ;Ljava/lang/String;)[LX/0C4;
    //   459: invokestatic asList : ([Ljava/lang/Object;)Ljava/util/List;
    //   462: invokevirtual addAll : (Ljava/util/Collection;)Z
    //   465: pop
    //   466: aload #18
    //   468: aload #16
    //   470: invokevirtual A03 : (LX/0BZ;)V
    //   473: new java/io/File
    //   476: dup
    //   477: aload_0
    //   478: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   481: ldc '/'
    //   483: ldc 'qpl_v3_'
    //   485: aload #13
    //   487: invokestatic A11 : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   490: invokespecial <init> : (Ljava/lang/String;)V
    //   493: astore #14
    //   495: aload #14
    //   497: invokevirtual exists : ()Z
    //   500: istore #8
    //   502: iconst_0
    //   503: istore #6
    //   505: iload #8
    //   507: ifeq -> 554
    //   510: iconst_1
    //   511: istore #6
    //   513: aload #18
    //   515: iconst_1
    //   516: putfield A0C : Z
    //   519: new X/0BZ
    //   522: dup
    //   523: invokespecial <init> : ()V
    //   526: astore #16
    //   528: aload #19
    //   530: aload #16
    //   532: aload #14
    //   534: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   537: invokestatic A04 : (LX/0BZ;Ljava/lang/String;)[LX/0C4;
    //   540: invokestatic asList : ([Ljava/lang/Object;)Ljava/util/List;
    //   543: invokevirtual addAll : (Ljava/util/Collection;)Z
    //   546: pop
    //   547: aload #18
    //   549: aload #16
    //   551: invokevirtual A03 : (LX/0BZ;)V
    //   554: aload #13
    //   556: iconst_1
    //   557: invokestatic A0E : (Ljava/lang/Object;I)V
    //   560: new java/io/File
    //   563: dup
    //   564: aload_0
    //   565: invokevirtual getCanonicalPath : ()Ljava/lang/String;
    //   568: ldc '/qpl_higher_guarantee_'
    //   570: aload #13
    //   572: invokestatic A0p : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   575: invokespecial <init> : (Ljava/lang/String;)V
    //   578: astore #13
    //   580: aload #13
    //   582: invokevirtual exists : ()Z
    //   585: istore #8
    //   587: iconst_0
    //   588: istore #7
    //   590: iload #8
    //   592: ifeq -> 718
    //   595: iconst_1
    //   596: istore #7
    //   598: aload #18
    //   600: iconst_1
    //   601: putfield A0C : Z
    //   604: new X/0BZ
    //   607: dup
    //   608: invokespecial <init> : ()V
    //   611: astore #14
    //   613: aload #13
    //   615: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   618: astore #13
    //   620: aload #13
    //   622: iconst_0
    //   623: invokestatic A0E : (Ljava/lang/Object;I)V
    //   626: aload #14
    //   628: iconst_1
    //   629: putfield A00 : I
    //   632: new java/io/RandomAccessFile
    //   635: dup
    //   636: aload #13
    //   638: ldc 'r'
    //   640: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
    //   643: astore #16
    //   645: aload #14
    //   647: aload #16
    //   649: lconst_0
    //   650: aload #16
    //   652: invokevirtual length : ()J
    //   655: invokestatic A01 : (LX/0BZ;Ljava/io/RandomAccessFile;JJ)[LX/0C4;
    //   658: astore #13
    //   660: aload #16
    //   662: invokevirtual close : ()V
    //   665: goto -> 700
    //   668: astore #13
    //   670: aload #13
    //   672: athrow
    //   673: astore #20
    //   675: aload #16
    //   677: aload #13
    //   679: invokestatic A00 : (Ljava/io/Closeable;Ljava/lang/Throwable;)V
    //   682: aload #20
    //   684: athrow
    //   685: astore #13
    //   687: aload #14
    //   689: aload #13
    //   691: invokestatic A00 : (LX/0BZ;Ljava/lang/Throwable;)V
    //   694: iconst_0
    //   695: anewarray X/0C4
    //   698: astore #13
    //   700: aload #19
    //   702: aload #13
    //   704: invokestatic asList : ([Ljava/lang/Object;)Ljava/util/List;
    //   707: invokevirtual addAll : (Ljava/util/Collection;)Z
    //   710: pop
    //   711: aload #18
    //   713: aload #14
    //   715: invokevirtual A03 : (LX/0BZ;)V
    //   718: iload #5
    //   720: ifne -> 775
    //   723: iload #6
    //   725: ifne -> 775
    //   728: iload #7
    //   730: ifne -> 775
    //   733: iload #4
    //   735: ifeq -> 807
    //   738: aload #19
    //   740: iconst_0
    //   741: anewarray X/0C4
    //   744: invokevirtual toArray : ([Ljava/lang/Object;)[Ljava/lang/Object;
    //   747: astore #13
    //   749: aload #13
    //   751: ifnull -> 807
    //   754: aload #17
    //   756: aload #13
    //   758: invokevirtual add : (Ljava/lang/Object;)Z
    //   761: pop
    //   762: aload_1
    //   763: aload #18
    //   765: invokevirtual A03 : (LX/0BZ;)V
    //   768: iload_3
    //   769: iconst_1
    //   770: iadd
    //   771: istore_3
    //   772: goto -> 7
    //   775: iload_2
    //   776: iconst_1
    //   777: iadd
    //   778: istore_2
    //   779: iconst_1
    //   780: istore #4
    //   782: goto -> 374
    //   785: iload_2
    //   786: ifeq -> 392
    //   789: aload #15
    //   791: ldc '_'
    //   793: iload_2
    //   794: invokestatic A0j : (Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;
    //   797: astore #13
    //   799: goto -> 392
    //   802: iconst_0
    //   803: istore_2
    //   804: goto -> 365
    //   807: aload #17
    //   809: invokevirtual iterator : ()Ljava/util/Iterator;
    //   812: astore_0
    //   813: iconst_0
    //   814: istore_2
    //   815: aload_0
    //   816: invokeinterface hasNext : ()Z
    //   821: ifeq -> 840
    //   824: iload_2
    //   825: aload_0
    //   826: invokeinterface next : ()Ljava/lang/Object;
    //   831: checkcast [LX/0C4;
    //   834: arraylength
    //   835: iadd
    //   836: istore_2
    //   837: goto -> 815
    //   840: iload_2
    //   841: anewarray X/0C4
    //   844: astore_0
    //   845: aload #17
    //   847: invokevirtual iterator : ()Ljava/util/Iterator;
    //   850: astore_1
    //   851: iconst_0
    //   852: istore_3
    //   853: aload_1
    //   854: invokeinterface hasNext : ()Z
    //   859: ifeq -> 913
    //   862: aload_1
    //   863: invokeinterface next : ()Ljava/lang/Object;
    //   868: checkcast [LX/0C4;
    //   871: astore #13
    //   873: aload #13
    //   875: arraylength
    //   876: istore #5
    //   878: iconst_0
    //   879: istore #4
    //   881: iload_3
    //   882: istore_2
    //   883: iload_2
    //   884: istore_3
    //   885: iload #4
    //   887: iload #5
    //   889: if_icmpge -> 853
    //   892: aload_0
    //   893: iload_2
    //   894: aload #13
    //   896: iload #4
    //   898: aaload
    //   899: aastore
    //   900: iload #4
    //   902: iconst_1
    //   903: iadd
    //   904: istore #4
    //   906: iload_2
    //   907: iconst_1
    //   908: iadd
    //   909: istore_2
    //   910: goto -> 883
    //   913: aload_0
    //   914: areturn
    //   915: aconst_null
    //   916: astore #14
    //   918: iconst_0
    //   919: istore_2
    //   920: iload_2
    //   921: iload #4
    //   923: if_icmpge -> 285
    //   926: aload #23
    //   928: iload_2
    //   929: iaload
    //   930: istore #5
    //   932: aload #24
    //   934: iload_2
    //   935: iaload
    //   936: istore #6
    //   938: aload #25
    //   940: iload_2
    //   941: laload
    //   942: lstore #11
    //   944: iload_2
    //   945: iconst_1
    //   946: iadd
    //   947: istore_2
    //   948: iload_2
    //   949: iload #4
    //   951: if_icmpge -> 175
    //   954: aload #25
    //   956: iload_2
    //   957: laload
    //   958: lstore #9
    //   960: iload #5
    //   962: ifne -> 211
    //   965: iload #6
    //   967: iconst_2
    //   968: if_icmpne -> 185
    //   971: goto -> 247
    // Exception table:
    //   from	to	target	type
    //   95	108	329	finally
    //   108	133	307	finally
    //   141	168	307	finally
    //   175	182	307	finally
    //   195	208	307	finally
    //   231	244	307	finally
    //   247	260	307	finally
    //   260	278	307	finally
    //   285	299	307	finally
    //   299	304	329	finally
    //   309	314	317	finally
    //   319	326	329	finally
    //   326	329	329	finally
    //   632	645	685	java/lang/Exception
    //   645	660	668	finally
    //   660	665	685	java/lang/Exception
    //   670	673	673	finally
    //   675	685	685	java/lang/Exception
  }
  
  public static void resetSingleton() {
    // Byte code:
    //   0: ldc X/02P
    //   2: monitorenter
    //   3: aconst_null
    //   4: putstatic X/02P.A06 : LX/02P;
    //   7: ldc X/02P
    //   9: monitorexit
    //   10: return
    //   11: astore_0
    //   12: ldc X/02P
    //   14: monitorexit
    //   15: aload_0
    //   16: athrow
    // Exception table:
    //   from	to	target	type
    //   3	10	11	finally
    //   12	15	11	finally
  }
  
  public final void A02(03y... paramVarArgs) {
    Lock lock = this.A05;
    lock.lock();
    try {
      Map map = this.A04;
      if (!map.isEmpty()) {
        if (!this.A03) {
          02M 02M = 001.A17(map).next();
          int j = paramVarArgs.length;
          int i = 0;
          label133: while (true) {
            if (i < j) {
              03y 03y1 = paramVarArgs[i];
              File file = 03y1.A00;
              Integer integer = 03y1.A01;
              boolean bool = 03y1.A03;
              String str = 03y1.A02;
              if (!(new File(file, "qpl_processed")).exists()) {
                02M.markerStart(27794854);
                0BZ 0BZ = new 0BZ();
                0BZ.A0C = true;
                0C4[] arrayOf0C4 = readOrangeBoxImpl(file, 0BZ);
                int m = arrayOf0C4.length;
                int k;
                for (k = 0;; k++) {
                  char c;
                  int n;
                  int i1;
                  TimeUnit timeUnit;
                  if (k < m) {
                    byte b;
                    String str1;
                    0C4 0C4 = arrayOf0C4[k];
                    n = integer.intValue();
                    if (n != 0) {
                      b = 1;
                    } else {
                      b = -1;
                    } 
                    i1 = 0C4.A05;
                    timeUnit = TimeUnit.NANOSECONDS;
                    02M.CKF(i1, 0, 0L, timeUnit, b);
                    if (bool) {
                      str1 = "foreground";
                    } else {
                      str1 = "background";
                    } 
                    02M.CJq(i1, 0, "qpl_cr_foreground_status", str1);
                    if (str != null)
                      02M.CJq(i1, 0, "exit_type", str); 
                    List<?> list = 0C4.A02;
                    if (list != null && Collections.unmodifiableList(list) != null) {
                      list = 0C4.A03;
                      if (list != null && Collections.unmodifiableList(list) != null) {
                        list = 0C4.A02;
                        if (list != null) {
                          list = Collections.unmodifiableList(list);
                        } else {
                          list = null;
                        } 
                        Iterator<?> iterator2 = list.iterator();
                        list = 0C4.A03;
                        if (list != null) {
                          list = Collections.unmodifiableList(list);
                        } else {
                          list = null;
                        } 
                        Iterator<?> iterator1 = list.iterator();
                        while (iterator2.hasNext() && iterator1.hasNext())
                          02M.CJq(i1, 0, (String)iterator2.next(), (String)iterator1.next()); 
                      } 
                    } 
                    list = 0C4.A00;
                    if (list != null && Collections.unmodifiableList(list) != null) {
                      list = 0C4.A01;
                      if (list != null && Collections.unmodifiableList(list) != null) {
                        list = 0C4.A00;
                        if (list != null) {
                          list = Collections.unmodifiableList(list);
                        } else {
                          list = null;
                        } 
                        Iterator<?> iterator2 = list.iterator();
                        list = 0C4.A01;
                        if (list != null) {
                          list = Collections.unmodifiableList(list);
                        } else {
                          list = null;
                        } 
                        Iterator<?> iterator1 = list.iterator();
                        while (iterator2.hasNext() && iterator1.hasNext())
                          02M.CJp(i1, 0, (String)iterator2.next(), ((Integer)iterator1.next()).intValue()); 
                      } 
                    } 
                  } else {
                    k = 0BZ.A02 + 0BZ.A03;
                    02M.markerAnnotate(27794854, "storage_version", 0BZ.A08);
                    02M.markerAnnotate(27794854, "records_count", 0BZ.A05);
                    02M.markerAnnotate(27794854, "markers_count", 0BZ.A04);
                    02M.markerAnnotate(27794854, "active_markers_count", 0BZ.A03);
                    02M.markerAnnotate(27794854, "unique_markers_count", 0BZ.A06);
                    int i2 = 0BZ.A02;
                    if (i2 >= 0) {
                      double d;
                      02M.markerAnnotate(27794854, "lost_active_markers_count", i2);
                      if (k == 0) {
                        d = 0.0D;
                      } else {
                        d = (0BZ.A02 / k);
                      } 
                      02M.markerAnnotate(27794854, "events_loss_ratio", d);
                    } 
                    k = 0BZ.A09;
                    if (k > 0)
                      02M.markerAnnotate(27794854, "time_window_sec", k); 
                    String str1 = 0BZ.A0A;
                    if (str1 != null)
                      02M.markerAnnotate(27794854, "error", str1); 
                    k = 0BZ.A07;
                    if (k > 0) {
                      double d = k;
                      02M.markerAnnotate(27794854, "annotations_loss_ratio", (d - 0BZ.A01) / d);
                    } 
                    break;
                  } 
                  if (n != 0) {
                    c = '˒';
                  } else {
                    c = 'ߑ';
                  } 
                  02M.CJt(i1, 0, c, 0L, timeUnit);
                } 
                for (k = 0;; k++) {
                  int[] arrayOfInt = 0BZ.A0F;
                  if (k < 3) {
                    int n = arrayOfInt[k];
                    m = 0BZ.A0G[k];
                    if (n != 0) {
                      02M.markerStart(27802751);
                      02M.markerAnnotate(27802751, "storage_version", 0BZ.A08);
                      02M.markerAnnotate(27802751, "markerId", n);
                      02M.markerAnnotate(27802751, "count", m);
                      02M.markerEnd(27802751, (short)2);
                    } 
                  } else {
                    for (0N3 0N3 : 0BZ.A0B) {
                      k = 0N3.A01;
                      if (k != 0) {
                        02M.markerStart(27799771);
                        02M.markerAnnotate(27799771, "markerId", k);
                        02M.markerAnnotate(27799771, "storage_version", 0BZ.A00);
                        02M.markerAnnotate(27799771, "markers_count", 0N3.A03);
                        02M.markerAnnotate(27799771, "active_markers_count", 0N3.A02);
                        02M.markerAnnotate(27799771, "lost_active_markers_count", 0N3.A00);
                        02M.markerAnnotate(27799771, "max_concurrent_markers_count", 0N3.A04);
                        02M.markerEnd(27799771, (short)2);
                      } 
                    } 
                    02M.markerEnd(27794854, (short)2);
                    try {
                      (new File(file, "qpl_processed")).createNewFile();
                      i++;
                    } catch (IOException iOException) {
                      i++;
                    } 
                    continue label133;
                  } 
                } 
                break;
              } 
              continue;
            } 
            this.A03 = true;
            return;
          } 
        } 
      } else {
        this.A02 = paramVarArgs;
      } 
      return;
    } finally {
      lock.unlock();
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\02P.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */