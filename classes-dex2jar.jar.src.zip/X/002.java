package X;

import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageItemInfo;
import android.database.Cursor;
import android.net.NetworkInfo;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import com.facebook.common.dextricks.DexStore;
import com.facebook.profilo.ipc.TraceContext;
import com.facebook.profilo.logger.BufferLogger;
import com.facebook.profilo.mmapbuf.core.Buffer;
import com.facebook.superpack.SuperpackArchive;
import dalvik.system.DexFile;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.util.AbstractCollection;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;

public abstract class 002 {
  public static float A00(Context paramContext, int paramInt) {
    return Math.round(paramContext.getResources().getDimension(paramInt));
  }
  
  public static int A01(int paramInt) {
    char c = 'ӕ';
    if (paramInt != 0)
      c = 'ӏ'; 
    return c;
  }
  
  public static int A02(long paramLong) {
    return (int)(paramLong ^ paramLong >>> 32L) * 31;
  }
  
  public static int A03(long paramLong, int paramInt) {
    return (paramInt + (int)(paramLong ^ paramLong >>> 32L)) * 31;
  }
  
  public static int A04(Object paramObject) {
    return (paramObject == null) ? 0 : paramObject.hashCode();
  }
  
  public static int A05(Object paramObject) {
    return (paramObject != null) ? paramObject.hashCode() : 0;
  }
  
  public static int A06(String paramString) {
    String str = SuperpackArchive.TAG;
    return paramString.equals("spo") ? Runtime.getRuntime().availableProcessors() : 1;
  }
  
  public static int A07(ThreadLocal<Number> paramThreadLocal) {
    Number number = paramThreadLocal.get();
    return (number == null) ? -1 : number.intValue();
  }
  
  public static long A08() {
    return System.currentTimeMillis() / 1000L;
  }
  
  public static long A09(Object paramObject, Map paramMap) {
    paramObject = paramMap.get(paramObject);
    return (paramObject == null) ? 0L : paramObject.longValue();
  }
  
  public static ComponentName A0A(PackageItemInfo paramPackageItemInfo) {
    return new ComponentName(paramPackageItemInfo.packageName, paramPackageItemInfo.name);
  }
  
  public static SharedPreferences A0B(Context paramContext) {
    return paramContext.getSharedPreferences("acra_criticaldata_store", 0);
  }
  
  public static Looper A0C(String paramString) {
    HandlerThread handlerThread = new HandlerThread(paramString);
    14I.A00(handlerThread);
    handlerThread.start();
    return handlerThread.getLooper();
  }
  
  public static SuperpackArchive A0D(InputStream paramInputStream, String paramString) {
    return new SuperpackArchive(SuperpackArchive.readNative(paramInputStream, paramString, 0L), null);
  }
  
  public static BufferedReader A0E(File paramFile) {
    return new BufferedReader(new FileReader(paramFile));
  }
  
  public static BufferedReader A0F(InputStream paramInputStream) {
    return new BufferedReader(new InputStreamReader(paramInputStream));
  }
  
  public static File A0G(Context paramContext) {
    return new File((paramContext.getApplicationInfo()).sourceDir);
  }
  
  public static File A0H(String paramString, File paramFile) {
    return new File(paramFile, paramString.replace("+", "_p_").replace("/", "_s_"));
  }
  
  public static Class A0I(Object<?> paramObject, StringBuilder paramStringBuilder) {
    paramObject = (Object<?>)paramObject.getClass();
    paramStringBuilder.append(paramObject.getSimpleName());
    paramStringBuilder.append("{");
    return (Class)paramObject;
  }
  
  public static IllegalArgumentException A0J(Object paramObject, String paramString, StringBuilder paramStringBuilder) {
    paramStringBuilder.append(paramString);
    paramStringBuilder.append(paramObject);
    return new IllegalArgumentException(paramStringBuilder.toString());
  }
  
  public static IllegalArgumentException A0K(String paramString, StringBuilder paramStringBuilder) {
    paramStringBuilder.append(paramString);
    return new IllegalArgumentException(paramStringBuilder.toString());
  }
  
  public static IllegalStateException A0L(Object paramObject, String paramString, StringBuilder paramStringBuilder) {
    paramStringBuilder.append(paramString);
    paramStringBuilder.append(paramObject);
    return new IllegalStateException(paramStringBuilder.toString());
  }
  
  public static IllegalStateException A0M(Object paramObject, StringBuilder paramStringBuilder) {
    paramStringBuilder.append(paramObject);
    return new IllegalStateException(paramStringBuilder.toString());
  }
  
  public static IllegalStateException A0N(String paramString, StringBuilder paramStringBuilder) {
    paramStringBuilder.append(paramString);
    return new IllegalStateException(paramStringBuilder.toString());
  }
  
  public static Object A0O(Parcel paramParcel, Parcelable.Creator paramCreator) {
    return (paramParcel.readInt() != 0) ? paramCreator.createFromParcel(paramParcel) : null;
  }
  
  public static Object A0P(Class paramClass) {
    return paramClass.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
  }
  
  public static Object A0Q(Object paramObject, int paramInt) {
    return Array.newInstance(paramObject.getClass().getComponentType(), paramInt);
  }
  
  public static Object A0R(Object paramObject, Class paramClass, String paramString) {
    Field field = paramClass.getDeclaredField(paramString);
    field.setAccessible(true);
    return field.get(paramObject);
  }
  
  public static String A0S(File paramFile) {
    String str = paramFile.getName();
    return str.substring(str.indexOf('-') + 1);
  }
  
  public static String A0T(Object paramObject, String paramString, StringBuilder paramStringBuilder) {
    paramStringBuilder.append(paramString);
    paramStringBuilder.append(paramObject);
    return paramStringBuilder.toString();
  }
  
  public static String A0U(Object paramObject, StringBuilder paramStringBuilder) {
    paramStringBuilder.append(paramObject);
    paramStringBuilder.append(')');
    return paramStringBuilder.toString();
  }
  
  public static String A0V(StringBuilder paramStringBuilder) {
    paramStringBuilder.append(')');
    return paramStringBuilder.toString();
  }
  
  public static String A0W(StringBuilder paramStringBuilder) {
    paramStringBuilder.append(']');
    return paramStringBuilder.toString();
  }
  
  public static String A0X(StringBuilder paramStringBuilder) {
    paramStringBuilder.append('}');
    return paramStringBuilder.toString();
  }
  
  public static String A0Y(StringBuilder paramStringBuilder) {
    paramStringBuilder.append("}");
    return paramStringBuilder.toString();
  }
  
  public static StringBuilder A0Z(Object paramObject) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(paramObject);
    return stringBuilder;
  }
  
  public static Throwable A0a(Object paramObject) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: \r\n\tat com.googlecode.dex2jar.ir.ts.NewTransformer.transform(NewTransformer.java:134)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:148)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public static UnsupportedOperationException A0b() {
    return new UnsupportedOperationException("Operation is not supported for read-only collection");
  }
  
  public static Field A0c(0nd param0nd, Class paramClass1, Class paramClass2, String paramString) {
    Field field = 0nf.A07(param0nd, paramClass1, paramClass2, paramString);
    if (field != null)
      field.setAccessible(true); 
    return field;
  }
  
  public static Field A0d(Class paramClass, String paramString) {
    Field field = paramClass.getDeclaredField(paramString);
    field.setAccessible(true);
    return field;
  }
  
  public static ArrayList A0e(Cursor paramCursor) {
    return new ArrayList(paramCursor.getCount());
  }
  
  public static ArrayList A0f(List paramList) {
    return new ArrayList(paramList.size());
  }
  
  public static Map A0g() {
    return Collections.synchronizedMap(new HashMap<Object, Object>());
  }
  
  public static Set A0h(Object[] paramArrayOfObject) {
    return Collections.unmodifiableSet(new HashSet(Arrays.asList(paramArrayOfObject)));
  }
  
  public static void A0i(Context paramContext, String paramString, StringBuilder paramStringBuilder) {
    paramStringBuilder.append(paramString);
    String str = paramContext.getPackageName();
    if (!TextUtils.isEmpty(str)) {
      paramStringBuilder.append('.');
      paramStringBuilder.append(str);
    } 
  }
  
  public static void A0j(NetworkInfo paramNetworkInfo, 0y4 param0y4, AbstractMap<String, String> paramAbstractMap, long paramLong) {
    paramAbstractMap.put("network_session_id", Long.toString(paramLong));
    0y4.A00(paramNetworkInfo, param0y4, paramAbstractMap);
  }
  
  public static void A0k(IBinder paramIBinder, Parcel paramParcel1, Parcel paramParcel2, int paramInt) {
    paramIBinder.transact(paramInt, paramParcel1, paramParcel2, 0);
    paramParcel2.readException();
  }
  
  public static void A0l(08q param08q, 08s param08s, Object<?> paramObject) {
    Class<?> clazz = paramObject.getClass();
    paramObject = (Object<?>)param08s.getClass();
    08p 08p = 08p.A01;
    String str = clazz.getName();
    Set set = (Set)param08q.A00.get(str);
    if (set == null || ((16F.A0S(paramObject.getSuperclass(), 08s.class) || !0Xa.A0m(set, paramObject.getSuperclass())) && (set.contains(paramObject) ^ true) != 0)) {
      08p.A03(param08q, param08s);
      return;
    } 
  }
  
  public static void A0m(0Jl param0Jl, String paramString) {
    param0Jl.A07(new RuntimeException(paramString));
  }
  
  public static void A0n(DexStore.Config.Builder paramBuilder) {
    paramBuilder.mMode = 0;
    paramBuilder.mSync = 0;
    paramBuilder.mDalvikVerify = 0;
    paramBuilder.mDalvikOptimize = 0;
    paramBuilder.mDalvikRegisterMaps = 0;
    paramBuilder.mArtFilter = 0;
    paramBuilder.mArtHugeMethodMax = -1;
    paramBuilder.mArtLargeMethodMax = -1;
    paramBuilder.mArtSmallMethodMax = -1;
    paramBuilder.mArtTinyMethodMax = -1;
    paramBuilder.mArtTruncatedDexSize = -1;
    paramBuilder.mEnableArtVerifyNone = false;
    paramBuilder.mEnableDex2OatQuickening = false;
    paramBuilder.mEnableQuickening = false;
    paramBuilder.mEnableMixedMode = false;
    paramBuilder.mEnableMixedModeClassPath = false;
    paramBuilder.mEnableMixedModePgo = false;
    paramBuilder.mPgoCompilerFilter = 0;
    paramBuilder.mDoPeriodicPgoCompilation = false;
    paramBuilder.mMinTimeBetweenPgoCompilationMs = 0L;
    paramBuilder.mMultidexCompilationStrategy = 0;
    paramBuilder.mLegacyFlags = 0;
    paramBuilder.mHenosisFlags = 0;
  }
  
  public static void A0o(0qe param0qe, 0qi param0qi, 0si param0si) {
    0r7 0r7 = 0r7.A01;
    param0qi.A0D(0r7, param0si);
    param0qi.A07(param0qe, 0r7, param0si);
    param0qi.A0C(0r7, param0si);
  }
  
  public static void A0p(TraceContext paramTraceContext, Buffer paramBuffer, int paramInt) {
    BufferLogger.writeStandardEntry(paramBuffer, 6, paramInt, 0L, 0, 0, 0, paramTraceContext.A06);
  }
  
  public static void A0q(Buffer paramBuffer, String paramString1, String paramString2, int paramInt) {
    BufferLogger.writeBytesEntry(paramBuffer, 0, 57, BufferLogger.writeBytesEntry(paramBuffer, 0, 56, BufferLogger.writeStandardEntry(paramBuffer, 6, 52, 0L, 0, paramInt, 0, 0L), paramString1), paramString2);
  }
  
  public static void A0r(141 param141, int paramInt, long paramLong) {
    if (paramInt != 0) {
      param141.A02("<T");
      param141.A02(Long.toString(paramLong));
      param141.A02(">");
    } 
  }
  
  public static void A0s(Object paramObject, String paramString, StringBuilder paramStringBuilder) {
    paramStringBuilder.append(paramString);
    paramStringBuilder.append(paramObject.getClass());
  }
  
  public static void A0t(String paramString1, String paramString2, String paramString3, StringBuilder paramStringBuilder) {
    paramStringBuilder.append(paramString1);
    paramStringBuilder.append(paramString2);
    paramStringBuilder.append(paramString3);
  }
  
  public static void A0u(String paramString1, String paramString2, StringBuilder paramStringBuilder, int paramInt) {
    paramStringBuilder.append(paramString1);
    paramStringBuilder.append(paramInt);
    paramStringBuilder.append(paramString2);
  }
  
  public static void A0v(StringBuilder paramStringBuilder, char paramChar, int paramInt1, int paramInt2) {
    paramStringBuilder.append(paramInt1);
    paramStringBuilder.append(paramChar);
    paramStringBuilder.append(paramInt2);
    paramStringBuilder.append(paramChar);
  }
  
  public static void A0w(StringBuilder paramStringBuilder, Object paramObject) {
    paramStringBuilder.append(Integer.toHexString(System.identityHashCode(paramObject)));
  }
  
  public static void A0x(URLConnection paramURLConnection, Iterator<Map.Entry> paramIterator) {
    Map.Entry entry = paramIterator.next();
    paramURLConnection.setRequestProperty(entry.getKey().toString(), entry.getValue().toString());
  }
  
  public static void A0y(AbstractMap<Class<byte>, String> paramAbstractMap) {
    paramAbstractMap.put(byte.class, "B");
    paramAbstractMap.put(char.class, "C");
    paramAbstractMap.put(short.class, "S");
    paramAbstractMap.put(int.class, "I");
    paramAbstractMap.put(long.class, "J");
    paramAbstractMap.put(float.class, "F");
    paramAbstractMap.put(double.class, "D");
  }
  
  public static void A0z(Map paramMap, Object paramObject) {
    0V2 0V2 = (0V2)paramMap.remove(paramObject);
    if (0V2 != null) {
      0V2.A01.A06(0V2.A00);
      0V2.A00 = null;
    } 
  }
  
  public static void A10(0Ij param0Ij) {
    if (param0Ij.A07())
      param0Ij.A02(); 
  }
  
  public static boolean A11(int paramInt) {
    boolean bool = false;
    if (paramInt != 0)
      bool = true; 
    return bool;
  }
  
  public static boolean A12(int paramInt) {
    boolean bool = false;
    if (paramInt == 0)
      bool = true; 
    return bool;
  }
  
  public static boolean A13(int paramInt) {
    boolean bool = false;
    if (paramInt > 0)
      bool = true; 
    return bool;
  }
  
  public static boolean A14(int paramInt1, int paramInt2) {
    boolean bool = false;
    if (paramInt1 == paramInt2)
      bool = true; 
    return bool;
  }
  
  public static boolean A15(int paramInt1, int paramInt2) {
    boolean bool = false;
    if (paramInt1 < paramInt2)
      bool = true; 
    return bool;
  }
  
  public static boolean A16(Parcel paramParcel) {
    int i = paramParcel.readInt();
    boolean bool = true;
    if (i != 1)
      bool = false; 
    return bool;
  }
  
  public static boolean A17(File paramFile, String paramString) {
    return (new File(paramFile, paramString)).exists();
  }
  
  public static boolean A18(Object paramObject) {
    boolean bool = false;
    if (paramObject != null)
      bool = true; 
    return bool;
  }
  
  public static boolean A19(Object paramObject) {
    boolean bool = false;
    if (paramObject == null)
      bool = true; 
    return bool;
  }
  
  public static boolean A1A(Object paramObject1, Object paramObject2) {
    System.arraycopy(paramObject1, 0, paramObject2, 0, 27);
    return false;
  }
  
  public static boolean A1B(String paramString) {
    return (new File(paramString)).exists();
  }
  
  public static boolean A1C(boolean paramBoolean) {
    boolean bool = false;
    if (paramBoolean)
      bool = true; 
    return bool;
  }
  
  public static byte[] A1D(String paramString, HttpsURLConnection paramHttpsURLConnection, SSLContext paramSSLContext) {
    paramHttpsURLConnection.setSSLSocketFactory(paramSSLContext.getSocketFactory());
    paramHttpsURLConnection.setConnectTimeout(30000);
    paramHttpsURLConnection.setReadTimeout(30000);
    paramHttpsURLConnection.setRequestMethod("POST");
    paramHttpsURLConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
    paramHttpsURLConnection.setDoOutput(true);
    byte[] arrayOfByte = paramString.getBytes(StandardCharsets.UTF_8);
    paramHttpsURLConnection.setFixedLengthStreamingMode(arrayOfByte.length);
    return arrayOfByte;
  }
  
  public static DexFile[] A1E(AbstractCollection paramAbstractCollection) {
    return (DexFile[])paramAbstractCollection.toArray((Object[])new DexFile[paramAbstractCollection.size()]);
  }
  
  public static String[] A1F(AbstractCollection paramAbstractCollection) {
    return (String[])paramAbstractCollection.toArray((Object[])new String[paramAbstractCollection.size()]);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\002.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */