package X;

import java.io.Serializable;

public final class 067 implements Serializable {
  public final Object value;
  
  public static final Throwable A00(Object paramObject) {
    return (paramObject instanceof 068) ? ((068)paramObject).exception : null;
  }
  
  public final boolean equals(Object paramObject) {
    Object object = this.value;
    boolean bool = paramObject instanceof 067;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (bool) {
      bool1 = bool2;
      if (16F.A0S(object, ((067)paramObject).value))
        bool1 = true; 
    } 
    return bool1;
  }
  
  public final int hashCode() {
    return 002.A04(this.value);
  }
  
  public final String toString() {
    Object object = this.value;
    if (object instanceof 068)
      return object.toString(); 
    StringBuilder stringBuilder = 001.A0s();
    stringBuilder.append("Success(");
    return 002.A0U(object, stringBuilder);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\067.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */