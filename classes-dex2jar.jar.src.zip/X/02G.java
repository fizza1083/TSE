package X;

public abstract class 02G extends 0BH implements 02H {
  public final boolean syntheticJavaProperty;
  
  public 02G(Class paramClass, Object paramObject, String paramString1, String paramString2, int paramInt) {
    super(paramObject, paramClass, paramString1, paramString2, bool1);
    bool1 = bool2;
    if ((paramInt & 0x2) == 2)
      bool1 = true; 
    this.syntheticJavaProperty = bool1;
  }
  
  public final 02H A00() {
    if (!this.syntheticJavaProperty)
      return (02H)super.getReflected(); 
    throw 001.A0x("Kotlin reflection is not yet supported for synthetic Java properties");
  }
  
  public final 0BI compute() {
    if (!this.syntheticJavaProperty) {
      0BI 0BI2 = this.reflected;
      0BI 0BI1 = 0BI2;
      if (0BI2 == null) {
        0BI1 = this;
        this.reflected = this;
      } 
      return 0BI1;
    } 
    return this;
  }
  
  public final boolean equals(Object paramObject) {
    if (paramObject != this) {
      if (paramObject instanceof 02G) {
        paramObject = paramObject;
        return !(!getOwner().equals(paramObject.getOwner()) || !this.name.equals(((0BH)paramObject).name) || !this.signature.equals(((0BH)paramObject).signature) || !16F.A0S(this.receiver, ((0BH)paramObject).receiver));
      } 
    } else {
      return true;
    } 
    return (paramObject instanceof 02H) ? paramObject.equals(super.compute()) : false;
  }
  
  public final int hashCode() {
    int i = getOwner().hashCode();
    return 001.A06(this.name, i * 31) + this.signature.hashCode();
  }
  
  public final String toString() {
    0BI 0BI = super.compute();
    return (0BI != this) ? 0BI.toString() : 0XK.A0p("property ", this.name, " (Kotlin reflection is not available)");
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\02G.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */