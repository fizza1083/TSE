package X;

public abstract class 07V {
  public static final 07W A00 = new 07W();
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07V.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */