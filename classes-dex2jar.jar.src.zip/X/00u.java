package X;

import android.app.ActivityThread;
import android.app.Application;
import android.content.Context;
import android.os.Build;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

public abstract class 00u {
  public static final List A00 = new CopyOnWriteArrayList();
  
  public static final Map A01;
  
  public static final Set A02 = 001.A12();
  
  static {
    A01 = 001.A11();
  }
  
  public static void A00(Context paramContext, String paramString) {
    Map<String, 00v> map = A01;
    if (map.isEmpty()) {
      00v 00v = new 00v();
      map.put(00v.A02, 00v);
      00x 00x = new 00x();
      map.put(00x.A02, 00x);
      if (Build.VERSION.SDK_INT >= 31) {
        00y 00y = new 00y();
        map.put(00y.A02, 00y);
      } 
      00z 00z = new 00z();
      map.put(00z.A02, 00z);
      010 010 = new 010();
      map.put(010.A02, 010);
      011 011 = new 011();
      map.put(011.A02, 011);
      A03("connectivity", "mService", "android.net.IConnectivityManager", null);
      A03("alarm", "mService", "android.app.IAlarmManager", null);
      A03("power", "mService", "android.os.IPowerManager", null);
      A03("location", "mService", "android.location.ILocationManager", null);
      A03("wifi", "mService", "android.net.wifi.IWifiManager", null);
      A03("accessibility", "mService", "android.view.accessibility.IAccessibilityManager", null);
      A03("storage", "mStorageManager", "android.os.storage.IStorageManager", null);
      A03("storagestats", "mService", "android.app.usage.IStorageStatsManager", null);
      A03("account", "mService", "android.accounts.IAccountManager", null);
      A03("clipboard", "mService", "android.content.IClipboard", null);
      A03("notification", "sService", "android.app.INotificationManager", "getService");
      A03("audio", "sService", "android.media.IAudioService", "getService");
      A03("appops", "mService", "com.android.internal.app.IAppOpsService", null);
      A03("batterymanager", "mBatteryStats", "com.android.internal.app.IBatteryStats", null);
      A03("jobscheduler", "mBinder", "android.app.job.IJobScheduler", null);
      A03("user", "mService", "android.os.IUserManager", null);
    } 
    try {
      if (map.containsKey(paramString)) {
        00w 00w = map.get(paramString);
        String str = 00w.A02;
        if (!A02.contains(str))
          00w.A01(paramContext, 013.A00()); 
      } 
      return;
    } catch (Exception|Error exception) {
      return;
    } 
  }
  
  public static void A01(00r param00r) {
    List<00r> list = A00;
    if (!list.contains(param00r))
      list.add(param00r); 
  }
  
  public static void A02(String paramString) {
    Application application = ActivityThread.currentActivityThread().getApplication();
    if (application != null)
      A00((Context)application, paramString); 
  }
  
  public static void A03(String paramString1, String paramString2, String paramString3, String paramString4) {
    00w 00w = new 00w(paramString1, paramString2, paramString3, paramString4);
    A01.put(00w.A02, 00w);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */