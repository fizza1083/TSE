package X;

import android.content.BroadcastReceiver;
import android.content.IntentFilter;

public final class 03M {
  public boolean A00;
  
  public boolean A01;
  
  public final BroadcastReceiver A02;
  
  public final IntentFilter A03;
  
  public 03M(BroadcastReceiver paramBroadcastReceiver, IntentFilter paramIntentFilter) {
    this.A03 = paramIntentFilter;
    this.A02 = paramBroadcastReceiver;
  }
  
  public final String toString() {
    StringBuilder stringBuilder = 001.A0t(128);
    stringBuilder.append("Receiver{");
    stringBuilder.append(this.A02);
    stringBuilder.append(" filter=");
    stringBuilder.append(this.A03);
    if (this.A01)
      stringBuilder.append(" DEAD"); 
    return 002.A0Y(stringBuilder);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\03M.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */