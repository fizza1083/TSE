package X;

public interface 04K extends 04H {
  public static final 04T A00 = 04T.A00;
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\04K.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */