package X;

import java.io.Closeable;
import java.util.concurrent.Executor;

public abstract class 04E extends 04F implements Closeable {
  public static final 04X A00 = new 04X();
  
  public abstract Executor A06();
  
  public abstract void close();
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\04E.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */