package X;

import java.util.LinkedHashMap;

public final class 06T {
  public final LinkedHashMap A00;
  
  public 06T() {
    this(16);
  }
  
  public 06T(int paramInt) {
    this.A00 = new LinkedHashMap<Object, Object>(paramInt, 0.75F, true);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\06T.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */