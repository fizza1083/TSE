package X;

import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;

public abstract class 08y {
  public static final 0GT A00(0BK param0BK) {
    return new 0GT(param0BK);
  }
  
  public static final void A01(Object paramObject1, Object paramObject2) {
    ((OnBackInvokedDispatcher)paramObject1).registerOnBackInvokedCallback(0, (OnBackInvokedCallback)paramObject2);
  }
  
  public static final void A02(Object paramObject1, Object paramObject2) {
    ((OnBackInvokedDispatcher)paramObject1).unregisterOnBackInvokedCallback((OnBackInvokedCallback)paramObject2);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */