package X;

import android.content.Context;
import android.content.Intent;
import android.os.BaseBundle;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import com.facebook.common.dextricks.DexStore;
import com.facebook.common.dextricks.Mlog;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.AbstractCollection;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import org.json.JSONObject;

public abstract class 001 {
  public static byte A00(RandomAccessFile paramRandomAccessFile, long paramLong) {
    paramRandomAccessFile.seek(paramLong);
    return paramRandomAccessFile.readByte();
  }
  
  public static byte A01(ByteBuffer paramByteBuffer, int paramInt) {
    paramByteBuffer.position(paramInt);
    return paramByteBuffer.get();
  }
  
  public static int A02(long paramLong, int paramInt) {
    return paramInt + (int)(paramLong ^ paramLong >>> 32L);
  }
  
  public static int A03(Object paramObject) {
    return ((Number)paramObject).intValue();
  }
  
  public static int A04(Object paramObject, int paramInt) {
    return (paramInt + paramObject.hashCode()) * 31;
  }
  
  public static int A05(String paramString) {
    return paramString.lastIndexOf('.');
  }
  
  public static int A06(String paramString, int paramInt) {
    return (paramInt + paramString.hashCode()) * 31;
  }
  
  public static int A07(List paramList) {
    return paramList.size() - 1;
  }
  
  public static long A08(Object paramObject) {
    return ((Number)paramObject).longValue();
  }
  
  public static Intent A09(String paramString) {
    return new Intent(paramString);
  }
  
  public static Bundle A0A() {
    return new Bundle();
  }
  
  public static Handler A0B() {
    return new Handler(Looper.getMainLooper());
  }
  
  public static 17U A0C(String paramString, int paramInt1, int paramInt2, boolean paramBoolean) {
    return new 17U(paramString, paramInt1, paramInt2, paramBoolean, paramBoolean, paramBoolean);
  }
  
  public static File A0D(DexStore paramDexStore, String paramString) {
    return new File(paramDexStore.root, paramString);
  }
  
  public static File A0E(File paramFile, String paramString) {
    return new File(paramFile, paramString);
  }
  
  public static File A0F(String paramString) {
    return new File(paramString);
  }
  
  public static FileInputStream A0G(File paramFile) {
    return new FileInputStream(paramFile);
  }
  
  public static FileOutputStream A0H(File paramFile) {
    return new FileOutputStream(paramFile);
  }
  
  public static IOException A0I(String paramString) {
    return new IOException(paramString);
  }
  
  public static RandomAccessFile A0J(File paramFile) {
    return new RandomAccessFile(paramFile, "r");
  }
  
  public static RandomAccessFile A0K(File paramFile) {
    return new RandomAccessFile(paramFile, "rw");
  }
  
  public static Boolean A0L() {
    return Boolean.valueOf(true);
  }
  
  public static ClassLoader A0M(Object paramObject) {
    return paramObject.getClass().getClassLoader();
  }
  
  public static IllegalArgumentException A0N() {
    return new IllegalArgumentException("Failed requirement.");
  }
  
  public static IllegalArgumentException A0O(String paramString) {
    return new IllegalArgumentException(paramString);
  }
  
  public static IllegalStateException A0P() {
    return new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
  }
  
  public static IllegalStateException A0Q() {
    return new IllegalStateException();
  }
  
  public static IllegalStateException A0R() {
    return new IllegalStateException("Required value was null.");
  }
  
  public static IllegalStateException A0S(String paramString) {
    return new IllegalStateException(paramString);
  }
  
  public static Long A0T() {
    return Long.valueOf(System.currentTimeMillis());
  }
  
  public static Long A0U(File paramFile) {
    return Long.valueOf(paramFile.length());
  }
  
  public static NullPointerException A0V(String paramString) {
    return new NullPointerException(paramString);
  }
  
  public static Object A0W() {
    return new Object();
  }
  
  public static Object A0X(Object paramObject, Method paramMethod) {
    return paramMethod.invoke(paramObject, new Object[0]);
  }
  
  public static Object A0Y(Map paramMap, int paramInt) {
    return paramMap.get(Integer.valueOf(paramInt));
  }
  
  public static RuntimeException A0Z(String paramString) {
    return new RuntimeException(paramString);
  }
  
  public static RuntimeException A0a(String paramString, Throwable paramThrowable) {
    return new RuntimeException(paramString, paramThrowable);
  }
  
  public static RuntimeException A0b(Throwable paramThrowable) {
    return new RuntimeException(paramThrowable);
  }
  
  public static SecurityException A0c(String paramString) {
    return new SecurityException(paramString);
  }
  
  public static String A0d() {
    return UUID.randomUUID().toString();
  }
  
  public static String A0e(int paramInt, String paramString) {
    return paramString.substring(paramInt + 1);
  }
  
  public static String A0f(Context paramContext) {
    return (paramContext.getApplicationInfo()).dataDir;
  }
  
  public static String A0g(Object paramObject) {
    return paramObject.getClass().getSimpleName();
  }
  
  public static String A0h(Object paramObject) {
    return paramObject.getClass().getName();
  }
  
  public static String A0i(Object paramObject, StringBuilder paramStringBuilder) {
    paramStringBuilder.append(paramObject);
    return paramStringBuilder.toString();
  }
  
  public static String A0j(Object paramObject, Map paramMap) {
    return (String)paramMap.get(paramObject);
  }
  
  public static String A0k(String paramString, int paramInt) {
    return paramString.substring(0, paramInt);
  }
  
  public static String A0l(String paramString, StringBuilder paramStringBuilder) {
    paramStringBuilder.append(paramString);
    return paramStringBuilder.toString();
  }
  
  public static String A0m(String paramString, Object[] paramArrayOfObject) {
    return String.format(null, paramString, paramArrayOfObject);
  }
  
  public static String A0n(StringBuilder paramStringBuilder, char paramChar) {
    paramStringBuilder.append(paramChar);
    return paramStringBuilder.toString();
  }
  
  public static String A0o(StringBuilder paramStringBuilder, int paramInt) {
    paramStringBuilder.append(paramInt);
    return paramStringBuilder.toString();
  }
  
  public static String A0p(Iterator<String> paramIterator) {
    return paramIterator.next();
  }
  
  public static String A0q(Map.Entry paramEntry) {
    return (String)paramEntry.getValue();
  }
  
  public static String A0r(Map.Entry paramEntry) {
    return (String)paramEntry.getKey();
  }
  
  public static StringBuilder A0s() {
    return new StringBuilder();
  }
  
  public static StringBuilder A0t(int paramInt) {
    return new StringBuilder(paramInt);
  }
  
  public static StringBuilder A0u(String paramString) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    return stringBuilder;
  }
  
  public static StringBuilder A0v(String paramString) {
    return new StringBuilder(paramString);
  }
  
  public static UnsupportedOperationException A0w() {
    return new UnsupportedOperationException();
  }
  
  public static UnsupportedOperationException A0x(String paramString) {
    return new UnsupportedOperationException(paramString);
  }
  
  public static ArrayList A0y() {
    return new ArrayList();
  }
  
  public static ArrayList A0z(int paramInt) {
    return new ArrayList(paramInt);
  }
  
  public static ArrayList A10(Collection<?> paramCollection) {
    return new ArrayList(paramCollection);
  }
  
  public static HashMap A11() {
    return new HashMap<Object, Object>();
  }
  
  public static HashSet A12() {
    return new HashSet();
  }
  
  public static Iterator A13(BaseBundle paramBaseBundle) {
    return paramBaseBundle.keySet().iterator();
  }
  
  public static Iterator A14(AbstractMap paramAbstractMap) {
    return paramAbstractMap.entrySet().iterator();
  }
  
  public static Iterator A15(AbstractMap paramAbstractMap) {
    return paramAbstractMap.values().iterator();
  }
  
  public static Iterator A16(Map paramMap) {
    return paramMap.entrySet().iterator();
  }
  
  public static Iterator A17(Map paramMap) {
    return paramMap.values().iterator();
  }
  
  public static LinkedHashMap A18() {
    return new LinkedHashMap<Object, Object>();
  }
  
  public static List A19(String paramString) {
    return Arrays.asList(new String[] { paramString });
  }
  
  public static Map.Entry A1A(Iterator<Map.Entry> paramIterator) {
    return paramIterator.next();
  }
  
  public static NoSuchElementException A1B() {
    return new NoSuchElementException();
  }
  
  public static AtomicBoolean A1C() {
    return new AtomicBoolean(false);
  }
  
  public static AtomicInteger A1D() {
    return new AtomicInteger(0);
  }
  
  public static AtomicInteger A1E() {
    return new AtomicInteger(1);
  }
  
  public static JSONObject A1F() {
    return new JSONObject();
  }
  
  public static void A1G() {
    Thread.currentThread().interrupt();
  }
  
  public static void A1H(0bg param0bg, Integer paramInteger) {
    0bg.A02(param0bg, paramInteger, new byte[0]);
  }
  
  public static void A1I(PrintWriter paramPrintWriter, int paramInt) {
    paramPrintWriter.print(Integer.toHexString(paramInt));
  }
  
  public static void A1J(RandomAccessFile paramRandomAccessFile) {
    paramRandomAccessFile.setLength(paramRandomAccessFile.getFilePointer());
  }
  
  public static void A1K(Object paramObject) {
    142.A00(paramObject.toString());
  }
  
  public static void A1L(Object paramObject, long paramLong, Map<Object, Long> paramMap) {
    paramMap.put(paramObject, Long.valueOf(paramLong));
  }
  
  public static void A1M(Object paramObject, AbstractMap<Object, Integer> paramAbstractMap, int paramInt) {
    paramAbstractMap.put(paramObject, Integer.valueOf(paramInt));
  }
  
  public static void A1N(String paramString) {
    Mlog.w(paramString, new Object[0]);
  }
  
  public static void A1O(String paramString1, String paramString2, Object[] paramArrayOfObject) {
    Log.w(paramString2, String.format(paramString1, paramArrayOfObject));
  }
  
  public static void A1P(StringBuilder paramStringBuilder) {
    paramStringBuilder.append(", ");
  }
  
  public static void A1Q(StringBuilder paramStringBuilder, Object paramObject) {
    paramStringBuilder.append(paramObject.toString());
  }
  
  public static void A1R(AbstractCollection<Integer> paramAbstractCollection, int paramInt) {
    paramAbstractCollection.add(Integer.valueOf(paramInt));
  }
  
  public static void A1S(ReadWriteLock paramReadWriteLock) {
    paramReadWriteLock.readLock().lock();
  }
  
  public static void A1T(ReadWriteLock paramReadWriteLock) {
    paramReadWriteLock.readLock().unlock();
  }
  
  public static void A1U(ReentrantReadWriteLock paramReentrantReadWriteLock) {
    paramReentrantReadWriteLock.writeLock().unlock();
  }
  
  public static void A1V(ReentrantReadWriteLock paramReentrantReadWriteLock) {
    paramReentrantReadWriteLock.readLock().unlock();
  }
  
  public static void A1W(ReentrantReadWriteLock paramReentrantReadWriteLock) {
    paramReentrantReadWriteLock.readLock().lock();
  }
  
  public static boolean A1X(Object paramObject) {
    return ((Boolean)paramObject).booleanValue();
  }
  
  public static boolean A1Y(Object paramObject1, Object paramObject2) {
    boolean bool = false;
    if (paramObject1 == paramObject2)
      bool = true; 
    return bool;
  }
  
  public static boolean A1Z(Throwable paramThrowable) {
    return paramThrowable.getCause() instanceof android.os.DeadObjectException;
  }
  
  public static Object[] A1a(int paramInt) {
    return new Object[] { Integer.valueOf(paramInt) };
  }
  
  public static Object[] A1b(Object paramObject, int paramInt) {
    return new Object[] { paramObject, Integer.valueOf(paramInt) };
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\001.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */