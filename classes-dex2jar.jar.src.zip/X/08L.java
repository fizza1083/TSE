package X;

public final class 08L implements 06h {
  public final float A00;
  
  public final float A01;
  
  public 08L(float paramFloat1, float paramFloat2) {
    this.A01 = paramFloat1;
    this.A00 = paramFloat2;
  }
  
  public final boolean equals(Object paramObject) {
    if (paramObject instanceof 08L)
      if (!isEmpty() || !((08L)paramObject).isEmpty()) {
        float f = this.A01;
        paramObject = paramObject;
        if (f == ((08L)paramObject).A01 && this.A00 == ((08L)paramObject).A00)
          return true; 
      } else {
        return true;
      }  
    return false;
  }
  
  public final int hashCode() {
    return isEmpty() ? -1 : (Float.floatToIntBits(this.A01) * 31 + Float.floatToIntBits(this.A00));
  }
  
  public final boolean isEmpty() {
    float f1 = this.A01;
    float f2 = this.A00;
    boolean bool = false;
    if (f1 > f2)
      bool = true; 
    return bool;
  }
  
  public final String toString() {
    StringBuilder stringBuilder = 001.A0s();
    stringBuilder.append(this.A01);
    stringBuilder.append("..");
    stringBuilder.append(this.A00);
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08L.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */