package X;

import java.util.Collection;
import java.util.Map;
import java.util.Set;

public final class 07m implements Map, 16M {
  public final Map A00;
  
  public final 0BQ A01;
  
  public 07m(Map paramMap, 0BQ param0BQ) {
    this.A00 = paramMap;
    this.A01 = param0BQ;
  }
  
  public final void clear() {
    throw 002.A0b();
  }
  
  public final boolean containsKey(Object paramObject) {
    return this.A00.containsKey(paramObject);
  }
  
  public final boolean containsValue(Object paramObject) {
    return this.A00.containsValue(paramObject);
  }
  
  public final boolean equals(Object paramObject) {
    return this.A00.equals(paramObject);
  }
  
  public final Object get(Object paramObject) {
    return this.A00.get(paramObject);
  }
  
  public final int hashCode() {
    return this.A00.hashCode();
  }
  
  public final boolean isEmpty() {
    return this.A00.isEmpty();
  }
  
  public final Object put(Object paramObject1, Object paramObject2) {
    throw 002.A0b();
  }
  
  public final void putAll(Map paramMap) {
    throw 002.A0b();
  }
  
  public final Object remove(Object paramObject) {
    throw 002.A0b();
  }
  
  public final String toString() {
    return this.A00.toString();
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */