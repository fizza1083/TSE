package X;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public final class 07a {
  public static final List A01 = Collections.unmodifiableList(Arrays.asList((Object[])new String[] { "scheme", "authority", "path", "query" }));
  
  public final Map A00;
  
  public 07a(Map paramMap) {
    this.A00 = paramMap;
  }
  
  public static 07a A00(JSONObject paramJSONObject) {
    if (paramJSONObject != null)
      try {
        HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
        for (String str : A01) {
          if (paramJSONObject.has(str))
            hashMap.put(str, 07b.A00(paramJSONObject.get(str))); 
        } 
        return !hashMap.isEmpty() ? new 07a(hashMap) : null;
      } catch (JSONException jSONException) {
        return null;
      }  
    return null;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */