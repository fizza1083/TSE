package X;

import android.content.Context;
import java.io.File;

public final class 00B {
  public final 00C A00;
  
  public final File A01;
  
  public 00B(Context paramContext) {}
  
  public static final 00H A00(00B param00B, String paramString1, String paramString2) {
    File file = param00B.A01;
    String str = paramString2;
    if (paramString2 == null)
      str = "0"; 
    paramString1 = 0XK.A0p(paramString1, "_", str);
    return new 00H(param00B.A00, new File(file, paramString1), false);
  }
  
  public static void A01(File paramFile) {
    if (paramFile.isDirectory()) {
      paramFile.setWritable(true);
      File[] arrayOfFile = paramFile.listFiles();
      if (arrayOfFile != null) {
        int j = arrayOfFile.length;
        for (int i = 0; i < j; i++)
          A01(arrayOfFile[i]); 
      } 
    } 
    paramFile.delete();
  }
  
  public final 00H A02(String paramString1, String paramString2) {
    00H 00H = A00(this, paramString1, paramString2);
    return new 00H(this.A00, new File(00H, "download.zip"), false);
  }
  
  public final 00H A03(String paramString1, String paramString2) {
    00H 00H = A00(this, paramString1, paramString2);
    return new 00H(this.A00, 001.A0E(00H, "dex"), false);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00B.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */