package X;

import com.facebook.profilo.logger.MultiBufferLogger;
import java.util.Arrays;
import java.util.List;

public final class 04m {
  public final int A00;
  
  public final MultiBufferLogger A01;
  
  public final String A02;
  
  public final ThreadLocal A03 = new ThreadLocal();
  
  public final long A04;
  
  public final int[] A05;
  
  public 04m(MultiBufferLogger paramMultiBufferLogger, String paramString, int[] paramArrayOfint, int paramInt, long paramLong) {
    this.A04 = paramLong;
    this.A02 = paramString;
    this.A00 = paramInt;
    this.A05 = paramArrayOfint;
    this.A01 = paramMultiBufferLogger;
  }
  
  public static void A00(04m param04m, 036 param036, long paramLong) {
    List<String> list = param036.Bmi();
    if (list != null) {
      ThreadLocal<StringBuilder> threadLocal = param04m.A03;
      StringBuilder stringBuilder2 = threadLocal.get();
      StringBuilder stringBuilder1 = stringBuilder2;
      if (stringBuilder2 == null) {
        stringBuilder1 = new StringBuilder();
        threadLocal.set(stringBuilder1);
      } 
      int i = 0;
      stringBuilder1.setLength(0);
      while (i < list.size()) {
        String str = list.get(i);
        if (str != null && stringBuilder1.length() + str.length() <= 1024) {
          if (str.length() > 0) {
            if (i != 0)
              stringBuilder1.append(","); 
            stringBuilder1.append(str);
          } 
          i++;
        } 
      } 
      if (stringBuilder1.length() > 0) {
        MultiBufferLogger multiBufferLogger = param04m.A01;
        multiBufferLogger.writeBytesEntry(1, 57, multiBufferLogger.writeBytesEntry(1, 56, multiBufferLogger.writeStandardEntry(7, 58, 0L, 0, param036.getMarkerId(), 0, paramLong), "tags"), stringBuilder1.toString());
      } 
    } 
  }
  
  public static boolean A01(04m param04m, int paramInt) {
    int[] arrayOfInt = param04m.A05;
    int i = arrayOfInt.length;
    boolean bool = false;
    if (i >= 1 && arrayOfInt[0] == -1)
      return true; 
    if (Arrays.binarySearch(arrayOfInt, paramInt) >= 0)
      bool = true; 
    return bool;
  }
  
  public static boolean A02(04m param04m, 036 param036) {
    long l1 = param04m.A04;
    int i = param036.getMarkerId();
    int j = param036.BJ3();
    long l2 = i;
    long l3 = j;
    boolean bool = false;
    if (l1 == (l3 << 32L | l2))
      bool = true; 
    return bool;
  }
  
  public final void A03(036 param036) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokeinterface getMarkerId : ()I
    //   7: invokestatic A01 : (LX/04m;I)Z
    //   10: ifeq -> 200
    //   13: getstatic X/0FA.A0C : LX/0FA;
    //   16: astore #12
    //   18: aload #12
    //   20: ifnull -> 200
    //   23: aload_0
    //   24: aload_1
    //   25: invokestatic A02 : (LX/04m;LX/036;)Z
    //   28: istore #7
    //   30: aload_1
    //   31: invokeinterface getMarkerId : ()I
    //   36: istore #5
    //   38: aload #12
    //   40: iload #5
    //   42: invokestatic A03 : (LX/0FA;I)Ljava/lang/String;
    //   45: astore #13
    //   47: aload #13
    //   49: ifnull -> 62
    //   52: aload_1
    //   53: ldc 'loom_id'
    //   55: aload #13
    //   57: invokeinterface AFu : (Ljava/lang/String;Ljava/lang/String;)V
    //   62: aload_1
    //   63: invokeinterface BrP : ()I
    //   68: i2l
    //   69: bipush #16
    //   71: lshl
    //   72: ldc2_w 281474976645120
    //   75: land
    //   76: lstore #10
    //   78: lload #10
    //   80: lstore #8
    //   82: aload_1
    //   83: invokeinterface CBI : ()Z
    //   88: ifne -> 99
    //   91: lload #10
    //   93: ldc2_w 281474976710656
    //   96: lor
    //   97: lstore #8
    //   99: iload #7
    //   101: ifne -> 154
    //   104: aload #12
    //   106: getfield A04 : Ljava/util/concurrent/atomic/AtomicInteger;
    //   109: invokevirtual get : ()I
    //   112: istore #6
    //   114: iconst_0
    //   115: istore #4
    //   117: iconst_0
    //   118: istore_3
    //   119: iconst_0
    //   120: istore_2
    //   121: iload #6
    //   123: ifne -> 201
    //   126: iload_2
    //   127: istore_3
    //   128: lload #8
    //   130: lstore #10
    //   132: iload_3
    //   133: getstatic X/16Q.A01 : I
    //   136: iand
    //   137: ifeq -> 162
    //   140: lload #8
    //   142: lstore #10
    //   144: aload #12
    //   146: iload #5
    //   148: invokestatic A03 : (LX/0FA;I)Ljava/lang/String;
    //   151: ifnull -> 162
    //   154: lload #8
    //   156: ldc2_w 562949953421312
    //   159: lor
    //   160: lstore #10
    //   162: aload_1
    //   163: invokeinterface BQm : ()J
    //   168: lstore #8
    //   170: aload_0
    //   171: getfield A01 : Lcom/facebook/profilo/logger/MultiBufferLogger;
    //   174: iconst_4
    //   175: bipush #46
    //   177: lload #8
    //   179: iconst_0
    //   180: aload_1
    //   181: invokeinterface getMarkerId : ()I
    //   186: iconst_0
    //   187: lload #10
    //   189: invokevirtual writeStandardEntry : (IIJIIIJ)I
    //   192: pop
    //   193: aload_0
    //   194: aload_1
    //   195: lload #10
    //   197: invokestatic A00 : (LX/04m;LX/036;J)V
    //   200: return
    //   201: aload #12
    //   203: getfield A06 : Ljava/util/concurrent/atomic/AtomicReferenceArray;
    //   206: iload #4
    //   208: invokevirtual get : (I)Ljava/lang/Object;
    //   211: checkcast com/facebook/profilo/ipc/TraceContext
    //   214: astore #13
    //   216: iload_3
    //   217: istore_2
    //   218: aload #13
    //   220: ifnull -> 231
    //   223: iload_3
    //   224: aload #13
    //   226: getfield A01 : I
    //   229: ior
    //   230: istore_2
    //   231: iload #4
    //   233: iconst_1
    //   234: iadd
    //   235: istore #4
    //   237: iload_2
    //   238: istore_3
    //   239: iload #4
    //   241: iconst_4
    //   242: if_icmpge -> 128
    //   245: iload_2
    //   246: istore_3
    //   247: goto -> 201
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\04m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */