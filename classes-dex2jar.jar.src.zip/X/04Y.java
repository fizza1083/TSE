package X;

public enum 04Y {
  A01, A02, A03;
  
  static {
    04Y 04Y1 = new 04Y("HERO_SERVICE_PLAYER", 0);
    A02 = 04Y1;
    04Y 04Y2 = new 04Y("LARGE_BITMAP", 1);
    A03 = 04Y2;
    04Y 04Y3 = new 04Y("COMPONENT_KEYS", 2);
    A01 = 04Y3;
    A00 = new 04Y[] { 04Y1, 04Y2, 04Y3 };
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\04Y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */