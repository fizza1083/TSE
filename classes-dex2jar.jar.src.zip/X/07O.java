package X;

import android.view.WindowInsets;

public final class 07O extends 07P {
  public static final 07N A00;
  
  static {
    WindowInsets windowInsets = WindowInsets.CONSUMED;
    07N 07N1 = 07N.A01;
    windowInsets.getClass();
    A00 = new 07N(windowInsets);
  }
  
  public static int A00(int paramInt) {
    boolean bool = false;
    byte b = 1;
    while (true) {
      boolean bool1;
      while (true) {
        bool1 = bool;
        break;
      } 
      if (SYNTHETIC_LOCAL_VARIABLE_4 > 'Ā')
        return bool1; 
    } 
  }
  
  public final 07U A0D(int paramInt) {
    return 07U.A01(this.A02.getInsets(A00(paramInt)));
  }
  
  public final 07U A0E(int paramInt) {
    return 07U.A01(this.A02.getInsetsIgnoringVisibility(A00(2)));
  }
  
  public final boolean A0F(int paramInt) {
    return this.A02.isVisible(A00(8));
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07O.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */