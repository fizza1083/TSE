package X;

import android.view.View;
import android.view.ViewTreeObserver;

public final class 08H implements View.OnAttachStateChangeListener, ViewTreeObserver.OnPreDrawListener {
  public ViewTreeObserver A00;
  
  public final View A01;
  
  public final Runnable A02;
  
  public 08H(View paramView, Runnable paramRunnable) {
    this.A01 = paramView;
    this.A00 = paramView.getViewTreeObserver();
    this.A02 = paramRunnable;
  }
  
  public static 08H A00(View paramView, Runnable paramRunnable) {
    if (paramView != null) {
      08H 08H1 = new 08H(paramView, paramRunnable);
      paramView.getViewTreeObserver().addOnPreDrawListener(08H1);
      paramView.addOnAttachStateChangeListener(08H1);
      return 08H1;
    } 
    throw 001.A0V("view == null");
  }
  
  public final void A01() {
    ViewTreeObserver viewTreeObserver;
    if (this.A00.isAlive()) {
      viewTreeObserver = this.A00;
    } else {
      viewTreeObserver = this.A01.getViewTreeObserver();
    } 
    viewTreeObserver.removeOnPreDrawListener(this);
    this.A01.removeOnAttachStateChangeListener(this);
  }
  
  public final boolean onPreDraw() {
    A01();
    this.A02.run();
    return true;
  }
  
  public final void onViewAttachedToWindow(View paramView) {
    this.A00 = paramView.getViewTreeObserver();
  }
  
  public final void onViewDetachedFromWindow(View paramView) {
    A01();
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08H.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */