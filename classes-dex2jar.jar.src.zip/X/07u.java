package X;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;

public final class 07u extends View.AccessibilityDelegate {
  public final 07t A00;
  
  public 07u(07t param07t) {
    this.A00 = param07t;
  }
  
  public final boolean dispatchPopulateAccessibilityEvent(View paramView, AccessibilityEvent paramAccessibilityEvent) {
    return this.A00.A0a(paramView, paramAccessibilityEvent);
  }
  
  public final AccessibilityNodeProvider getAccessibilityNodeProvider(View paramView) {
    0Mq 0Mq = this.A00.A0c(paramView);
    return (0Mq != null) ? (AccessibilityNodeProvider)0Mq.A00 : null;
  }
  
  public final void onInitializeAccessibilityEvent(View paramView, AccessibilityEvent paramAccessibilityEvent) {
    this.A00.A0V(paramView, paramAccessibilityEvent);
  }
  
  public final void onInitializeAccessibilityNodeInfo(View paramView, AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    // Byte code:
    //   0: new androidx/core/view/accessibility/AccessibilityNodeInfoCompat
    //   3: dup
    //   4: aload_2
    //   5: invokespecial <init> : (Landroid/view/accessibility/AccessibilityNodeInfo;)V
    //   8: astore #6
    //   10: aload_1
    //   11: invokevirtual isScreenReaderFocusable : ()Z
    //   14: istore #5
    //   16: iload #5
    //   18: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   21: ifnull -> 32
    //   24: iconst_1
    //   25: istore #4
    //   27: iload #5
    //   29: ifne -> 35
    //   32: iconst_0
    //   33: istore #4
    //   35: aload #6
    //   37: getfield mInfo : Landroid/view/accessibility/AccessibilityNodeInfo;
    //   40: iload #4
    //   42: invokevirtual setScreenReaderFocusable : (Z)V
    //   45: aload_1
    //   46: invokevirtual isAccessibilityHeading : ()Z
    //   49: istore #5
    //   51: iload #5
    //   53: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   56: ifnull -> 67
    //   59: iconst_1
    //   60: istore #4
    //   62: iload #5
    //   64: ifne -> 70
    //   67: iconst_0
    //   68: istore #4
    //   70: aload #6
    //   72: getfield mInfo : Landroid/view/accessibility/AccessibilityNodeInfo;
    //   75: iload #4
    //   77: invokevirtual setHeading : (Z)V
    //   80: aload_1
    //   81: invokevirtual getAccessibilityPaneTitle : ()Ljava/lang/CharSequence;
    //   84: astore #7
    //   86: aload #6
    //   88: getfield mInfo : Landroid/view/accessibility/AccessibilityNodeInfo;
    //   91: aload #7
    //   93: invokevirtual setPaneTitle : (Ljava/lang/CharSequence;)V
    //   96: aload_1
    //   97: invokevirtual getStateDescription : ()Ljava/lang/CharSequence;
    //   100: astore #7
    //   102: aload #6
    //   104: getfield mInfo : Landroid/view/accessibility/AccessibilityNodeInfo;
    //   107: aload #7
    //   109: invokevirtual setStateDescription : (Ljava/lang/CharSequence;)V
    //   112: aload_0
    //   113: getfield A00 : LX/07t;
    //   116: aload_1
    //   117: aload #6
    //   119: invokevirtual A0Y : (Landroid/view/View;Landroidx/core/view/accessibility/AccessibilityNodeInfoCompat;)V
    //   122: aload_2
    //   123: invokevirtual getText : ()Ljava/lang/CharSequence;
    //   126: pop
    //   127: aload_1
    //   128: ldc 2131370812
    //   130: invokevirtual getTag : (I)Ljava/lang/Object;
    //   133: checkcast java/util/List
    //   136: astore_2
    //   137: aload_2
    //   138: astore_1
    //   139: aload_2
    //   140: ifnonnull -> 147
    //   143: invokestatic emptyList : ()Ljava/util/List;
    //   146: astore_1
    //   147: iconst_0
    //   148: istore_3
    //   149: iload_3
    //   150: aload_1
    //   151: invokeinterface size : ()I
    //   156: if_icmpge -> 181
    //   159: aload #6
    //   161: aload_1
    //   162: iload_3
    //   163: invokeinterface get : (I)Ljava/lang/Object;
    //   168: checkcast X/0V7
    //   171: invokevirtual addAction : (LX/0V7;)V
    //   174: iload_3
    //   175: iconst_1
    //   176: iadd
    //   177: istore_3
    //   178: goto -> 149
    //   181: return
  }
  
  public final void onPopulateAccessibilityEvent(View paramView, AccessibilityEvent paramAccessibilityEvent) {
    this.A00.A0W(paramView, paramAccessibilityEvent);
  }
  
  public final boolean onRequestSendAccessibilityEvent(ViewGroup paramViewGroup, View paramView, AccessibilityEvent paramAccessibilityEvent) {
    return this.A00.A0b(paramViewGroup, paramView, paramAccessibilityEvent);
  }
  
  public final boolean performAccessibilityAction(View paramView, int paramInt, Bundle paramBundle) {
    return this.A00.A0Z(paramView, paramInt, paramBundle);
  }
  
  public final void sendAccessibilityEvent(View paramView, int paramInt) {
    this.A00.A0U(paramView, paramInt);
  }
  
  public final void sendAccessibilityEventUnchecked(View paramView, AccessibilityEvent paramAccessibilityEvent) {
    this.A00.A0X(paramView, paramAccessibilityEvent);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */