package X;

import android.text.TextUtils;
import org.json.JSONException;
import org.json.JSONObject;

public final class 07B {
  public static final 0I4 A04 = (new 0Up()).A01();
  
  public final String A00;
  
  public final String A01;
  
  public final String A02;
  
  public final String A03;
  
  public 07B(String paramString1, String paramString2, String paramString3, String paramString4) {
    this.A03 = paramString1;
    this.A01 = paramString2;
    this.A00 = paramString3;
    this.A02 = paramString4;
  }
  
  public static final String A00(07B param07B) {
    StringBuilder stringBuilder = 001.A0s();
    String str2 = param07B.A03;
    if (!TextUtils.isEmpty(str2)) {
      stringBuilder.append(str2);
      stringBuilder.append(':');
    } 
    str2 = param07B.A01;
    if (!TextUtils.isEmpty(str2)) {
      stringBuilder.append("//");
      stringBuilder.append(str2);
    } 
    str2 = param07B.A00;
    if (!TextUtils.isEmpty(str2))
      stringBuilder.append(str2); 
    String str1 = param07B.A02;
    if (!TextUtils.isEmpty(str1)) {
      stringBuilder.append('?');
      stringBuilder.append(str1);
    } 
    return stringBuilder.toString();
  }
  
  public final JSONObject A01() {
    JSONObject jSONObject = 001.A1F();
    try {
      String str = this.A03;
      if (!TextUtils.isEmpty(str))
        jSONObject.put("scheme", str); 
      str = this.A01;
      if (!TextUtils.isEmpty(str))
        jSONObject.put("authority", str); 
      str = this.A00;
      if (!TextUtils.isEmpty(str))
        jSONObject.put("path", str); 
      str = this.A02;
      if (!TextUtils.isEmpty(str))
        jSONObject.put("query", str); 
      return jSONObject;
    } catch (JSONException jSONException) {
      return jSONObject;
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07B.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */