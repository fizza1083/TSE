package X;

import android.os.Build;
import android.util.Log;
import android.view.View;
import android.view.WindowInsets;
import java.util.AbstractCollection;
import java.util.AbstractList;
import java.util.WeakHashMap;

public abstract class 07v {
  public static WeakHashMap A00;
  
  public static final 07x A01;
  
  public static final int[] A02;
  
  public static final 07z A03;
  
  static {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public static 07t A00(View paramView) {
    View.AccessibilityDelegate accessibilityDelegate = paramView.getAccessibilityDelegate();
    return (accessibilityDelegate == null) ? null : ((accessibilityDelegate instanceof 07u) ? ((07u)accessibilityDelegate).A00 : new 07t(accessibilityDelegate));
  }
  
  public static 0ap A01(View paramView, 0ap param0ap) {
    if (Log.isLoggable("ViewCompat", 3))
      paramView.getId(); 
    if (Build.VERSION.SDK_INT >= 31)
      return 0bE.A00(paramView, param0ap); 
    0Ws 0Ws = (0Ws)paramView.getTag(2131370826);
    0ap 0ap1 = param0ap;
    if (0Ws != null) {
      param0ap = 0Ws.D5q(paramView, param0ap);
      0ap1 = param0ap;
      if (param0ap == null)
        return null; 
    } 
    if (paramView instanceof 07x) {
      07x 07x2 = (07x)paramView;
      return 07x2.D5r(0ap1);
    } 
    07x 07x1 = A01;
    return 07x1.D5r(0ap1);
  }
  
  @Deprecated
  public static 0bM A02(View paramView) {
    WeakHashMap<Object, Object> weakHashMap2 = A00;
    WeakHashMap<Object, Object> weakHashMap1 = weakHashMap2;
    if (weakHashMap2 == null) {
      weakHashMap1 = new WeakHashMap<Object, Object>();
      A00 = weakHashMap1;
    } 
    0bM 0bM2 = (0bM)weakHashMap1.get(paramView);
    0bM 0bM1 = 0bM2;
    if (0bM2 == null) {
      0bM1 = new 0bM(paramView);
      A00.put(paramView, 0bM1);
    } 
    return 0bM1;
  }
  
  public static 07N A03(View paramView, 07N param07N) {
    WindowInsets windowInsets = param07N.A05();
    if (windowInsets != null) {
      WindowInsets windowInsets1 = paramView.dispatchApplyWindowInsets(windowInsets);
      if (!windowInsets1.equals(windowInsets))
        return 07N.A00(paramView, windowInsets1); 
    } 
    return param07N;
  }
  
  public static 07N A04(View paramView, 07N param07N) {
    WindowInsets windowInsets = param07N.A05();
    if (windowInsets != null) {
      WindowInsets windowInsets1 = paramView.onApplyWindowInsets(windowInsets);
      if (!windowInsets1.equals(windowInsets))
        return 07N.A00(paramView, windowInsets1); 
    } 
    return param07N;
  }
  
  public static void A05(View paramView) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getContext : ()Landroid/content/Context;
    //   4: ldc 'accessibility'
    //   6: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   9: checkcast android/view/accessibility/AccessibilityManager
    //   12: invokevirtual isEnabled : ()Z
    //   15: ifeq -> 170
    //   18: aload_0
    //   19: invokevirtual getAccessibilityPaneTitle : ()Ljava/lang/CharSequence;
    //   22: ifnull -> 43
    //   25: aload_0
    //   26: invokevirtual isShown : ()Z
    //   29: ifeq -> 43
    //   32: aload_0
    //   33: invokevirtual getWindowVisibility : ()I
    //   36: istore_2
    //   37: iconst_1
    //   38: istore_1
    //   39: iload_2
    //   40: ifeq -> 45
    //   43: iconst_0
    //   44: istore_1
    //   45: aload_0
    //   46: invokevirtual getAccessibilityLiveRegion : ()I
    //   49: istore_3
    //   50: bipush #32
    //   52: istore_2
    //   53: iload_3
    //   54: ifne -> 108
    //   57: iload_1
    //   58: ifne -> 108
    //   61: aload_0
    //   62: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   65: ifnull -> 170
    //   68: aload_0
    //   69: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   72: astore #4
    //   74: aload #4
    //   76: aload_0
    //   77: aload_0
    //   78: iconst_0
    //   79: invokeinterface notifySubtreeAccessibilityStateChanged : (Landroid/view/View;Landroid/view/View;I)V
    //   84: return
    //   85: astore #4
    //   87: ldc 'ViewCompat'
    //   89: aload_0
    //   90: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   93: invokestatic A0g : (Ljava/lang/Object;)Ljava/lang/String;
    //   96: ldc ' does not fully implement ViewParent'
    //   98: invokestatic A0b : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   101: aload #4
    //   103: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   106: pop
    //   107: return
    //   108: invokestatic obtain : ()Landroid/view/accessibility/AccessibilityEvent;
    //   111: astore #4
    //   113: iload_1
    //   114: ifne -> 121
    //   117: sipush #2048
    //   120: istore_2
    //   121: aload #4
    //   123: iload_2
    //   124: invokevirtual setEventType : (I)V
    //   127: aload #4
    //   129: iconst_0
    //   130: invokevirtual setContentChangeTypes : (I)V
    //   133: iload_1
    //   134: ifeq -> 164
    //   137: aload #4
    //   139: invokevirtual getText : ()Ljava/util/List;
    //   142: aload_0
    //   143: invokevirtual getAccessibilityPaneTitle : ()Ljava/lang/CharSequence;
    //   146: invokeinterface add : (Ljava/lang/Object;)Z
    //   151: pop
    //   152: aload_0
    //   153: invokevirtual getImportantForAccessibility : ()I
    //   156: ifne -> 164
    //   159: aload_0
    //   160: iconst_1
    //   161: invokevirtual setImportantForAccessibility : (I)V
    //   164: aload_0
    //   165: aload #4
    //   167: invokevirtual sendAccessibilityEventUnchecked : (Landroid/view/accessibility/AccessibilityEvent;)V
    //   170: return
    // Exception table:
    //   from	to	target	type
    //   74	84	85	java/lang/AbstractMethodError
  }
  
  public static void A06(View paramView, int paramInt) {
    AbstractList<0V7> abstractList2 = (AbstractList)paramView.getTag(2131370812);
    AbstractList<0V7> abstractList1 = abstractList2;
    if (abstractList2 == null) {
      abstractList1 = 001.A0y();
      paramView.setTag(2131370812, abstractList1);
    } 
    int i = 0;
    while (true) {
      if (i < abstractList1.size())
        if (((0V7)abstractList1.get(i)).A00() == paramInt) {
          abstractList1.remove(i);
        } else {
          i++;
          continue;
        }  
      A05(paramView);
      return;
    } 
  }
  
  public static void A07(View paramView, 07t param07t) {
    View.AccessibilityDelegate accessibilityDelegate;
    07t 07t1 = param07t;
    if (param07t == null) {
      07t1 = param07t;
      if (paramView.getAccessibilityDelegate() instanceof 07u)
        07t1 = new 07t(); 
    } 
    if (paramView.getImportantForAccessibility() == 0)
      paramView.setImportantForAccessibility(1); 
    if (07t1 == null) {
      param07t = null;
    } else {
      accessibilityDelegate = 07t1.A00;
    } 
    paramView.setAccessibilityDelegate(accessibilityDelegate);
  }
  
  public static void A08(View paramView, 0Ws param0Ws, String[] paramArrayOfString) {
    // Byte code:
    //   0: getstatic android/os/Build$VERSION.SDK_INT : I
    //   3: bipush #31
    //   5: if_icmplt -> 15
    //   8: aload_0
    //   9: aload_1
    //   10: aload_2
    //   11: invokestatic A01 : (Landroid/view/View;LX/0Ws;[Ljava/lang/String;)V
    //   14: return
    //   15: aload_2
    //   16: ifnull -> 27
    //   19: aload_2
    //   20: astore #7
    //   22: aload_2
    //   23: arraylength
    //   24: ifne -> 30
    //   27: aconst_null
    //   28: astore #7
    //   30: iconst_0
    //   31: istore #5
    //   33: aload #7
    //   35: invokestatic A18 : (Ljava/lang/Object;)Z
    //   38: ldc_w 'When the listener is set, MIME types must also be set'
    //   41: invokestatic A06 : (ZLjava/lang/Object;)V
    //   44: aload #7
    //   46: ifnull -> 100
    //   49: aload #7
    //   51: arraylength
    //   52: istore #6
    //   54: iconst_0
    //   55: istore_3
    //   56: iload #5
    //   58: istore #4
    //   60: iload_3
    //   61: iload #6
    //   63: if_icmpge -> 82
    //   66: aload #7
    //   68: iload_3
    //   69: aaload
    //   70: ldc_w '*'
    //   73: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   76: ifeq -> 117
    //   79: iconst_1
    //   80: istore #4
    //   82: iload #4
    //   84: iconst_1
    //   85: ixor
    //   86: ldc_w 'A MIME type set here must not start with *: '
    //   89: aload #7
    //   91: invokestatic toString : ([Ljava/lang/Object;)Ljava/lang/String;
    //   94: invokestatic A0b : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   97: invokestatic A06 : (ZLjava/lang/Object;)V
    //   100: aload_0
    //   101: ldc_w 2131370827
    //   104: aload #7
    //   106: invokevirtual setTag : (ILjava/lang/Object;)V
    //   109: aload_0
    //   110: ldc 2131370826
    //   112: aload_1
    //   113: invokevirtual setTag : (ILjava/lang/Object;)V
    //   116: return
    //   117: iload_3
    //   118: iconst_1
    //   119: iadd
    //   120: istore_3
    //   121: goto -> 56
  }
  
  public static void A09(View paramView, 0V7 param0V7) {
    07t 07t2 = A00(paramView);
    07t 07t1 = 07t2;
    if (07t2 == null)
      07t1 = new 07t(); 
    A07(paramView, 07t1);
    int j = param0V7.A00();
    AbstractList<0V7> abstractList2 = (AbstractList)paramView.getTag(2131370812);
    AbstractList<0V7> abstractList1 = abstractList2;
    if (abstractList2 == null) {
      abstractList1 = 001.A0y();
      paramView.setTag(2131370812, abstractList1);
    } 
    int i = 0;
    while (true) {
      if (i < abstractList1.size())
        if (((0V7)abstractList1.get(i)).A00() == j) {
          abstractList1.remove(i);
        } else {
          i++;
          continue;
        }  
      AbstractCollection<0V7> abstractCollection2 = (AbstractCollection)paramView.getTag(2131370812);
      AbstractCollection<0V7> abstractCollection1 = abstractCollection2;
      if (abstractCollection2 == null) {
        abstractCollection1 = 001.A0y();
        paramView.setTag(2131370812, abstractCollection1);
      } 
      abstractCollection1.add(param0V7);
      A05(paramView);
      return;
    } 
  }
  
  public static void A0A(View paramView, 0V7 param0V7, 0V8 param0V8) {
    if (param0V8 == null) {
      A06(paramView, param0V7.A00());
      return;
    } 
    int i = param0V7.A00;
    A09(paramView, new 0V7(param0V8, null, param0V7.A02, null, i));
  }
  
  public static void A0B(View paramView, CharSequence paramCharSequence) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokevirtual setAccessibilityPaneTitle : (Ljava/lang/CharSequence;)V
    //   5: getstatic X/07v.A03 : LX/07z;
    //   8: astore #4
    //   10: aload_1
    //   11: ifnull -> 73
    //   14: aload #4
    //   16: getfield A00 : Ljava/util/WeakHashMap;
    //   19: astore_1
    //   20: aload_0
    //   21: invokevirtual isShown : ()Z
    //   24: ifeq -> 38
    //   27: aload_0
    //   28: invokevirtual getWindowVisibility : ()I
    //   31: istore_2
    //   32: iconst_1
    //   33: istore_3
    //   34: iload_2
    //   35: ifeq -> 40
    //   38: iconst_0
    //   39: istore_3
    //   40: aload_1
    //   41: aload_0
    //   42: iload_3
    //   43: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   46: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   49: pop
    //   50: aload_0
    //   51: aload #4
    //   53: invokevirtual addOnAttachStateChangeListener : (Landroid/view/View$OnAttachStateChangeListener;)V
    //   56: aload_0
    //   57: invokevirtual isAttachedToWindow : ()Z
    //   60: ifeq -> 72
    //   63: aload_0
    //   64: invokevirtual getViewTreeObserver : ()Landroid/view/ViewTreeObserver;
    //   67: aload #4
    //   69: invokevirtual addOnGlobalLayoutListener : (Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V
    //   72: return
    //   73: aload #4
    //   75: getfield A00 : Ljava/util/WeakHashMap;
    //   78: aload_0
    //   79: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   82: pop
    //   83: aload_0
    //   84: aload #4
    //   86: invokevirtual removeOnAttachStateChangeListener : (Landroid/view/View$OnAttachStateChangeListener;)V
    //   89: aload_0
    //   90: invokevirtual getViewTreeObserver : ()Landroid/view/ViewTreeObserver;
    //   93: aload #4
    //   95: invokevirtual removeOnGlobalLayoutListener : (Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V
    //   98: return
  }
  
  public static void A0C(View paramView, boolean paramBoolean) {
    paramView.setAccessibilityHeading(Boolean.valueOf(paramBoolean).booleanValue());
  }
  
  public static String[] A0D(View paramView) {
    return (Build.VERSION.SDK_INT >= 31) ? 0bE.A02(paramView) : (String[])paramView.getTag(2131370827);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */