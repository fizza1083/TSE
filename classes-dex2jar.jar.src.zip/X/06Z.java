package X;

public class 06Z extends 06a {
  public 06Z(Class paramClass, String paramString1, String paramString2) {
    super(paramClass, 0BH.NO_RECEIVER, paramString1, paramString2, 0);
  }
  
  public Object A01() {
    A02();
    throw 0GH.createAndThrow();
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\06Z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */