package X;

import java.io.Serializable;
import java.util.Arrays;

public final class 02B implements Serializable {
  public static final long serialVersionUID = 0L;
  
  public String sha1Hash;
  
  public String sha256Hash;
  
  public 02B(String paramString) {
    if (paramString.length() == 43) {
      this.sha256Hash = paramString;
      return;
    } 
    throw 001.A0c("Invalid SHA256 key hash - should be 256-bit.");
  }
  
  public static 02B A00(String paramString) {
    return new 02B(paramString);
  }
  
  public final boolean equals(Object paramObject) {
    if (!(paramObject instanceof 02B))
      return false; 
    paramObject = paramObject;
    return this.sha256Hash.equals(((02B)paramObject).sha256Hash);
  }
  
  public final int hashCode() {
    return Arrays.hashCode(new Object[] { this.sha256Hash });
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\02B.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */