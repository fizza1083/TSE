package X;

public abstract class 04n {
  public static final 04p A00;
  
  public static final 04p A01;
  
  public static final 04o A02 = 04o.A00("COMPLETING_ALREADY");
  
  public static final 04o A03;
  
  public static final 04o A04 = 04o.A00("COMPLETING_WAITING_CHILDREN");
  
  public static final 04o A05;
  
  public static final 04o A06;
  
  static {
    A03 = 04o.A00("COMPLETING_RETRY");
    A06 = 04o.A00("TOO_LATE_TO_CANCEL");
    A05 = 04o.A00("SEALED");
    A01 = new 04p(false);
    A00 = new 04p(true);
  }
  
  public static final Object A00(Object paramObject) {
    if (paramObject instanceof 0QU) {
      0QU 0QU = (0QU)paramObject;
      if (0QU != null) {
        04q 04q = 0QU.A00;
        if (04q != null)
          return 04q; 
      } 
    } 
    return paramObject;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\04n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */