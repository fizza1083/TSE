package X;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.os.Handler;

public abstract class 01K {
  public static final void A00(BroadcastReceiver paramBroadcastReceiver, Context paramContext, IntentFilter paramIntentFilter) {
    if ((paramContext.getApplicationInfo()).targetSdkVersion >= 34) {
      paramContext.registerReceiver(paramBroadcastReceiver, paramIntentFilter, 4);
      return;
    } 
    paramContext.registerReceiver(paramBroadcastReceiver, paramIntentFilter);
  }
  
  public static final void A01(BroadcastReceiver paramBroadcastReceiver, Context paramContext, IntentFilter paramIntentFilter, Handler paramHandler, String paramString, boolean paramBoolean) {
    if ((paramContext.getApplicationInfo()).targetSdkVersion >= 34) {
      byte b = 4;
      if (paramBoolean)
        b = 2; 
      paramContext.registerReceiver(paramBroadcastReceiver, paramIntentFilter, paramString, paramHandler, b);
      return;
    } 
    paramContext.registerReceiver(paramBroadcastReceiver, paramIntentFilter, paramString, paramHandler);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01K.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */