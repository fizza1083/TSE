package X;

public abstract class 05G {
  public static final 04I A00(04I param04I1, 04I param04I2, boolean paramBoolean) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: \r\n\tat com.googlecode.dex2jar.ir.ts.NewTransformer.transform(NewTransformer.java:134)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:148)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public static final 04I A01(04I param04I, 058 param058) {
    04I 04I1 = A00(param058.B32(), param04I, true);
    04F 04F = 05I.A00;
    param04I = 04I1;
    if (04I1 != 04F) {
      param04I = 04I1;
      if (04I1.get(04K.A00) == null)
        param04I = 04I1.plus(04F); 
    } 
    return param04I;
  }
  
  public static final 0ID A02(Object paramObject, 05D param05D, 04I param04I) {
    boolean bool = param05D instanceof 05E;
    0ID 0ID = null;
    05E 05E = 0ID;
    if (bool) {
      05E = 0ID;
      if (param04I.get(0IE.A00) != null) {
        05E 05E1 = (05E)param05D;
        while (true) {
          05E = 0ID;
          if (!(05E1 instanceof 0Ia)) {
            05E 05E2 = 05E1.Aym();
            05E = 0ID;
            if (05E2 != null) {
              05E1 = 05E2;
              if (05E2 instanceof 0ID) {
                0ID = (0ID)05E2;
                05E1 = 0ID;
                05E = 05E1;
                if (0ID != null) {
                  0ID.threadLocalIsSet = true;
                  0ID.A00.set(new 0BW(param04I, paramObject));
                  05E = 05E1;
                } 
                break;
              } 
              continue;
            } 
          } 
          break;
        } 
      } 
    } 
    return (0ID)05E;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\05G.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */