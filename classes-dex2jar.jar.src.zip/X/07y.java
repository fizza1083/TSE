package X;

public abstract class 07y {
  public static String A00(double... paramVarArgs) {
    int j = paramVarArgs.length;
    if (j == 0)
      return ""; 
    StringBuilder stringBuilder = new StringBuilder();
    int i = 0;
    while (true) {
      stringBuilder.append(paramVarArgs[i]);
      stringBuilder.append(",,,");
      int k = i + 1;
      i = k;
      if (k >= j) {
        stringBuilder.setLength(stringBuilder.length() - 3);
        return stringBuilder.toString();
      } 
    } 
  }
  
  public static String A01(int... paramVarArgs) {
    int j = paramVarArgs.length;
    if (j == 0)
      return ""; 
    StringBuilder stringBuilder = new StringBuilder();
    int i = 0;
    while (true) {
      stringBuilder.append(paramVarArgs[i]);
      stringBuilder.append(",,,");
      int k = i + 1;
      i = k;
      if (k >= j) {
        stringBuilder.setLength(stringBuilder.length() - 3);
        return stringBuilder.toString();
      } 
    } 
  }
  
  public static String A02(long... paramVarArgs) {
    int j = paramVarArgs.length;
    if (j == 0)
      return ""; 
    StringBuilder stringBuilder = 001.A0s();
    int i = 0;
    while (true) {
      stringBuilder.append(paramVarArgs[i]);
      stringBuilder.append(",,,");
      int k = i + 1;
      i = k;
      if (k >= j) {
        stringBuilder.setLength(stringBuilder.length() - 3);
        return stringBuilder.toString();
      } 
    } 
  }
  
  public static String A03(String... paramVarArgs) {
    int j = paramVarArgs.length;
    if (j == 0)
      return ""; 
    StringBuilder stringBuilder = new StringBuilder();
    int i = 0;
    while (true) {
      stringBuilder.append(paramVarArgs[i]);
      stringBuilder.append(",,,");
      int k = i + 1;
      i = k;
      if (k >= j) {
        stringBuilder.setLength(stringBuilder.length() - 3);
        return stringBuilder.toString();
      } 
    } 
  }
  
  public static String A04(boolean... paramVarArgs) {
    int j = paramVarArgs.length;
    if (j == 0)
      return ""; 
    StringBuilder stringBuilder = 001.A0s();
    int i = 0;
    while (true) {
      stringBuilder.append(paramVarArgs[i]);
      stringBuilder.append(",,,");
      int k = i + 1;
      i = k;
      if (k >= j) {
        stringBuilder.setLength(stringBuilder.length() - 3);
        return stringBuilder.toString();
      } 
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */