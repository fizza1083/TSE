package X;

import android.graphics.Insets;

public final class 07U {
  public static final 07U A04 = new 07U(0, 0, 0, 0);
  
  public final int A00;
  
  public final int A01;
  
  public final int A02;
  
  public final int A03;
  
  public 07U(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.A01 = paramInt1;
    this.A03 = paramInt2;
    this.A02 = paramInt3;
    this.A00 = paramInt4;
  }
  
  public static 07U A00(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return (paramInt1 == 0 && paramInt2 == 0 && paramInt3 == 0 && paramInt4 == 0) ? A04 : new 07U(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public static 07U A01(Insets paramInsets) {
    return A00(paramInsets.left, paramInsets.top, paramInsets.right, paramInsets.bottom);
  }
  
  public final boolean equals(Object paramObject) {
    if (this != paramObject)
      if (paramObject != null && getClass() == paramObject.getClass()) {
        paramObject = paramObject;
        if (this.A00 != ((07U)paramObject).A00 || this.A01 != ((07U)paramObject).A01 || this.A02 != ((07U)paramObject).A02 || this.A03 != ((07U)paramObject).A03)
          return false; 
      } else {
        return false;
      }  
    return true;
  }
  
  public final int hashCode() {
    return ((this.A01 * 31 + this.A03) * 31 + this.A02) * 31 + this.A00;
  }
  
  public final String toString() {
    StringBuilder stringBuilder = 001.A0s();
    stringBuilder.append("Insets{left=");
    stringBuilder.append(this.A01);
    stringBuilder.append(", top=");
    stringBuilder.append(this.A03);
    stringBuilder.append(", right=");
    stringBuilder.append(this.A02);
    stringBuilder.append(", bottom=");
    stringBuilder.append(this.A00);
    return 002.A0X(stringBuilder);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07U.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */