package X;

import java.util.Iterator;

public class 06g implements Iterable, 16M {
  public final int A00;
  
  public final int A01;
  
  public final int A02;
  
  public 06g(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt3 != 0) {
      if (paramInt3 != Integer.MIN_VALUE) {
        this.A00 = paramInt1;
        this.A01 = 06i.A00(paramInt1, paramInt2, paramInt3);
        this.A02 = paramInt3;
        return;
      } 
      throw 001.A0O("Step must be greater than Int.MIN_VALUE to avoid overflow on negation.");
    } 
    throw 001.A0O("Step must be non-zero.");
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject instanceof 06g)
      if (!isEmpty() || !((06g)paramObject).isEmpty()) {
        int i = this.A00;
        paramObject = paramObject;
        if (i == ((06g)paramObject).A00 && this.A01 == ((06g)paramObject).A01 && this.A02 == ((06g)paramObject).A02)
          return true; 
      } else {
        return true;
      }  
    return false;
  }
  
  public int hashCode() {
    return isEmpty() ? -1 : ((this.A00 * 31 + this.A01) * 31 + this.A02);
  }
  
  public boolean isEmpty() {
    int i = this.A02;
    int j = this.A00;
    int k = this.A01;
    if (i > 0) {
      if (j > k)
        return true; 
    } else if (j < k) {
      return true;
    } 
    return false;
  }
  
  public String toString() {
    int i = this.A02;
    StringBuilder stringBuilder = 001.A0s();
    int j = this.A00;
    if (i > 0) {
      stringBuilder.append(j);
      stringBuilder.append("..");
      stringBuilder.append(this.A01);
      stringBuilder.append(" step ");
      return 001.A0o(stringBuilder, i);
    } 
    stringBuilder.append(j);
    stringBuilder.append(" downTo ");
    stringBuilder.append(this.A01);
    stringBuilder.append(" step ");
    i = -i;
    return 001.A0o(stringBuilder, i);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\06g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */