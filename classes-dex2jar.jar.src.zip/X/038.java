package X;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class 038 {
  public int A00 = 0;
  
  public int A01 = -1;
  
  public int A02 = 0;
  
  public int A03 = 0;
  
  public String A04 = null;
  
  public ArrayList A05 = new ArrayList();
  
  public ArrayList A06 = new ArrayList();
  
  public List A07;
  
  public List A08;
  
  public byte[] A09 = new byte[20];
  
  public double[] A0A = new double[15];
  
  public long[] A0B = new long[15];
  
  public static void A00(038 param038, byte paramByte) {
    int i = param038.A03;
    byte[] arrayOfByte2 = param038.A09;
    int j = arrayOfByte2.length;
    byte[] arrayOfByte1 = arrayOfByte2;
    if (i == j) {
      if (j == 0) {
        arrayOfByte1 = new byte[20];
      } else {
        arrayOfByte1 = Arrays.copyOf(arrayOfByte2, (int)(j * 1.4D));
      } 
      param038.A09 = arrayOfByte1;
    } 
    i = param038.A03;
    param038.A03 = i + 1;
    arrayOfByte1[i] = paramByte;
  }
  
  public static void A01(038 param038, long paramLong) {
    int i = param038.A02;
    long[] arrayOfLong2 = param038.A0B;
    int j = arrayOfLong2.length;
    long[] arrayOfLong1 = arrayOfLong2;
    if (i == j) {
      arrayOfLong1 = Arrays.copyOf(arrayOfLong2, (int)(j * 1.4D));
      param038.A0B = arrayOfLong1;
    } 
    i = param038.A02;
    param038.A02 = i + 1;
    arrayOfLong1[i] = paramLong;
  }
  
  public final String A02(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield A03 : I
    //   6: ifne -> 13
    //   9: aload_0
    //   10: monitorexit
    //   11: aconst_null
    //   12: areturn
    //   13: aconst_null
    //   14: astore #11
    //   16: iconst_0
    //   17: istore #5
    //   19: iconst_0
    //   20: istore_3
    //   21: iconst_0
    //   22: istore #6
    //   24: iconst_0
    //   25: istore #4
    //   27: iload #5
    //   29: aload_0
    //   30: getfield A03 : I
    //   33: if_icmpge -> 475
    //   36: aload_1
    //   37: aload_0
    //   38: getfield A05 : Ljava/util/ArrayList;
    //   41: iload #5
    //   43: invokevirtual get : (I)Ljava/lang/Object;
    //   46: invokevirtual equals : (Ljava/lang/Object;)Z
    //   49: istore #8
    //   51: aload_0
    //   52: getfield A09 : [B
    //   55: astore #12
    //   57: aload #12
    //   59: iload #5
    //   61: baload
    //   62: tableswitch default -> 484, 1 -> 424, 2 -> 394, 3 -> 365, 4 -> 333, 5 -> 301, 6 -> 272, 7 -> 240, 8 -> 194, 9 -> 162, 10 -> 130
    //   116: ldc 'Unsupported type '
    //   118: aload #12
    //   120: iload #5
    //   122: baload
    //   123: invokestatic A0Z : (Ljava/lang/String;I)Ljava/lang/String;
    //   126: invokestatic A0x : (Ljava/lang/String;)Ljava/lang/UnsupportedOperationException;
    //   129: athrow
    //   130: iload #8
    //   132: ifeq -> 515
    //   135: aload_0
    //   136: getfield A06 : Ljava/util/ArrayList;
    //   139: astore #11
    //   141: iload_3
    //   142: iconst_1
    //   143: iadd
    //   144: istore_2
    //   145: aload #11
    //   147: iload_3
    //   148: invokevirtual get : (I)Ljava/lang/Object;
    //   151: checkcast [J
    //   154: invokestatic A02 : ([J)Ljava/lang/String;
    //   157: astore #11
    //   159: goto -> 507
    //   162: iload #8
    //   164: ifeq -> 515
    //   167: aload_0
    //   168: getfield A06 : Ljava/util/ArrayList;
    //   171: astore #11
    //   173: iload_3
    //   174: iconst_1
    //   175: iadd
    //   176: istore_2
    //   177: aload #11
    //   179: iload_3
    //   180: invokevirtual get : (I)Ljava/lang/Object;
    //   183: checkcast [Z
    //   186: invokestatic A04 : ([Z)Ljava/lang/String;
    //   189: astore #11
    //   191: goto -> 507
    //   194: iload #8
    //   196: ifeq -> 499
    //   199: aload_0
    //   200: getfield A0B : [J
    //   203: astore #11
    //   205: iload #6
    //   207: iconst_1
    //   208: iadd
    //   209: istore_2
    //   210: aload #11
    //   212: iload #6
    //   214: laload
    //   215: lstore #9
    //   217: iconst_0
    //   218: istore #7
    //   220: lload #9
    //   222: lconst_0
    //   223: lcmp
    //   224: ifeq -> 230
    //   227: iconst_1
    //   228: istore #7
    //   230: iload #7
    //   232: invokestatic toString : (Z)Ljava/lang/String;
    //   235: astore #11
    //   237: goto -> 525
    //   240: iload #8
    //   242: ifeq -> 515
    //   245: aload_0
    //   246: getfield A06 : Ljava/util/ArrayList;
    //   249: astore #11
    //   251: iload_3
    //   252: iconst_1
    //   253: iadd
    //   254: istore_2
    //   255: aload #11
    //   257: iload_3
    //   258: invokevirtual get : (I)Ljava/lang/Object;
    //   261: checkcast [D
    //   264: invokestatic A00 : ([D)Ljava/lang/String;
    //   267: astore #11
    //   269: goto -> 507
    //   272: iload #8
    //   274: ifeq -> 487
    //   277: aload_0
    //   278: getfield A0A : [D
    //   281: iload #4
    //   283: daload
    //   284: invokestatic toString : (D)Ljava/lang/String;
    //   287: astore #11
    //   289: iload #4
    //   291: iconst_1
    //   292: iadd
    //   293: istore #4
    //   295: iload #6
    //   297: istore_2
    //   298: goto -> 453
    //   301: iload #8
    //   303: ifeq -> 515
    //   306: aload_0
    //   307: getfield A06 : Ljava/util/ArrayList;
    //   310: astore #11
    //   312: iload_3
    //   313: iconst_1
    //   314: iadd
    //   315: istore_2
    //   316: aload #11
    //   318: iload_3
    //   319: invokevirtual get : (I)Ljava/lang/Object;
    //   322: checkcast [I
    //   325: invokestatic A01 : ([I)Ljava/lang/String;
    //   328: astore #11
    //   330: goto -> 507
    //   333: iload #8
    //   335: ifeq -> 515
    //   338: aload_0
    //   339: getfield A06 : Ljava/util/ArrayList;
    //   342: astore #11
    //   344: iload_3
    //   345: iconst_1
    //   346: iadd
    //   347: istore_2
    //   348: aload #11
    //   350: iload_3
    //   351: invokevirtual get : (I)Ljava/lang/Object;
    //   354: checkcast [Ljava/lang/String;
    //   357: invokestatic A03 : ([Ljava/lang/String;)Ljava/lang/String;
    //   360: astore #11
    //   362: goto -> 507
    //   365: iload #8
    //   367: ifeq -> 499
    //   370: aload_0
    //   371: getfield A0B : [J
    //   374: astore #11
    //   376: iload #6
    //   378: iconst_1
    //   379: iadd
    //   380: istore_2
    //   381: aload #11
    //   383: iload #6
    //   385: laload
    //   386: invokestatic toString : (J)Ljava/lang/String;
    //   389: astore #11
    //   391: goto -> 525
    //   394: iload #8
    //   396: ifeq -> 499
    //   399: aload_0
    //   400: getfield A0B : [J
    //   403: astore #11
    //   405: iload #6
    //   407: iconst_1
    //   408: iadd
    //   409: istore_2
    //   410: aload #11
    //   412: iload #6
    //   414: laload
    //   415: l2i
    //   416: invokestatic toString : (I)Ljava/lang/String;
    //   419: astore #11
    //   421: goto -> 525
    //   424: iload #8
    //   426: ifeq -> 515
    //   429: aload_0
    //   430: getfield A06 : Ljava/util/ArrayList;
    //   433: astore #11
    //   435: iload_3
    //   436: iconst_1
    //   437: iadd
    //   438: istore_2
    //   439: aload #11
    //   441: iload_3
    //   442: invokevirtual get : (I)Ljava/lang/Object;
    //   445: checkcast java/lang/String
    //   448: astore #11
    //   450: goto -> 507
    //   453: iload #8
    //   455: ifeq -> 463
    //   458: aload_0
    //   459: monitorexit
    //   460: aload #11
    //   462: areturn
    //   463: iload #5
    //   465: iconst_1
    //   466: iadd
    //   467: istore #5
    //   469: iload_2
    //   470: istore #6
    //   472: goto -> 27
    //   475: aload_0
    //   476: monitorexit
    //   477: aconst_null
    //   478: areturn
    //   479: astore_1
    //   480: aload_0
    //   481: monitorexit
    //   482: aload_1
    //   483: athrow
    //   484: goto -> 116
    //   487: iload #4
    //   489: iconst_1
    //   490: iadd
    //   491: istore #4
    //   493: iload #6
    //   495: istore_2
    //   496: goto -> 453
    //   499: iload #6
    //   501: iconst_1
    //   502: iadd
    //   503: istore_2
    //   504: goto -> 453
    //   507: iload_2
    //   508: istore_3
    //   509: iload #6
    //   511: istore_2
    //   512: goto -> 453
    //   515: iload_3
    //   516: iconst_1
    //   517: iadd
    //   518: istore_3
    //   519: iload #6
    //   521: istore_2
    //   522: goto -> 453
    //   525: goto -> 453
    // Exception table:
    //   from	to	target	type
    //   2	9	479	finally
    //   27	57	479	finally
    //   116	130	479	finally
    //   135	141	479	finally
    //   145	159	479	finally
    //   167	173	479	finally
    //   177	191	479	finally
    //   199	205	479	finally
    //   230	237	479	finally
    //   245	251	479	finally
    //   255	269	479	finally
    //   277	289	479	finally
    //   306	312	479	finally
    //   316	330	479	finally
    //   338	344	479	finally
    //   348	362	479	finally
    //   370	376	479	finally
    //   381	391	479	finally
    //   399	405	479	finally
    //   410	421	479	finally
    //   429	435	479	finally
    //   439	450	479	finally
  }
  
  public final List A03() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield A07 : Ljava/util/List;
    //   6: astore #4
    //   8: aload #4
    //   10: astore_3
    //   11: aload #4
    //   13: ifnonnull -> 74
    //   16: aload_0
    //   17: getfield A03 : I
    //   20: istore_2
    //   21: iload_2
    //   22: ifne -> 32
    //   25: invokestatic emptyList : ()Ljava/util/List;
    //   28: astore_3
    //   29: goto -> 74
    //   32: new java/util/ArrayList
    //   35: dup
    //   36: iload_2
    //   37: invokespecial <init> : (I)V
    //   40: astore_3
    //   41: iconst_0
    //   42: istore_1
    //   43: iload_1
    //   44: iload_2
    //   45: if_icmpge -> 69
    //   48: aload_3
    //   49: aload_0
    //   50: getfield A09 : [B
    //   53: iload_1
    //   54: baload
    //   55: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   58: invokevirtual add : (Ljava/lang/Object;)Z
    //   61: pop
    //   62: iload_1
    //   63: iconst_1
    //   64: iadd
    //   65: istore_1
    //   66: goto -> 43
    //   69: aload_0
    //   70: aload_3
    //   71: putfield A07 : Ljava/util/List;
    //   74: aload_0
    //   75: monitorexit
    //   76: aload_3
    //   77: areturn
    //   78: astore_3
    //   79: aload_0
    //   80: monitorexit
    //   81: aload_3
    //   82: athrow
    // Exception table:
    //   from	to	target	type
    //   2	8	78	finally
    //   16	21	78	finally
    //   25	29	78	finally
    //   32	41	78	finally
    //   48	62	78	finally
    //   69	74	78	finally
  }
  
  public final List A04() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield A08 : Ljava/util/List;
    //   6: astore #10
    //   8: aload #10
    //   10: astore #9
    //   12: aload #10
    //   14: ifnonnull -> 480
    //   17: aload_0
    //   18: getfield A03 : I
    //   21: istore_1
    //   22: iload_1
    //   23: ifne -> 34
    //   26: invokestatic emptyList : ()Ljava/util/List;
    //   29: astore #9
    //   31: goto -> 480
    //   34: new java/util/ArrayList
    //   37: dup
    //   38: iload_1
    //   39: iconst_2
    //   40: imul
    //   41: invokespecial <init> : (I)V
    //   44: astore #10
    //   46: iconst_0
    //   47: istore_3
    //   48: iconst_0
    //   49: istore_1
    //   50: iconst_0
    //   51: istore_2
    //   52: iconst_0
    //   53: istore #4
    //   55: iload_3
    //   56: aload_0
    //   57: getfield A03 : I
    //   60: if_icmpge -> 470
    //   63: aload_0
    //   64: getfield A09 : [B
    //   67: astore #9
    //   69: aload #9
    //   71: iload_3
    //   72: baload
    //   73: tableswitch default -> 492, 1 -> 413, 2 -> 386, 3 -> 360, 4 -> 329, 5 -> 298, 6 -> 277, 7 -> 246, 8 -> 203, 9 -> 172, 10 -> 141
    //   128: ldc 'Unsupported type '
    //   130: aload #9
    //   132: iload_3
    //   133: baload
    //   134: invokestatic A0Z : (Ljava/lang/String;I)Ljava/lang/String;
    //   137: invokestatic A0x : (Ljava/lang/String;)Ljava/lang/UnsupportedOperationException;
    //   140: athrow
    //   141: aload_0
    //   142: getfield A06 : Ljava/util/ArrayList;
    //   145: astore #9
    //   147: iload_1
    //   148: iconst_1
    //   149: iadd
    //   150: istore #5
    //   152: aload #9
    //   154: iload_1
    //   155: invokevirtual get : (I)Ljava/lang/Object;
    //   158: checkcast [J
    //   161: invokestatic A02 : ([J)Ljava/lang/String;
    //   164: astore #9
    //   166: iload #5
    //   168: istore_1
    //   169: goto -> 438
    //   172: aload_0
    //   173: getfield A06 : Ljava/util/ArrayList;
    //   176: astore #9
    //   178: iload_1
    //   179: iconst_1
    //   180: iadd
    //   181: istore #5
    //   183: aload #9
    //   185: iload_1
    //   186: invokevirtual get : (I)Ljava/lang/Object;
    //   189: checkcast [Z
    //   192: invokestatic A04 : ([Z)Ljava/lang/String;
    //   195: astore #9
    //   197: iload #5
    //   199: istore_1
    //   200: goto -> 438
    //   203: aload_0
    //   204: getfield A0B : [J
    //   207: astore #9
    //   209: iload_2
    //   210: iconst_1
    //   211: iadd
    //   212: istore #5
    //   214: aload #9
    //   216: iload_2
    //   217: laload
    //   218: lstore #6
    //   220: iconst_0
    //   221: istore #8
    //   223: lload #6
    //   225: lconst_0
    //   226: lcmp
    //   227: ifeq -> 233
    //   230: iconst_1
    //   231: istore #8
    //   233: iload #8
    //   235: invokestatic toString : (Z)Ljava/lang/String;
    //   238: astore #9
    //   240: iload #5
    //   242: istore_2
    //   243: goto -> 495
    //   246: aload_0
    //   247: getfield A06 : Ljava/util/ArrayList;
    //   250: astore #9
    //   252: iload_1
    //   253: iconst_1
    //   254: iadd
    //   255: istore #5
    //   257: aload #9
    //   259: iload_1
    //   260: invokevirtual get : (I)Ljava/lang/Object;
    //   263: checkcast [D
    //   266: invokestatic A00 : ([D)Ljava/lang/String;
    //   269: astore #9
    //   271: iload #5
    //   273: istore_1
    //   274: goto -> 438
    //   277: aload_0
    //   278: getfield A0A : [D
    //   281: iload #4
    //   283: daload
    //   284: invokestatic toString : (D)Ljava/lang/String;
    //   287: astore #9
    //   289: iload #4
    //   291: iconst_1
    //   292: iadd
    //   293: istore #4
    //   295: goto -> 438
    //   298: aload_0
    //   299: getfield A06 : Ljava/util/ArrayList;
    //   302: astore #9
    //   304: iload_1
    //   305: iconst_1
    //   306: iadd
    //   307: istore #5
    //   309: aload #9
    //   311: iload_1
    //   312: invokevirtual get : (I)Ljava/lang/Object;
    //   315: checkcast [I
    //   318: invokestatic A01 : ([I)Ljava/lang/String;
    //   321: astore #9
    //   323: iload #5
    //   325: istore_1
    //   326: goto -> 438
    //   329: aload_0
    //   330: getfield A06 : Ljava/util/ArrayList;
    //   333: astore #9
    //   335: iload_1
    //   336: iconst_1
    //   337: iadd
    //   338: istore #5
    //   340: aload #9
    //   342: iload_1
    //   343: invokevirtual get : (I)Ljava/lang/Object;
    //   346: checkcast [Ljava/lang/String;
    //   349: invokestatic A03 : ([Ljava/lang/String;)Ljava/lang/String;
    //   352: astore #9
    //   354: iload #5
    //   356: istore_1
    //   357: goto -> 438
    //   360: aload_0
    //   361: getfield A0B : [J
    //   364: astore #9
    //   366: iload_2
    //   367: iconst_1
    //   368: iadd
    //   369: istore #5
    //   371: aload #9
    //   373: iload_2
    //   374: laload
    //   375: invokestatic toString : (J)Ljava/lang/String;
    //   378: astore #9
    //   380: iload #5
    //   382: istore_2
    //   383: goto -> 495
    //   386: aload_0
    //   387: getfield A0B : [J
    //   390: astore #9
    //   392: iload_2
    //   393: iconst_1
    //   394: iadd
    //   395: istore #5
    //   397: aload #9
    //   399: iload_2
    //   400: laload
    //   401: l2i
    //   402: invokestatic toString : (I)Ljava/lang/String;
    //   405: astore #9
    //   407: iload #5
    //   409: istore_2
    //   410: goto -> 495
    //   413: aload_0
    //   414: getfield A06 : Ljava/util/ArrayList;
    //   417: astore #9
    //   419: iload_1
    //   420: iconst_1
    //   421: iadd
    //   422: istore #5
    //   424: aload #9
    //   426: iload_1
    //   427: invokevirtual get : (I)Ljava/lang/Object;
    //   430: checkcast java/lang/String
    //   433: astore #9
    //   435: iload #5
    //   437: istore_1
    //   438: aload #10
    //   440: aload_0
    //   441: getfield A05 : Ljava/util/ArrayList;
    //   444: iload_3
    //   445: invokevirtual get : (I)Ljava/lang/Object;
    //   448: checkcast java/lang/String
    //   451: invokevirtual add : (Ljava/lang/Object;)Z
    //   454: pop
    //   455: aload #10
    //   457: aload #9
    //   459: invokevirtual add : (Ljava/lang/Object;)Z
    //   462: pop
    //   463: iload_3
    //   464: iconst_1
    //   465: iadd
    //   466: istore_3
    //   467: goto -> 55
    //   470: aload_0
    //   471: aload #10
    //   473: putfield A08 : Ljava/util/List;
    //   476: aload #10
    //   478: astore #9
    //   480: aload_0
    //   481: monitorexit
    //   482: aload #9
    //   484: areturn
    //   485: astore #9
    //   487: aload_0
    //   488: monitorexit
    //   489: aload #9
    //   491: athrow
    //   492: goto -> 128
    //   495: goto -> 438
    // Exception table:
    //   from	to	target	type
    //   2	8	485	finally
    //   17	22	485	finally
    //   26	31	485	finally
    //   34	46	485	finally
    //   55	69	485	finally
    //   128	141	485	finally
    //   141	147	485	finally
    //   152	166	485	finally
    //   172	178	485	finally
    //   183	197	485	finally
    //   203	209	485	finally
    //   233	240	485	finally
    //   246	252	485	finally
    //   257	271	485	finally
    //   277	289	485	finally
    //   298	304	485	finally
    //   309	323	485	finally
    //   329	335	485	finally
    //   340	354	485	finally
    //   360	366	485	finally
    //   371	380	485	finally
    //   386	392	485	finally
    //   397	407	485	finally
    //   413	419	485	finally
    //   424	435	485	finally
    //   438	463	485	finally
    //   470	476	485	finally
  }
  
  public final void A05(String paramString1, String paramString2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aconst_null
    //   4: putfield A08 : Ljava/util/List;
    //   7: aload_0
    //   8: aconst_null
    //   9: putfield A07 : Ljava/util/List;
    //   12: aload_0
    //   13: getfield A05 : Ljava/util/ArrayList;
    //   16: aload_1
    //   17: invokevirtual add : (Ljava/lang/Object;)Z
    //   20: pop
    //   21: aload_0
    //   22: getfield A06 : Ljava/util/ArrayList;
    //   25: aload_2
    //   26: invokevirtual add : (Ljava/lang/Object;)Z
    //   29: pop
    //   30: aload_0
    //   31: iconst_1
    //   32: invokestatic A00 : (LX/038;B)V
    //   35: aload_0
    //   36: monitorexit
    //   37: return
    //   38: astore_1
    //   39: aload_0
    //   40: monitorexit
    //   41: aload_1
    //   42: athrow
    // Exception table:
    //   from	to	target	type
    //   2	35	38	finally
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\038.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */