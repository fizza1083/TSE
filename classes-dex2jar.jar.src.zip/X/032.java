package X;

import com.facebook.acra.anr.ANRReportProvider;
import java.util.HashMap;

public final class 032 implements ANRReportProvider {
  public 032(02U param02U) {}
  
  public final void reportSoftError(String paramString, Throwable paramThrowable) {
    HashMap<String, String> hashMap = 001.A11();
    hashMap.put("anr_error_msg", paramString);
    0tB.A00().Ci5("ANRReportProvider", paramThrowable, hashMap);
  }
  
  public final boolean shouldCollectAndUploadANRReports() {
    return this.A00.A0D;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\032.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */