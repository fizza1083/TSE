package X;

public final class 07q {
  public float A00;
  
  public float A01;
  
  public int A02;
  
  public Object A03;
  
  public boolean A04;
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */