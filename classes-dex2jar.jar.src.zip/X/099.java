package X;

import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class 099 {
  public Integer A00;
  
  public Integer A01;
  
  public boolean A02;
  
  public boolean A03;
  
  public boolean A04;
  
  public boolean A05;
  
  public boolean A06;
  
  public final Fragment A07;
  
  public final 08v A08;
  
  public final List A09;
  
  public final List A0A;
  
  public final List A0B;
  
  public 099(08v param08v, Integer paramInteger1, Integer paramInteger2) {
    this.A00 = paramInteger1;
    this.A01 = paramInteger2;
    this.A07 = fragment;
    this.A0A = new ArrayList();
    this.A02 = true;
    ArrayList arrayList = new ArrayList();
    this.A09 = arrayList;
    this.A0B = arrayList;
    this.A08 = param08v;
  }
  
  public final void A00() {
    this.A06 = false;
    if (!this.A04) {
      this.A04 = true;
      Iterator<Runnable> iterator = this.A0A.iterator();
      while (iterator.hasNext())
        ((Runnable)iterator.next()).run(); 
    } 
    this.A07.mTransitioning = false;
    this.A08.A04();
  }
  
  public final void A01(ViewGroup paramViewGroup) {
    this.A06 = false;
    if (!this.A03) {
      this.A03 = true;
      if (this.A09.isEmpty()) {
        A00();
        return;
      } 
    } else {
      return;
    } 
    Iterator<0X9> iterator = 0Xa.A0V(this.A0B).iterator();
    while (true) {
      if (iterator.hasNext()) {
        0X9 0X9 = iterator.next();
        if (!0X9.A00)
          0X9.A04(paramViewGroup); 
        0X9.A00 = true;
        continue;
      } 
      return;
    } 
  }
  
  public final void A02(0X9 param0X9) {
    List list = this.A09;
    if (list.remove(param0X9) && list.isEmpty())
      A00(); 
  }
  
  public final void A03(Integer paramInteger1, Integer paramInteger2) {
    16F.A0E(paramInteger1, 0);
    int i = paramInteger2.intValue();
    if (i != 1) {
      if (i != 2) {
        if (i == 0 && this.A00 != 0Xy.A00) {
          if (0Cy.A0H(2))
            paramInteger1.intValue(); 
          this.A00 = paramInteger1;
        } 
        return;
      } 
      this.A00 = 0Xy.A00;
      paramInteger1 = 0Xy.A0C;
    } else if (this.A00 == 0Xy.A00) {
      paramInteger1 = 0Xy.A01;
      this.A00 = paramInteger1;
    } else {
      return;
    } 
    this.A01 = paramInteger1;
    this.A02 = true;
  }
  
  public final String toString() {
    String str = Integer.toHexString(System.identityHashCode(this));
    StringBuilder stringBuilder = 001.A0s();
    stringBuilder.append("Operation {");
    stringBuilder.append(str);
    stringBuilder.append("} {finalState = ");
    switch (this.A00.intValue()) {
      default:
        str = "INVISIBLE";
        stringBuilder.append(str);
        stringBuilder.append(" lifecycleImpact = ");
        switch (this.A01.intValue()) {
          default:
            str = "REMOVING";
            stringBuilder.append(str);
            stringBuilder.append(" fragment = ");
            stringBuilder.append(this.A07);
            return 002.A0X(stringBuilder);
          case 0:
            str = "NONE";
            stringBuilder.append(str);
            stringBuilder.append(" fragment = ");
            stringBuilder.append(this.A07);
            return 002.A0X(stringBuilder);
          case 1:
            break;
        } 
        str = "ADDING";
        stringBuilder.append(str);
        stringBuilder.append(" fragment = ");
        stringBuilder.append(this.A07);
        return 002.A0X(stringBuilder);
      case 0:
        str = "REMOVED";
        stringBuilder.append(str);
        stringBuilder.append(" lifecycleImpact = ");
        switch (this.A01.intValue()) {
          default:
            str = "REMOVING";
            stringBuilder.append(str);
            stringBuilder.append(" fragment = ");
            stringBuilder.append(this.A07);
            return 002.A0X(stringBuilder);
          case 0:
            str = "NONE";
            stringBuilder.append(str);
            stringBuilder.append(" fragment = ");
            stringBuilder.append(this.A07);
            return 002.A0X(stringBuilder);
          case 1:
            break;
        } 
        str = "ADDING";
        stringBuilder.append(str);
        stringBuilder.append(" fragment = ");
        stringBuilder.append(this.A07);
        return 002.A0X(stringBuilder);
      case 2:
        str = "GONE";
        stringBuilder.append(str);
        stringBuilder.append(" lifecycleImpact = ");
        switch (this.A01.intValue()) {
          default:
            str = "REMOVING";
            stringBuilder.append(str);
            stringBuilder.append(" fragment = ");
            stringBuilder.append(this.A07);
            return 002.A0X(stringBuilder);
          case 0:
            str = "NONE";
            stringBuilder.append(str);
            stringBuilder.append(" fragment = ");
            stringBuilder.append(this.A07);
            return 002.A0X(stringBuilder);
          case 1:
            break;
        } 
        str = "ADDING";
        stringBuilder.append(str);
        stringBuilder.append(" fragment = ");
        stringBuilder.append(this.A07);
        return 002.A0X(stringBuilder);
      case 1:
        break;
    } 
    str = "VISIBLE";
    stringBuilder.append(str);
    stringBuilder.append(" lifecycleImpact = ");
    switch (this.A01.intValue()) {
      default:
        str = "REMOVING";
        stringBuilder.append(str);
        stringBuilder.append(" fragment = ");
        stringBuilder.append(this.A07);
        return 002.A0X(stringBuilder);
      case 0:
        str = "NONE";
        stringBuilder.append(str);
        stringBuilder.append(" fragment = ");
        stringBuilder.append(this.A07);
        return 002.A0X(stringBuilder);
      case 1:
        break;
    } 
    str = "ADDING";
    stringBuilder.append(str);
    stringBuilder.append(" fragment = ");
    stringBuilder.append(this.A07);
    return 002.A0X(stringBuilder);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\099.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */