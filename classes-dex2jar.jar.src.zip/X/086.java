package X;

import java.lang.reflect.Array;

public final class 086 {
  public int A00;
  
  public long A01;
  
  public Object[] A02;
  
  public final int A03;
  
  public final int A04;
  
  public final 0p4 A05;
  
  public final Class A06;
  
  public final int A07;
  
  public final 085 A08;
  
  public 086(085 param085, 0p4 param0p4, Class<?> paramClass, int paramInt1, int paramInt2) {
    this.A06 = paramClass;
    paramInt1 = Math.max(paramInt1, 0);
    this.A04 = paramInt1;
    this.A07 = Math.max(paramInt1, 1024);
    this.A03 = Math.max(paramInt2, 1);
    this.A08 = param085;
    this.A05 = param0p4;
    this.A02 = (Object[])Array.newInstance(paramClass, paramInt1);
  }
  
  public final Object A00() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield A00 : I
    //   6: istore_1
    //   7: iload_1
    //   8: ifle -> 44
    //   11: iload_1
    //   12: iconst_1
    //   13: isub
    //   14: istore_1
    //   15: aload_0
    //   16: iload_1
    //   17: putfield A00 : I
    //   20: aload_0
    //   21: getfield A02 : [Ljava/lang/Object;
    //   24: astore_3
    //   25: aload_3
    //   26: iload_1
    //   27: aaload
    //   28: astore_2
    //   29: aload_3
    //   30: iload_1
    //   31: aconst_null
    //   32: aastore
    //   33: aload_0
    //   34: getfield A08 : LX/085;
    //   37: aload_2
    //   38: invokevirtual A01 : (Ljava/lang/Object;)V
    //   41: goto -> 55
    //   44: aload_0
    //   45: getfield A08 : LX/085;
    //   48: invokevirtual A00 : ()Ljava/lang/Object;
    //   51: astore_2
    //   52: goto -> 33
    //   55: aload_0
    //   56: monitorexit
    //   57: aload_2
    //   58: areturn
    //   59: astore_2
    //   60: aload_0
    //   61: monitorexit
    //   62: aload_2
    //   63: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	59	finally
    //   15	25	59	finally
    //   33	41	59	finally
    //   44	52	59	finally
  }
  
  public final void A01(Object paramObject) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield A05 : LX/0p4;
    //   6: invokeinterface now : ()J
    //   11: lstore #7
    //   13: aload_0
    //   14: getfield A00 : I
    //   17: istore_2
    //   18: aload_0
    //   19: getfield A03 : I
    //   22: istore #4
    //   24: iload_2
    //   25: iload #4
    //   27: iconst_2
    //   28: imul
    //   29: if_icmpge -> 38
    //   32: aload_0
    //   33: lload #7
    //   35: putfield A01 : J
    //   38: lload #7
    //   40: aload_0
    //   41: getfield A01 : J
    //   44: lsub
    //   45: ldc2_w 60000
    //   48: lcmp
    //   49: ifle -> 134
    //   52: aload_0
    //   53: getfield A02 : [Ljava/lang/Object;
    //   56: arraylength
    //   57: istore_2
    //   58: iload_2
    //   59: iload #4
    //   61: isub
    //   62: aload_0
    //   63: getfield A04 : I
    //   66: invokestatic max : (II)I
    //   69: istore_3
    //   70: iload_3
    //   71: iload_2
    //   72: if_icmpeq -> 134
    //   75: aload_0
    //   76: getfield A06 : Ljava/lang/Class;
    //   79: iload_3
    //   80: invokestatic newInstance : (Ljava/lang/Class;I)Ljava/lang/Object;
    //   83: checkcast [Ljava/lang/Object;
    //   86: astore #9
    //   88: aload_0
    //   89: getfield A02 : [Ljava/lang/Object;
    //   92: astore #10
    //   94: aload #10
    //   96: iconst_0
    //   97: aload #9
    //   99: iconst_0
    //   100: aload #10
    //   102: arraylength
    //   103: iload_3
    //   104: invokestatic min : (II)I
    //   107: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   110: aload_0
    //   111: aload #9
    //   113: putfield A02 : [Ljava/lang/Object;
    //   116: aload_0
    //   117: aload_0
    //   118: getfield A00 : I
    //   121: iload_3
    //   122: invokestatic min : (II)I
    //   125: putfield A00 : I
    //   128: goto -> 134
    //   131: astore_1
    //   132: aload_1
    //   133: athrow
    //   134: aload_0
    //   135: getfield A08 : LX/085;
    //   138: aload_1
    //   139: invokevirtual A02 : (Ljava/lang/Object;)V
    //   142: aload_0
    //   143: getfield A00 : I
    //   146: istore_3
    //   147: aload_0
    //   148: getfield A07 : I
    //   151: istore #5
    //   153: iload_3
    //   154: iload #5
    //   156: if_icmpge -> 258
    //   159: aload_0
    //   160: getfield A02 : [Ljava/lang/Object;
    //   163: astore #9
    //   165: aload #9
    //   167: arraylength
    //   168: istore #6
    //   170: iload_3
    //   171: istore_2
    //   172: iload_3
    //   173: iconst_1
    //   174: iadd
    //   175: iload #6
    //   177: if_icmple -> 246
    //   180: iload #5
    //   182: iload #6
    //   184: iload #4
    //   186: iadd
    //   187: invokestatic min : (II)I
    //   190: istore_2
    //   191: aload_0
    //   192: getfield A06 : Ljava/lang/Class;
    //   195: iload_2
    //   196: invokestatic newInstance : (Ljava/lang/Class;I)Ljava/lang/Object;
    //   199: checkcast [Ljava/lang/Object;
    //   202: astore #9
    //   204: aload_0
    //   205: getfield A02 : [Ljava/lang/Object;
    //   208: astore #10
    //   210: aload #10
    //   212: iconst_0
    //   213: aload #9
    //   215: iconst_0
    //   216: aload #10
    //   218: arraylength
    //   219: iload_2
    //   220: invokestatic min : (II)I
    //   223: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   226: aload_0
    //   227: aload #9
    //   229: putfield A02 : [Ljava/lang/Object;
    //   232: aload_0
    //   233: getfield A00 : I
    //   236: iload_2
    //   237: invokestatic min : (II)I
    //   240: istore_2
    //   241: aload_0
    //   242: iload_2
    //   243: putfield A00 : I
    //   246: aload_0
    //   247: iload_2
    //   248: iconst_1
    //   249: iadd
    //   250: putfield A00 : I
    //   253: aload #9
    //   255: iload_2
    //   256: aload_1
    //   257: aastore
    //   258: aload_0
    //   259: monitorexit
    //   260: return
    //   261: astore_1
    //   262: aload_1
    //   263: athrow
    //   264: astore_1
    //   265: aload_0
    //   266: monitorexit
    //   267: aload_1
    //   268: athrow
    // Exception table:
    //   from	to	target	type
    //   2	24	261	finally
    //   32	38	261	finally
    //   38	52	261	finally
    //   52	70	131	finally
    //   75	128	131	finally
    //   132	134	261	finally
    //   134	153	264	finally
    //   159	170	264	finally
    //   180	246	264	finally
    //   246	253	264	finally
    //   262	264	264	finally
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\086.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */