package X;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public abstract class 01l extends 01m {
  public static final Object A00(Object paramObject, Map paramMap) {
    16F.A0E(paramMap, 0);
    return 01n.A0H(paramObject, paramMap);
  }
  
  public static final HashMap A01(0BW... paramVarArgs) {
    int j = paramVarArgs.length;
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>(01m.A0D(j));
    for (int i = 0; i < j; i++) {
      0BW 0BW1 = paramVarArgs[i];
      hashMap.put(0BW1.first, 0BW1.second);
    } 
    return hashMap;
  }
  
  public static final LinkedHashMap A02(Map<?, ?> paramMap) {
    16F.A0E(paramMap, 0);
    return new LinkedHashMap<Object, Object>(paramMap);
  }
  
  public static final LinkedHashMap A03(Map<?, ?> paramMap1, Map<?, ?> paramMap2) {
    16F.A0E(paramMap1, 0);
    16F.A0E(paramMap2, 1);
    paramMap1 = new LinkedHashMap<Object, Object>(paramMap1);
    paramMap1.putAll(paramMap2);
    return (LinkedHashMap)paramMap1;
  }
  
  public static final LinkedHashMap A04(0BW... paramVarArgs) {
    int j = paramVarArgs.length;
    LinkedHashMap<Object, Object> linkedHashMap = new LinkedHashMap<Object, Object>(01m.A0D(j));
    for (int i = 0; i < j; i++) {
      0BW 0BW1 = paramVarArgs[i];
      linkedHashMap.put(0BW1.first, 0BW1.second);
    } 
    return linkedHashMap;
  }
  
  public static final LinkedHashMap A05(0BW... paramVarArgs) {
    int j = paramVarArgs.length;
    LinkedHashMap<Object, Object> linkedHashMap = new LinkedHashMap<Object, Object>(01m.A0D(j));
    for (int i = 0; i < j; i++) {
      0BW 0BW1 = paramVarArgs[i];
      linkedHashMap.put(0BW1.first, 0BW1.second);
    } 
    return linkedHashMap;
  }
  
  public static final LinkedHashMap A06(0BW... paramVarArgs) {
    int j = paramVarArgs.length;
    LinkedHashMap<Object, Object> linkedHashMap = new LinkedHashMap<Object, Object>(01m.A0D(j));
    for (int i = 0; i < j; i++) {
      0BW 0BW1 = paramVarArgs[i];
      linkedHashMap.put(0BW1.first, 0BW1.second);
    } 
    return linkedHashMap;
  }
  
  public static final Map A07(Iterable<Iterable> paramIterable) {
    01o 01o;
    if (paramIterable instanceof Collection) {
      Collection collection = (Collection)paramIterable;
      int i = collection.size();
      if (i != 0) {
        if (i != 1) {
          LinkedHashMap<Object, Object> linkedHashMap1 = new LinkedHashMap<Object, Object>(01m.A0D(collection.size()));
          A0C(paramIterable, linkedHashMap1);
          return linkedHashMap1;
        } 
        if (paramIterable instanceof List) {
          paramIterable = ((List<Iterable>)paramIterable).get(0);
          return 01m.A0E((0BW)paramIterable);
        } 
        paramIterable = paramIterable.iterator().next();
        return 01m.A0E((0BW)paramIterable);
      } 
      01o = 01o.A00;
      16F.A0I(01o, "null cannot be cast to non-null type kotlin.collections.Map<K of kotlin.collections.MapsKt__MapsKt.emptyMap, V of kotlin.collections.MapsKt__MapsKt.emptyMap>");
      return 01o;
    } 
    LinkedHashMap linkedHashMap = 001.A18();
    A0C((Iterable)01o, linkedHashMap);
    return A08(linkedHashMap);
  }
  
  public static final Map A08(Map<?, ?> paramMap) {
    int i = paramMap.size();
    if (i != 0) {
      Map<?, ?> map = paramMap;
      if (i == 1) {
        Map.Entry entry = 001.A1A(001.A16(paramMap));
        map = Collections.singletonMap(entry.getKey(), entry.getValue());
        16F.A0A(map);
      } 
      return map;
    } 
    paramMap = 01o.A00;
    16F.A0I(paramMap, "null cannot be cast to non-null type kotlin.collections.Map<K of kotlin.collections.MapsKt__MapsKt.emptyMap, V of kotlin.collections.MapsKt__MapsKt.emptyMap>");
    return paramMap;
  }
  
  public static final Map A09(Map<?, ?> paramMap) {
    16F.A0E(paramMap, 0);
    int i = paramMap.size();
    if (i != 0) {
      if (i != 1)
        return new LinkedHashMap<Object, Object>(paramMap); 
      Map.Entry entry = paramMap.entrySet().iterator().next();
      Map<?, ?> map = Collections.singletonMap(entry.getKey(), entry.getValue());
      16F.A0A(map);
      return map;
    } 
    paramMap = 01o.A00;
    16F.A0I(paramMap, "null cannot be cast to non-null type kotlin.collections.Map<K of kotlin.collections.MapsKt__MapsKt.emptyMap, V of kotlin.collections.MapsKt__MapsKt.emptyMap>");
    return paramMap;
  }
  
  public static final Map A0A(Map<?, ?> paramMap, 0BW param0BW) {
    16F.A0E(paramMap, 0);
    if (paramMap.isEmpty())
      return 01m.A0E(param0BW); 
    paramMap = new LinkedHashMap<Object, Object>(paramMap);
    paramMap.put(param0BW.first, param0BW.second);
    return paramMap;
  }
  
  public static final 01o A0B() {
    01o 01o = 01o.A00;
    16F.A0I(01o, "null cannot be cast to non-null type kotlin.collections.Map<K of kotlin.collections.MapsKt__MapsKt.emptyMap, V of kotlin.collections.MapsKt__MapsKt.emptyMap>");
    return 01o;
  }
  
  public static final void A0C(Iterable paramIterable, Map<Object, Object> paramMap) {
    for (0BW 0BW : paramIterable)
      paramMap.put(0BW.first, 0BW.second); 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */