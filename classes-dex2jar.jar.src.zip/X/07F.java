package X;

public interface 07F {
  0Fa CL6(int paramInt);
  
  void DfS(long paramLong, int paramInt, boolean paramBoolean);
  
  void DfT(int paramInt, String paramString1, String paramString2);
  
  void DfU(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  void DfV(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  void DfW(int paramInt, String paramString1, String paramString2);
  
  void Dfp(0Fa param0Fa);
  
  void Dfq(0Fa param0Fa, String paramString, boolean paramBoolean);
  
  void Dfr(0Fa param0Fa);
  
  void Dfs(0Fa param0Fa, long paramLong);
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07F.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */