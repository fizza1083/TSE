package X;

import com.facebook.common.stringformat.StringFormatUtil;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.AbstractSet;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Set;

public final class 01v<E> extends AbstractSet<E> implements Set<E>, Cloneable, Serializable {
  public static final Object A03 = new 01w();
  
  public static final Object[] A04 = new Object[0];
  
  public static final long serialVersionUID = 0L;
  
  public transient int A00 = 0;
  
  public transient int A01 = 0;
  
  public transient Object[] A02;
  
  public int mSize = 0;
  
  public 01v() {
    float f = 0.0F / 0.75F;
    int i = (int)f;
    if (i >= 0) {
      Object[] arrayOfObject;
      if (i == 0) {
        arrayOfObject = A04;
      } else {
        arrayOfObject = new Object[i];
      } 
      this.A02 = arrayOfObject;
      return;
    } 
    throw 001.A0Z(StringFormatUtil.formatStrLocaleSafe("adjustedCapacity = %d, capacity = %d, LOAD_FACTOR = %s, (capacity / LOAD_FACTOR) = %s", Integer.valueOf(i), Integer.valueOf(0), Float.toString(0.75F), Float.toString(f)));
  }
  
  public static int A00(Object[] paramArrayOfObject, Object paramObject) {
    int m = paramArrayOfObject.length;
    int i = paramObject.hashCode();
    i += i << 15 ^ 0xFFFFCD7D;
    i ^= i >>> 10;
    i += i << 3;
    i ^= i >>> 6;
    i += (i << 2) + (i << 14);
    int k = ((i ^ i >>> 16) & Integer.MAX_VALUE) % m;
    int j = k;
    while (true) {
      Object object = paramArrayOfObject[j];
      i = j;
      if (object != null) {
        i = j;
        if (object != paramObject) {
          i = j;
          if (!object.equals(paramObject)) {
            i = ++j;
            if (j == m)
              i = 0; 
            j = i;
            if (i == k)
              break; 
            continue;
          } 
        } 
      } 
      break;
    } 
    return i;
  }
  
  private void readObject(ObjectInputStream paramObjectInputStream) {
    paramObjectInputStream.defaultReadObject();
    int i = paramObjectInputStream.readInt();
    paramObjectInputStream.readFloat();
    this.A02 = new Object[i];
    i = 0;
    this.mSize = 0;
    int j = paramObjectInputStream.readInt();
    while (i < j) {
      super.add((E)paramObjectInputStream.readObject());
      i++;
    } 
  }
  
  private void writeObject(ObjectOutputStream paramObjectOutputStream) {
    paramObjectOutputStream.defaultWriteObject();
    paramObjectOutputStream.writeInt(this.A02.length);
    paramObjectOutputStream.writeFloat(0.75F);
    paramObjectOutputStream.writeInt(super.size());
    for (int i = A01(-1); i >= 0; i = A01(i))
      paramObjectOutputStream.writeObject(getFromBackingArray(i)); 
  }
  
  public final int A01(int paramInt) {
    while (true) {
      int i = paramInt + 1;
      Object[] arrayOfObject = this.A02;
      if (i < arrayOfObject.length) {
        paramInt = i;
        if (arrayOfObject[i] != null)
          return i; 
        continue;
      } 
      return Integer.MIN_VALUE;
    } 
  }
  
  public final boolean add(Object paramObject) {
    int j = this.mSize;
    if (j >= this.A01) {
      this.A00++;
      Object[] arrayOfObject1 = this.A02;
      int i1 = arrayOfObject1.length;
      int m = 2;
      int n = i1 * 2;
      if (n != 0)
        m = n; 
      Object[] arrayOfObject2 = new Object[m];
      for (n = 0; n < i1; n++) {
        Object object1 = arrayOfObject1[n];
        if (object1 != null)
          arrayOfObject2[A00(arrayOfObject2, object1)] = object1; 
      } 
      this.A02 = arrayOfObject2;
      this.A01 = (int)(m * 0.75F);
    } 
    Object object = paramObject;
    if (paramObject == null)
      object = A03; 
    paramObject = this.A02;
    int k = paramObject.length;
    int i = object.hashCode();
    i += i << 15 ^ 0xFFFFCD7D;
    i ^= i >>> 10;
    i += i << 3;
    i ^= i >>> 6;
    i += (i << 2) + (i << 14);
    i = ((i ^ i >>> 16) & Integer.MAX_VALUE) % k;
    while (true) {
      Object object1 = paramObject[i];
      if (object1 == null) {
        this.mSize = j + 1;
        this.A00++;
        paramObject[i] = object;
        return true;
      } 
      if (object1 != object && !object1.equals(object)) {
        int m = i + 1;
        i = m;
        if (m == k)
          i = 0; 
        continue;
      } 
      break;
    } 
    return false;
  }
  
  public final void clear() {
    this.mSize = 0;
    Arrays.fill(this.A02, (Object)null);
    this.A00++;
  }
  
  public final Object clone() {
    try {
      01v 01v1 = (01v)super.clone();
      Object[] arrayOfObject1 = new Object[this.A02.length];
      01v1.A02 = arrayOfObject1;
      Object[] arrayOfObject2 = this.A02;
      System.arraycopy(arrayOfObject2, 0, arrayOfObject1, 0, arrayOfObject2.length);
      return 01v1;
    } catch (CloneNotSupportedException cloneNotSupportedException) {
      throw new AssertionError(cloneNotSupportedException);
    } 
  }
  
  public final boolean contains(Object paramObject) {
    Object[] arrayOfObject = this.A02;
    int i = arrayOfObject.length;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (i != 0) {
      Object object = paramObject;
      if (paramObject == null)
        object = A03; 
      bool1 = bool2;
      if (arrayOfObject[A00(arrayOfObject, object)] != null)
        bool1 = true; 
    } 
    return bool1;
  }
  
  public final boolean equals(Object paramObject) {
    if (paramObject != this)
      if (paramObject instanceof Set) {
        paramObject = paramObject;
        if (super.size() == paramObject.size()) {
          Object[] arrayOfObject = this.A02;
          int j = arrayOfObject.length;
          int i = 0;
          while (i < j) {
            Object object = arrayOfObject[i];
            if (object == null || paramObject.contains(object)) {
              i++;
              continue;
            } 
            return false;
          } 
        } else {
          return false;
        } 
      } else {
        return false;
      }  
    return true;
  }
  
  public Object getFromBackingArray(int paramInt) {
    Object object2 = this.A02[paramInt];
    Object object1 = object2;
    if (object2 == A03)
      object1 = null; 
    return object1;
  }
  
  public final int hashCode() {
    int i = A01(-1);
    int j = 0;
    while (i >= 0) {
      j += this.A02[i].hashCode();
      i = A01(i);
    } 
    return j;
  }
  
  public final boolean isEmpty() {
    int i = this.mSize;
    boolean bool = false;
    if (i == 0)
      bool = true; 
    return bool;
  }
  
  public final Iterator iterator() {
    return new 09w(this, this);
  }
  
  public final boolean remove(Object paramObject) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: fail exe a24 = a7\r\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:92)\r\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:1)\r\n\tat com.googlecode.dex2jar.ir.ts.Cfg.dfs(Cfg.java:255)\r\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze0(BaseAnalyze.java:75)\r\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze(BaseAnalyze.java:69)\r\n\tat com.googlecode.dex2jar.ir.ts.Ir2JRegAssignTransformer.transform(Ir2JRegAssignTransformer.java:182)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:164)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\nCaused by: java.lang.NullPointerException: Cannot assign field \"used\" because \"aValue\" is null\r\n\tat com.googlecode.dex2jar.ir.ts.an.SimpleLiveAnalyze.onUseLocal(SimpleLiveAnalyze.java:89)\r\n\tat com.googlecode.dex2jar.ir.ts.an.SimpleLiveAnalyze.onUseLocal(SimpleLiveAnalyze.java:1)\r\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.onUse(BaseAnalyze.java:166)\r\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.onUse(BaseAnalyze.java:1)\r\n\tat com.googlecode.dex2jar.ir.ts.Cfg.travel(Cfg.java:331)\r\n\tat com.googlecode.dex2jar.ir.ts.Cfg.travel(Cfg.java:387)\r\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:90)\r\n\t... 17 more\r\n");
  }
  
  public final int size() {
    return this.mSize;
  }
  
  public final Object[] toArray() {
    int i = super.size();
    if (i == 0)
      return A04; 
    Object[] arrayOfObject = new Object[i];
    i = 0;
    int j = A01(-1);
    while (true) {
      Object[] arrayOfObject1 = arrayOfObject;
      if (j >= 0) {
        arrayOfObject[i] = getFromBackingArray(j);
        j = A01(j);
        i++;
        continue;
      } 
      return arrayOfObject1;
    } 
  }
  
  public final Object[] toArray(Object[] paramArrayOfObject) {
    int k = super.size();
    Object[] arrayOfObject = paramArrayOfObject;
    if (paramArrayOfObject.length < k)
      arrayOfObject = (Object[])002.A0Q(paramArrayOfObject, k); 
    int i = 0;
    int j = A01(-1);
    while (j >= 0) {
      arrayOfObject[i] = getFromBackingArray(j);
      j = A01(j);
      i++;
    } 
    if (arrayOfObject.length > k)
      arrayOfObject[k] = null; 
    return arrayOfObject;
  }
  
  public final String toString() {
    if (super.isEmpty())
      return "{}"; 
    StringBuilder stringBuilder = 001.A0s();
    stringBuilder.append('{');
    boolean bool = true;
    for (int i = A01(-1); i >= 0; i = A01(i)) {
      Object object2 = this.A02[i];
      if (!bool)
        001.A1P(stringBuilder); 
      Object object1 = object2;
      if (object2 == A03)
        object1 = "null"; 
      stringBuilder.append(object1);
      bool = false;
    } 
    return 002.A0X(stringBuilder);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */