package X;

import java.util.List;
import java.util.Map;

public abstract class 08a {
  public 04L A00;
  
  public final void A0L(07A param07A, String paramString) {
    this.A00.ACE(param07A, paramString);
  }
  
  public final void A0M(08Z param08Z, String paramString) {
    this.A00.AEJ(param08Z, paramString);
  }
  
  public final void A0N(String paramString, Boolean paramBoolean) {
    this.A00.ABp(paramString, paramBoolean);
  }
  
  public final void A0O(String paramString, Long paramLong) {
    this.A00.AD3(paramString, paramLong);
  }
  
  public final void A0P(String paramString1, String paramString2) {
    this.A00.AEH(paramString1, paramString2);
  }
  
  public final void A0Q(String paramString, List paramList) {
    this.A00.AEl(paramString, paramList);
  }
  
  public final void A0R(String paramString, Map paramMap) {
    this.A00.AD5(paramString, paramMap);
  }
  
  public void CEm() {
    this.A00.CEm();
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */