package X;

import android.database.DataSetObserver;
import androidx.viewpager.widget.ViewPager;

public final class 08J extends DataSetObserver {
  public 08J(ViewPager paramViewPager) {}
  
  public final void onChanged() {
    this.A00.A0F();
  }
  
  public final void onInvalidated() {
    this.A00.A0F();
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08J.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */