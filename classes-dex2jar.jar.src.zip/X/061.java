package X;

public final class 061 {
  public final long A00;
  
  public final String A01;
  
  public final String A02;
  
  public final String A03;
  
  public 061(long paramLong, String paramString1, String paramString2, String paramString3) {
    this.A03 = paramString1;
    this.A02 = paramString2;
    this.A00 = paramLong;
    this.A01 = paramString3;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\061.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */