package X;

import com.facebook.quicklog.EventBuilder;
import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public final class 06A implements EventBuilder {
  public final int A00;
  
  public final int A01;
  
  public final String A02;
  
  public final ArrayList A03 = 001.A0y();
  
  public final 0Yr A04;
  
  public 06A(0Yr param0Yr, String paramString, int paramInt1, int paramInt2) {
    this.A04 = param0Yr;
    this.A01 = paramInt1;
    this.A00 = paramInt2;
    this.A02 = paramString;
  }
  
  public static void A00(Object paramObject, String paramString, AbstractCollection<06C> paramAbstractCollection, int paramInt) {
    paramAbstractCollection.add(new 06C(paramString, paramObject, paramInt));
  }
  
  public final EventBuilder annotate(String paramString, double paramDouble) {
    A00(Double.valueOf(paramDouble), paramString, this.A03, 5);
    return this;
  }
  
  public final EventBuilder annotate(String paramString, int paramInt) {
    A00(Integer.valueOf(paramInt), paramString, this.A03, 3);
    return this;
  }
  
  public final EventBuilder annotate(String paramString, long paramLong) {
    A00(Long.valueOf(paramLong), paramString, this.A03, 4);
    return this;
  }
  
  public final EventBuilder annotate(String paramString1, String paramString2) {
    A00(paramString2, paramString1, this.A03, 2);
    return this;
  }
  
  public final EventBuilder annotate(String paramString, boolean paramBoolean) {
    A00(Boolean.valueOf(paramBoolean), paramString, this.A03, 6);
    return this;
  }
  
  public final EventBuilder annotate(String paramString, double[] paramArrayOfdouble) {
    A00(paramArrayOfdouble, paramString, this.A03, 10);
    return this;
  }
  
  public final EventBuilder annotate(String paramString, int[] paramArrayOfint) {
    A00(paramArrayOfint, paramString, this.A03, 8);
    return this;
  }
  
  public final EventBuilder annotate(String paramString, long[] paramArrayOflong) {
    A00(paramArrayOflong, paramString, this.A03, 9);
    return this;
  }
  
  public final EventBuilder annotate(String paramString, String[] paramArrayOfString) {
    A00(paramArrayOfString, paramString, this.A03, 7);
    return this;
  }
  
  public final EventBuilder annotate(String paramString, boolean[] paramArrayOfboolean) {
    A00(paramArrayOfboolean, paramString, this.A03, 11);
    return this;
  }
  
  public final boolean isSampled() {
    return true;
  }
  
  public final void report() {
    0Yr.A02(this.A04, this, "", TimeUnit.MILLISECONDS, 14, 0, 0, 0L);
  }
  
  public final EventBuilder setActionId(short paramShort) {
    A00(Short.valueOf(paramShort), "", this.A03, 1);
    return this;
  }
  
  public final EventBuilder setLevel(int paramInt) {
    A00(Integer.valueOf(paramInt), "", this.A03, 0);
    return this;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\06A.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */