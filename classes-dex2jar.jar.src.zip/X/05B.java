package X;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

public abstract class 05B extends 05C {
  public transient 05D A00;
  
  public final 04I _context;
  
  public 05B(05D param05D) {
    this(param05D, 04I1);
  }
  
  public 05B(05D param05D, 04I param04I) {
    super(param05D);
    this._context = param04I;
  }
  
  public final void A08() {
    05D 05D1 = this.A00;
    if (05D1 != null && 05D1 != this) {
      16F.A0D(B2c().get(04K.A00));
      AtomicReferenceFieldUpdater<05D, 04o> atomicReferenceFieldUpdater = 05y.A04;
      do {
      
      } while (atomicReferenceFieldUpdater.get(05D1) == 062.A00);
      05D1 = (05D)atomicReferenceFieldUpdater.get(05D1);
      if (05D1 instanceof 0IT) {
        05D1 = 05D1;
        if (05D1 != null)
          05D1.A0F(); 
      } 
    } 
    this.A00 = 0IW.A00;
  }
  
  public 04I B2c() {
    04I 04I1 = this._context;
    16F.A0D(04I1);
    return 04I1;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\05B.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */