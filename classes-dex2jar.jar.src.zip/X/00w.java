package X;

import android.content.Context;

public class 00w {
  public final String A00;
  
  public final String A01;
  
  public final String A02;
  
  public final String A03;
  
  public 00w(String paramString1, String paramString2, String paramString3, String paramString4) {
    this.A02 = paramString1;
    this.A00 = paramString2;
    this.A01 = paramString3;
    this.A03 = paramString4;
  }
  
  public static Object A00(00w param00w, Class paramClass, Object paramObject) {
    return (new 014(paramClass, paramObject, param00w.A02, true)).A00;
  }
  
  public void A01(Context paramContext, 013 param013) {
    try {
      String str = this.A02;
      Object object = paramContext.getSystemService(str);
      return;
    } finally {
      paramContext = null;
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */