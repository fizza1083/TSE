package X;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

@Deprecated
public abstract class 01X extends BroadcastReceiver implements 01Y {
  public 03J A00 = 03J.A00;
  
  public String A01;
  
  public static void A00(Object paramObject) {
    if (paramObject != null)
      return; 
    throw 001.A0V("Object is null!");
  }
  
  public abstract 03H A01(Context paramContext, String paramString);
  
  public Object A02(03H param03H) {
    return param03H;
  }
  
  public String A03() {
    return "SecureBroadcastReceiver";
  }
  
  public boolean A04(Context paramContext, Intent paramIntent) {
    return true;
  }
  
  public abstract boolean A05(String paramString);
  
  public void handleMissingReceiver(Context paramContext, String paramString) {
    String str = A03();
    Log.e(str, 0XK.A11("Rejected the intent for the receiver because it was not registered: ", paramString, ":", str));
  }
  
  public final void onReceive(Context paramContext, Intent paramIntent) {
    // Byte code:
    //   0: ldc -1544703797
    //   2: invokestatic A01 : (I)I
    //   5: istore #4
    //   7: aload_0
    //   8: getfield A01 : Ljava/lang/String;
    //   11: astore #7
    //   13: aload #7
    //   15: astore #6
    //   17: aload #7
    //   19: ifnonnull -> 46
    //   22: aload_1
    //   23: invokevirtual getPackageName : ()Ljava/lang/String;
    //   26: ldc '/'
    //   28: aload_0
    //   29: invokevirtual getClass : ()Ljava/lang/Class;
    //   32: invokevirtual getName : ()Ljava/lang/String;
    //   35: invokestatic A0p : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   38: astore #6
    //   40: aload_0
    //   41: aload #6
    //   43: putfield A01 : Ljava/lang/String;
    //   46: aload #6
    //   48: invokestatic A00 : (Ljava/lang/Object;)V
    //   51: aload_2
    //   52: invokevirtual getAction : ()Ljava/lang/String;
    //   55: astore #8
    //   57: aload #8
    //   59: ifnonnull -> 83
    //   62: aload_0
    //   63: invokevirtual A03 : ()Ljava/lang/String;
    //   66: ldc 'action is null for SecureBroadcastReceiver'
    //   68: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   71: pop
    //   72: ldc -1553093352
    //   74: istore_3
    //   75: iload_3
    //   76: iload #4
    //   78: aload_2
    //   79: invokestatic A0D : (IILandroid/content/Intent;)V
    //   82: return
    //   83: aload_0
    //   84: aload_1
    //   85: aload #8
    //   87: invokevirtual A01 : (Landroid/content/Context;Ljava/lang/String;)LX/03H;
    //   90: astore #7
    //   92: aload #7
    //   94: ifnull -> 154
    //   97: aload_0
    //   98: aload #7
    //   100: invokevirtual A02 : (LX/03H;)Ljava/lang/Object;
    //   103: astore #8
    //   105: invokestatic A03 : ()LX/03T;
    //   108: aload_1
    //   109: aload_2
    //   110: aload #8
    //   112: invokevirtual A02 : (Landroid/content/Context;Landroid/content/Intent;Ljava/lang/Object;)Z
    //   115: ifne -> 136
    //   118: getstatic X/09p.A00 : LX/09q;
    //   121: aload_2
    //   122: aload #6
    //   124: aconst_null
    //   125: ldc 'deny'
    //   127: invokevirtual A00 : (Landroid/content/Intent;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   130: ldc -975594931
    //   132: istore_3
    //   133: goto -> 75
    //   136: aload_0
    //   137: monitorenter
    //   138: aload_0
    //   139: getfield A00 : LX/03J;
    //   142: aload_1
    //   143: aload_2
    //   144: aconst_null
    //   145: aload_0
    //   146: invokevirtual A00 : (Landroid/content/Context;Landroid/content/Intent;LX/11P;Ljava/lang/Object;)Z
    //   149: istore #5
    //   151: goto -> 185
    //   154: aload_0
    //   155: aload #8
    //   157: invokevirtual A05 : (Ljava/lang/String;)Z
    //   160: ifne -> 223
    //   163: getstatic X/09p.A00 : LX/09q;
    //   166: aload_2
    //   167: aload #6
    //   169: aconst_null
    //   170: ldc 'deny'
    //   172: invokevirtual A00 : (Landroid/content/Intent;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   175: aload_0
    //   176: aload_1
    //   177: aload #8
    //   179: invokevirtual handleMissingReceiver : (Landroid/content/Context;Ljava/lang/String;)V
    //   182: goto -> 223
    //   185: aload_0
    //   186: monitorexit
    //   187: iload #5
    //   189: ifeq -> 229
    //   192: aload_0
    //   193: aload_1
    //   194: aload_2
    //   195: invokevirtual A04 : (Landroid/content/Context;Landroid/content/Intent;)Z
    //   198: ifeq -> 229
    //   201: getstatic X/09p.A00 : LX/09q;
    //   204: aload_2
    //   205: aload #6
    //   207: aconst_null
    //   208: ldc 'allow'
    //   210: invokevirtual A00 : (Landroid/content/Intent;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   213: aload #7
    //   215: aload_1
    //   216: aload_2
    //   217: aload_0
    //   218: invokeinterface onReceive : (Landroid/content/Context;Landroid/content/Intent;LX/01Y;)V
    //   223: ldc -1140512073
    //   225: istore_3
    //   226: goto -> 75
    //   229: getstatic X/09p.A00 : LX/09q;
    //   232: aload_2
    //   233: aload #6
    //   235: aconst_null
    //   236: ldc 'deny'
    //   238: invokevirtual A00 : (Landroid/content/Intent;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   241: ldc 1800194351
    //   243: istore_3
    //   244: goto -> 75
    //   247: astore_1
    //   248: aload_0
    //   249: monitorexit
    //   250: aload_1
    //   251: athrow
    // Exception table:
    //   from	to	target	type
    //   138	151	247	finally
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01X.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */