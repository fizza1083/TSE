package X;

import android.content.ContentResolver;
import android.content.Context;
import android.content.IntentFilter;

public final class 07c {
  public final ContentResolver A00 = null;
  
  public final IntentFilter A01 = null;
  
  public final String A02 = "";
  
  public final boolean A03 = false;
  
  public 07c() {}
  
  public 07c(ContentResolver paramContentResolver, IntentFilter paramIntentFilter, String paramString, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: aload_1
    //   6: putfield A00 : Landroid/content/ContentResolver;
    //   9: aload_0
    //   10: aload_3
    //   11: putfield A02 : Ljava/lang/String;
    //   14: aload_3
    //   15: ifnull -> 26
    //   18: iconst_1
    //   19: istore #5
    //   21: iload #4
    //   23: ifne -> 29
    //   26: iconst_0
    //   27: istore #5
    //   29: aload_0
    //   30: iload #5
    //   32: putfield A03 : Z
    //   35: aload_0
    //   36: aload_2
    //   37: putfield A01 : Landroid/content/IntentFilter;
    //   40: return
  }
  
  public static 07c[] A00(Context paramContext, String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
    //   4: astore #10
    //   6: aload_1
    //   7: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   10: istore #6
    //   12: iconst_0
    //   13: istore_2
    //   14: iload #6
    //   16: ifeq -> 24
    //   19: iconst_0
    //   20: anewarray X/07c
    //   23: areturn
    //   24: aload_1
    //   25: ldc '\^\^\^'
    //   27: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   30: astore #11
    //   32: aload #11
    //   34: arraylength
    //   35: istore_3
    //   36: iload_3
    //   37: anewarray X/07c
    //   40: astore #7
    //   42: aload #7
    //   44: astore_0
    //   45: iload_2
    //   46: iload_3
    //   47: if_icmpge -> 301
    //   50: aload #11
    //   52: iload_2
    //   53: aaload
    //   54: astore_1
    //   55: aload_1
    //   56: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   59: ifeq -> 73
    //   62: new X/07c
    //   65: dup
    //   66: invokespecial <init> : ()V
    //   69: astore_0
    //   70: goto -> 303
    //   73: iconst_0
    //   74: istore #6
    //   76: aload_1
    //   77: iconst_0
    //   78: invokevirtual codePointAt : (I)I
    //   81: istore #4
    //   83: iload #4
    //   85: bipush #33
    //   87: if_icmpeq -> 107
    //   90: iload #4
    //   92: bipush #42
    //   94: if_icmpeq -> 165
    //   97: iload #4
    //   99: bipush #58
    //   101: if_icmpeq -> 107
    //   104: goto -> 278
    //   107: aload_1
    //   108: iload #4
    //   110: iconst_1
    //   111: invokevirtual indexOf : (II)I
    //   114: istore #5
    //   116: iload #5
    //   118: iflt -> 269
    //   121: aload_1
    //   122: iconst_1
    //   123: iload #5
    //   125: invokevirtual substring : (II)Ljava/lang/String;
    //   128: astore #8
    //   130: aload_1
    //   131: iload #5
    //   133: iconst_1
    //   134: iadd
    //   135: invokevirtual substring : (I)Ljava/lang/String;
    //   138: astore #9
    //   140: aload #9
    //   142: astore_1
    //   143: aload #8
    //   145: astore_0
    //   146: iload #4
    //   148: bipush #33
    //   150: if_icmpne -> 173
    //   153: iconst_1
    //   154: istore #6
    //   156: aload #9
    //   158: astore_1
    //   159: aload #8
    //   161: astore_0
    //   162: goto -> 173
    //   165: aconst_null
    //   166: astore_0
    //   167: aload_1
    //   168: iconst_1
    //   169: invokevirtual substring : (I)Ljava/lang/String;
    //   172: astore_1
    //   173: aload_1
    //   174: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   177: ifeq -> 185
    //   180: aconst_null
    //   181: astore_1
    //   182: goto -> 237
    //   185: new android/content/IntentFilter
    //   188: dup
    //   189: invokespecial <init> : ()V
    //   192: astore #8
    //   194: invokestatic newInstance : ()Lorg/xmlpull/v1/XmlPullParserFactory;
    //   197: astore #9
    //   199: aload #9
    //   201: iconst_1
    //   202: invokevirtual setNamespaceAware : (Z)V
    //   205: aload #9
    //   207: invokevirtual newPullParser : ()Lorg/xmlpull/v1/XmlPullParser;
    //   210: astore #9
    //   212: aload #9
    //   214: new java/io/StringReader
    //   217: dup
    //   218: aload_1
    //   219: invokespecial <init> : (Ljava/lang/String;)V
    //   222: invokeinterface setInput : (Ljava/io/Reader;)V
    //   227: aload #8
    //   229: aload #9
    //   231: invokevirtual readFromXml : (Lorg/xmlpull/v1/XmlPullParser;)V
    //   234: aload #8
    //   236: astore_1
    //   237: new X/07c
    //   240: dup
    //   241: aload #10
    //   243: aload_1
    //   244: aload_0
    //   245: iload #6
    //   247: invokespecial <init> : (Landroid/content/ContentResolver;Landroid/content/IntentFilter;Ljava/lang/String;Z)V
    //   250: astore_0
    //   251: goto -> 303
    //   254: astore_0
    //   255: new java/io/IOException
    //   258: dup
    //   259: ldc 'Something went wrong with the parser'
    //   261: aload_0
    //   262: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   265: astore_0
    //   266: goto -> 284
    //   269: ldc 'Criteria specification is not valid'
    //   271: invokestatic A0O : (Ljava/lang/String;)Ljava/lang/IllegalArgumentException;
    //   274: astore_0
    //   275: goto -> 284
    //   278: ldc 'Criteria specification is not valid'
    //   280: invokestatic A0O : (Ljava/lang/String;)Ljava/lang/IllegalArgumentException;
    //   283: astore_0
    //   284: aload_0
    //   285: athrow
    //   286: astore_0
    //   287: ldc 'IntentCriteria'
    //   289: ldc 'Error parsing switch-off criteria.'
    //   291: aload_0
    //   292: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   295: pop
    //   296: iconst_0
    //   297: anewarray X/07c
    //   300: astore_0
    //   301: aload_0
    //   302: areturn
    //   303: aload #7
    //   305: iload_2
    //   306: aload_0
    //   307: aastore
    //   308: iload_2
    //   309: iconst_1
    //   310: iadd
    //   311: istore_2
    //   312: goto -> 42
    // Exception table:
    //   from	to	target	type
    //   0	12	286	java/io/IOException
    //   0	12	286	java/lang/IllegalArgumentException
    //   19	24	286	java/io/IOException
    //   19	24	286	java/lang/IllegalArgumentException
    //   24	42	286	java/io/IOException
    //   24	42	286	java/lang/IllegalArgumentException
    //   55	70	286	java/io/IOException
    //   55	70	286	java/lang/IllegalArgumentException
    //   76	83	286	java/io/IOException
    //   76	83	286	java/lang/IllegalArgumentException
    //   107	116	286	java/io/IOException
    //   107	116	286	java/lang/IllegalArgumentException
    //   121	140	286	java/io/IOException
    //   121	140	286	java/lang/IllegalArgumentException
    //   167	173	286	java/io/IOException
    //   167	173	286	java/lang/IllegalArgumentException
    //   173	180	286	java/io/IOException
    //   173	180	286	java/lang/IllegalArgumentException
    //   185	194	286	java/io/IOException
    //   185	194	286	java/lang/IllegalArgumentException
    //   194	234	254	org/xmlpull/v1/XmlPullParserException
    //   194	234	286	java/io/IOException
    //   194	234	286	java/lang/IllegalArgumentException
    //   237	251	286	java/io/IOException
    //   237	251	286	java/lang/IllegalArgumentException
    //   255	266	286	java/io/IOException
    //   255	266	286	java/lang/IllegalArgumentException
    //   269	275	286	java/io/IOException
    //   269	275	286	java/lang/IllegalArgumentException
    //   278	284	286	java/io/IOException
    //   278	284	286	java/lang/IllegalArgumentException
    //   284	286	286	java/io/IOException
    //   284	286	286	java/lang/IllegalArgumentException
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */