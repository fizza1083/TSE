package X;

public interface 04M {
  04s C25(Runnable paramRunnable, 04I param04I, long paramLong);
  
  void Djw(0IU param0IU, long paramLong);
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\04M.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */