package X;

import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;

public final class 07M<T> implements Collection<T>, 16M {
  public final Object[] A00;
  
  public final boolean A01;
  
  public 07M(Object[] paramArrayOfObject, boolean paramBoolean) {
    this.A00 = paramArrayOfObject;
    this.A01 = paramBoolean;
  }
  
  public final boolean add(Object paramObject) {
    throw 002.A0b();
  }
  
  public final boolean addAll(Collection paramCollection) {
    throw 002.A0b();
  }
  
  public final void clear() {
    throw 002.A0b();
  }
  
  public final boolean contains(Object paramObject) {
    return 027.A0F(paramObject, this.A00);
  }
  
  public final boolean containsAll(Collection paramCollection) {
    16F.A0E(paramCollection, 0);
    boolean bool = paramCollection.isEmpty();
    boolean bool2 = true;
    boolean bool1 = bool2;
    if (!bool) {
      Iterator iterator = paramCollection.iterator();
      while (true) {
        bool1 = bool2;
        if (iterator.hasNext()) {
          if (!contains(iterator.next())) {
            bool1 = false;
            break;
          } 
          continue;
        } 
        break;
      } 
    } 
    return bool1;
  }
  
  public final boolean isEmpty() {
    return 002.A12(this.A00.length);
  }
  
  public final Iterator iterator() {
    return new 06M(this.A00);
  }
  
  public final boolean remove(Object paramObject) {
    throw 002.A0b();
  }
  
  public final boolean removeAll(Collection paramCollection) {
    throw 002.A0b();
  }
  
  public final boolean retainAll(Collection paramCollection) {
    throw 002.A0b();
  }
  
  public final Object[] toArray() {
    Object[] arrayOfObject = this.A00;
    if (this.A01 && 16F.A0S(arrayOfObject.getClass(), Object[].class))
      return arrayOfObject; 
    arrayOfObject = Arrays.copyOf(arrayOfObject, arrayOfObject.length, Object[].class);
    16F.A0A(arrayOfObject);
    return arrayOfObject;
  }
  
  public final Object[] toArray(Object[] paramArrayOfObject) {
    return 16F.A0U(this, paramArrayOfObject);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07M.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */