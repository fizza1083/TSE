package X;

public final class 08V {
  public int A00 = 1000;
  
  public 08X A01;
  
  public String A02;
  
  public String A03;
  
  public Throwable A04;
  
  public boolean A05;
  
  public boolean A06;
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08V.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */