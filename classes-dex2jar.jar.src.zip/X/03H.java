package X;

import android.content.Context;
import android.content.Intent;

@Deprecated
public interface 03H {
  void onReceive(Context paramContext, Intent paramIntent, 01Y param01Y);
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\03H.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */