package X;

import android.content.Context;
import android.os.Handler;
import android.os.HandlerThread;

public abstract class 00b implements 00c {
  public Handler A00;
  
  public final Context A01;
  
  public 00b(Context paramContext) {
    this.A01 = paramContext.getApplicationContext();
  }
  
  public final Handler Avn() {
    Handler handler2 = this.A00;
    Handler handler1 = handler2;
    if (handler2 == null) {
      HandlerThread handlerThread = new HandlerThread("Fixie-background-pri", 10);
      14I.A00(handlerThread);
      handlerThread.start();
      handler1 = new Handler(handlerThread.getLooper());
      this.A00 = handler1;
    } 
    return handler1;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */