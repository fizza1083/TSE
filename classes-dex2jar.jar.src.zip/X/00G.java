package X;

import android.content.Context;
import java.io.File;
import java.util.concurrent.atomic.AtomicInteger;

public final class 00G {
  public static 00G A03;
  
  public static final AtomicInteger A04 = new AtomicInteger();
  
  public final Context A00;
  
  public final 009 A01;
  
  public final 00B A02;
  
  public 00G(Context paramContext, 009 param009, 00B param00B) {
    this.A00 = paramContext;
    this.A01 = param009;
    this.A02 = param00B;
  }
  
  @Deprecated
  public static 00G A00(Context paramContext, 009 param009, 00B param00B) {
    // Byte code:
    //   0: ldc X/00G
    //   2: monitorenter
    //   3: getstatic X/00G.A03 : LX/00G;
    //   6: astore_3
    //   7: aload_3
    //   8: ifnull -> 27
    //   11: aload_3
    //   12: astore_0
    //   13: aload_3
    //   14: getfield A01 : LX/009;
    //   17: aload_1
    //   18: if_acmpeq -> 53
    //   21: ldc 'Different VoltronModuleLoaders detected!'
    //   23: invokestatic A0Z : (Ljava/lang/String;)Ljava/lang/RuntimeException;
    //   26: athrow
    //   27: aload_0
    //   28: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   31: astore_3
    //   32: aload_3
    //   33: ifnull -> 38
    //   36: aload_3
    //   37: astore_0
    //   38: new X/00G
    //   41: dup
    //   42: aload_0
    //   43: aload_1
    //   44: aload_2
    //   45: invokespecial <init> : (Landroid/content/Context;LX/009;LX/00B;)V
    //   48: astore_0
    //   49: aload_0
    //   50: putstatic X/00G.A03 : LX/00G;
    //   53: ldc X/00G
    //   55: monitorexit
    //   56: aload_0
    //   57: areturn
    //   58: astore_0
    //   59: ldc X/00G
    //   61: monitorexit
    //   62: aload_0
    //   63: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	58	finally
    //   13	27	58	finally
    //   27	32	58	finally
    //   38	53	58	finally
  }
  
  public static final File A01(00G param00G, String paramString) {
    String str;
    Context context = param00G.A00;
    if (03m.A01(context, paramString)) {
      File file = 03m.A00(context, paramString);
      if (file != null)
        return file; 
    } 
    if (02S.A00(context) && 02Y.A01(paramString) == 0Xy.A0N) {
      str = param00G.A02(paramString);
      if (str == null) {
        0pd.A0P("VoltronModuleManager", "Hash not found for module %s", new Object[] { paramString });
        return null;
      } 
    } else {
      return null;
    } 
    return param00G.A02.A02(paramString, str);
  }
  
  public final String A02(String paramString) {
    if (02Y.A01(paramString) != 0Xy.A0N)
      return null; 
    00E.A00().A07(this.A00);
    return 00E.A00().A03(paramString);
  }
  
  public final void A03(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: invokevirtual A04 : (Ljava/lang/String;)V
    //   7: aload_0
    //   8: monitorexit
    //   9: return
    //   10: astore_1
    //   11: aload_0
    //   12: monitorexit
    //   13: aload_1
    //   14: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	10	finally
  }
  
  public final void A04(String paramString) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: \r\n\tat com.googlecode.dex2jar.ir.ts.NewTransformer.transform(NewTransformer.java:134)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:148)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00G.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */