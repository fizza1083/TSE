package X;

import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.util.Locale;

public final class 06K {
  public static final int[] A02 = new int[3];
  
  public final int A00;
  
  public final IntBuffer A01;
  
  public 06K(ByteBuffer paramByteBuffer) {
    this.A01 = paramByteBuffer.asIntBuffer();
    this.A00 = i;
  }
  
  public static final int A00(06K param06K, int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt3 != 0) {
      if (paramInt3 == 1) {
        paramInt3 = param06K.A00;
        paramInt2 = Math.abs((paramInt1 + paramInt2 * 31) / paramInt3);
        paramInt1 = paramInt3;
        return paramInt2 % paramInt1;
      } 
    } else {
      paramInt2 = Math.abs(paramInt1 + paramInt2 * 31);
      paramInt1 = param06K.A00;
      return paramInt2 % paramInt1;
    } 
    throw 001.A0O("Supporting only 2 hashes at the moment");
  }
  
  public static int A01(06K param06K, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    int i = paramInt1;
    if (paramInt5 < 5) {
      i = 0;
      while (true) {
        int j = A00(param06K, paramInt1, paramInt2, i);
        int k = param06K.A00;
        IntBuffer intBuffer = param06K.A01;
        intBuffer.position((i * k + j) * 3);
        j = intBuffer.get();
        int m = intBuffer.get();
        if (j == paramInt1 && m == paramInt2) {
          intBuffer.put(paramInt3);
          return 0;
        } 
        j = i + 1;
        i = j;
        if (j >= 2) {
          i = (paramInt4 * k + A00(param06K, paramInt1, paramInt2, paramInt4)) * 3;
          intBuffer.position(i);
          j = intBuffer.get();
          k = intBuffer.get();
          m = intBuffer.get();
          intBuffer.position(i);
          intBuffer.put(paramInt1);
          intBuffer.put(paramInt2);
          intBuffer.put(paramInt3);
          if (j == 0 && k == 0)
            return 0; 
          i = A01(param06K, j, k, m, (paramInt4 + 1) % 2, paramInt5 + 1);
          break;
        } 
      } 
    } 
    return i;
  }
  
  public String printContent() {
    IntBuffer intBuffer = this.A01;
    intBuffer.position(0);
    StringBuilder stringBuilder = 001.A0s();
    int i = 0;
    while (true) {
      stringBuilder.append("{");
      int j;
      for (j = 0; j < this.A00; j++) {
        int k = intBuffer.get();
        int m = intBuffer.get();
        int n = intBuffer.get();
        stringBuilder.append(String.format(Locale.ENGLISH, "%2d,%2d=%d ", new Object[] { Integer.valueOf(k), Integer.valueOf(m), Integer.valueOf(n) }));
      } 
      stringBuilder.append("}\n");
      j = i + 1;
      i = j;
      if (j >= 2)
        return stringBuilder.toString(); 
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\06K.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */