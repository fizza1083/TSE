package X;

public final class 01S {
  public final 01T A00;
  
  public 01S(String paramString) {
    this.A00 = new 01T(paramString, 1024, true, true);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01S.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */