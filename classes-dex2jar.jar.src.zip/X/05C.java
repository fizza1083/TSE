package X;

import java.io.Serializable;

public abstract class 05C implements 05D, 05E, Serializable {
  public final 05D completion;
  
  public 05C(05D param05D) {
    this.completion = param05D;
  }
  
  public static 05D A00(Object paramObject1, Object paramObject2, 05C param05C) {
    return param05C.A0A(paramObject2, (05D)paramObject1);
  }
  
  public StackTraceElement A07() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getClass : ()Ljava/lang/Class;
    //   4: astore #6
    //   6: aload #6
    //   8: ldc kotlin/coroutines/jvm/internal/DebugMetadata
    //   10: invokevirtual getAnnotation : (Ljava/lang/Class;)Ljava/lang/annotation/Annotation;
    //   13: checkcast kotlin/coroutines/jvm/internal/DebugMetadata
    //   16: astore #5
    //   18: aload #5
    //   20: ifnonnull -> 25
    //   23: aconst_null
    //   24: areturn
    //   25: aload #5
    //   27: invokeinterface v : ()I
    //   32: istore_1
    //   33: iload_1
    //   34: iconst_1
    //   35: if_icmpgt -> 345
    //   38: aload_0
    //   39: aload #6
    //   41: ldc 'label'
    //   43: invokestatic A0R : (Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Object;
    //   46: astore_2
    //   47: aload_2
    //   48: instanceof java/lang/Integer
    //   51: ifeq -> 368
    //   54: aload_2
    //   55: checkcast java/lang/Integer
    //   58: astore_2
    //   59: aload_2
    //   60: ifnull -> 368
    //   63: aload_2
    //   64: invokevirtual intValue : ()I
    //   67: istore_1
    //   68: goto -> 370
    //   71: iconst_m1
    //   72: istore_1
    //   73: iload_1
    //   74: ifge -> 92
    //   77: iconst_m1
    //   78: istore_1
    //   79: getstatic X/15l.A00 : LX/15k;
    //   82: astore_3
    //   83: aload_3
    //   84: astore_2
    //   85: aload_3
    //   86: ifnonnull -> 177
    //   89: goto -> 105
    //   92: aload #5
    //   94: invokeinterface l : ()[I
    //   99: iload_1
    //   100: iaload
    //   101: istore_1
    //   102: goto -> 79
    //   105: new X/15k
    //   108: dup
    //   109: ldc java/lang/Class
    //   111: ldc 'getModule'
    //   113: iconst_0
    //   114: anewarray java/lang/Class
    //   117: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   120: aload #6
    //   122: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   125: ldc 'java.lang.Module'
    //   127: invokevirtual loadClass : (Ljava/lang/String;)Ljava/lang/Class;
    //   130: ldc 'getDescriptor'
    //   132: iconst_0
    //   133: anewarray java/lang/Class
    //   136: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   139: aload #6
    //   141: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   144: ldc 'java.lang.module.ModuleDescriptor'
    //   146: invokevirtual loadClass : (Ljava/lang/String;)Ljava/lang/Class;
    //   149: ldc 'name'
    //   151: iconst_0
    //   152: anewarray java/lang/Class
    //   155: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   158: invokespecial <init> : (Ljava/lang/reflect/Method;Ljava/lang/reflect/Method;Ljava/lang/reflect/Method;)V
    //   161: astore_2
    //   162: aload_2
    //   163: putstatic X/15l.A00 : LX/15k;
    //   166: goto -> 177
    //   169: getstatic X/15l.A01 : LX/15k;
    //   172: astore_2
    //   173: aload_2
    //   174: putstatic X/15l.A00 : LX/15k;
    //   177: getstatic X/15l.A01 : LX/15k;
    //   180: astore #7
    //   182: aconst_null
    //   183: astore #4
    //   185: aload #4
    //   187: astore_3
    //   188: aload_2
    //   189: aload #7
    //   191: if_acmpeq -> 287
    //   194: aload_2
    //   195: getfield A01 : Ljava/lang/reflect/Method;
    //   198: astore #7
    //   200: aload #4
    //   202: astore_3
    //   203: aload #7
    //   205: ifnull -> 287
    //   208: aload #6
    //   210: aload #7
    //   212: invokestatic A0X : (Ljava/lang/Object;Ljava/lang/reflect/Method;)Ljava/lang/Object;
    //   215: astore #6
    //   217: aload #4
    //   219: astore_3
    //   220: aload #6
    //   222: ifnull -> 287
    //   225: aload_2
    //   226: getfield A00 : Ljava/lang/reflect/Method;
    //   229: astore #7
    //   231: aload #4
    //   233: astore_3
    //   234: aload #7
    //   236: ifnull -> 287
    //   239: aload #6
    //   241: aload #7
    //   243: invokestatic A0X : (Ljava/lang/Object;Ljava/lang/reflect/Method;)Ljava/lang/Object;
    //   246: astore #6
    //   248: aload #4
    //   250: astore_3
    //   251: aload #6
    //   253: ifnull -> 287
    //   256: aload_2
    //   257: getfield A02 : Ljava/lang/reflect/Method;
    //   260: astore_2
    //   261: aload_2
    //   262: ifnull -> 340
    //   265: aload #6
    //   267: aload_2
    //   268: invokestatic A0X : (Ljava/lang/Object;Ljava/lang/reflect/Method;)Ljava/lang/Object;
    //   271: astore_2
    //   272: aload #4
    //   274: astore_3
    //   275: aload_2
    //   276: instanceof java/lang/String
    //   279: ifeq -> 287
    //   282: aload_2
    //   283: checkcast java/lang/String
    //   286: astore_3
    //   287: aload_3
    //   288: ifnonnull -> 323
    //   291: aload #5
    //   293: invokeinterface c : ()Ljava/lang/String;
    //   298: astore_2
    //   299: new java/lang/StackTraceElement
    //   302: dup
    //   303: aload_2
    //   304: aload #5
    //   306: invokeinterface m : ()Ljava/lang/String;
    //   311: aload #5
    //   313: invokeinterface f : ()Ljava/lang/String;
    //   318: iload_1
    //   319: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V
    //   322: areturn
    //   323: aload_3
    //   324: aload #5
    //   326: invokeinterface c : ()Ljava/lang/String;
    //   331: bipush #47
    //   333: invokestatic A0d : (Ljava/lang/String;Ljava/lang/String;C)Ljava/lang/String;
    //   336: astore_2
    //   337: goto -> 299
    //   340: aconst_null
    //   341: astore_2
    //   342: goto -> 272
    //   345: ldc 'Debug metadata version mismatch. Expected: '
    //   347: ldc ', got '
    //   349: ldc '. Please update the Kotlin standard library.'
    //   351: iconst_1
    //   352: iload_1
    //   353: invokestatic A0v : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;II)Ljava/lang/String;
    //   356: invokestatic A0S : (Ljava/lang/String;)Ljava/lang/IllegalStateException;
    //   359: athrow
    //   360: astore_2
    //   361: goto -> 71
    //   364: astore_2
    //   365: goto -> 169
    //   368: iconst_0
    //   369: istore_1
    //   370: iload_1
    //   371: iconst_1
    //   372: isub
    //   373: istore_1
    //   374: goto -> 73
    // Exception table:
    //   from	to	target	type
    //   38	59	360	java/lang/Exception
    //   63	68	360	java/lang/Exception
    //   105	166	364	java/lang/Exception
  }
  
  public void A08() {}
  
  public abstract Object A09(Object paramObject);
  
  public 05D A0A(Object paramObject, 05D param05D) {
    throw 001.A0x("create(Any?;Continuation) has not been overridden");
  }
  
  public 05E Aym() {
    05D 05D1 = this.completion;
    return (05D1 instanceof 05E) ? (05E)05D1 : null;
  }
  
  public final void DiG(Object paramObject) {
    05C 05C1 = this;
    while (true) {
      05C 05C2 = 05C1;
      05D 05D1 = 05C2.completion;
      16F.A0D(05D1);
      try {
        Object object = 05C2.A09(paramObject);
        paramObject = object;
      } finally {
        paramObject = null;
      } 
      05C2.A08();
      if (05D1 instanceof 05C)
        continue; 
      05D1.DiG(paramObject);
      return;
    } 
  }
  
  public String toString() {
    String str;
    StringBuilder stringBuilder = 001.A0s();
    stringBuilder.append("Continuation at ");
    StackTraceElement stackTraceElement2 = A07();
    StackTraceElement stackTraceElement1 = stackTraceElement2;
    if (stackTraceElement2 == null)
      str = 001.A0h(this); 
    return 001.A0i(str, stringBuilder);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\05C.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */