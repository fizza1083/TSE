package X;

import java.util.Arrays;

public final class 08D implements Cloneable {
  public 08D() {
    this(10);
  }
  
  public 08D(int paramInt) {
    Object[] arrayOfObject;
    if (paramInt == 0) {
      this.A02 = 0Xj.A00;
      arrayOfObject = 0Xj.A02;
    } else {
      int i;
      int j = paramInt * 4;
      paramInt = 4;
      while (true) {
        int k = (1 << paramInt) - 12;
        i = k;
        if (j > k) {
          i = paramInt + 1;
          paramInt = i;
          if (i >= 32) {
            i = j;
            break;
          } 
          continue;
        } 
        break;
      } 
      paramInt = i / 4;
      this.A02 = new int[paramInt];
      arrayOfObject = new Object[paramInt];
    } 
    this.A03 = arrayOfObject;
  }
  
  public final int A00() {
    if (this.A01)
      08F.A01(this); 
    return this.A00;
  }
  
  public final int A01(int paramInt) {
    if (this.A01)
      08F.A01(this); 
    return 0Xj.A00(this.A02, this.A00, paramInt);
  }
  
  public final int A02(int paramInt) {
    if (this.A01)
      08F.A01(this); 
    return this.A02[paramInt];
  }
  
  public final int A03(Object paramObject) {
    // Byte code:
    //   0: aload_0
    //   1: getfield A01 : Z
    //   4: ifeq -> 11
    //   7: aload_0
    //   8: invokestatic A01 : (LX/08D;)V
    //   11: iconst_0
    //   12: istore_2
    //   13: aload_0
    //   14: getfield A00 : I
    //   17: istore #4
    //   19: iload_2
    //   20: iload #4
    //   22: if_icmpge -> 44
    //   25: iload_2
    //   26: istore_3
    //   27: aload_0
    //   28: getfield A03 : [Ljava/lang/Object;
    //   31: iload_2
    //   32: aaload
    //   33: aload_1
    //   34: if_acmpeq -> 46
    //   37: iload_2
    //   38: iconst_1
    //   39: iadd
    //   40: istore_2
    //   41: goto -> 19
    //   44: iconst_m1
    //   45: istore_3
    //   46: iload_3
    //   47: ireturn
  }
  
  public final 08D A04() {
    Object object = super.clone();
    16F.A0I(object, "null cannot be cast to non-null type androidx.collection.SparseArrayCompat<E of androidx.collection.SparseArrayCompat>");
    object = object;
    ((08D)object).A02 = (int[])this.A02.clone();
    ((08D)object).A03 = (Object[])this.A03.clone();
    return (08D)object;
  }
  
  public final Object A05(int paramInt) {
    if (this.A01)
      08F.A01(this); 
    return this.A03[paramInt];
  }
  
  public final void A06() {
    int j = this.A00;
    Object[] arrayOfObject = this.A03;
    for (int i = 0; i < j; i++)
      arrayOfObject[i] = null; 
    this.A00 = 0;
    this.A01 = false;
  }
  
  public final void A07(int paramInt) {
    paramInt = 0Xj.A00(this.A02, this.A00, paramInt);
    if (paramInt >= 0) {
      Object[] arrayOfObject = this.A03;
      Object object1 = arrayOfObject[paramInt];
      Object object2 = 08F.A00;
      if (object1 != object2) {
        arrayOfObject[paramInt] = object2;
        this.A01 = true;
      } 
    } 
  }
  
  public final void A08(int paramInt, Object paramObject) {
    int i = 0Xj.A00(this.A02, this.A00, paramInt);
    int j = i;
    if (i < 0) {
      j = i ^ 0xFFFFFFFF;
      int k = this.A00;
      if (j < k && this.A03[j] == 08F.A00) {
        this.A02[j] = paramInt;
      } else {
        i = j;
        if (this.A01) {
          int[] arrayOfInt1 = this.A02;
          i = j;
          if (k >= arrayOfInt1.length) {
            08F.A01(this);
            i = 0Xj.A00(arrayOfInt1, this.A00, paramInt) ^ 0xFFFFFFFF;
          } 
        } 
        j = this.A00;
        int[] arrayOfInt = this.A02;
        if (j >= arrayOfInt.length) {
          int m = (j + 1) * 4;
          j = 4;
          while (true) {
            int n = (1 << j) - 12;
            k = n;
            if (m > n) {
              k = j + 1;
              j = k;
              if (k >= 32) {
                k = m;
                break;
              } 
              continue;
            } 
            break;
          } 
          j = k / 4;
          arrayOfInt = Arrays.copyOf(arrayOfInt, j);
          16F.A0A(arrayOfInt);
          this.A02 = arrayOfInt;
          arrayOfInt = Arrays.copyOf((int[])this.A03, j);
          16F.A0A(arrayOfInt);
          this.A03 = (Object[])arrayOfInt;
        } 
        j = this.A00;
        if (j - i != 0) {
          arrayOfInt = this.A02;
          k = i + 1;
          155.A0K(arrayOfInt, arrayOfInt, k, i, j);
          Object[] arrayOfObject = this.A03;
          155.A0M(arrayOfObject, arrayOfObject, k, i, this.A00);
        } 
        this.A02[i] = paramInt;
        this.A03[i] = paramObject;
        this.A00++;
        return;
      } 
    } 
    this.A03[j] = paramObject;
  }
  
  public final String toString() {
    if (A00() <= 0)
      return "{}"; 
    int j = this.A00;
    StringBuilder stringBuilder = 001.A0t(j * 28);
    stringBuilder.append('{');
    for (int i = 0; i < j; i++) {
      if (i > 0)
        001.A1P(stringBuilder); 
      stringBuilder.append(A02(i));
      stringBuilder.append('=');
      Object object = A05(i);
      if (object != this) {
        stringBuilder.append(object);
      } else {
        stringBuilder.append("(this Map)");
      } 
    } 
    String str = 002.A0X(stringBuilder);
    16F.A0A(str);
    return str;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */