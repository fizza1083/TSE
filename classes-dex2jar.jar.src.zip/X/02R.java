package X;

import com.facebook.quicklog.EventBuilder;
import com.facebook.quicklog.MarkerEditor;
import com.facebook.quicklog.QuickPerformanceLogger;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public final class 02R implements QuickPerformanceLogger {
  public final long currentMonotonicTimestamp() {
    return 0L;
  }
  
  public final long currentMonotonicTimestampNanos() {
    return 0L;
  }
  
  public final void dropAllInstancesOfMarker(int paramInt) {}
  
  public final void dropAllInstancesOfMarker(int paramInt1, int paramInt2) {}
  
  public final void endAllInstancesOfMarker(int paramInt, short paramShort) {}
  
  public final void endAllMarkers(short paramShort, boolean paramBoolean) {}
  
  public final boolean isMarkerOn(int paramInt) {
    return false;
  }
  
  public final boolean isMarkerOn(int paramInt1, int paramInt2) {
    return false;
  }
  
  public final boolean isMarkerOn(int paramInt1, int paramInt2, boolean paramBoolean) {
    return false;
  }
  
  public final boolean isMarkerOn(int paramInt, boolean paramBoolean) {
    return false;
  }
  
  public final void markEvent(int paramInt1, String paramString, int paramInt2) {}
  
  public final EventBuilder markEventBuilder(int paramInt1, int paramInt2, String paramString) {
    return 06F.A00;
  }
  
  public final EventBuilder markEventBuilder(int paramInt, String paramString) {
    return 06F.A00;
  }
  
  public final void markJoinRequestForE2E(int paramInt1, int paramInt2, String paramString) {}
  
  public final void markJoinRequestForE2E(int paramInt1, int paramInt2, String paramString, long paramLong, TimeUnit paramTimeUnit) {}
  
  public final void markJoinResponseForE2E(int paramInt1, int paramInt2, String paramString) {}
  
  public final void markJoinResponseForE2E(int paramInt1, int paramInt2, String paramString, long paramLong, TimeUnit paramTimeUnit) {}
  
  public final void markerAnnotate(int paramInt1, int paramInt2, String paramString, double paramDouble) {}
  
  public final void markerAnnotate(int paramInt1, int paramInt2, String paramString, int paramInt3) {}
  
  public final void markerAnnotate(int paramInt1, int paramInt2, String paramString, long paramLong) {}
  
  public final void markerAnnotate(int paramInt1, int paramInt2, String paramString1, String paramString2) {}
  
  public final void markerAnnotate(int paramInt1, int paramInt2, String paramString, boolean paramBoolean) {}
  
  public final void markerAnnotate(int paramInt1, int paramInt2, String paramString, double[] paramArrayOfdouble) {}
  
  public final void markerAnnotate(int paramInt1, int paramInt2, String paramString, int[] paramArrayOfint) {}
  
  public final void markerAnnotate(int paramInt1, int paramInt2, String paramString, long[] paramArrayOflong) {}
  
  public final void markerAnnotate(int paramInt1, int paramInt2, String paramString, String[] paramArrayOfString) {}
  
  public final void markerAnnotate(int paramInt1, int paramInt2, String paramString, boolean[] paramArrayOfboolean) {}
  
  public final void markerAnnotate(int paramInt, String paramString, double paramDouble) {}
  
  public final void markerAnnotate(int paramInt1, String paramString, int paramInt2) {}
  
  public final void markerAnnotate(int paramInt, String paramString, long paramLong) {}
  
  public final void markerAnnotate(int paramInt, String paramString1, String paramString2) {}
  
  public final void markerAnnotate(int paramInt, String paramString, boolean paramBoolean) {}
  
  public final void markerAnnotate(int paramInt, String paramString, double[] paramArrayOfdouble) {}
  
  public final void markerAnnotate(int paramInt, String paramString, int[] paramArrayOfint) {}
  
  public final void markerAnnotate(int paramInt, String paramString, long[] paramArrayOflong) {}
  
  public final void markerAnnotate(int paramInt, String paramString, String[] paramArrayOfString) {}
  
  public final void markerAnnotate(int paramInt, String paramString, boolean[] paramArrayOfboolean) {}
  
  public final void markerAnnotateCrucialForUserFlow(int paramInt1, int paramInt2, String paramString, int paramInt3) {}
  
  public final void markerAnnotateCrucialForUserFlow(int paramInt1, int paramInt2, String paramString1, String paramString2) {}
  
  public final void markerDrop(int paramInt) {}
  
  public final void markerDrop(int paramInt1, int paramInt2) {}
  
  public final void markerDropForUserFlow(int paramInt1, int paramInt2) {}
  
  public final void markerEnd(int paramInt1, int paramInt2, short paramShort) {}
  
  public final void markerEnd(int paramInt1, int paramInt2, short paramShort, long paramLong, TimeUnit paramTimeUnit) {}
  
  public final void markerEnd(int paramInt, short paramShort) {}
  
  public final void markerEnd(int paramInt, short paramShort, long paramLong, TimeUnit paramTimeUnit) {}
  
  public final void markerEndAtPoint(int paramInt1, int paramInt2, short paramShort, String paramString) {}
  
  public final void markerEndAtPoint(int paramInt, short paramShort, String paramString) {}
  
  public final void markerEndAtPointForUserFlow(int paramInt1, int paramInt2, short paramShort, String paramString) {}
  
  public final void markerEndForUserFlow(int paramInt1, int paramInt2, short paramShort) {}
  
  public final void markerEndForUserFlow(int paramInt1, String paramString, int paramInt2, short paramShort) {}
  
  public final void markerGenerate(int paramInt, short paramShort, long paramLong, TimeUnit paramTimeUnit) {}
  
  public final void markerGenerateWithAnnotations(int paramInt, short paramShort, long paramLong, TimeUnit paramTimeUnit, Map paramMap) {}
  
  public final void markerLinkPivot(int paramInt1, int paramInt2, String paramString) {}
  
  public final void markerPoint(int paramInt1, int paramInt2, int paramInt3, String paramString, 03D param03D, long paramLong, TimeUnit paramTimeUnit, int paramInt4) {}
  
  public final void markerPoint(int paramInt1, int paramInt2, String paramString) {}
  
  public final void markerPoint(int paramInt1, int paramInt2, String paramString, long paramLong, TimeUnit paramTimeUnit) {}
  
  public final void markerPoint(int paramInt1, int paramInt2, String paramString1, String paramString2) {}
  
  public final void markerPoint(int paramInt1, int paramInt2, String paramString1, String paramString2, long paramLong, TimeUnit paramTimeUnit) {}
  
  public final void markerPoint(int paramInt1, int paramInt2, String paramString1, String paramString2, long paramLong, TimeUnit paramTimeUnit, int paramInt3) {}
  
  public final void markerPoint(int paramInt, String paramString) {}
  
  public final void markerPoint(int paramInt, String paramString, long paramLong, TimeUnit paramTimeUnit) {}
  
  public final void markerPoint(int paramInt, String paramString1, String paramString2) {}
  
  public final void markerPoint(int paramInt, String paramString1, String paramString2, long paramLong, TimeUnit paramTimeUnit) {}
  
  public final void markerStart(int paramInt) {}
  
  public final void markerStart(int paramInt1, int paramInt2) {}
  
  public final void markerStart(int paramInt1, int paramInt2, long paramLong, TimeUnit paramTimeUnit) {}
  
  public final void markerStart(int paramInt1, int paramInt2, long paramLong, TimeUnit paramTimeUnit, int paramInt3) {}
  
  public final void markerStart(int paramInt1, int paramInt2, String paramString1, String paramString2) {}
  
  public final void markerStart(int paramInt1, int paramInt2, String paramString1, String paramString2, long paramLong, TimeUnit paramTimeUnit) {}
  
  public final void markerStart(int paramInt1, int paramInt2, boolean paramBoolean) {}
  
  public final void markerStart(int paramInt, String paramString1, String paramString2) {}
  
  public final void markerStart(int paramInt, String paramString1, String paramString2, long paramLong, TimeUnit paramTimeUnit) {}
  
  public final void markerStart(int paramInt, boolean paramBoolean) {}
  
  public final void markerStartForE2E(int paramInt1, int paramInt2, String paramString) {}
  
  public final void markerStartForE2E(int paramInt1, int paramInt2, String paramString, long paramLong, TimeUnit paramTimeUnit) {}
  
  public final void markerStartForE2E(int paramInt1, int paramInt2, String paramString, boolean paramBoolean, long paramLong, TimeUnit paramTimeUnit) {}
  
  public final void markerStartForLegacy(int paramInt1, int paramInt2, long paramLong, TimeUnit paramTimeUnit, 112 param112) {}
  
  public final void markerStartForLegacy(int paramInt, long paramLong, TimeUnit paramTimeUnit, 112 param112) {}
  
  public final void markerStartForUserFlow(int paramInt1, int paramInt2, long paramLong, TimeUnit paramTimeUnit, boolean paramBoolean) {}
  
  public final void markerStartForUserFlow(int paramInt1, int paramInt2, String paramString, boolean paramBoolean, long paramLong) {}
  
  public final void markerStartForUserFlow(int paramInt1, int paramInt2, String paramString, boolean paramBoolean, long paramLong1, long paramLong2, TimeUnit paramTimeUnit) {}
  
  public final void markerStartForUserFlow(int paramInt1, int paramInt2, boolean paramBoolean, long paramLong) {}
  
  public final void markerStartWithCancelPolicy(int paramInt, boolean paramBoolean) {}
  
  public final void markerStartWithCancelPolicy(int paramInt1, boolean paramBoolean, int paramInt2) {}
  
  public final void markerStartWithCancelPolicy(int paramInt1, boolean paramBoolean, int paramInt2, long paramLong, TimeUnit paramTimeUnit) {}
  
  public final void markerStartWithCancelPolicy(int paramInt1, boolean paramBoolean, int paramInt2, long paramLong, TimeUnit paramTimeUnit, String paramString) {}
  
  public final void markerStartWithSamplingBasis(int paramInt1, int paramInt2, String paramString) {}
  
  public final void markerTag(int paramInt1, int paramInt2, String paramString) {}
  
  public final void markerTag(int paramInt, String paramString) {}
  
  public final int sampleRateForMarker(int paramInt) {
    return 0;
  }
  
  public final void setMissingConfigSampleRate(int paramInt1, int paramInt2) {}
  
  public final void updateListenerMarkers() {}
  
  public final MarkerEditor withMarker(int paramInt) {
    return 08G.A00;
  }
  
  public final MarkerEditor withMarker(int paramInt1, int paramInt2) {
    return 08G.A00;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\02R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */