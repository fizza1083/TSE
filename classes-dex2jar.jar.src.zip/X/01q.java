package X;

public final class 01q {
  public int A00;
  
  public int A01;
  
  public int A02;
  
  public int mOomAdj = Integer.MIN_VALUE;
  
  public int mOomScore = Integer.MIN_VALUE;
  
  public int mOomScoreAdj = Integer.MIN_VALUE;
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */