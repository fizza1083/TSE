package X;

import android.view.DisplayCutout;
import android.view.WindowInsets;

public abstract class 07Q extends 07R {
  public final 09L A05() {
    DisplayCutout displayCutout = this.A02.getDisplayCutout();
    return (displayCutout == null) ? null : new 09L(displayCutout);
  }
  
  public final 07N A06() {
    WindowInsets windowInsets = this.A02.consumeDisplayCutout();
    07N 07N = 07N.A01;
    windowInsets.getClass();
    return new 07N(windowInsets);
  }
  
  public final boolean equals(Object paramObject) {
    boolean bool2 = true;
    boolean bool1 = bool2;
    if (this != paramObject) {
      if (!(paramObject instanceof 07Q))
        return false; 
      paramObject = paramObject;
      bool1 = bool2;
      if (!0B3.A00(this.A02, ((07S)paramObject).A02))
        bool1 = false; 
    } 
    return bool1;
  }
  
  public final int hashCode() {
    return this.A02.hashCode();
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07Q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */