package X;

import kotlin.enums.EnumEntries;

public enum 02s {
  A02, A03, A04, A05, A06, A07, A08, A09, A0A, A0B;
  
  static {
    02s 02s1 = new 02s("NO_ANR_DETECTED", 0);
    A04 = 02s1;
    02s 02s2 = new 02s("DURING_ANR", 1);
    A03 = 02s2;
    02s 02s3 = new 02s("ANR_RECOVERED", 2);
    A02 = 02s3;
    02s 02s4 = new 02s("SIGQUIT_RECEIVED_AM_UNCONFIRMED_MT_BLOCKED", 3);
    A0A = 02s4;
    02s 02s5 = new 02s("SIGQUIT_RECEIVED_AM_CONFIRMED_MT_BLOCKED", 4);
    A07 = 02s5;
    02s 02s6 = new 02s("SIGQUIT_RECEIVED_AM_CONFIRMED_MT_UNBLOCKED", 5);
    A08 = 02s6;
    02s 02s7 = new 02s("SIGQUIT_RECEIVED_AM_UNCONFIRMED_MT_UNBLOCKED", 6);
    A0B = 02s7;
    02s 02s8 = new 02s("SIGQUIT_RECEIVED_AM_EXPIRED_MT_BLOCKED", 7);
    A09 = 02s8;
    02s 02s9 = new 02s("NO_SIGQUIT_AM_CONFIRMED_MT_BLOCKED", 8);
    A05 = 02s9;
    02s 02s10 = new 02s("NO_SIGQUIT_AM_CONFIRMED_MT_UNBLOCKED", 9);
    A06 = 02s10;
    02s[] arrayOf02s = new 02s[10];
    arrayOf02s[0] = 02s1;
    arrayOf02s[1] = 02s2;
    arrayOf02s[2] = 02s3;
    arrayOf02s[3] = 02s4;
    arrayOf02s[4] = 02s5;
    arrayOf02s[5] = 02s6;
    arrayOf02s[6] = 02s7;
    arrayOf02s[7] = 02s8;
    arrayOf02s[8] = 02s9;
    arrayOf02s[9] = 02s10;
    A01 = arrayOf02s;
    A00 = 00S.A00((Enum[])arrayOf02s);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\02s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */