package X;

import java.util.Arrays;

public final class 08U {
  public final int A00;
  
  public final 08X A01;
  
  public final String A02;
  
  public final String A03;
  
  public final boolean A04;
  
  public final boolean A05;
  
  public 08U(08V param08V) {
    this.A02 = param08V.A02;
    this.A03 = param08V.A03;
    this.A04 = param08V.A05;
    this.A00 = param08V.A00;
    this.A05 = param08V.A06;
    this.A01 = new 08Y(new 08W(param08V));
  }
  
  public static 08U A00(String paramString1, String paramString2) {
    08V 08V = new 08V();
    08V.A02 = paramString1;
    08V.A03 = paramString2;
    return new 08U(08V);
  }
  
  public static 08V A01(String paramString1, String paramString2) {
    08V 08V = new 08V();
    08V.A02 = paramString1;
    08V.A03 = paramString2;
    return 08V;
  }
  
  public final boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject != null && getClass() == paramObject.getClass()) {
        paramObject = paramObject;
        if (this.A04 == ((08U)paramObject).A04 && this.A05 == ((08U)paramObject).A05 && this.A00 == ((08U)paramObject).A00) {
          String str1 = this.A02;
          String str2 = ((08U)paramObject).A02;
          if (str1 == str2 || (str1 != null && str1.equals(str2))) {
            Object object1 = this.A01.get();
            Object object2 = ((08U)paramObject).A01.get();
            if (object1 == object2 || (object1 != null && object1.equals(object2))) {
              object1 = this.A03;
              paramObject = ((08U)paramObject).A03;
              if (object1 == paramObject || (object1 != null && object1.equals(paramObject)))
                return true; 
            } 
          } 
        } 
      } 
    } else {
      return true;
    } 
    return false;
  }
  
  public final int hashCode() {
    return Arrays.hashCode(new Object[] { this.A02, this.A03, Boolean.valueOf(this.A04), Integer.valueOf(this.A00) });
  }
  
  public final String toString() {
    StringBuilder stringBuilder = 001.A0s();
    stringBuilder.append("SoftError{mCategory='");
    stringBuilder.append(this.A02);
    stringBuilder.append('\'');
    stringBuilder.append(", mMessage='");
    stringBuilder.append(this.A03);
    stringBuilder.append('\'');
    stringBuilder.append(", mCause=");
    stringBuilder.append(this.A01.get());
    stringBuilder.append(", mFailHarder=");
    stringBuilder.append(this.A04);
    stringBuilder.append(", mSamplingFrequency=");
    stringBuilder.append(this.A00);
    stringBuilder.append(", mOnlyIfEmployeeOrBetaBuild=");
    stringBuilder.append(this.A05);
    return 002.A0X(stringBuilder);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08U.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */