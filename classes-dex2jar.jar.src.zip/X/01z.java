package X;

import android.content.Context;
import android.content.pm.ProviderInfo;
import android.database.Cursor;
import android.net.Uri;

public interface 01z {
  void CKq(Context paramContext, ProviderInfo paramProviderInfo, Cursor paramCursor, Uri paramUri);
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */