package X;

import android.content.Intent;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class 07Z {
  public static final 07Z[] A04 = new 07Z[0];
  
  public final 0FY A00;
  
  public final 0FY A01;
  
  public final 07a A02;
  
  public final Pattern A03;
  
  public 07Z(0FY param0FY1, 0FY param0FY2, 07a param07a, String paramString) {
    Pattern pattern;
    if (paramString == null) {
      paramString = null;
    } else {
      pattern = Pattern.compile(paramString, 32);
    } 
    this.A03 = pattern;
    this.A01 = param0FY2;
    this.A00 = param0FY1;
    this.A02 = param07a;
  }
  
  public static 07Z[] A00(String paramString) {
    if (paramString == null)
      return A04; 
    try {
      JSONArray jSONArray = new JSONArray(paramString);
      if (jSONArray.length() > 0) {
        07Z[] arrayOf07Z = new 07Z[jSONArray.length()];
        int i = 0;
        while (true) {
          07Z[] arrayOf07Z1 = arrayOf07Z;
          if (i < jSONArray.length()) {
            0FY 0FY1;
            07a 07a1;
            JSONObject jSONObject = jSONArray.getJSONObject(i);
            boolean bool = jSONObject.has("endpoint_name");
            0FY 0FY2 = null;
            if (bool) {
              String str = jSONObject.getString("endpoint_name");
            } else {
              arrayOf07Z1 = null;
            } 
            if (jSONObject.has("caller_info")) {
              0FY1 = 0FY.A00(jSONObject.getJSONObject("caller_info"));
            } else {
              0FY1 = null;
            } 
            if (jSONObject.has("uri_component")) {
              07a1 = 07a.A00(jSONObject.getJSONObject("uri_component"));
            } else {
              07a1 = null;
            } 
            if (jSONObject.has("intent_field"))
              0FY2 = 0FY.A00(jSONObject.getJSONObject("intent_field")); 
            arrayOf07Z[i] = new 07Z(0FY1, 0FY2, 07a1, (String)arrayOf07Z1);
            i++;
            continue;
          } 
          return arrayOf07Z1;
        } 
      } 
    } catch (JSONException jSONException) {}
    return A04;
  }
  
  public final boolean A01(Intent paramIntent, 0G9 param0G9) {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull -> 10
    //   4: aload_2
    //   5: ifnonnull -> 10
    //   8: iconst_0
    //   9: ireturn
    //   10: aconst_null
    //   11: astore #5
    //   13: aload_2
    //   14: astore_3
    //   15: aload_2
    //   16: ifnonnull -> 49
    //   19: aload_1
    //   20: ifnonnull -> 33
    //   23: aconst_null
    //   24: astore_2
    //   25: aconst_null
    //   26: astore #4
    //   28: aload_2
    //   29: astore_3
    //   30: goto -> 55
    //   33: aload_1
    //   34: aconst_null
    //   35: aconst_null
    //   36: invokestatic A00 : (Landroid/content/Intent;LX/0I4;LX/0I4;)LX/0G9;
    //   39: astore_2
    //   40: aload_2
    //   41: astore_3
    //   42: aload_2
    //   43: ifnonnull -> 49
    //   46: goto -> 25
    //   49: aload_3
    //   50: getfield A00 : Ljava/util/List;
    //   53: astore #4
    //   55: aload_0
    //   56: getfield A02 : LX/07a;
    //   59: astore #6
    //   61: aload #6
    //   63: ifnull -> 360
    //   66: aload #4
    //   68: ifnull -> 8
    //   71: aload #4
    //   73: invokeinterface isEmpty : ()Z
    //   78: ifne -> 8
    //   81: aload #4
    //   83: invokeinterface iterator : ()Ljava/util/Iterator;
    //   88: astore #4
    //   90: aload #4
    //   92: invokeinterface hasNext : ()Z
    //   97: ifeq -> 8
    //   100: aload #4
    //   102: invokeinterface next : ()Ljava/lang/Object;
    //   107: checkcast android/net/Uri
    //   110: astore #7
    //   112: aload #6
    //   114: getfield A00 : Ljava/util/Map;
    //   117: invokeinterface entrySet : ()Ljava/util/Set;
    //   122: invokeinterface iterator : ()Ljava/util/Iterator;
    //   127: astore #8
    //   129: aload #8
    //   131: invokeinterface hasNext : ()Z
    //   136: ifeq -> 360
    //   139: aload #8
    //   141: invokeinterface next : ()Ljava/lang/Object;
    //   146: checkcast java/util/Map$Entry
    //   149: astore #9
    //   151: aload #9
    //   153: invokeinterface getKey : ()Ljava/lang/Object;
    //   158: checkcast java/lang/String
    //   161: astore_2
    //   162: aload_2
    //   163: invokevirtual hashCode : ()I
    //   166: lookupswitch default -> 357, -907987547 -> 208, 3433509 -> 226, 107944136 -> 244, 1475610435 -> 262
    //   208: aload_2
    //   209: ldc 'scheme'
    //   211: invokevirtual equals : (Ljava/lang/Object;)Z
    //   214: ifeq -> 90
    //   217: aload #7
    //   219: invokevirtual getScheme : ()Ljava/lang/String;
    //   222: astore_2
    //   223: goto -> 277
    //   226: aload_2
    //   227: ldc 'path'
    //   229: invokevirtual equals : (Ljava/lang/Object;)Z
    //   232: ifeq -> 90
    //   235: aload #7
    //   237: invokevirtual getPath : ()Ljava/lang/String;
    //   240: astore_2
    //   241: goto -> 277
    //   244: aload_2
    //   245: ldc 'query'
    //   247: invokevirtual equals : (Ljava/lang/Object;)Z
    //   250: ifeq -> 90
    //   253: aload #7
    //   255: invokevirtual getQuery : ()Ljava/lang/String;
    //   258: astore_2
    //   259: goto -> 277
    //   262: aload_2
    //   263: ldc 'authority'
    //   265: invokevirtual equals : (Ljava/lang/Object;)Z
    //   268: ifeq -> 90
    //   271: aload #7
    //   273: invokevirtual getAuthority : ()Ljava/lang/String;
    //   276: astore_2
    //   277: aload_2
    //   278: ifnull -> 90
    //   281: aload #9
    //   283: invokeinterface getValue : ()Ljava/lang/Object;
    //   288: checkcast X/07b
    //   291: astore #9
    //   293: aload #9
    //   295: getfield A00 : Ljava/util/regex/Pattern;
    //   298: aload_2
    //   299: invokevirtual matcher : (Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    //   302: invokevirtual matches : ()Z
    //   305: aload #9
    //   307: getfield A01 : Z
    //   310: ixor
    //   311: ifne -> 129
    //   314: goto -> 90
    //   317: aload_3
    //   318: getfield A01 : Lorg/json/JSONObject;
    //   321: astore_2
    //   322: goto -> 366
    //   325: aload_1
    //   326: invokevirtual getSelector : ()Landroid/content/Intent;
    //   329: astore_3
    //   330: aload_0
    //   331: getfield A01 : LX/0FY;
    //   334: astore_1
    //   335: aload_1
    //   336: ifnull -> 376
    //   339: aload_2
    //   340: ifnull -> 8
    //   343: aload_1
    //   344: aload_3
    //   345: aload_2
    //   346: invokevirtual A02 : (Landroid/content/Intent;Lorg/json/JSONObject;)Z
    //   349: ifne -> 376
    //   352: iconst_0
    //   353: ireturn
    //   354: astore_1
    //   355: iconst_0
    //   356: ireturn
    //   357: goto -> 90
    //   360: aload_3
    //   361: ifnonnull -> 317
    //   364: aconst_null
    //   365: astore_2
    //   366: aload #5
    //   368: astore_3
    //   369: aload_1
    //   370: ifnull -> 330
    //   373: goto -> 325
    //   376: iconst_1
    //   377: ireturn
    // Exception table:
    //   from	to	target	type
    //   33	40	354	org/json/JSONException
    //   49	55	354	org/json/JSONException
    //   55	61	354	org/json/JSONException
    //   71	90	354	org/json/JSONException
    //   90	129	354	org/json/JSONException
    //   129	208	354	org/json/JSONException
    //   208	223	354	org/json/JSONException
    //   226	241	354	org/json/JSONException
    //   244	259	354	org/json/JSONException
    //   262	277	354	org/json/JSONException
    //   281	314	354	org/json/JSONException
    //   317	322	354	org/json/JSONException
    //   325	330	354	org/json/JSONException
    //   330	335	354	org/json/JSONException
    //   343	352	354	org/json/JSONException
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07Z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */