package X;

import android.net.Uri;
import android.util.LruCache;
import java.net.URI;

public abstract class 08N {
  public static final LruCache A00;
  
  public static final 08P A01;
  
  static {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: \r\n\tat com.googlecode.dex2jar.ir.ts.NewTransformer.transform(NewTransformer.java:134)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:148)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public static Uri A00(11P param11P, String paramString) {
    return A01(param11P, paramString, false);
  }
  
  public static Uri A01(11P param11P, String paramString, boolean paramBoolean) {
    if (paramString != null) {
      if (param11P != null)
        try {
          return A02(paramString);
        } catch (SecurityException securityException) {
          param11P.DfI("UriParser", 0XK.A1E("Parse uri <sanitized \"", A01.DjQ(paramString), "\"> failed. Fail open: ", paramBoolean), securityException);
          return paramBoolean ? Uri.parse(paramString) : null;
        }  
      throw 001.A0O("reporter is null");
    } 
    throw 001.A0O("Url string is null");
  }
  
  public static Uri A02(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: invokestatic parse : (Ljava/lang/String;)Landroid/net/Uri;
    //   4: astore #5
    //   6: aload #5
    //   8: invokevirtual getScheme : ()Ljava/lang/String;
    //   11: astore #4
    //   13: iconst_1
    //   14: istore_1
    //   15: iconst_1
    //   16: istore_3
    //   17: iload_3
    //   18: istore_2
    //   19: aload #4
    //   21: ifnull -> 70
    //   24: iload_3
    //   25: istore_2
    //   26: aload #4
    //   28: invokevirtual isEmpty : ()Z
    //   31: ifne -> 70
    //   34: aload #4
    //   36: invokevirtual length : ()I
    //   39: bipush #30
    //   41: if_icmpgt -> 77
    //   44: iconst_0
    //   45: istore_1
    //   46: getstatic X/08N.A00 : Landroid/util/LruCache;
    //   49: aload #4
    //   51: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   54: checkcast java/lang/Boolean
    //   57: astore #6
    //   59: aload #6
    //   61: ifnull -> 77
    //   64: aload #6
    //   66: invokevirtual booleanValue : ()Z
    //   69: istore_2
    //   70: iload_2
    //   71: ifne -> 251
    //   74: goto -> 109
    //   77: aload #4
    //   79: ldc '([a-zA-Z][a-zA-Z0-9+.-]*)?'
    //   81: invokevirtual matches : (Ljava/lang/String;)Z
    //   84: istore_3
    //   85: iload_3
    //   86: istore_2
    //   87: iload_1
    //   88: ifne -> 70
    //   91: getstatic X/08N.A00 : Landroid/util/LruCache;
    //   94: aload #4
    //   96: iload_3
    //   97: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   100: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   103: pop
    //   104: iload_3
    //   105: istore_2
    //   106: goto -> 70
    //   109: new java/net/URI
    //   112: dup
    //   113: aload_0
    //   114: invokespecial <init> : (Ljava/lang/String;)V
    //   117: astore #4
    //   119: aload #4
    //   121: invokevirtual isOpaque : ()Z
    //   124: istore_2
    //   125: new android/net/Uri$Builder
    //   128: dup
    //   129: invokespecial <init> : ()V
    //   132: aload #4
    //   134: invokevirtual getScheme : ()Ljava/lang/String;
    //   137: invokevirtual scheme : (Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   140: astore #5
    //   142: iload_2
    //   143: ifeq -> 180
    //   146: aload #5
    //   148: aload #4
    //   150: invokevirtual getRawSchemeSpecificPart : ()Ljava/lang/String;
    //   153: invokevirtual encodedOpaquePart : (Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   156: aload #4
    //   158: invokevirtual getRawFragment : ()Ljava/lang/String;
    //   161: invokevirtual encodedFragment : (Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   164: invokevirtual build : ()Landroid/net/Uri;
    //   167: astore #5
    //   169: aload #5
    //   171: aload_0
    //   172: aload #4
    //   174: invokestatic A04 : (Landroid/net/Uri;Ljava/lang/String;Ljava/net/URI;)V
    //   177: aload #5
    //   179: areturn
    //   180: aload #5
    //   182: aload #4
    //   184: invokevirtual getRawAuthority : ()Ljava/lang/String;
    //   187: invokevirtual encodedAuthority : (Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   190: aload #4
    //   192: invokevirtual getRawPath : ()Ljava/lang/String;
    //   195: invokevirtual encodedPath : (Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   198: aload #4
    //   200: invokevirtual getRawQuery : ()Ljava/lang/String;
    //   203: invokevirtual encodedQuery : (Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   206: aload #4
    //   208: invokevirtual getRawFragment : ()Ljava/lang/String;
    //   211: invokevirtual encodedFragment : (Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   214: invokevirtual build : ()Landroid/net/Uri;
    //   217: astore_0
    //   218: aload_0
    //   219: aload #4
    //   221: iconst_0
    //   222: invokestatic A05 : (Landroid/net/Uri;Ljava/net/URI;Z)V
    //   225: aload_0
    //   226: areturn
    //   227: new java/lang/SecurityException
    //   230: dup
    //   231: ldc 'Parsing url <sanitized "'
    //   233: getstatic X/08N.A01 : LX/08P;
    //   236: aload_0
    //   237: invokeinterface DjQ : (Ljava/lang/String;)Ljava/lang/String;
    //   242: ldc '"> caused exception'
    //   244: invokestatic A0p : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   247: invokespecial <init> : (Ljava/lang/String;)V
    //   250: athrow
    //   251: aload #5
    //   253: invokevirtual isOpaque : ()Z
    //   256: ifeq -> 318
    //   259: new java/net/URI
    //   262: dup
    //   263: aload #5
    //   265: invokevirtual getScheme : ()Ljava/lang/String;
    //   268: aload #5
    //   270: invokevirtual getSchemeSpecificPart : ()Ljava/lang/String;
    //   273: aload #5
    //   275: invokevirtual getFragment : ()Ljava/lang/String;
    //   278: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   281: astore #4
    //   283: aload #5
    //   285: aload_0
    //   286: aload #4
    //   288: invokestatic A04 : (Landroid/net/Uri;Ljava/lang/String;Ljava/net/URI;)V
    //   291: aload #5
    //   293: areturn
    //   294: new java/lang/SecurityException
    //   297: dup
    //   298: ldc 'Parsing url <sanitized "'
    //   300: getstatic X/08N.A01 : LX/08P;
    //   303: aload_0
    //   304: invokeinterface DjQ : (Ljava/lang/String;)Ljava/lang/String;
    //   309: ldc '"> caused exception'
    //   311: invokestatic A0p : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   314: invokespecial <init> : (Ljava/lang/String;)V
    //   317: athrow
    //   318: new java/net/URI
    //   321: dup
    //   322: aload #5
    //   324: invokevirtual getScheme : ()Ljava/lang/String;
    //   327: aload #5
    //   329: invokevirtual getUserInfo : ()Ljava/lang/String;
    //   332: aload #5
    //   334: invokevirtual getHost : ()Ljava/lang/String;
    //   337: aload #5
    //   339: invokevirtual getPort : ()I
    //   342: aload #5
    //   344: invokevirtual getPath : ()Ljava/lang/String;
    //   347: aload #5
    //   349: invokevirtual getQuery : ()Ljava/lang/String;
    //   352: aload #5
    //   354: invokevirtual getFragment : ()Ljava/lang/String;
    //   357: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   360: astore #4
    //   362: aload #4
    //   364: astore_0
    //   365: goto -> 415
    //   368: new java/net/URI
    //   371: dup
    //   372: aload #5
    //   374: invokevirtual toString : ()Ljava/lang/String;
    //   377: invokespecial <init> : (Ljava/lang/String;)V
    //   380: astore #4
    //   382: aload #5
    //   384: invokevirtual getHost : ()Ljava/lang/String;
    //   387: astore #6
    //   389: aload #4
    //   391: invokevirtual getHost : ()Ljava/lang/String;
    //   394: ifnonnull -> 460
    //   397: aload #6
    //   399: ifnull -> 460
    //   402: aload #6
    //   404: ldc '_'
    //   406: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   409: ifeq -> 460
    //   412: aload #4
    //   414: astore_0
    //   415: aload #5
    //   417: invokevirtual getHost : ()Ljava/lang/String;
    //   420: astore #4
    //   422: aload_0
    //   423: invokevirtual getHost : ()Ljava/lang/String;
    //   426: ifnonnull -> 448
    //   429: aload #4
    //   431: ifnull -> 448
    //   434: aload #4
    //   436: ldc '_'
    //   438: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   441: istore_3
    //   442: iconst_1
    //   443: istore_2
    //   444: iload_3
    //   445: ifne -> 450
    //   448: iconst_0
    //   449: istore_2
    //   450: aload #5
    //   452: aload_0
    //   453: iload_2
    //   454: invokestatic A05 : (Landroid/net/Uri;Ljava/net/URI;Z)V
    //   457: aload #5
    //   459: areturn
    //   460: new java/lang/SecurityException
    //   463: dup
    //   464: ldc 'Parsing url <sanitized "'
    //   466: getstatic X/08N.A01 : LX/08P;
    //   469: aload_0
    //   470: invokeinterface DjQ : (Ljava/lang/String;)Ljava/lang/String;
    //   475: ldc '"> caused exception'
    //   477: invokestatic A0p : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   480: invokespecial <init> : (Ljava/lang/String;)V
    //   483: athrow
    //   484: astore #4
    //   486: goto -> 227
    //   489: astore #4
    //   491: goto -> 294
    //   494: astore #4
    //   496: goto -> 368
    //   499: astore #4
    //   501: goto -> 460
    // Exception table:
    //   from	to	target	type
    //   109	119	484	java/net/URISyntaxException
    //   259	283	489	java/net/URISyntaxException
    //   318	362	494	java/net/URISyntaxException
    //   368	397	499	java/net/URISyntaxException
    //   402	412	499	java/net/URISyntaxException
  }
  
  @Deprecated
  public static Uri A03(String paramString) {
    URI uRI = URI.create(paramString);
    Uri uri = (new Uri.Builder()).scheme(uRI.getScheme()).encodedAuthority(uRI.getRawAuthority()).encodedPath(uRI.getRawPath()).encodedQuery(uRI.getRawQuery()).encodedFragment(uRI.getRawFragment()).build();
    A05(uri, uRI, false);
    return uri;
  }
  
  public static void A04(Uri paramUri, String paramString, URI paramURI) {
    boolean bool1 = A07(paramURI.getScheme(), paramUri.getScheme());
    boolean bool2 = A07(paramURI.getSchemeSpecificPart(), paramUri.getSchemeSpecificPart());
    if (bool1 && bool2)
      return; 
    String str = paramURI.toString();
    08P 08P1 = A01;
    throw 001.A0c(0XK.A19("java uri <sanitized \"", 08P1.DjQ(str), "\"> not equal to android uri <sanitized \"", 08P1.DjQ(paramUri.toString()), "\"> from original <sanitized \"", 08P1.DjQ(paramString), "\">"));
  }
  
  public static void A05(Uri paramUri, URI paramURI, boolean paramBoolean) {
    boolean bool1 = A07(paramURI.getScheme(), paramUri.getScheme());
    boolean bool2 = A07(paramURI.getAuthority(), paramUri.getAuthority());
    boolean bool3 = A07(paramURI.getPath(), paramUri.getPath());
    if (bool1 && bool2 && bool3)
      return; 
    String str3 = "";
    if (!bool1)
      str3 = 0XK.A17("", "javaUri scheme: \"", paramURI.getScheme(), "\". androidUri scheme: \"", paramUri.getScheme(), "\"."); 
    String str2 = str3;
    if (!paramBoolean) {
      str2 = str3;
      if (!bool2)
        str2 = 0XK.A17(str3, "javaUri authority: \"", paramURI.getAuthority(), "\". androidUri authority: \"", paramUri.getAuthority(), "\"."); 
    } 
    str3 = str2;
    if (!bool3)
      str3 = 0XK.A17(str2, "javaUri path: \"", paramURI.getPath(), "\". androidUri path: \"", paramUri.getPath(), "\"."); 
    String str1 = paramURI.toString();
    08P 08P1 = A01;
    throw 001.A0c(0XK.A19("java uri <sanitized \"", 08P1.DjQ(str1), "\"> not equal to android uri <sanitized \"", 08P1.DjQ(paramUri.toString()), "\">. Debug info ", str3, "."));
  }
  
  public static boolean A06(Uri paramUri, String paramString, boolean paramBoolean) {
    String str = paramUri.getHost();
    boolean bool = false;
    null = bool;
    if (str != null) {
      if (!str.equalsIgnoreCase(paramString)) {
        null = bool;
        if (paramBoolean) {
          null = bool;
          if (str.endsWith(0XK.A0b(".", paramString)))
            return true; 
        } 
        return null;
      } 
    } else {
      return null;
    } 
    return true;
  }
  
  public static boolean A07(String paramString1, String paramString2) {
    if (paramString1 != null && !paramString1.equals(""))
      return paramString1.equals(paramString2); 
    if (paramString2 != null) {
      boolean bool1 = paramString2.equals("");
      boolean bool = false;
      return bool1 ? true : bool;
    } 
    return true;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08N.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */