package X;

import java.io.BufferedReader;
import java.io.Reader;
import java.io.StringWriter;
import java.util.Iterator;

public abstract class 03S {
  public static final String A00(Reader paramReader) {
    StringWriter stringWriter = new StringWriter();
    char[] arrayOfChar = new char[8192];
    while (true) {
      int i = paramReader.read(arrayOfChar);
      if (i >= 0) {
        stringWriter.write(arrayOfChar, 0, i);
        continue;
      } 
      String str = stringWriter.toString();
      16F.A0A(str);
      return str;
    } 
  }
  
  public static final void A01(Reader paramReader, 0BQ param0BQ) {
    paramReader = paramReader;
    try {
      Iterator iterator = (new 0Dp(new 0uG((BufferedReader)paramReader))).iterator();
      while (iterator.hasNext())
        param0BQ.invoke(iterator.next()); 
      return;
    } finally {
      param0BQ = null;
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\03S.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */