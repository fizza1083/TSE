package X;

import java.util.concurrent.CancellationException;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

public abstract class 04k implements 04l {
  static {
    A00 = AtomicReferenceFieldUpdater.newUpdater(04k.class, Object.class, "_parentHandle$volatile");
  }
  
  public static final int A00(Object paramObject, 04k param04k) {
    0Io 0Io;
    AtomicReferenceFieldUpdater atomicReferenceFieldUpdater;
    if (paramObject instanceof 04p) {
      if (!((04p)paramObject).A00) {
        atomicReferenceFieldUpdater = A01;
        04p 04p = 04n.A00;
      } else {
        return 0;
      } 
    } else if (paramObject instanceof 0In) {
      atomicReferenceFieldUpdater = A01;
      0Io = ((0In)paramObject).A00;
    } else {
      return 0;
    } 
    if (!05v.A00(param04k, paramObject, 0Io, atomicReferenceFieldUpdater))
      return -1; 
    param04k.A0F();
    return 1;
  }
  
  private final Object A01(Object paramObject1, Object paramObject2) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: \r\n\tat com.googlecode.dex2jar.ir.ts.NewTransformer.transform(NewTransformer.java:134)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:148)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public static final Object A02(Object paramObject, 0Ir param0Ir, 04k param04k) {
    // Byte code:
    //   0: aload_0
    //   1: instanceof X/0IX
    //   4: istore_3
    //   5: aconst_null
    //   6: astore #4
    //   8: aload #4
    //   10: astore #6
    //   12: iload_3
    //   13: ifeq -> 38
    //   16: aload_0
    //   17: checkcast X/0IX
    //   20: astore #5
    //   22: aload #4
    //   24: astore #6
    //   26: aload #5
    //   28: ifnull -> 38
    //   31: aload #5
    //   33: getfield A00 : Ljava/lang/Throwable;
    //   36: astore #6
    //   38: aload_1
    //   39: monitorenter
    //   40: getstatic X/0Ir.A03 : Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;
    //   43: astore #8
    //   45: aload #8
    //   47: aload_1
    //   48: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   51: pop
    //   52: getstatic X/0Ir.A02 : Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;
    //   55: astore #4
    //   57: aload #4
    //   59: aload_1
    //   60: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   63: astore #7
    //   65: aload #7
    //   67: ifnonnull -> 107
    //   70: new java/util/ArrayList
    //   73: dup
    //   74: iconst_4
    //   75: invokespecial <init> : (I)V
    //   78: astore #5
    //   80: aload #8
    //   82: aload_1
    //   83: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   86: checkcast java/lang/Throwable
    //   89: astore #7
    //   91: aload #7
    //   93: ifnull -> 154
    //   96: aload #5
    //   98: iconst_0
    //   99: aload #7
    //   101: invokevirtual add : (ILjava/lang/Object;)V
    //   104: goto -> 154
    //   107: aload #7
    //   109: instanceof java/lang/Throwable
    //   112: ifeq -> 136
    //   115: new java/util/ArrayList
    //   118: dup
    //   119: iconst_4
    //   120: invokespecial <init> : (I)V
    //   123: astore #5
    //   125: aload #5
    //   127: aload #7
    //   129: invokevirtual add : (Ljava/lang/Object;)Z
    //   132: pop
    //   133: goto -> 80
    //   136: aload #7
    //   138: instanceof java/util/ArrayList
    //   141: ifeq -> 656
    //   144: aload #7
    //   146: checkcast java/util/ArrayList
    //   149: astore #5
    //   151: goto -> 80
    //   154: aload #6
    //   156: ifnull -> 177
    //   159: aload #6
    //   161: aload #7
    //   163: invokevirtual equals : (Ljava/lang/Object;)Z
    //   166: ifne -> 177
    //   169: aload #5
    //   171: aload #6
    //   173: invokevirtual add : (Ljava/lang/Object;)Z
    //   176: pop
    //   177: aload #4
    //   179: aload_1
    //   180: getstatic X/04n.A05 : LX/04o;
    //   183: invokevirtual set : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   186: aload #5
    //   188: invokevirtual isEmpty : ()Z
    //   191: istore_3
    //   192: aconst_null
    //   193: astore #4
    //   195: aconst_null
    //   196: astore #7
    //   198: iload_3
    //   199: ifeq -> 232
    //   202: aload #8
    //   204: aload_1
    //   205: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   208: checkcast java/lang/Throwable
    //   211: ifnull -> 681
    //   214: new X/0Q2
    //   217: dup
    //   218: aload_2
    //   219: invokevirtual A0D : ()Ljava/lang/String;
    //   222: aconst_null
    //   223: aload_2
    //   224: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;LX/04l;)V
    //   227: astore #4
    //   229: goto -> 681
    //   232: aload #5
    //   234: invokevirtual iterator : ()Ljava/util/Iterator;
    //   237: astore #8
    //   239: aload #8
    //   241: invokeinterface hasNext : ()Z
    //   246: ifeq -> 672
    //   249: aload #8
    //   251: invokeinterface next : ()Ljava/lang/Object;
    //   256: astore #4
    //   258: aload #4
    //   260: instanceof java/util/concurrent/CancellationException
    //   263: iconst_1
    //   264: ixor
    //   265: ifeq -> 239
    //   268: aload #4
    //   270: checkcast java/lang/Throwable
    //   273: astore #8
    //   275: aload #8
    //   277: astore #4
    //   279: aload #8
    //   281: ifnonnull -> 378
    //   284: aload #5
    //   286: iconst_0
    //   287: invokevirtual get : (I)Ljava/lang/Object;
    //   290: checkcast java/lang/Throwable
    //   293: astore #8
    //   295: aload #8
    //   297: astore #4
    //   299: aload #8
    //   301: instanceof X/0Q6
    //   304: ifeq -> 681
    //   307: aload #5
    //   309: invokevirtual iterator : ()Ljava/util/Iterator;
    //   312: astore #9
    //   314: aload #7
    //   316: astore #4
    //   318: aload #9
    //   320: invokeinterface hasNext : ()Z
    //   325: ifeq -> 355
    //   328: aload #9
    //   330: invokeinterface next : ()Ljava/lang/Object;
    //   335: astore #4
    //   337: aload #4
    //   339: aload #8
    //   341: if_acmpeq -> 314
    //   344: aload #4
    //   346: instanceof X/0Q6
    //   349: ifeq -> 314
    //   352: goto -> 678
    //   355: aload #4
    //   357: checkcast java/lang/Throwable
    //   360: astore #7
    //   362: aload #8
    //   364: astore #4
    //   366: aload #7
    //   368: ifnull -> 681
    //   371: aload #7
    //   373: astore #4
    //   375: goto -> 681
    //   378: aload #4
    //   380: astore #7
    //   382: aload #5
    //   384: invokevirtual size : ()I
    //   387: iconst_1
    //   388: if_icmple -> 478
    //   391: new java/util/IdentityHashMap
    //   394: dup
    //   395: aload #5
    //   397: invokevirtual size : ()I
    //   400: invokespecial <init> : (I)V
    //   403: invokestatic newSetFromMap : (Ljava/util/Map;)Ljava/util/Set;
    //   406: astore #8
    //   408: aload #5
    //   410: invokevirtual iterator : ()Ljava/util/Iterator;
    //   413: astore #5
    //   415: aload #4
    //   417: astore #7
    //   419: aload #5
    //   421: invokeinterface hasNext : ()Z
    //   426: ifeq -> 478
    //   429: aload #5
    //   431: invokeinterface next : ()Ljava/lang/Object;
    //   436: checkcast java/lang/Throwable
    //   439: astore #7
    //   441: aload #7
    //   443: aload #4
    //   445: if_acmpeq -> 415
    //   448: aload #7
    //   450: instanceof java/util/concurrent/CancellationException
    //   453: ifne -> 415
    //   456: aload #8
    //   458: aload #7
    //   460: invokeinterface add : (Ljava/lang/Object;)Z
    //   465: ifeq -> 415
    //   468: aload #4
    //   470: aload #7
    //   472: invokestatic A01 : (Ljava/lang/Throwable;Ljava/lang/Throwable;)V
    //   475: goto -> 415
    //   478: aload_1
    //   479: monitorexit
    //   480: aload_0
    //   481: astore #4
    //   483: aload #7
    //   485: ifnull -> 579
    //   488: aload #7
    //   490: aload #6
    //   492: if_acmpeq -> 506
    //   495: new X/0IX
    //   498: dup
    //   499: aload #7
    //   501: iconst_0
    //   502: invokespecial <init> : (Ljava/lang/Throwable;Z)V
    //   505: astore_0
    //   506: aload_2
    //   507: invokevirtual A0N : ()Z
    //   510: ifne -> 560
    //   513: aload #7
    //   515: instanceof java/util/concurrent/CancellationException
    //   518: istore_3
    //   519: getstatic X/04k.A00 : Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;
    //   522: aload_2
    //   523: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   526: checkcast X/04t
    //   529: astore #4
    //   531: aload #4
    //   533: ifnull -> 637
    //   536: aload #4
    //   538: getstatic X/04r.A00 : LX/04r;
    //   541: if_acmpeq -> 637
    //   544: aload #4
    //   546: aload #7
    //   548: invokeinterface AO7 : (Ljava/lang/Throwable;)Z
    //   553: ifne -> 560
    //   556: iload_3
    //   557: ifeq -> 641
    //   560: aload_0
    //   561: ldc 'null cannot be cast to non-null type kotlinx.coroutines.CompletedExceptionally'
    //   563: invokestatic A0I : (Ljava/lang/Object;Ljava/lang/String;)V
    //   566: getstatic X/0IX.A01 : Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;
    //   569: aload_0
    //   570: iconst_0
    //   571: iconst_1
    //   572: invokevirtual compareAndSet : (Ljava/lang/Object;II)Z
    //   575: pop
    //   576: aload_0
    //   577: astore #4
    //   579: aload_2
    //   580: aload #4
    //   582: invokevirtual A0H : (Ljava/lang/Object;)V
    //   585: getstatic X/04k.A01 : Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;
    //   588: astore #6
    //   590: aload #4
    //   592: astore_0
    //   593: aload_0
    //   594: astore #5
    //   596: aload #4
    //   598: instanceof X/04q
    //   601: ifeq -> 617
    //   604: new X/0QU
    //   607: dup
    //   608: aload_0
    //   609: checkcast X/04q
    //   612: invokespecial <init> : (LX/04q;)V
    //   615: astore #5
    //   617: aload_2
    //   618: aload_1
    //   619: aload #5
    //   621: aload #6
    //   623: invokestatic A00 : (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;)Z
    //   626: pop
    //   627: aload_2
    //   628: aload #4
    //   630: aload_1
    //   631: invokespecial A06 : (Ljava/lang/Object;LX/04q;)V
    //   634: aload #4
    //   636: areturn
    //   637: iload_3
    //   638: ifne -> 560
    //   641: aload_0
    //   642: astore #4
    //   644: aload_2
    //   645: aload #7
    //   647: invokevirtual A0R : (Ljava/lang/Throwable;)Z
    //   650: ifeq -> 579
    //   653: goto -> 560
    //   656: aload #7
    //   658: ldc 'State is '
    //   660: invokestatic A0s : ()Ljava/lang/StringBuilder;
    //   663: invokestatic A0L : (Ljava/lang/Object;Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/IllegalStateException;
    //   666: athrow
    //   667: astore_0
    //   668: aload_1
    //   669: monitorexit
    //   670: aload_0
    //   671: athrow
    //   672: aconst_null
    //   673: astore #4
    //   675: goto -> 268
    //   678: goto -> 355
    //   681: aload #4
    //   683: astore #7
    //   685: aload #4
    //   687: ifnull -> 478
    //   690: goto -> 378
    // Exception table:
    //   from	to	target	type
    //   40	65	667	finally
    //   70	80	667	finally
    //   80	91	667	finally
    //   96	104	667	finally
    //   107	133	667	finally
    //   136	151	667	finally
    //   159	177	667	finally
    //   177	192	667	finally
    //   202	229	667	finally
    //   232	239	667	finally
    //   239	268	667	finally
    //   268	275	667	finally
    //   284	295	667	finally
    //   299	314	667	finally
    //   318	337	667	finally
    //   344	352	667	finally
    //   355	362	667	finally
    //   382	415	667	finally
    //   419	441	667	finally
    //   448	475	667	finally
    //   656	667	667	finally
  }
  
  public static final String A03(Object paramObject) {
    boolean bool = paramObject instanceof 0Ir;
    String str = "Active";
    return bool ? ((0Ir.A03.get(paramObject) != null) ? "Cancelling" : ((0Ir.A01.get(paramObject) != 0) ? "Completing" : str)) : ((paramObject instanceof 04q) ? (!((04q)paramObject).C2C() ? "New" : str) : ((paramObject instanceof 0IX) ? "Cancelled" : "Completed"));
  }
  
  private final Throwable A04(Object paramObject) {
    if (paramObject instanceof Throwable) {
      Throwable throwable = (Throwable)paramObject;
      paramObject = throwable;
      if (throwable == null)
        paramObject = new 0Q2(A0D(), null, this); 
      return (Throwable)paramObject;
    } 
    04k 04k1 = (04k)paramObject;
    Object object = 04k1.A0A();
    boolean bool = object instanceof 0Ir;
    paramObject = null;
    if (bool) {
      paramObject = 0Ir.A03.get(object);
    } else if (object instanceof 0IX) {
      paramObject = ((0IX)object).A00;
    } else if (object instanceof 04q) {
      throw 002.A0L(object, "Cannot be cancelling child in this state: ", 001.A0s());
    } 
    if (paramObject instanceof CancellationException) {
      Object object1 = paramObject;
      return (Throwable)((paramObject == null) ? new 0Q2(0XK.A0b("Parent job is ", A03(object)), (Throwable)paramObject, 04k1) : object1);
    } 
    return new 0Q2(0XK.A0b("Parent job is ", A03(object)), (Throwable)paramObject, 04k1);
  }
  
  public static final 04u A05(04y param04y) {
    04y 04y1;
    while (true) {
      04y1 = param04y;
      if (param04y.A03()) {
        04y 04y2 = 04y.A00(param04y);
        04y1 = 04y2;
        if (04y2 == null) {
          AtomicReferenceFieldUpdater<04y, 04y> atomicReferenceFieldUpdater = 04y.A01;
          param04y = atomicReferenceFieldUpdater.get(param04y);
          while (true) {
            param04y = param04y;
            04y1 = param04y;
            if (param04y.A03()) {
              param04y = atomicReferenceFieldUpdater.get(param04y);
              continue;
            } 
            break;
          } 
        } 
        param04y = 04y1;
        continue;
      } 
      break;
    } 
    while (true) {
      param04y = 04y1.A02();
      04y1 = param04y;
      if (!param04y.A03()) {
        if (param04y instanceof 04u)
          return (04u)param04y; 
        04y1 = param04y;
        if (param04y instanceof 0Io)
          return null; 
      } 
    } 
  }
  
  private final void A06(Object paramObject, 04q param04q) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: \r\n\tat com.googlecode.dex2jar.ir.ts.NewTransformer.transform(NewTransformer.java:134)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:148)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  private final void A07(Throwable paramThrowable, 0Io param0Io) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: \r\n\tat com.googlecode.dex2jar.ir.ts.NewTransformer.transform(NewTransformer.java:134)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:148)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  private final void A08(04w param04w) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: \r\n\tat com.googlecode.dex2jar.ir.ts.NewTransformer.transform(NewTransformer.java:134)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:148)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  private final boolean A09(Object paramObject, 04w param04w, 0Io param0Io) {
    0Is 0Is = new 0Is(paramObject, this, param04w);
    while (true) {
      04y 04y = 04y.A00(param0Io);
      paramObject = 04y;
      if (04y == null) {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater1 = 04y.A01;
        paramObject = atomicReferenceFieldUpdater1.get(param0Io);
        while (true) {
          04y = (04y)paramObject;
          paramObject = 04y;
          if (04y.A03()) {
            paramObject = atomicReferenceFieldUpdater1.get(04y);
            continue;
          } 
          break;
        } 
      } 
      04y.A01.set(param04w, paramObject);
      AtomicReferenceFieldUpdater<04w, 0Io> atomicReferenceFieldUpdater = 04y.A00;
      atomicReferenceFieldUpdater.set(param04w, param0Io);
      0Is.A00 = param0Io;
      if (05v.A00(paramObject, param0Io, 0Is, atomicReferenceFieldUpdater)) {
        paramObject = 0Is.A00(paramObject);
        boolean bool = false;
        if (paramObject == null)
          bool = true; 
        return bool;
      } 
    } 
  }
  
  public final Object A0A() {
    AtomicReferenceFieldUpdater<04k, Object> atomicReferenceFieldUpdater = A01;
    while (true) {
      05u 05u = (05u)atomicReferenceFieldUpdater.get(this);
      if (!(05u instanceof 05u))
        return 05u; 
      ((05u)05u).A00(this);
    } 
  }
  
  public final Object A0B(Object paramObject) {
    while (true) {
      Object object = A01(A0A(), paramObject);
      if (object != 04n.A02) {
        if (object != 04n.A03)
          return object; 
        continue;
      } 
      object = 001.A0s();
      object.append("Job ");
      object.append(this);
      String str = 002.A0T(paramObject, " is already complete or completing, but is being completed with ", (StringBuilder)object);
      boolean bool = paramObject instanceof 0IX;
      Object object1 = null;
      object = object1;
      if (bool) {
        paramObject = paramObject;
        object = object1;
        if (paramObject != null)
          object = ((0IX)paramObject).A00; 
      } 
      throw new IllegalStateException(str, object);
    } 
  }
  
  public final Object A0C(05D param05D) {
    while (true) {
      Object object = A0A();
      if (!(object instanceof 04q)) {
        if (object instanceof 0IX)
          throw ((0IX)object).A00; 
      } else {
        if (A00(object, this) >= 0) {
          object = 0IT.__redex_internal_original_name;
          param05D = new 0WH(05x.A02(param05D), this);
          param05D.A0G();
          0IT.A02(new 0Qe(C24(new 0WI((0IT)param05D), false, true)), (0IT)param05D);
          return param05D.A0C();
        } 
        continue;
      } 
      return 04n.A00(object);
    } 
  }
  
  public String A0D() {
    return "Job was cancelled";
  }
  
  public String A0E() {
    return 001.A0g(this);
  }
  
  public void A0F() {}
  
  public void A0G(Object paramObject) {}
  
  public void A0H(Object paramObject) {}
  
  public void A0I(Throwable paramThrowable) {
    A0O(paramThrowable);
  }
  
  public void A0J(Throwable paramThrowable) {
    throw paramThrowable;
  }
  
  public final void A0K(04l param04l) {
    if (param04l != null) {
      04k 04k1 = (04k)param04l;
      while (true) {
        int i = A00(04k1.A0A(), 04k1);
        if (i != 0 && i != 1)
          continue; 
        break;
      } 
      04s 04s = param04l.C24(new 04u(this), true, true);
      16F.A0I(04s, "null cannot be cast to non-null type kotlinx.coroutines.ChildHandle");
      A00.set(this, 04s);
      if ((A0A() instanceof 04q ^ true) != 0) {
        04s.dispose();
      } else {
        return;
      } 
    } 
    04r 04r = 04r.A00;
    A00.set(this, 04r);
  }
  
  public boolean A0L() {
    return true;
  }
  
  public boolean A0M() {
    return false;
  }
  
  public boolean A0N() {
    return false;
  }
  
  public final boolean A0O(Object paramObject) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: \r\n\tat com.googlecode.dex2jar.ir.ts.NewTransformer.transform(NewTransformer.java:134)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:148)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public final boolean A0P(Object paramObject) {
    while (true) {
      Object object = A01(A0A(), paramObject);
      if (object == 04n.A02)
        return false; 
      04o 04o = 04n.A04;
      boolean bool = true;
      if (object != 04o) {
        if (object != 04n.A03) {
          A0G(object);
          return true;
        } 
        continue;
      } 
      return bool;
    } 
  }
  
  public boolean A0Q(Throwable paramThrowable) {
    return (paramThrowable instanceof CancellationException || (A0O(paramThrowable) && A0L()));
  }
  
  public boolean A0R(Throwable paramThrowable) {
    return false;
  }
  
  public void AMi(CancellationException paramCancellationException) {
    CancellationException cancellationException = paramCancellationException;
    if (paramCancellationException == null)
      cancellationException = new 0Q2(A0D(), null, this); 
    A0I(cancellationException);
  }
  
  public final CancellationException AzG() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual A0A : ()Ljava/lang/Object;
    //   4: astore_1
    //   5: aload_1
    //   6: instanceof X/0Ir
    //   9: ifeq -> 88
    //   12: getstatic X/0Ir.A03 : Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;
    //   15: aload_1
    //   16: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   19: checkcast java/lang/Throwable
    //   22: astore #4
    //   24: aload #4
    //   26: ifnull -> 142
    //   29: aload_0
    //   30: invokevirtual getClass : ()Ljava/lang/Class;
    //   33: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   36: ldc_w ' is cancelling'
    //   39: invokestatic A0b : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   42: astore_2
    //   43: aload #4
    //   45: instanceof java/util/concurrent/CancellationException
    //   48: ifeq -> 63
    //   51: aload #4
    //   53: checkcast java/util/concurrent/CancellationException
    //   56: astore_3
    //   57: aload_3
    //   58: astore_1
    //   59: aload_3
    //   60: ifnonnull -> 86
    //   63: aload_2
    //   64: astore_1
    //   65: aload_2
    //   66: ifnonnull -> 74
    //   69: aload_0
    //   70: invokevirtual A0D : ()Ljava/lang/String;
    //   73: astore_1
    //   74: new X/0Q2
    //   77: dup
    //   78: aload_1
    //   79: aload #4
    //   81: aload_0
    //   82: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;LX/04l;)V
    //   85: astore_1
    //   86: aload_1
    //   87: areturn
    //   88: aload_1
    //   89: instanceof X/04q
    //   92: ifne -> 173
    //   95: aload_1
    //   96: instanceof X/0IX
    //   99: ifeq -> 153
    //   102: aload_1
    //   103: checkcast X/0IX
    //   106: getfield A00 : Ljava/lang/Throwable;
    //   109: astore_3
    //   110: aload_3
    //   111: instanceof java/util/concurrent/CancellationException
    //   114: ifeq -> 128
    //   117: aload_3
    //   118: checkcast java/util/concurrent/CancellationException
    //   121: astore_2
    //   122: aload_2
    //   123: astore_1
    //   124: aload_2
    //   125: ifnonnull -> 86
    //   128: new X/0Q2
    //   131: dup
    //   132: aload_0
    //   133: invokevirtual A0D : ()Ljava/lang/String;
    //   136: aload_3
    //   137: aload_0
    //   138: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;LX/04l;)V
    //   141: areturn
    //   142: aload_0
    //   143: ldc_w 'Job is still new or active: '
    //   146: invokestatic A0s : ()Ljava/lang/StringBuilder;
    //   149: invokestatic A0L : (Ljava/lang/Object;Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/IllegalStateException;
    //   152: athrow
    //   153: new X/0Q2
    //   156: dup
    //   157: aload_0
    //   158: invokestatic A0g : (Ljava/lang/Object;)Ljava/lang/String;
    //   161: ldc_w ' has completed normally'
    //   164: invokestatic A0b : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   167: aconst_null
    //   168: aload_0
    //   169: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;LX/04l;)V
    //   172: areturn
    //   173: aload_0
    //   174: ldc_w 'Job is still new or active: '
    //   177: invokestatic A0s : ()Ljava/lang/StringBuilder;
    //   180: invokestatic A0L : (Ljava/lang/Object;Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/IllegalStateException;
    //   183: athrow
  }
  
  public final 04s C24(0BQ param0BQ, boolean paramBoolean1, boolean paramBoolean2) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: \r\n\tat com.googlecode.dex2jar.ir.ts.NewTransformer.transform(NewTransformer.java:134)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:148)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public final boolean C2C() {
    Object object = A0A();
    if (object instanceof 04q) {
      boolean bool1 = ((04q)object).C2C();
      boolean bool = true;
      return !bool1 ? false : bool;
    } 
    return false;
  }
  
  public final Object CC1(05D param05D) {
    while (true) {
      Object object = A0A();
      if (!(object instanceof 04q)) {
        0IZ.A01(param05D.B2c());
        return 0BV.A00;
      } 
      if (A00(object, this) >= 0) {
        object = 0IT.__redex_internal_original_name;
        param05D = new 0IT(05x.A02(param05D), 1);
        param05D.A0G();
        0IT.A02(new 0Qe(C24(new 0QT(param05D), false, true)), (0IT)param05D);
        object = param05D.A0C();
        0IS 0IS = 0IS.A02;
        Object object1 = object;
        if (object != 0IS)
          object1 = 0BV.A00; 
        return (object1 == 0IS) ? object1 : 0BV.A00;
      } 
    } 
  }
  
  public final Object fold(Object paramObject, 053 param053) {
    16F.A0E(param053, 2);
    return param053.invoke(paramObject, this);
  }
  
  public final 04H get(04R param04R) {
    return 04z.A00(this, param04R);
  }
  
  public final 04R getKey() {
    return 04l.A00;
  }
  
  public final boolean isCancelled() {
    Object object = A0A();
    return (object instanceof 0IX || (object instanceof 0Ir && 0Ir.A03.get(object) != null));
  }
  
  public final 04I minusKey(04R param04R) {
    return 04z.A01(this, param04R);
  }
  
  public final 04I plus(04I param04I) {
    return 04z.A02(this, param04I);
  }
  
  public final String toString() {
    return 0XK.A0d(0XK.A0e(A0E(), A03(A0A()), '{', '}'), Integer.toHexString(System.identityHashCode(this)), '@');
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\04k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */