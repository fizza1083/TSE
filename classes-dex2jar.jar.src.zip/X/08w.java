package X;

import android.view.View;
import androidx.fragment.app.Fragment;

public final class 08w extends 0Cv {
  public 08w(Fragment paramFragment) {}
  
  public final View A00(int paramInt) {
    Fragment fragment = this.A00;
    View view = fragment.mView;
    if (view != null)
      return view.findViewById(paramInt); 
    throw 002.A0N(" does not have a view", 002.A0Z(fragment));
  }
  
  public final boolean A01() {
    View view = this.A00.mView;
    boolean bool = false;
    if (view != null)
      bool = true; 
    return bool;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */