package X;

import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public abstract class 06R {
  public static final ReadWriteLock A00 = new ReentrantReadWriteLock();
  
  public static volatile boolean A01;
  
  public static void A00() {
    try {
      ReadWriteLock readWriteLock = A00;
      readWriteLock.readLock().lock();
      return;
    } finally {
      001.A1T(A00);
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\06R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */