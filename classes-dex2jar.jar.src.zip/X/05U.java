package X;

import java.io.Closeable;
import java.util.ArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.locks.LockSupport;

public final class 05U implements Executor, Closeable {
  public static final 04o A07;
  
  public final int A00;
  
  public final int A01;
  
  public final long A02;
  
  public final String A03;
  
  public final 05Y A04;
  
  public final 05V A05;
  
  public final 05V A06;
  
  static {
    A09 = AtomicLongFieldUpdater.newUpdater(05U.class, "controlState$volatile");
    A08 = AtomicIntegerFieldUpdater.newUpdater(05U.class, "_isTerminated$volatile");
    A07 = 04o.A00("NOT_IN_STACK");
  }
  
  public 05U(int paramInt1, int paramInt2, long paramLong, String paramString) {}
  
  private final int A00() {
    synchronized (this.A04) {
      if (A08.get(this) != 0)
        return -1; 
      AtomicLongFieldUpdater<05U> atomicLongFieldUpdater = A09;
      long l = atomicLongFieldUpdater.get(this);
      int k = (int)(l & 0x1FFFFFL);
      int j = k - (int)((l & 0x3FFFFE00000L) >> 21L);
      boolean bool = false;
      int i = j;
      if (j < 0)
        i = 0; 
      j = bool;
      if (i < this.A00) {
        j = bool;
        if (k < this.A01) {
          j = (int)(atomicLongFieldUpdater.get(this) & 0x1FFFFFL) + 1;
          if (j > 0 && null.A00(j) == null) {
            0WQ 0WQ = new 0WQ(this, j);
            null.A01(j, 0WQ);
            if (j == (int)(0x1FFFFFL & atomicLongFieldUpdater.incrementAndGet(this))) {
              0WQ.start();
              return i + 1;
            } 
          } else {
            IllegalArgumentException illegalArgumentException1 = 001.A0N();
            throw illegalArgumentException1;
          } 
          IllegalArgumentException illegalArgumentException = 001.A0N();
          throw illegalArgumentException;
        } 
      } 
      return j;
    } 
  }
  
  public static final void A01(060 param060) {
    try {
      return;
    } finally {
      param060 = null;
    } 
  }
  
  private final boolean A02() {
    label29: while (true) {
      AtomicLongFieldUpdater<05U> atomicLongFieldUpdater = A0A;
      label26: while (true) {
        long l = atomicLongFieldUpdater.get(this);
        int i = (int)(0x1FFFFFL & l);
        0WQ 0WQ1 = (0WQ)this.A04.A00(i);
        if (0WQ1 == null) {
          0WQ1 = null;
          continue;
        } 
        0WQ 0WQ2 = 0WQ1;
        while (true) {
          Object object = 0WQ2.nextParkedWorker;
          04o 04o1 = A07;
          if (object != 04o1) {
            if (object == null) {
              i = 0;
              if (atomicLongFieldUpdater.compareAndSet(this, l, i | 2097152L + l & 0xFFFFFFFFFFE00000L)) {
                0WQ1.nextParkedWorker = 04o1;
                boolean bool = false;
                if (0WQ1 != null) {
                  if (0WQ.A08.compareAndSet(0WQ1, -1, 0)) {
                    LockSupport.unpark(0WQ1);
                    return true;
                  } 
                  continue label29;
                } 
                return bool;
              } 
              continue label26;
            } 
            object = object;
            i = ((0WQ)object).indexInArray;
            if (i != 0 && i >= 0)
              continue; 
            continue;
          } 
          continue label26;
        } 
        break;
      } 
      break;
    } 
  }
  
  public final void A03() {
    if (!A02()) {
      long l = A09.get(this);
      int j = (int)(0x1FFFFFL & l) - (int)((l & 0x3FFFFE00000L) >> 21L);
      int i = j;
      if (j < 0)
        i = 0; 
      j = this.A00;
      if (i < j) {
        i = A00();
        if (i == 1) {
          if (j > 1)
            A00(); 
          return;
        } 
        if (i > 0)
          return; 
      } 
    } else {
      return;
    } 
    A02();
  }
  
  public final void A04(Runnable paramRunnable, 05R param05R, boolean paramBoolean) {
    // Byte code:
    //   0: getstatic X/05N.A01 : I
    //   3: istore #4
    //   5: invokestatic nanoTime : ()J
    //   8: lstore #8
    //   10: aload_1
    //   11: instanceof X/060
    //   14: ifeq -> 505
    //   17: aload_1
    //   18: checkcast X/060
    //   21: astore_1
    //   22: aload_1
    //   23: lload #8
    //   25: putfield A00 : J
    //   28: aload_1
    //   29: aload_2
    //   30: putfield A01 : LX/05R;
    //   33: aload_1
    //   34: getfield A01 : LX/05R;
    //   37: getfield A00 : I
    //   40: istore #4
    //   42: iconst_0
    //   43: istore #6
    //   45: iload #4
    //   47: iconst_1
    //   48: if_icmpne -> 496
    //   51: iconst_1
    //   52: istore #4
    //   54: getstatic X/05U.A09 : Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;
    //   57: aload_0
    //   58: ldc2_w 2097152
    //   61: invokevirtual addAndGet : (Ljava/lang/Object;J)J
    //   64: lstore #8
    //   66: invokestatic currentThread : ()Ljava/lang/Thread;
    //   69: astore #11
    //   71: aload #11
    //   73: instanceof X/0WQ
    //   76: istore #7
    //   78: aconst_null
    //   79: astore #10
    //   81: aload_1
    //   82: astore #12
    //   84: aload #10
    //   86: astore_2
    //   87: iload #7
    //   89: ifeq -> 181
    //   92: aload #11
    //   94: checkcast X/0WQ
    //   97: astore #11
    //   99: aload_1
    //   100: astore #12
    //   102: aload #10
    //   104: astore_2
    //   105: aload #11
    //   107: ifnull -> 181
    //   110: getstatic X/0WQ.__redex_internal_original_name : Ljava/lang/String;
    //   113: astore_2
    //   114: aload_1
    //   115: astore #12
    //   117: aload #10
    //   119: astore_2
    //   120: aload #11
    //   122: getfield A07 : LX/05U;
    //   125: aload_0
    //   126: invokestatic A0S : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   129: ifeq -> 181
    //   132: aload #11
    //   134: astore #10
    //   136: aload #11
    //   138: getfield A03 : Ljava/lang/Integer;
    //   141: astore #13
    //   143: aload_1
    //   144: astore #12
    //   146: aload #10
    //   148: astore_2
    //   149: aload #13
    //   151: getstatic X/0Xy.A0Y : Ljava/lang/Integer;
    //   154: if_acmpeq -> 181
    //   157: aload_1
    //   158: getfield A01 : LX/05R;
    //   161: getfield A00 : I
    //   164: ifne -> 232
    //   167: aload #13
    //   169: getstatic X/0Xy.A01 : Ljava/lang/Integer;
    //   172: if_acmpne -> 232
    //   175: aload #10
    //   177: astore_2
    //   178: aload_1
    //   179: astore #12
    //   181: aload #12
    //   183: getfield A01 : LX/05R;
    //   186: getfield A00 : I
    //   189: iconst_1
    //   190: if_icmpne -> 224
    //   193: aload_0
    //   194: getfield A05 : LX/05V;
    //   197: astore_1
    //   198: aload_1
    //   199: aload #12
    //   201: invokevirtual A03 : (Ljava/lang/Object;)Z
    //   204: ifne -> 474
    //   207: new java/util/concurrent/RejectedExecutionException
    //   210: dup
    //   211: aload_0
    //   212: getfield A03 : Ljava/lang/String;
    //   215: ldc ' was terminated'
    //   217: invokestatic A0b : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   220: invokespecial <init> : (Ljava/lang/String;)V
    //   223: athrow
    //   224: aload_0
    //   225: getfield A06 : LX/05V;
    //   228: astore_1
    //   229: goto -> 198
    //   232: aload #11
    //   234: iconst_1
    //   235: putfield A04 : Z
    //   238: aload #11
    //   240: getfield A06 : LX/0WR;
    //   243: astore #13
    //   245: aload_1
    //   246: astore #11
    //   248: iload_3
    //   249: ifne -> 372
    //   252: getstatic X/0WR.A04 : Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;
    //   255: aload #13
    //   257: aload_1
    //   258: invokevirtual getAndSet : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   261: checkcast X/060
    //   264: astore_1
    //   265: aload_1
    //   266: astore #11
    //   268: aload_1
    //   269: ifnonnull -> 372
    //   272: iload #6
    //   274: istore #5
    //   276: iload #4
    //   278: ifeq -> 362
    //   281: iload #5
    //   283: ifne -> 361
    //   286: aload_0
    //   287: invokespecial A02 : ()Z
    //   290: ifne -> 361
    //   293: ldc2_w 2097151
    //   296: lload #8
    //   298: land
    //   299: l2i
    //   300: lload #8
    //   302: ldc2_w 4398044413952
    //   305: land
    //   306: bipush #21
    //   308: lshr
    //   309: l2i
    //   310: isub
    //   311: istore #5
    //   313: iload #5
    //   315: istore #4
    //   317: iload #5
    //   319: ifge -> 325
    //   322: iconst_0
    //   323: istore #4
    //   325: aload_0
    //   326: getfield A00 : I
    //   329: istore #5
    //   331: iload #4
    //   333: iload #5
    //   335: if_icmpge -> 526
    //   338: aload_0
    //   339: invokespecial A00 : ()I
    //   342: istore #4
    //   344: iload #4
    //   346: iconst_1
    //   347: if_icmpne -> 520
    //   350: iload #5
    //   352: iconst_1
    //   353: if_icmple -> 361
    //   356: aload_0
    //   357: invokespecial A00 : ()I
    //   360: pop
    //   361: return
    //   362: iload #5
    //   364: ifne -> 361
    //   367: aload_0
    //   368: invokevirtual A03 : ()V
    //   371: return
    //   372: getstatic X/0WR.A03 : Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;
    //   375: astore_1
    //   376: aload #11
    //   378: astore #12
    //   380: aload #10
    //   382: astore_2
    //   383: aload_1
    //   384: aload #13
    //   386: invokevirtual get : (Ljava/lang/Object;)I
    //   389: getstatic X/0WR.A02 : Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;
    //   392: aload #13
    //   394: invokevirtual get : (Ljava/lang/Object;)I
    //   397: isub
    //   398: bipush #127
    //   400: if_icmpeq -> 181
    //   403: aload #11
    //   405: getfield A01 : LX/05R;
    //   408: getfield A00 : I
    //   411: iconst_1
    //   412: if_icmpne -> 424
    //   415: getstatic X/0WR.A01 : Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;
    //   418: aload #13
    //   420: invokevirtual incrementAndGet : (Ljava/lang/Object;)I
    //   423: pop
    //   424: aload_1
    //   425: aload #13
    //   427: invokevirtual get : (Ljava/lang/Object;)I
    //   430: bipush #127
    //   432: iand
    //   433: istore #5
    //   435: aload #13
    //   437: getfield A00 : Ljava/util/concurrent/atomic/AtomicReferenceArray;
    //   440: astore_2
    //   441: aload_2
    //   442: iload #5
    //   444: invokevirtual get : (I)Ljava/lang/Object;
    //   447: ifnull -> 456
    //   450: invokestatic yield : ()V
    //   453: goto -> 435
    //   456: aload_2
    //   457: iload #5
    //   459: aload #11
    //   461: invokevirtual lazySet : (ILjava/lang/Object;)V
    //   464: aload_1
    //   465: aload #13
    //   467: invokevirtual incrementAndGet : (Ljava/lang/Object;)I
    //   470: pop
    //   471: aload #10
    //   473: astore_2
    //   474: iload #6
    //   476: istore #5
    //   478: iload_3
    //   479: ifeq -> 276
    //   482: iload #6
    //   484: istore #5
    //   486: aload_2
    //   487: ifnull -> 276
    //   490: iconst_1
    //   491: istore #5
    //   493: goto -> 276
    //   496: iconst_0
    //   497: istore #4
    //   499: lconst_0
    //   500: lstore #8
    //   502: goto -> 66
    //   505: new X/1AV
    //   508: dup
    //   509: aload_1
    //   510: aload_2
    //   511: lload #8
    //   513: invokespecial <init> : (Ljava/lang/Runnable;LX/05R;J)V
    //   516: astore_1
    //   517: goto -> 33
    //   520: iload #4
    //   522: ifle -> 526
    //   525: return
    //   526: aload_0
    //   527: invokespecial A02 : ()Z
    //   530: pop
    //   531: return
  }
  
  public final void A05(0WQ param0WQ, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: getstatic X/05U.A0A : Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;
    //   3: astore #9
    //   5: aload #9
    //   7: aload_0
    //   8: invokevirtual get : (Ljava/lang/Object;)J
    //   11: lstore #6
    //   13: ldc2_w 2097151
    //   16: lload #6
    //   18: land
    //   19: l2i
    //   20: istore #5
    //   22: iload #5
    //   24: istore #4
    //   26: iload #5
    //   28: iload_2
    //   29: if_icmpne -> 113
    //   32: iload_3
    //   33: ifne -> 110
    //   36: aload_1
    //   37: astore #8
    //   39: aload #8
    //   41: getfield nextParkedWorker : Ljava/lang/Object;
    //   44: astore #8
    //   46: aload #8
    //   48: getstatic X/05U.A07 : LX/04o;
    //   51: if_acmpeq -> 5
    //   54: aload #8
    //   56: ifnonnull -> 88
    //   59: iconst_0
    //   60: istore #4
    //   62: aload #9
    //   64: aload_0
    //   65: lload #6
    //   67: ldc2_w 2097152
    //   70: lload #6
    //   72: ladd
    //   73: ldc2_w -2097152
    //   76: land
    //   77: iload #4
    //   79: i2l
    //   80: lor
    //   81: invokevirtual compareAndSet : (Ljava/lang/Object;JJ)Z
    //   84: ifeq -> 5
    //   87: return
    //   88: aload #8
    //   90: checkcast X/0WQ
    //   93: astore #8
    //   95: aload #8
    //   97: getfield indexInArray : I
    //   100: istore #4
    //   102: iload #4
    //   104: ifeq -> 39
    //   107: goto -> 113
    //   110: iload_3
    //   111: istore #4
    //   113: iload #4
    //   115: iflt -> 5
    //   118: goto -> 62
  }
  
  public final void close() {
    // Byte code:
    //   0: getstatic X/05U.A08 : Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;
    //   3: aload_0
    //   4: iconst_0
    //   5: iconst_1
    //   6: invokevirtual compareAndSet : (Ljava/lang/Object;II)Z
    //   9: ifeq -> 400
    //   12: invokestatic currentThread : ()Ljava/lang/Thread;
    //   15: astore #9
    //   17: aload #9
    //   19: instanceof X/0WQ
    //   22: istore #4
    //   24: aconst_null
    //   25: astore #8
    //   27: aload #8
    //   29: astore #7
    //   31: iload #4
    //   33: ifeq -> 77
    //   36: aload #9
    //   38: checkcast X/0WQ
    //   41: astore #9
    //   43: aload #8
    //   45: astore #7
    //   47: aload #9
    //   49: ifnull -> 77
    //   52: getstatic X/0WQ.__redex_internal_original_name : Ljava/lang/String;
    //   55: astore #7
    //   57: aload #8
    //   59: astore #7
    //   61: aload #9
    //   63: getfield A07 : LX/05U;
    //   66: aload_0
    //   67: invokestatic A0S : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   70: ifeq -> 77
    //   73: aload #9
    //   75: astore #7
    //   77: aload_0
    //   78: getfield A04 : LX/05Y;
    //   81: astore #12
    //   83: aload #12
    //   85: monitorenter
    //   86: getstatic X/05U.A09 : Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;
    //   89: astore #11
    //   91: aload #11
    //   93: aload_0
    //   94: invokevirtual get : (Ljava/lang/Object;)J
    //   97: lstore #5
    //   99: lload #5
    //   101: ldc2_w 2097151
    //   104: land
    //   105: l2i
    //   106: istore_3
    //   107: aload #12
    //   109: monitorexit
    //   110: aload #7
    //   112: astore #9
    //   114: iconst_1
    //   115: iload_3
    //   116: if_icmpgt -> 272
    //   119: iconst_1
    //   120: istore_1
    //   121: aload #12
    //   123: iload_1
    //   124: invokevirtual A00 : (I)Ljava/lang/Object;
    //   127: astore #8
    //   129: aload #8
    //   131: invokestatic A0D : (Ljava/lang/Object;)V
    //   134: aload #8
    //   136: checkcast X/0WQ
    //   139: astore #9
    //   141: aload #7
    //   143: astore #8
    //   145: iload_1
    //   146: istore_2
    //   147: aload #9
    //   149: aload #7
    //   151: if_acmpeq -> 252
    //   154: aload #9
    //   156: invokevirtual getState : ()Ljava/lang/Thread$State;
    //   159: getstatic java/lang/Thread$State.TERMINATED : Ljava/lang/Thread$State;
    //   162: if_acmpeq -> 181
    //   165: aload #9
    //   167: invokestatic unpark : (Ljava/lang/Thread;)V
    //   170: aload #9
    //   172: ldc2_w 10000
    //   175: invokevirtual join : (J)V
    //   178: goto -> 154
    //   181: aload #9
    //   183: getfield A06 : LX/0WR;
    //   186: astore #13
    //   188: aload_0
    //   189: getfield A05 : LX/05V;
    //   192: astore #14
    //   194: getstatic X/0WR.A04 : Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;
    //   197: aload #13
    //   199: aconst_null
    //   200: invokevirtual getAndSet : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   203: astore #9
    //   205: aload #7
    //   207: astore #8
    //   209: iload_1
    //   210: istore_2
    //   211: aload #9
    //   213: ifnull -> 230
    //   216: aload #14
    //   218: aload #9
    //   220: invokevirtual A03 : (Ljava/lang/Object;)Z
    //   223: pop
    //   224: iload_1
    //   225: istore_2
    //   226: aload #7
    //   228: astore #8
    //   230: aload #13
    //   232: invokestatic A00 : (LX/0WR;)LX/060;
    //   235: astore #10
    //   237: aload #10
    //   239: astore #9
    //   241: aload #8
    //   243: astore #7
    //   245: iload_2
    //   246: istore_1
    //   247: aload #10
    //   249: ifnonnull -> 216
    //   252: aload #8
    //   254: astore #9
    //   256: iload_2
    //   257: iload_3
    //   258: if_icmpeq -> 272
    //   261: iload_2
    //   262: iconst_1
    //   263: iadd
    //   264: istore_1
    //   265: aload #8
    //   267: astore #7
    //   269: goto -> 121
    //   272: aload_0
    //   273: getfield A05 : LX/05V;
    //   276: astore #10
    //   278: aload #10
    //   280: invokevirtual A02 : ()V
    //   283: aload_0
    //   284: getfield A06 : LX/05V;
    //   287: astore #12
    //   289: aload #12
    //   291: invokevirtual A02 : ()V
    //   294: aload #9
    //   296: ifnull -> 316
    //   299: aload #9
    //   301: iconst_1
    //   302: invokevirtual A02 : (Z)LX/060;
    //   305: astore #8
    //   307: aload #8
    //   309: astore #7
    //   311: aload #8
    //   313: ifnonnull -> 384
    //   316: aload #12
    //   318: invokevirtual A01 : ()Ljava/lang/Object;
    //   321: checkcast X/060
    //   324: astore #8
    //   326: aload #8
    //   328: astore #7
    //   330: aload #8
    //   332: ifnonnull -> 384
    //   335: aload #10
    //   337: invokevirtual A01 : ()Ljava/lang/Object;
    //   340: checkcast X/060
    //   343: astore #8
    //   345: aload #8
    //   347: astore #7
    //   349: aload #8
    //   351: ifnonnull -> 384
    //   354: aload #9
    //   356: ifnull -> 368
    //   359: aload #9
    //   361: getstatic X/0Xy.A0Y : Ljava/lang/Integer;
    //   364: invokevirtual A03 : (Ljava/lang/Integer;)Z
    //   367: pop
    //   368: getstatic X/05U.A0A : Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;
    //   371: aload_0
    //   372: lconst_0
    //   373: invokevirtual set : (Ljava/lang/Object;J)V
    //   376: aload #11
    //   378: aload_0
    //   379: lconst_0
    //   380: invokevirtual set : (Ljava/lang/Object;J)V
    //   383: return
    //   384: aload #7
    //   386: invokestatic A01 : (LX/060;)V
    //   389: goto -> 294
    //   392: astore #7
    //   394: aload #12
    //   396: monitorexit
    //   397: aload #7
    //   399: athrow
    //   400: return
    // Exception table:
    //   from	to	target	type
    //   86	99	392	finally
  }
  
  public final void execute(Runnable paramRunnable) {
    A04(paramRunnable, 05N.A07, false);
  }
  
  public final String toString() {
    Object object1;
    int i;
    Object object2;
    int j;
    Object object3;
    int k;
    Object object4;
    Object object5;
    ArrayList<String> arrayList = 001.A0y();
    05Y 05Y1 = this.A04;
    int i1 = 05Y1.array.length();
    boolean bool1 = false;
    boolean bool2 = false;
    boolean bool4 = false;
    boolean bool3 = false;
    boolean bool5 = false;
    int n = 1;
    while (true) {
      byte b;
      StringBuilder stringBuilder1;
      if (n < i1) {
        0WQ 0WQ = (0WQ)05Y1.A00(n);
        Object object9 = object5;
        Object object8 = object3;
        Object object10 = object4;
        Object object11 = object2;
        Object object12 = object1;
        if (0WQ != null) {
          0WR 0WR = 0WQ.A06;
          Object object = 0WR.A04.get(0WR);
          int i5 = 0WR.A03.get(0WR) - 0WR.A02.get(0WR);
          int i6 = i5;
          if (object != null)
            i6 = i5 + 1; 
          int i7 = 0WQ.A03.intValue();
          if (i7 != 2) {
            if (i7 != 1) {
              if (i7 != 0) {
                if (i7 != 3) {
                  object9 = object5;
                  Object object13 = object3;
                  object10 = object4;
                  object11 = object2;
                  object12 = object1;
                  if (i7 == 4) {
                    int i10 = object5 + 1;
                    object12 = object1;
                    object11 = object2;
                    object10 = object4;
                    object13 = object3;
                  } 
                  continue;
                } 
              } else {
                i = object1 + 1;
                stringBuilder1 = 001.A0s();
                stringBuilder1.append(i6);
                b = 99;
                arrayList.add(001.A0n(stringBuilder1, b));
                object9 = object5;
                Object object13 = object3;
                object10 = object4;
                object11 = object2;
                int i10 = i;
              } 
            } else {
              j = object2 + 1;
              stringBuilder1 = 001.A0s();
              stringBuilder1.append(i6);
              b = 98;
              arrayList.add(001.A0n(stringBuilder1, b));
              object9 = object5;
              Object object13 = object3;
              object10 = object4;
              int i10 = j;
              int i11 = i;
            } 
            k = object3 + 1;
            object9 = object5;
            i5 = k;
            object10 = object4;
            int i8 = j;
            int i9 = i;
            if (i6 > 0) {
              stringBuilder1 = 001.A0s();
              stringBuilder1.append(i6);
              b = 100;
            } else {
              continue;
            } 
          } else {
            int i8 = object4 + 1;
            object9 = object5;
            i5 = k;
            int i9 = j;
            int i10 = i;
            continue;
          } 
        } else {
          continue;
        } 
      } else {
        break;
      } 
      arrayList.add(001.A0n(stringBuilder1, b));
      Object object6 = object5;
      int i2 = k;
      Object object7 = object4;
      int i3 = j;
      int i4 = i;
      n++;
      object5 = SYNTHETIC_LOCAL_VARIABLE_9;
      object3 = SYNTHETIC_LOCAL_VARIABLE_5;
      object4 = SYNTHETIC_LOCAL_VARIABLE_10;
      object2 = SYNTHETIC_LOCAL_VARIABLE_12;
      object1 = SYNTHETIC_LOCAL_VARIABLE_13;
    } 
    long l = A09.get(this);
    StringBuilder stringBuilder = 001.A0s();
    stringBuilder.append(this.A03);
    stringBuilder.append('@');
    002.A0w(stringBuilder, this);
    stringBuilder.append("[Pool Size {core = ");
    int m = this.A00;
    stringBuilder.append(m);
    stringBuilder.append(", max = ");
    stringBuilder.append(this.A01);
    stringBuilder.append("}, Worker States {CPU = ");
    stringBuilder.append(i);
    stringBuilder.append(", blocking = ");
    stringBuilder.append(j);
    stringBuilder.append(", parked = ");
    stringBuilder.append(object4);
    stringBuilder.append(", dormant = ");
    stringBuilder.append(k);
    stringBuilder.append(", terminated = ");
    stringBuilder.append(object5);
    stringBuilder.append("}, running workers queues = ");
    stringBuilder.append(arrayList);
    stringBuilder.append(", global CPU queue size = ");
    stringBuilder.append(this.A06.A00());
    stringBuilder.append(", global blocking queue size = ");
    stringBuilder.append(this.A05.A00());
    stringBuilder.append(", Control State {created workers= ");
    stringBuilder.append((int)(0x1FFFFFL & l));
    stringBuilder.append(", blocking tasks = ");
    stringBuilder.append((int)((0x3FFFFE00000L & l) >> 21L));
    stringBuilder.append(", CPUs acquired = ");
    stringBuilder.append(m - (int)((0x7FFFFC0000000000L & l) >> 42L));
    return 001.A0l("}]", stringBuilder);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\05U.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */