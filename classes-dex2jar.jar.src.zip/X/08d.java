package X;

import java.util.ArrayList;

public abstract class 08d {
  public static void A00(Object paramObject, ArrayList paramArrayList) {
    // Byte code:
    //   0: aload_0
    //   1: ifnull -> 39
    //   4: aload_0
    //   5: instanceof [Ljava/lang/Object;
    //   8: ifeq -> 40
    //   11: aload_0
    //   12: checkcast [Ljava/lang/Object;
    //   15: astore_0
    //   16: aload_0
    //   17: arraylength
    //   18: istore_2
    //   19: iload_2
    //   20: ifle -> 39
    //   23: aload_1
    //   24: aload_1
    //   25: invokevirtual size : ()I
    //   28: iload_2
    //   29: iadd
    //   30: invokevirtual ensureCapacity : (I)V
    //   33: aload_1
    //   34: aload_0
    //   35: invokestatic addAll : (Ljava/util/Collection;[Ljava/lang/Object;)Z
    //   38: pop
    //   39: return
    //   40: aload_0
    //   41: instanceof java/util/Collection
    //   44: ifeq -> 57
    //   47: aload_1
    //   48: aload_0
    //   49: checkcast java/util/Collection
    //   52: invokevirtual addAll : (Ljava/util/Collection;)Z
    //   55: pop
    //   56: return
    //   57: aload_0
    //   58: instanceof java/lang/Iterable
    //   61: ifeq -> 97
    //   64: aload_0
    //   65: checkcast java/lang/Iterable
    //   68: invokeinterface iterator : ()Ljava/util/Iterator;
    //   73: astore_0
    //   74: aload_0
    //   75: invokeinterface hasNext : ()Z
    //   80: ifeq -> 39
    //   83: aload_1
    //   84: aload_0
    //   85: invokeinterface next : ()Ljava/lang/Object;
    //   90: invokevirtual add : (Ljava/lang/Object;)Z
    //   93: pop
    //   94: goto -> 74
    //   97: aload_0
    //   98: instanceof java/util/Iterator
    //   101: ifeq -> 132
    //   104: aload_0
    //   105: checkcast java/util/Iterator
    //   108: astore_0
    //   109: aload_0
    //   110: invokeinterface hasNext : ()Z
    //   115: ifeq -> 39
    //   118: aload_1
    //   119: aload_0
    //   120: invokeinterface next : ()Ljava/lang/Object;
    //   125: invokevirtual add : (Ljava/lang/Object;)Z
    //   128: pop
    //   129: goto -> 109
    //   132: invokestatic A0s : ()Ljava/lang/StringBuilder;
    //   135: astore_1
    //   136: aload_0
    //   137: ldc 'Don't know how to spread '
    //   139: aload_1
    //   140: invokestatic A0s : (Ljava/lang/Object;Ljava/lang/String;Ljava/lang/StringBuilder;)V
    //   143: aload_1
    //   144: invokevirtual toString : ()Ljava/lang/String;
    //   147: invokestatic A0x : (Ljava/lang/String;)Ljava/lang/UnsupportedOperationException;
    //   150: athrow
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */