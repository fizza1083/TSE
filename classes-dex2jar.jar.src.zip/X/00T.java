package X;

import java.io.Serializable;
import kotlin.enums.EnumEntries;

public final class 00T<T extends Enum<T>> extends 00U<T> implements EnumEntries<T>, Serializable {
  public final Enum[] entries;
  
  public 00T(Enum[] paramArrayOfEnum) {
    this.entries = paramArrayOfEnum;
  }
  
  private final Object writeReplace() {
    return new 15n(this.entries);
  }
  
  public final int A08() {
    return this.entries.length;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00T.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */