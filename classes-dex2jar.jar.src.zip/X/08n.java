package X;

import android.os.Bundle;
import androidx.fragment.app.Fragment;

public final class 08n extends 08o {
  public 08n(Fragment paramFragment) {}
  
  public final void A00() {
    Fragment fragment = this.A00;
    fragment.mSavedStateRegistryController.A00();
    0Ca.A01((0Bv)fragment);
    Bundle bundle = fragment.mSavedFragmentState;
    if (bundle != null) {
      bundle = bundle.getBundle("registryState");
    } else {
      bundle = null;
    } 
    fragment.mSavedStateRegistryController.A01(bundle);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */