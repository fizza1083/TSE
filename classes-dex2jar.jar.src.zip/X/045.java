package X;

import android.os.StrictMode;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;

public abstract class 045 {
  public static final AtomicReference A00 = new AtomicReference();
  
  public static UUID A00() {
    StrictMode.ThreadPolicy threadPolicy = StrictMode.allowThreadDiskReads();
    try {
      return UUID.randomUUID();
    } finally {
      StrictMode.setThreadPolicy(threadPolicy);
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\045.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */