package X;

import android.content.Context;
import java.lang.reflect.Field;

public final class 00x extends 00w {
  public 00x() {
    super("activity_task", null, null, null);
  }
  
  public final void A01(Context paramContext, 013 param013) {
    Class clazz = param013.A01("android.app.ActivityTaskManager");
    if (clazz != null) {
      Field field = param013.A03(clazz, "IActivityTaskManagerSingleton");
      if (field != null)
        try {
          Object object = field.get(null);
          if (object != null) {
            Class clazz1 = param013.A01("android.util.Singleton");
            if (clazz1 != null) {
              Field field1 = param013.A03(clazz1, "mInstance");
              if (field1 != null) {
                Object object1 = field1.get(object);
                if (object1 != null) {
                  Class clazz2 = param013.A01("android.app.IActivityTaskManager");
                  if (clazz2 != null) {
                    Object object2 = 00w.A00(this, clazz2, object1);
                    field1.set(object, object2);
                  } 
                } 
              } 
            } 
          } 
          return;
        } catch (Exception exception) {
          return;
        }  
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */