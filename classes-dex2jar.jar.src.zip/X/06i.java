package X;

public abstract class 06i {
  public static final int A00(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt3 > 0) {
      int j = paramInt2;
      if (paramInt1 < paramInt2) {
        int k = paramInt2 % paramInt3;
        j = k;
        if (k < 0)
          j = k + paramInt3; 
        k = paramInt1 % paramInt3;
        paramInt1 = k;
        if (k < 0)
          paramInt1 = k + paramInt3; 
        j = (j - paramInt1) % paramInt3;
        paramInt1 = j;
        if (j < 0)
          paramInt1 = j + paramInt3; 
        j = paramInt2 - paramInt1;
      } 
      return j;
    } 
    int i = paramInt2;
    if (paramInt1 > paramInt2) {
      int j = -paramInt3;
      paramInt3 = paramInt1 % j;
      paramInt1 = paramInt3;
      if (paramInt3 < 0)
        paramInt1 = paramInt3 + j; 
      i = paramInt2 % j;
      paramInt3 = i;
      if (i < 0)
        paramInt3 = i + j; 
      paramInt3 = (paramInt1 - paramInt3) % j;
      paramInt1 = paramInt3;
      if (paramInt3 < 0)
        paramInt1 = paramInt3 + j; 
      return paramInt2 + paramInt1;
    } 
    return i;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\06i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */