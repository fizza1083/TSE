package X;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public abstract class 02J {
  public static 02N A00() {
    boolean bool = (0Ao.A00()).A01.A01;
    Set set = 0OT.A0h;
    return bool ? A01("*|all_packages|*", set) : new 02N(A04(set, 0Gh.A03));
  }
  
  public static 02N A01(String paramString, Set paramSet) {
    return new 02N(A04(paramSet, Collections.unmodifiableSet(new HashSet(Collections.singletonList(paramString)))));
  }
  
  public static 02N A02(Map paramMap) {
    HashMap<?, ?> hashMap = 001.A11();
    Iterator<Map.Entry> iterator = 001.A16(paramMap);
    while (iterator.hasNext()) {
      Map.Entry entry = iterator.next();
      hashMap.put(entry.getKey(), Collections.singleton(entry.getValue()));
    } 
    return new 02N(Collections.unmodifiableMap(hashMap));
  }
  
  public static 02N A03(Set paramSet) {
    HashMap<?, ?> hashMap = 001.A11();
    Iterator iterator = paramSet.iterator();
    while (iterator.hasNext())
      hashMap.put(iterator.next(), Collections.unmodifiableSet(new HashSet(Collections.singletonList("*|all_packages|*")))); 
    return new 02N(Collections.unmodifiableMap(hashMap));
  }
  
  public static Map A04(Set paramSet1, Set<?> paramSet2) {
    HashMap<?, ?> hashMap = 001.A11();
    Iterator iterator = paramSet1.iterator();
    while (iterator.hasNext())
      hashMap.put(iterator.next(), Collections.unmodifiableSet(paramSet2)); 
    return Collections.unmodifiableMap(hashMap);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\02J.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */