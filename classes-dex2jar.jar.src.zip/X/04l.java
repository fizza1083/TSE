package X;

import java.util.concurrent.CancellationException;

public interface 04l extends 04H {
  public static final 054 A00 = 054.A00;
  
  void AMi(CancellationException paramCancellationException);
  
  CancellationException AzG();
  
  04s C24(0BQ param0BQ, boolean paramBoolean1, boolean paramBoolean2);
  
  boolean C2C();
  
  Object CC1(05D param05D);
  
  boolean isCancelled();
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\04l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */