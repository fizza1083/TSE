package X;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import java.util.Collections;
import java.util.List;

public final class 08j extends 08k {
  private Intent A00(Context paramContext, Intent paramIntent, List paramList) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: \r\n\tat com.googlecode.dex2jar.ir.ts.NewTransformer.transform(NewTransformer.java:134)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:148)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public final boolean A0B(Context paramContext, 0Gm param0Gm) {
    throw 001.A0w();
  }
  
  public final Intent Ak9(Context paramContext, Intent paramIntent, String paramString) {
    07d.A01(paramContext, paramIntent, this.A01, paramString);
    Intent intent = paramIntent;
    if (!08k.A04(paramContext, paramIntent))
      intent = A00(paramContext, paramIntent, A07(paramContext, paramIntent)); 
    return intent;
  }
  
  public final List AkA(Context paramContext, Intent paramIntent, String paramString) {
    07d.A01(paramContext, paramIntent, this.A01, paramString);
    if (!08k.A04(paramContext, paramIntent))
      paramIntent.setPackage(paramContext.getPackageName()); 
    return Collections.singletonList(paramIntent);
  }
  
  public final Intent AkD(BroadcastReceiver paramBroadcastReceiver, Context paramContext, Intent paramIntent, String paramString) {
    String str1;
    11P 11P;
    0Hx 0Hx2 = 07d.A00(paramContext, paramIntent, null, 86400000);
    0Hx 0Hx1 = 0Hx2;
    if (0Hx2 == null)
      0Hx1 = 09l.A00(paramBroadcastReceiver, paramContext); 
    if (0Hx1 != null) {
      str1 = 0Hx1.A03();
    } else {
      paramBroadcastReceiver = null;
    } 
    String str2 = paramContext.getPackageName();
    if (!str2.equals(paramBroadcastReceiver)) {
      if (0Hx1 != null) {
        str1 = 0Hx1.toString();
      } else {
        str1 = "null";
      } 
      str1 = 0XK.A11("Access denied. ", str2, " cannot receive broadcasts from ", str1);
      boolean bool = A0A();
      11P = this.A01;
      if (bool) {
        11P.DfI("InternalIntentScope", 0XK.A0b("Fail-open: ", str1), null);
        return paramIntent;
      } 
    } else {
      return paramIntent;
    } 
    11P.DfI("InternalIntentScope", str1, 001.A0c(str1));
    return null;
  }
  
  public final Intent AkE(Context paramContext, Intent paramIntent, String paramString) {
    07d.A01(paramContext, paramIntent, this.A01, paramString);
    Intent intent = paramIntent;
    if (!08k.A04(paramContext, paramIntent))
      intent = A00(paramContext, paramIntent, A08(paramContext, paramIntent)); 
    return intent;
  }
  
  public final 0RE BfO() {
    return 0RE.A05;
  }
  
  public final boolean Bhk() {
    return true;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */