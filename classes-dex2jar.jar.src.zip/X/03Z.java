package X;

public final class 03Z extends 03a {
  public final Object A00 = new Object();
  
  public 03Z(int paramInt) {
    super(paramInt);
  }
  
  public final Object AAG() {
    synchronized (this.A00) {
      return super.AAG();
    } 
  }
  
  public final boolean Dbd(Object paramObject) {
    16F.A0E(paramObject, 0);
    synchronized (this.A00) {
      return super.Dbd(paramObject);
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\03Z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */