package X;

import android.app.ActivityThread;
import android.content.Context;
import android.content.pm.PackageManager;
import java.lang.reflect.Field;

public final class 011 extends 00w {
  public 011() {
    super("package", null, null, null);
  }
  
  public final void A01(Context paramContext, 013 param013) {
    PackageManager packageManager = paramContext.getPackageManager();
    if (packageManager != null) {
      ActivityThread activityThread = ActivityThread.currentActivityThread();
      if (activityThread != null) {
        Field field = param013.A03(activityThread.getClass(), "sPackageManager");
        if (field != null) {
          Field field1 = param013.A03(packageManager.getClass(), "mPM");
          if (field1 != null)
            try {
              Object object = field1.get(packageManager);
              if (object != null) {
                Class clazz = param013.A01("android.content.pm.IPackageManager");
                if (clazz != null) {
                  Object object1 = 00w.A00(this, clazz, object);
                  if (object1 != null)
                    try {
                      field.set(null, object1);
                    } catch (Exception exception) {} 
                  field1.set(packageManager, object1);
                } 
              } 
              return;
            } catch (Exception exception) {
              return;
            }  
        } 
      } 
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\011.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */