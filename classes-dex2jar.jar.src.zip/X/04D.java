package X;

import java.util.concurrent.CancellationException;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

public final class 04D extends 04E implements 04M {
  public final Executor A00;
  
  public 04D(Executor paramExecutor) {
    this.A00 = paramExecutor;
    try {
      return;
    } finally {
      paramExecutor = null;
    } 
  }
  
  public final void A05(Runnable paramRunnable, 04I param04I) {
    try {
      this.A00.execute(paramRunnable);
      return;
    } catch (RejectedExecutionException rejectedExecutionException) {
      CancellationException cancellationException = new CancellationException("The task was rejected");
      cancellationException.initCause(rejectedExecutionException);
      0IZ.A00(cancellationException, param04I);
      05I.A01.A05(paramRunnable, param04I);
      return;
    } 
  }
  
  public final Executor A06() {
    return this.A00;
  }
  
  public final 04s C25(Runnable paramRunnable, 04I param04I, long paramLong) {
    Executor executor = this.A00;
    if (executor instanceof ScheduledExecutorService) {
      executor = executor;
      if (executor != null)
        try {
          ScheduledFuture<?> scheduledFuture = executor.schedule(paramRunnable, paramLong, TimeUnit.MILLISECONDS);
          if (scheduledFuture != null)
            return new 11b(scheduledFuture); 
        } catch (RejectedExecutionException rejectedExecutionException) {
          CancellationException cancellationException = new CancellationException("The task was rejected");
          cancellationException.initCause(rejectedExecutionException);
          0IZ.A00(cancellationException, param04I);
        }  
    } 
    return 05n.A00.C25(paramRunnable, param04I, paramLong);
  }
  
  public final void Djw(0IU param0IU, long paramLong) {
    Executor executor = this.A00;
    if (executor instanceof ScheduledExecutorService) {
      ScheduledExecutorService scheduledExecutorService = (ScheduledExecutorService)executor;
      if (scheduledExecutorService != null) {
        0WF 0WF = new 0WF(param0IU, this);
        04I 04I = param0IU.B2c();
        try {
          ScheduledFuture<?> scheduledFuture = scheduledExecutorService.schedule(0WF, paramLong, TimeUnit.MILLISECONDS);
          if (scheduledFuture != null) {
            0IT.A02(new 0WG(scheduledFuture), (0IT)param0IU);
            return;
          } 
        } catch (RejectedExecutionException rejectedExecutionException) {
          CancellationException cancellationException = new CancellationException("The task was rejected");
          cancellationException.initCause(rejectedExecutionException);
          0IZ.A00(cancellationException, 04I);
        } 
      } 
    } 
    05n.A00.Djw(param0IU, paramLong);
  }
  
  public final void close() {
    Executor executor = this.A00;
    if (executor instanceof java.util.concurrent.ExecutorService) {
      executor = executor;
      if (executor != null)
        executor.shutdown(); 
    } 
  }
  
  public final boolean equals(Object paramObject) {
    if (paramObject instanceof 04D) {
      paramObject = ((04D)paramObject).A00;
      Executor executor = this.A00;
      boolean bool = true;
      return (paramObject != executor) ? false : bool;
    } 
    return false;
  }
  
  public final int hashCode() {
    return System.identityHashCode(this.A00);
  }
  
  public final String toString() {
    return this.A00.toString();
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\04D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */