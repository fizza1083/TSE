package X;

public abstract class 04F extends 04G implements 04K {
  public static final 04N A00 = new 04N();
  
  public 04F() {
    super(04K.A00);
  }
  
  public 04F A02(int paramInt) {
    05k.A00(paramInt);
    return new 05l(this, paramInt);
  }
  
  public void A03(Runnable paramRunnable, 04I param04I) {
    A05(paramRunnable, param04I);
  }
  
  public boolean A04(04I param04I) {
    return true;
  }
  
  public abstract void A05(Runnable paramRunnable, 04I param04I);
  
  public final 04H get(04R param04R) {
    04H 04H;
    16F.A0E(param04R, 1);
    if (param04R instanceof 04P) {
      param04R = param04R;
      04R 04R1 = getKey();
      16F.A0E(04R1, 0);
      if (04R1 == param04R || ((04P)param04R).A00 == 04R1) {
        04H = (04H)((04P)param04R).A01.invoke(this);
        if (04H != null)
          return 04H; 
      } 
    } else if (04K.A00 == 04H) {
      return this;
    } 
    return null;
  }
  
  public final 04I minusKey(04R param04R) {
    // Byte code:
    //   0: aload_1
    //   1: iconst_1
    //   2: invokestatic A0E : (Ljava/lang/Object;I)V
    //   5: aload_1
    //   6: instanceof X/04P
    //   9: ifeq -> 68
    //   12: aload_1
    //   13: checkcast X/04P
    //   16: astore_2
    //   17: aload_0
    //   18: invokeinterface getKey : ()LX/04R;
    //   23: astore_3
    //   24: aload_3
    //   25: iconst_0
    //   26: invokestatic A0E : (Ljava/lang/Object;I)V
    //   29: aload_3
    //   30: aload_2
    //   31: if_acmpeq -> 44
    //   34: aload_0
    //   35: astore_1
    //   36: aload_2
    //   37: getfield A00 : LX/04R;
    //   40: aload_3
    //   41: if_acmpne -> 63
    //   44: aload_0
    //   45: astore_1
    //   46: aload_2
    //   47: getfield A01 : LX/0BQ;
    //   50: aload_0
    //   51: invokeinterface invoke : (Ljava/lang/Object;)Ljava/lang/Object;
    //   56: ifnull -> 63
    //   59: getstatic X/050.A00 : LX/050;
    //   62: astore_1
    //   63: aload_1
    //   64: checkcast X/04I
    //   67: areturn
    //   68: aload_0
    //   69: astore_2
    //   70: getstatic X/04K.A00 : LX/04T;
    //   73: aload_1
    //   74: if_acmpne -> 81
    //   77: getstatic X/050.A00 : LX/050;
    //   80: astore_2
    //   81: aload_2
    //   82: checkcast X/04I
    //   85: areturn
  }
  
  public String toString() {
    return 0XK.A0d(001.A0g(this), Integer.toHexString(System.identityHashCode(this)), '@');
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\04F.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */