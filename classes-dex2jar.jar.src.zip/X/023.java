package X;

public final class 023 implements 0nQ {
  public 023(021 param021) {}
  
  public final int getId() {
    return 8;
  }
  
  public final int handleUncaughtException(Thread paramThread, Throwable paramThrowable, 0nJ param0nJ) {
    021 0211 = this.A00;
    paramThrowable = 0211.A01.A00(paramThrowable);
    0u8 0u8 = 0211.A02;
    16F.A0E(paramThread, 0);
    if ((0u8.A00.AA5(paramThread, paramThrowable) ^ true) != 0)
      021.A00(0211, paramThread, paramThrowable, true); 
    return 0;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\023.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */