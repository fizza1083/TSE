package X;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

public abstract class 029 extends 025 {
  public static final LinkedHashSet A04(Iterable paramIterable, Set paramSet) {
    16F.A0E(paramSet, 0);
    16F.A0E(paramIterable, 1);
    if (paramIterable instanceof Collection) {
      int j = ((Collection)paramIterable).size();
      if (Integer.valueOf(j) != null) {
        j = paramSet.size() + j;
        LinkedHashSet linkedHashSet1 = new LinkedHashSet(01m.A0D(j));
        linkedHashSet1.addAll(paramSet);
        0YE.A0x(paramIterable, linkedHashSet1);
        return linkedHashSet1;
      } 
    } 
    int i = paramSet.size() * 2;
    LinkedHashSet linkedHashSet = new LinkedHashSet(01m.A0D(i));
    linkedHashSet.addAll(paramSet);
    0YE.A0x(paramIterable, linkedHashSet);
    return linkedHashSet;
  }
  
  public static final LinkedHashSet A05(Object paramObject, Set paramSet) {
    16F.A0E(paramSet, 0);
    LinkedHashSet<Object> linkedHashSet = new LinkedHashSet(01m.A0D(paramSet.size() + 1));
    linkedHashSet.addAll(paramSet);
    linkedHashSet.add(paramObject);
    return linkedHashSet;
  }
  
  public static final Set A06(Iterable<Iterable> paramIterable, Set paramSet) {
    Iterator<Iterable> iterator;
    16F.A0G(paramSet, paramIterable);
    Iterable<Iterable> iterable = paramIterable;
    if (!(paramIterable instanceof Collection))
      iterable = 0Xa.A0V(paramIterable); 
    Collection<?> collection = (Collection)iterable;
    if (collection.isEmpty())
      return 0Xa.A0e(paramSet); 
    if (collection instanceof Set) {
      iterable = new LinkedHashSet();
      iterator = paramSet.iterator();
      while (true) {
        paramIterable = iterable;
        if (iterator.hasNext()) {
          paramIterable = iterator.next();
          if (!collection.contains(paramIterable))
            iterable.add(paramIterable); 
          continue;
        } 
        return (Set)paramIterable;
      } 
    } 
    iterable = new LinkedHashSet<Iterable>((Collection<? extends Iterable>)iterator);
    iterable.removeAll(collection);
    return (Set)iterable;
  }
  
  public static final Set A07(Object paramObject, Set paramSet) {
    16F.A0E(paramSet, 0);
    LinkedHashSet linkedHashSet = new LinkedHashSet(01m.A0D(paramSet.size()));
    Iterator<Object> iterator = paramSet.iterator();
    boolean bool = false;
    while (iterator.hasNext()) {
      Object object = iterator.next();
      if (!bool && 16F.A0S(object, paramObject)) {
        bool = true;
        continue;
      } 
      linkedHashSet.add(object);
    } 
    return linkedHashSet;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\029.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */