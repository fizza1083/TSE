package X;

import java.util.concurrent.CancellationException;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

public abstract class 056 {
  public static final Object A00(05D param05D, 053 param053) {
    AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = 04k.A00;
    param05D = new 0GU(param05D, param05D.B2c());
    return 0IY.A00(param05D, param053, (0GU)param05D);
  }
  
  public static final 057 A01() {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: \r\n\tat com.googlecode.dex2jar.ir.ts.NewTransformer.transform(NewTransformer.java:134)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:148)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public static final 057 A02(04I param04I) {
    04I 04I1 = param04I;
    if (param04I.get(04l.A00) == null)
      04I1 = param04I.plus(new 04j(null)); 
    return new 057(04I1);
  }
  
  public static final void A03(CancellationException paramCancellationException, 058 param058) {
    04l 04l = (04l)param058.B32().get(04l.A00);
    if (04l != null) {
      04l.AMi(paramCancellationException);
      return;
    } 
    throw 002.A0L(param058, "Scope cannot be cancelled because it does not have a job: ", 001.A0s());
  }
  
  public static final boolean A04(058 param058) {
    04l 04l = (04l)param058.B32().get(04l.A00);
    return (04l != null) ? 04l.C2C() : true;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\056.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */