package X;

import android.content.Context;

public final class 02S {
  public static Boolean A00;
  
  public static boolean A00(Context paramContext) {
    // Byte code:
    //   0: ldc X/02S
    //   2: monitorenter
    //   3: getstatic X/02S.A00 : Ljava/lang/Boolean;
    //   6: ifnonnull -> 35
    //   9: iconst_0
    //   10: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   13: putstatic X/02S.A00 : Ljava/lang/Boolean;
    //   16: aload_0
    //   17: invokevirtual getAssets : ()Landroid/content/res/AssetManager;
    //   20: ldc 'app_modules.json'
    //   22: invokevirtual open : (Ljava/lang/String;)Ljava/io/InputStream;
    //   25: invokevirtual close : ()V
    //   28: iconst_1
    //   29: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   32: putstatic X/02S.A00 : Ljava/lang/Boolean;
    //   35: getstatic X/02S.A00 : Ljava/lang/Boolean;
    //   38: invokevirtual booleanValue : ()Z
    //   41: istore_1
    //   42: ldc X/02S
    //   44: monitorexit
    //   45: iload_1
    //   46: ireturn
    //   47: astore_0
    //   48: ldc X/02S
    //   50: monitorexit
    //   51: aload_0
    //   52: athrow
    //   53: astore_0
    //   54: goto -> 35
    // Exception table:
    //   from	to	target	type
    //   3	9	47	finally
    //   9	35	53	java/io/IOException
    //   9	35	47	finally
    //   35	42	47	finally
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\02S.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */