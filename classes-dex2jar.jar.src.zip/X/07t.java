package X;

import android.os.Bundle;
import android.text.Spanned;
import android.text.style.ClickableSpan;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeProvider;
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat;
import java.lang.ref.Reference;
import java.util.Collections;
import java.util.List;

public class 07t {
  public static final View.AccessibilityDelegate A02 = new View.AccessibilityDelegate();
  
  public final View.AccessibilityDelegate A00;
  
  public final View.AccessibilityDelegate A01;
  
  public 07t() {
    this(A02);
  }
  
  public 07t(View.AccessibilityDelegate paramAccessibilityDelegate) {
    this.A01 = paramAccessibilityDelegate;
    this.A00 = new 07u(this);
  }
  
  public void A0U(View paramView, int paramInt) {
    this.A01.sendAccessibilityEvent(paramView, paramInt);
  }
  
  public void A0V(View paramView, AccessibilityEvent paramAccessibilityEvent) {
    this.A01.onInitializeAccessibilityEvent(paramView, paramAccessibilityEvent);
  }
  
  public void A0W(View paramView, AccessibilityEvent paramAccessibilityEvent) {
    this.A01.onPopulateAccessibilityEvent(paramView, paramAccessibilityEvent);
  }
  
  public void A0X(View paramView, AccessibilityEvent paramAccessibilityEvent) {
    this.A01.sendAccessibilityEventUnchecked(paramView, paramAccessibilityEvent);
  }
  
  public void A0Y(View paramView, AccessibilityNodeInfoCompat paramAccessibilityNodeInfoCompat) {
    this.A01.onInitializeAccessibilityNodeInfo(paramView, paramAccessibilityNodeInfoCompat.mInfo);
  }
  
  public boolean A0Z(View paramView, int paramInt, Bundle paramBundle) {
    List<?> list2 = (List)paramView.getTag(2131370812);
    List<?> list1 = list2;
    if (list2 == null)
      list1 = Collections.emptyList(); 
    int i = 0;
    while (true) {
      0V8 0V8;
      if (i < list1.size()) {
        0V7 0V7 = (0V7)list1.get(i);
        if (0V7.A00() == paramInt) {
          0V8 = 0V7.A01;
          if (0V8 != null) {
            list1 = null;
            List list = null;
            Class clazz = 0V7.A02;
            if (clazz != null) {
              try {
                0VA 0VA = (0VA)002.A0P(clazz);
                try {
                  0VA.A00 = paramBundle;
                } catch (Exception null) {}
              } catch (Exception exception) {
                list1 = list;
              } 
              Log.e("A11yActionCompat", 0XK.A0b("Failed to execute command with argument class ViewCommandArgument: ", clazz.getName()), exception);
            } 
          } else {
            break;
          } 
        } else {
          i++;
          continue;
        } 
      } else {
        break;
      } 
      boolean bool4 = 0V8.DT2(paramView, (0VA)list1);
      boolean bool3 = bool4;
      if (!bool4)
        break; 
      return bool3;
    } 
    boolean bool2 = this.A01.performAccessibilityAction(paramView, paramInt, paramBundle);
    boolean bool1 = bool2;
    if (!bool2) {
      bool1 = bool2;
      if (paramInt == 2131361830) {
        bool1 = bool2;
        if (paramBundle != null) {
          paramInt = paramBundle.getInt("ACCESSIBILITY_CLICKABLE_SPAN_ID", -1);
          SparseArray sparseArray = (SparseArray)paramView.getTag(2131370813);
          if (sparseArray != null) {
            Reference<ClickableSpan> reference = (Reference)sparseArray.get(paramInt);
            if (reference != null) {
              ClickableSpan clickableSpan = reference.get();
              if (clickableSpan != null) {
                CharSequence charSequence = paramView.createAccessibilityNodeInfo().getText();
                if (charSequence instanceof Spanned) {
                  ClickableSpan[] arrayOfClickableSpan = (ClickableSpan[])((Spanned)charSequence).getSpans(0, charSequence.length(), ClickableSpan.class);
                  paramInt = 0;
                  if (arrayOfClickableSpan != null)
                    while (paramInt < arrayOfClickableSpan.length) {
                      if (clickableSpan.equals(arrayOfClickableSpan[paramInt])) {
                        clickableSpan.onClick(paramView);
                        return true;
                      } 
                      paramInt++;
                    }  
                } 
              } 
            } 
          } 
        } else {
          return bool1;
        } 
      } else {
        return bool1;
      } 
    } else {
      return bool1;
    } 
    return false;
  }
  
  public boolean A0a(View paramView, AccessibilityEvent paramAccessibilityEvent) {
    return this.A01.dispatchPopulateAccessibilityEvent(paramView, paramAccessibilityEvent);
  }
  
  public boolean A0b(ViewGroup paramViewGroup, View paramView, AccessibilityEvent paramAccessibilityEvent) {
    return this.A01.onRequestSendAccessibilityEvent(paramViewGroup, paramView, paramAccessibilityEvent);
  }
  
  public 0Mq A0c(View paramView) {
    AccessibilityNodeProvider accessibilityNodeProvider = this.A01.getAccessibilityNodeProvider(paramView);
    return (accessibilityNodeProvider != null) ? new 0Mq(accessibilityNodeProvider) : null;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */