package X;

import com.facebook.errorreporting.lacrima.detector.mobileconfig.LightMobileConfigDetector;
import com.facebook.mobileconfig.MobileConfigCanaryChangeListener;

public final class 03t implements MobileConfigCanaryChangeListener {
  public 03t(LightMobileConfigDetector paramLightMobileConfigDetector) {}
  
  public final void onConfigChanged() {
    LightMobileConfigDetector.access$onUpdate(this.A00);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\03t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */