package X;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

public final class 05y extends 05z implements 05D, 05E {
  public static final String __redex_internal_original_name = "DispatchedContinuation";
  
  public Object A00;
  
  public final Object A01;
  
  public final 05D A02;
  
  public final 04F A03;
  
  public 05y(05D param05D, 04F param04F) {
    super.A00 = -1;
    this.A03 = param04F;
    this.A02 = param05D;
    this.A00 = 062.A01;
    Object object = param05D.B2c().fold(Integer.valueOf(0), 063.A00);
    16F.A0D(object);
    this.A01 = object;
  }
  
  public final Object A07() {
    Object object = this.A00;
    this.A00 = 062.A01;
    return object;
  }
  
  public final 05D A0A() {
    return this;
  }
  
  public final void A0B(Object paramObject, Throwable paramThrowable) {}
  
  public final 05E Aym() {
    05D 05D1 = this.A02;
    return (05D1 instanceof 05E) ? (05E)05D1 : null;
  }
  
  public final 04I B2c() {
    return this.A02.B2c();
  }
  
  public final void DiG(Object paramObject) {
    05D 05D1 = this.A02;
    04I 04I = 05D1.B2c();
    Object object = paramObject;
    Throwable throwable = 067.A00(paramObject);
    if (throwable != null)
      object = new 0IX(throwable, false); 
    04F 04F1 = this.A03;
    if (04F1.A04(04I)) {
      this.A00 = object;
      super.A00 = 0;
      04F1.A05(this, 04I);
      return;
    } 
    04I = 0IP.A00();
    long l = ((05q)04I).A00;
    if (l >= 4294967296L) {
      this.A00 = object;
      super.A00 = 0;
      04I.A08(this);
      return;
    } 
    ((05q)04I).A00 = l + 4294967296L;
    try {
      object = 05D1.B2c();
      Object object1 = 063.A00(this.A01, (04I)object);
    } finally {
      paramObject = null;
    } 
    04I.A09(true);
  }
  
  public final String toString() {
    StringBuilder stringBuilder = 001.A0s();
    stringBuilder.append("DispatchedContinuation[");
    stringBuilder.append(this.A03);
    001.A1P(stringBuilder);
    stringBuilder.append(17N.A00(this.A02));
    return 002.A0W(stringBuilder);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\05y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */