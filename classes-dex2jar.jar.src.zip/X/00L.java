package X;

public final class 00L extends ThreadLocal {
  public 00L(00J param00J) {}
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00L.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */