package X;

import android.os.ConditionVariable;

public abstract class 008 {
  public static final ConditionVariable A00 = new ConditionVariable(false);
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\008.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */