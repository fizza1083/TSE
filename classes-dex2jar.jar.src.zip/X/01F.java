package X;

import android.database.sqlite.SQLiteDatabase;
import com.facebook.profilo.provider.constants.ExternalProviders;

public abstract class 01F {
  public static final ThreadLocal A00 = new 01H();
  
  public static void A00(int paramInt) {
    if (A00.get() == Boolean.FALSE)
      ExternalProviders.A07.A07().A00(6, 20, paramInt, 0L, 0); 
  }
  
  public static void A01(SQLiteDatabase paramSQLiteDatabase, int paramInt) {
    ExternalProviders.A07.A07().A00(6, 21, paramInt, 0L, 0);
    paramSQLiteDatabase.beginTransaction();
    A00.set(Boolean.TRUE);
  }
  
  public static void A02(SQLiteDatabase paramSQLiteDatabase, int paramInt) {
    ExternalProviders.A07.A07().A00(6, 21, paramInt, 0L, 0);
    paramSQLiteDatabase.beginTransactionNonExclusive();
    A00.set(Boolean.TRUE);
  }
  
  public static void A03(SQLiteDatabase paramSQLiteDatabase, int paramInt) {
    try {
      paramSQLiteDatabase.endTransaction();
      if (!paramSQLiteDatabase.inTransaction())
        A00.set(Boolean.FALSE); 
      return;
    } finally {
      ExternalProviders.A07.A07().A00(6, 22, paramInt, 0L, 0);
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01F.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */