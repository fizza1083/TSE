package X;

public abstract class 060 implements Runnable {
  public static final String __redex_internal_original_name = "Task";
  
  public long A00 = 0L;
  
  public 05R A01;
  
  public 060() {
    this.A01 = 05R1;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\060.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */