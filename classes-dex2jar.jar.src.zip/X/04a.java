package X;

public final class 04a {
  public final int A00;
  
  public final long A01;
  
  public final 04Y A02;
  
  public final String A03;
  
  public 04a(04Y param04Y, String paramString, int paramInt, long paramLong) {
    this.A02 = param04Y;
    this.A01 = paramLong;
    this.A00 = paramInt;
    this.A03 = paramString.replace(':', '/');
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\04a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */