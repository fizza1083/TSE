package X;

public abstract class 063 {
  public static final 053 A00;
  
  public static final 04o A01 = 04o.A00("NO_THREAD_ELEMENTS");
  
  public static final 053 A02;
  
  public static final 053 A03;
  
  static {
    A00 = 064.A00;
    A02 = 065.A00;
    A03 = 066.A00;
  }
  
  public static final Object A00(Object paramObject, 04I param04I) {
    Object object = paramObject;
    if (paramObject == null) {
      object = param04I.fold(Integer.valueOf(0), A00);
      16F.A0D(object);
    } 
    if (object == Integer.valueOf(0))
      return A01; 
    if (object instanceof Integer)
      return param04I.fold(new 18L(param04I, 001.A03(object)), A03); 
    16F.A0I(object, "null cannot be cast to non-null type kotlinx.coroutines.ThreadContextElement<kotlin.Any?>");
    throw 001.A0V("updateThreadContext");
  }
  
  public static final void A01(Object paramObject, 04I param04I) {
    if (paramObject != A01)
      if (paramObject instanceof 18L) {
        paramObject = ((18L)paramObject).A01;
        int i = paramObject.length - 1;
        if (i >= 0) {
          16F.A0D(paramObject[i]);
          throw 001.A0V("restoreThreadContext");
        } 
      } else {
        16F.A0I(param04I.fold(null, A02), "null cannot be cast to non-null type kotlinx.coroutines.ThreadContextElement<kotlin.Any?>");
        throw 001.A0V("restoreThreadContext");
      }  
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\063.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */