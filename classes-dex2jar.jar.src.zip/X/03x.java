package X;

public abstract class 03x {
  public static int A00;
  
  public static long A01;
  
  public static 06E A02;
  
  public static boolean A03;
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\03x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */