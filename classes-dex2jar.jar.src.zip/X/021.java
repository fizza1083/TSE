package X;

public final class 021 implements 0si {
  public static 021 A07;
  
  public int A00 = 1;
  
  public final 0wQ A01;
  
  public final 0u8 A02;
  
  public final 0qi A03;
  
  public final 020 A04;
  
  public final 0tW A05;
  
  public final Object A06 = 001.A0W();
  
  public 021(0wQ param0wQ, 0qi param0qi, 020 param020, 0u8 param0u8, 0tW param0tW) {
    this.A05 = param0tW;
    this.A03 = param0qi;
    this.A04 = param020;
    this.A01 = param0wQ;
    this.A02 = param0u8;
  }
  
  public static void A00(021 param021, Thread paramThread, Throwable paramThrowable, boolean paramBoolean) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public final 0sj getName() {
    return 0sj.A0D;
  }
  
  public final void start() {
    0tA.A00("JavascriptCrashDetector", this.A05.A04);
    A07 = this;
    if (0nN.A01() != null) {
      0nN.A02(new 023(this), 100);
      return;
    } 
    Thread.setDefaultUncaughtExceptionHandler(new 0t1(this, Thread.getDefaultUncaughtExceptionHandler()));
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\021.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */