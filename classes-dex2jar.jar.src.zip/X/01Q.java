package X;

import com.facebook.common.util.TriState;

public interface 01Q {
  TriState E1O();
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01Q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */