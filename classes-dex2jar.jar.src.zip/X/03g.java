package X;

public final class 03g implements 0r0 {
  public static 03g A03;
  
  public int A00 = -1;
  
  public 0r0 A01;
  
  public final 0tW A02;
  
  public 03g(0r0 param0r0, 0tW param0tW) {
    this.A02 = param0tW;
    this.A01 = param0r0;
  }
  
  public static void A00(int paramInt) {
    03g 03g1 = A03;
    if (03g1 != null)
      03g1.D3k(paramInt); 
  }
  
  public final void D3k(int paramInt) {
    0r0 0r01 = this.A01;
    if (0r01 != null)
      0r01.D3k(paramInt); 
    this.A00 = paramInt;
    0dR 0dR = this.A02.A05;
    0ah.A03(0dR);
    0dR.A07(paramInt);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\03g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */