package X;

import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceArray;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

public final class 05X {
  public static final 04o A04;
  
  public final int A00;
  
  public final int A01;
  
  public final boolean A02;
  
  static {
    A05 = AtomicLongFieldUpdater.newUpdater(05X.class, "_state$volatile");
    A04 = 04o.A00("REMOVE_FROZEN");
  }
  
  public 05X(int paramInt, boolean paramBoolean) {
    this.A00 = paramInt;
    this.A02 = paramBoolean;
    int i = paramInt - 1;
    this.A01 = i;
    this.A03 = new AtomicReferenceArray(paramInt);
    boolean bool = false;
    if (i <= 1073741823)
      bool = true; 
    if (bool) {
      if ((paramInt & i) == 0)
        return; 
      throw 001.A0S("Check failed.");
    } 
    throw 001.A0S("Check failed.");
  }
  
  private final 05X A00(long paramLong) {
    AtomicReferenceFieldUpdater<05X, 05X> atomicReferenceFieldUpdater = A06;
    while (true) {
      05X 05X1 = atomicReferenceFieldUpdater.get(this);
      if (05X1 != null)
        return 05X1; 
      05X 05X2 = new 05X(this.A00 * 2, this.A02);
      int i = (int)((0x3FFFFFFFL & paramLong) >> 0L);
      int j = (int)((0xFFFFFFFC0000000L & paramLong) >> 30L);
      while (true) {
        int k = this.A01;
        if ((i & k) != (k & j)) {
          0SH 0SH;
          05X 05X3 = (05X)this.A03.get(k & i);
          05X1 = 05X3;
          if (05X3 == null)
            0SH = new 0SH(i); 
          05X2.A03.set(05X2.A01 & i, 0SH);
          i++;
          continue;
        } 
        A05.set(05X2, paramLong & 0xEFFFFFFFFFFFFFFFL);
        05v.A00(this, null, 05X2, atomicReferenceFieldUpdater);
      } 
      break;
    } 
  }
  
  public final int A01(Object paramObject) {
    05X 05X1 = this;
    AtomicLongFieldUpdater<05X> atomicLongFieldUpdater = A05;
    while (true) {
      long l = atomicLongFieldUpdater.get(05X1);
      if ((0x3000000000000000L & l) != 0L) {
        byte b = 1;
        if ((l & 0x2000000000000000L) != 0L)
          b = 2; 
        return b;
      } 
      int j = (int)((0x3FFFFFFFL & l) >> 0L);
      int i = (int)((0xFFFFFFFC0000000L & l) >> 30L);
      int k = 05X1.A01;
      if ((i + 2 & k) != (j & k)) {
        if (!05X1.A02 && 05X1.A03.get(i & k) != null) {
          k = 05X1.A00;
          if (k < 1024 || (i - j & 0x3FFFFFFF) > k >> 1)
            return 1; 
          continue;
        } 
      } else {
        return 1;
      } 
      if (atomicLongFieldUpdater.compareAndSet(05X1, l, l & 0xF00000003FFFFFFFL | (i + 1 & 0x3FFFFFFF) << 30L)) {
        05X1.A03.set(i & k, paramObject);
        while ((atomicLongFieldUpdater.get(05X1) & 0x1000000000000000L) != 0L) {
          while (true) {
            long l1 = atomicLongFieldUpdater.get(05X1);
            l = l1;
            if ((l1 & 0x1000000000000000L) == 0L) {
              l = l1 | 0x1000000000000000L;
              if (atomicLongFieldUpdater.compareAndSet(05X1, l1, l))
                break; 
              continue;
            } 
            break;
          } 
          05X1 = 05X1.A00(l);
          AtomicReferenceArray<Object> atomicReferenceArray = 05X1.A03;
          j = 05X1.A01 & i;
          Object object = atomicReferenceArray.get(j);
          if (object instanceof 0SH && ((0SH)object).A00 == i)
            atomicReferenceArray.set(j, paramObject); 
        } 
        return 0;
      } 
    } 
  }
  
  public final Object A02() {
    long l;
    Object object;
    05X 05X1 = this;
    AtomicLongFieldUpdater<05X> atomicLongFieldUpdater = A05;
    while (true) {
      long l1 = atomicLongFieldUpdater.get(05X1);
      if ((0x1000000000000000L & l1) != 0L)
        return A04; 
      int i = (int)((0x3FFFFFFFL & l1) >> 0L);
      int j = (int)((0xFFFFFFFC0000000L & l1) >> 30L);
      int k = 05X1.A01;
      int m = k & i;
      Object object2 = null;
      Object object1 = object2;
      if ((j & k) != m) {
        AtomicReferenceArray<Object> atomicReferenceArray = 05X1.A03;
        object = atomicReferenceArray.get(m);
        if (object == null) {
          if (05X1.A02)
            return null; 
          continue;
        } 
        object1 = object2;
        if (!(object instanceof 0SH)) {
          l = (i + 1 & 0x3FFFFFFF) << 0L;
          if (atomicLongFieldUpdater.compareAndSet(05X1, l1, l1 & 0xFFFFFFFFC0000000L | l)) {
            atomicReferenceArray.set(m, null);
            return object;
          } 
          if (05X1.A02)
            break; 
          continue;
        } 
      } 
      return object1;
    } 
    while (true) {
      long l1 = atomicLongFieldUpdater.get(05X1);
      int i = (int)((0x3FFFFFFFL & l1) >> 0L);
      if ((0x1000000000000000L & l1) == 0L) {
        if (atomicLongFieldUpdater.compareAndSet(05X1, l1, l1 & 0xFFFFFFFFC0000000L | l)) {
          05X1.A03.set(05X1.A01 & i, null);
          return object;
        } 
        continue;
      } 
      while (true) {
        long l2 = atomicLongFieldUpdater.get(05X1);
        l1 = l2;
        if ((l2 & 0x1000000000000000L) == 0L) {
          l1 = l2 | 0x1000000000000000L;
          if (atomicLongFieldUpdater.compareAndSet(05X1, l2, l1))
            break; 
          continue;
        } 
        break;
      } 
      05X1 = 05X1.A00(l1);
    } 
  }
  
  public final 05X A03() {
    long l;
    AtomicLongFieldUpdater<05X> atomicLongFieldUpdater = A05;
    while (true) {
      long l1 = atomicLongFieldUpdater.get(this);
      l = l1;
      if ((l1 & 0x1000000000000000L) == 0L) {
        l = l1 | 0x1000000000000000L;
        if (atomicLongFieldUpdater.compareAndSet(this, l1, l))
          break; 
        continue;
      } 
      break;
    } 
    return A00(l);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\05X.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */