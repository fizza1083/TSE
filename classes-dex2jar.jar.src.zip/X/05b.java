package X;

import com.facebook.profilo.ipc.TraceContext;
import com.facebook.profilo.multiprocess.ProfiloMultiProcessTraceServiceImpl;
import com.facebook.profilo.provider.constants.ExternalProviders;

public final class 05b extends 05a {
  public final 05i A00;
  
  public final ProfiloMultiProcessTraceServiceImpl A01;
  
  public final 05j A00() {
    return this.A00;
  }
  
  public final void onTraceAbort(TraceContext paramTraceContext) {
    if ((paramTraceContext.A02 & ExternalProviders.A06.A01) != 0)
      this.A01.onTraceAbort(paramTraceContext); 
  }
  
  public final void onTraceStart(TraceContext paramTraceContext) {
    if ((paramTraceContext.A02 & ExternalProviders.A06.A01) != 0) {
      ProfiloMultiProcessTraceServiceImpl profiloMultiProcessTraceServiceImpl = this.A01;
      profiloMultiProcessTraceServiceImpl.DLI(paramTraceContext);
      profiloMultiProcessTraceServiceImpl.DLH(paramTraceContext);
    } 
  }
  
  public final void onTraceStop(TraceContext paramTraceContext) {
    if ((paramTraceContext.A02 & ExternalProviders.A06.A01) != 0)
      this.A01.onTraceStop(paramTraceContext); 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\05b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */