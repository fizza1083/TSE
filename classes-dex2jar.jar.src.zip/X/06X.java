package X;

import android.app.Application;
import android.content.Context;
import android.os.SystemClock;
import android.view.Window;
import com.facebook.katana.app.mainactivity.FbMainActivity;
import com.facebook.katana.app.mainactivity.FbMainActivitySplashHelper;
import com.facebook.perf.background.BackgroundStartupDetector;
import java.lang.ref.Reference;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;

public final class 06X implements Runnable {
  public static final 06X A00 = new 06X();
  
  public static final String __redex_internal_original_name = "FbMainActivityTracker$dismissSplashScreen$runnable$1";
  
  public final void run() {
    ArrayList arrayList = 08S.A00;
    if (!arrayList.isEmpty()) {
      02A.A03 = true;
      02A.A01 = Long.valueOf(SystemClock.elapsedRealtime());
      arrayList.size();
      Object object = arrayList.clone();
      16F.A0I(object, "null cannot be cast to non-null type java.util.ArrayList<java.lang.ref.WeakReference<com.facebook.katana.app.mainactivity.FbMainActivity>>");
      object = object;
      arrayList.clear();
      Iterator<Reference<FbMainActivity>> iterator = object.iterator();
      while (iterator.hasNext()) {
        object = ((Reference<FbMainActivity>)iterator.next()).get();
        if (object != null && !object.isFinishing() && !object.isDestroyed()) {
          0Hj 0Hj = ((FbMainActivity)object).A00;
          if (0Hj != null) {
            BackgroundStartupDetector backgroundStartupDetector = BackgroundStartupDetector.A0J;
            if (backgroundStartupDetector != null)
              backgroundStartupDetector.A03 = true; 
            0Hj.A06.getApplication().registerActivityLifecycleCallbacks((Application.ActivityLifecycleCallbacks)new FbMainActivitySplashHelper.ActivityRecreateLifecycleListener(0Hj));
          } 
          0Hj = ((FbMainActivity)object).A00;
          if (0Hj != null)
            0Hj.A01(); 
          ((FbMainActivity)object).A00 = null;
          if ((0l3.A01((Context)object)).A2D) {
            object.getWindow().addFlags(16777216);
            Field field = Window.class.getDeclaredField("mHardwareAccelerated");
            if (field != null) {
              field.setAccessible(true);
              field.set(object.getWindow(), Boolean.valueOf(true));
            } 
          } 
          object.recreate();
        } 
      } 
      02A.A03 = false;
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\06X.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */