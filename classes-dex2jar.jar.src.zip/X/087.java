package X;

import android.content.Context;

public final class 087 {
  public static volatile Integer A00;
  
  public static int A00(Context paramContext) {
    // Byte code:
    //   0: getstatic X/087.A00 : Ljava/lang/Integer;
    //   3: ifnonnull -> 321
    //   6: ldc X/087
    //   8: monitorenter
    //   9: getstatic X/087.A00 : Ljava/lang/Integer;
    //   12: ifnonnull -> 259
    //   15: aload_0
    //   16: invokestatic A03 : (Landroid/content/Context;)J
    //   19: lstore_3
    //   20: lload_3
    //   21: ldc2_w -1
    //   24: lcmp
    //   25: ifne -> 139
    //   28: invokestatic A0y : ()Ljava/util/ArrayList;
    //   31: astore #5
    //   33: invokestatic A01 : ()I
    //   36: istore_2
    //   37: iload_2
    //   38: iconst_1
    //   39: if_icmplt -> 60
    //   42: iload_2
    //   43: iconst_1
    //   44: if_icmpne -> 328
    //   47: sipush #2008
    //   50: istore_1
    //   51: goto -> 54
    //   54: aload #5
    //   56: iload_1
    //   57: invokestatic A1R : (Ljava/util/AbstractCollection;I)V
    //   60: invokestatic A00 : ()I
    //   63: i2l
    //   64: lstore_3
    //   65: lload_3
    //   66: ldc2_w -1
    //   69: lcmp
    //   70: ifeq -> 94
    //   73: lload_3
    //   74: ldc2_w 528000
    //   77: lcmp
    //   78: ifgt -> 344
    //   81: sipush #2008
    //   84: istore_1
    //   85: goto -> 88
    //   88: aload #5
    //   90: iload_1
    //   91: invokestatic A1R : (Ljava/util/AbstractCollection;I)V
    //   94: aload_0
    //   95: invokestatic A03 : (Landroid/content/Context;)J
    //   98: lstore_3
    //   99: lload_3
    //   100: lconst_0
    //   101: lcmp
    //   102: ifle -> 126
    //   105: lload_3
    //   106: ldc2_w 201326592
    //   109: lcmp
    //   110: ifgt -> 423
    //   113: sipush #2008
    //   116: istore_1
    //   117: goto -> 120
    //   120: aload #5
    //   122: iload_1
    //   123: invokestatic A1R : (Ljava/util/AbstractCollection;I)V
    //   126: aload #5
    //   128: invokevirtual isEmpty : ()Z
    //   131: ifeq -> 213
    //   134: iconst_m1
    //   135: istore_1
    //   136: goto -> 252
    //   139: lload_3
    //   140: ldc2_w 805306368
    //   143: lcmp
    //   144: ifgt -> 167
    //   147: invokestatic A01 : ()I
    //   150: istore_2
    //   151: sipush #2010
    //   154: istore_1
    //   155: iload_2
    //   156: iconst_1
    //   157: if_icmpgt -> 252
    //   160: sipush #2009
    //   163: istore_1
    //   164: goto -> 252
    //   167: sipush #2012
    //   170: istore_1
    //   171: lload_3
    //   172: ldc2_w 1073741824
    //   175: lcmp
    //   176: ifgt -> 194
    //   179: invokestatic A00 : ()I
    //   182: ldc 1300000
    //   184: if_icmpge -> 252
    //   187: sipush #2011
    //   190: istore_1
    //   191: goto -> 252
    //   194: lload_3
    //   195: ldc2_w 1610612736
    //   198: lcmp
    //   199: ifgt -> 502
    //   202: invokestatic A00 : ()I
    //   205: ldc 1800000
    //   207: if_icmpge -> 544
    //   210: goto -> 252
    //   213: aload #5
    //   215: invokestatic sort : (Ljava/util/List;)V
    //   218: aload #5
    //   220: invokevirtual size : ()I
    //   223: istore_1
    //   224: aload #5
    //   226: invokevirtual size : ()I
    //   229: iconst_2
    //   230: idiv
    //   231: istore_2
    //   232: iload_1
    //   233: iconst_1
    //   234: iand
    //   235: iconst_1
    //   236: if_icmpne -> 265
    //   239: aload #5
    //   241: iload_2
    //   242: invokevirtual get : (I)Ljava/lang/Object;
    //   245: checkcast java/lang/Integer
    //   248: invokevirtual intValue : ()I
    //   251: istore_1
    //   252: iload_1
    //   253: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   256: putstatic X/087.A00 : Ljava/lang/Integer;
    //   259: ldc X/087
    //   261: monitorexit
    //   262: goto -> 321
    //   265: iload_2
    //   266: iconst_1
    //   267: isub
    //   268: istore_1
    //   269: aload #5
    //   271: iload_1
    //   272: invokevirtual get : (I)Ljava/lang/Object;
    //   275: checkcast java/lang/Integer
    //   278: invokevirtual intValue : ()I
    //   281: aload #5
    //   283: iload_1
    //   284: iconst_1
    //   285: iadd
    //   286: invokevirtual get : (I)Ljava/lang/Object;
    //   289: checkcast java/lang/Integer
    //   292: invokevirtual intValue : ()I
    //   295: aload #5
    //   297: iload_1
    //   298: invokevirtual get : (I)Ljava/lang/Object;
    //   301: checkcast java/lang/Integer
    //   304: invokevirtual intValue : ()I
    //   307: isub
    //   308: iconst_2
    //   309: idiv
    //   310: iadd
    //   311: istore_1
    //   312: goto -> 252
    //   315: astore_0
    //   316: ldc X/087
    //   318: monitorexit
    //   319: aload_0
    //   320: athrow
    //   321: getstatic X/087.A00 : Ljava/lang/Integer;
    //   324: invokevirtual intValue : ()I
    //   327: ireturn
    //   328: sipush #2012
    //   331: istore_1
    //   332: iload_2
    //   333: iconst_3
    //   334: if_icmpgt -> 54
    //   337: sipush #2011
    //   340: istore_1
    //   341: goto -> 54
    //   344: lload_3
    //   345: ldc2_w 620000
    //   348: lcmp
    //   349: ifgt -> 359
    //   352: sipush #2009
    //   355: istore_1
    //   356: goto -> 88
    //   359: lload_3
    //   360: ldc2_w 1020000
    //   363: lcmp
    //   364: ifgt -> 374
    //   367: sipush #2010
    //   370: istore_1
    //   371: goto -> 88
    //   374: lload_3
    //   375: ldc2_w 1220000
    //   378: lcmp
    //   379: ifgt -> 389
    //   382: sipush #2011
    //   385: istore_1
    //   386: goto -> 88
    //   389: lload_3
    //   390: ldc2_w 1520000
    //   393: lcmp
    //   394: ifgt -> 404
    //   397: sipush #2012
    //   400: istore_1
    //   401: goto -> 88
    //   404: sipush #2014
    //   407: istore_1
    //   408: lload_3
    //   409: ldc2_w 2020000
    //   412: lcmp
    //   413: ifgt -> 88
    //   416: sipush #2013
    //   419: istore_1
    //   420: goto -> 88
    //   423: lload_3
    //   424: ldc2_w 304087040
    //   427: lcmp
    //   428: ifgt -> 438
    //   431: sipush #2009
    //   434: istore_1
    //   435: goto -> 120
    //   438: lload_3
    //   439: ldc2_w 536870912
    //   442: lcmp
    //   443: ifgt -> 453
    //   446: sipush #2010
    //   449: istore_1
    //   450: goto -> 120
    //   453: lload_3
    //   454: ldc2_w 1073741824
    //   457: lcmp
    //   458: ifgt -> 468
    //   461: sipush #2011
    //   464: istore_1
    //   465: goto -> 120
    //   468: lload_3
    //   469: ldc2_w 1610612736
    //   472: lcmp
    //   473: ifgt -> 483
    //   476: sipush #2012
    //   479: istore_1
    //   480: goto -> 120
    //   483: sipush #2014
    //   486: istore_1
    //   487: lload_3
    //   488: ldc2_w 2147483648
    //   491: lcmp
    //   492: ifgt -> 120
    //   495: sipush #2013
    //   498: istore_1
    //   499: goto -> 120
    //   502: lload_3
    //   503: ldc2_w 2147483648
    //   506: lcmp
    //   507: ifle -> 544
    //   510: lload_3
    //   511: ldc2_w 3221225472
    //   514: lcmp
    //   515: ifgt -> 525
    //   518: sipush #2014
    //   521: istore_1
    //   522: goto -> 252
    //   525: sipush #2016
    //   528: istore_1
    //   529: lload_3
    //   530: ldc2_w 5368709120
    //   533: lcmp
    //   534: ifgt -> 252
    //   537: sipush #2015
    //   540: istore_1
    //   541: goto -> 252
    //   544: sipush #2013
    //   547: istore_1
    //   548: goto -> 252
    // Exception table:
    //   from	to	target	type
    //   9	20	315	finally
    //   28	37	315	finally
    //   54	60	315	finally
    //   60	65	315	finally
    //   88	94	315	finally
    //   94	99	315	finally
    //   120	126	315	finally
    //   126	134	315	finally
    //   147	151	315	finally
    //   179	187	315	finally
    //   202	210	315	finally
    //   213	232	315	finally
    //   239	252	315	finally
    //   252	259	315	finally
    //   259	262	315	finally
    //   269	312	315	finally
    //   316	319	315	finally
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\087.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */