package X;

import android.content.Context;
import android.content.pm.PackageManager;
import com.facebook.voltron.runtime.ModuleApkUtil;
import java.io.File;

public abstract class 03m {
  public static File A00(Context paramContext, String paramString) {
    String str2 = ModuleApkUtil.ModuleResolver.getSplitApkLocation(paramString, paramContext);
    String str1 = str2;
    if (str2 == null) {
      try {
        Context context = paramContext.createPackageContext(paramContext.getPackageName(), 0);
        paramContext = context;
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {}
      String str = ModuleApkUtil.ModuleResolver.getSplitApkLocation(paramString, paramContext);
      str1 = str;
      if (str == null)
        return null; 
    } 
    return new File(str1);
  }
  
  public static boolean A01(Context paramContext, String paramString) {
    boolean bool = false;
    String str = ModuleApkUtil.ModuleResolver.getSplitApkLocation(paramString, paramContext);
    if (str != null)
      bool = (new File(str)).exists(); 
    return bool;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\03m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */