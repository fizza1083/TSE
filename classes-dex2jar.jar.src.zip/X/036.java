package X;

import java.util.List;

public interface 036 {
  void AFs(String paramString, long paramLong);
  
  void AFu(String paramString1, String paramString2);
  
  void AFv(String paramString, String[] paramArrayOfString);
  
  short Arx();
  
  String AuB(String paramString);
  
  038 AuC();
  
  int B7u();
  
  long B7v();
  
  long B8v();
  
  int B9w();
  
  List BAl();
  
  List BAw();
  
  boolean BFG();
  
  int BJ3();
  
  short BKt();
  
  String BL0();
  
  String BL1();
  
  long BL9();
  
  long BLA();
  
  int BLi();
  
  int BO0();
  
  0FP BPj();
  
  long BQl();
  
  long BQm();
  
  112 BWJ();
  
  031 BWy();
  
  03C BY2();
  
  int Bdn();
  
  long Bf1();
  
  String Blq();
  
  List Bmi();
  
  String Bmj();
  
  long Bon();
  
  long BqV();
  
  int BrP();
  
  String BrQ();
  
  boolean Bxc();
  
  boolean C2P();
  
  boolean C34();
  
  boolean C5f();
  
  boolean C79(long paramLong);
  
  boolean C7G();
  
  boolean CAu();
  
  boolean CBI();
  
  boolean Dz0();
  
  int getFlags();
  
  int getMarkerId();
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\036.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */