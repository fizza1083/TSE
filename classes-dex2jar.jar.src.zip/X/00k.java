package X;

import java.util.Map;

public abstract class 00k {
  public static final Object A0A = 001.A0W();
  
  public int A00 = 0;
  
  public int A01;
  
  public boolean A02;
  
  public 0Xh A03 = new 0Xh();
  
  public boolean A04;
  
  public boolean A05;
  
  public final Object A06 = new Object();
  
  public final Runnable A07;
  
  public volatile Object A08;
  
  public volatile Object A09;
  
  public 00k() {
    Object object = A0A;
    this.A09 = object;
    this.A07 = new 00l(this);
    this.A08 = object;
    this.A01 = -1;
  }
  
  public 00k(Object paramObject) {
    this.A09 = A0A;
    this.A07 = new 00l(this);
    this.A08 = paramObject;
    this.A01 = 0;
  }
  
  public static void A00(String paramString) {
    if (18m.A00().A03())
      return; 
    throw 0XK.A08("Cannot invoke ", paramString, " on a background thread");
  }
  
  public Object A02() {
    Object object2 = this.A08;
    Object object1 = object2;
    if (object2 == A0A)
      object1 = null; 
    return object1;
  }
  
  public final void A03(0cu param0cu) {
    A00("removeObservers");
    for (Map.Entry entry : this.A03) {
      if (((0Tn)entry.getValue()).A03(param0cu))
        A06((0Tk)entry.getKey()); 
    } 
  }
  
  public void A04(0cu param0cu, 0Tk param0Tk) {
    A00("observe");
    if (param0cu.getLifecycle().A04() != 0cr.A02) {
      0To 0To = new 0To(param0cu, this, param0Tk);
      0Tn 0Tn = (0Tn)this.A03.A02(param0Tk, 0To);
      if (0Tn != null) {
        if (!0Tn.A03(param0cu))
          throw 001.A0O("Cannot add the same observer with different lifecycles"); 
      } else {
        param0cu.getLifecycle().A05(0To);
      } 
    } 
  }
  
  public final void A05(0Tn param0Tn) {
    if (this.A05) {
      this.A04 = true;
      return;
    } 
    this.A05 = true;
    label35: while (true) {
      this.A04 = false;
      if (param0Tn != null) {
        if (param0Tn.A01)
          if (!param0Tn.A02()) {
            param0Tn.A01(false);
          } else {
            int i = param0Tn.A00;
            int j = this.A01;
            if (i < j) {
              param0Tn.A00 = j;
              param0Tn.A02.CWf(this.A08);
            } 
          }  
        Object object = null;
        continue;
      } 
      0Xh 0Xh1 = this.A03;
      0E8 0E8 = new 0E8(0Xh1);
      0Xh1.A03.put(0E8, Boolean.valueOf(false));
      while (true) {
        0Tn 0Tn1 = param0Tn;
        if (0E8.hasNext()) {
          0Tn1 = (0Tn)((Map.Entry)0E8.next()).getValue();
          if (0Tn1.A01)
            if (!0Tn1.A02()) {
              0Tn1.A01(false);
            } else {
              int i = 0Tn1.A00;
              int j = this.A01;
              if (i < j) {
                0Tn1.A00 = j;
                0Tn1.A02.CWf(this.A08);
              } 
            }  
          if (this.A04) {
            0Tn1 = param0Tn;
          } else {
            continue;
          } 
        } 
        param0Tn = 0Tn1;
        if (!this.A04) {
          this.A05 = false;
          return;
        } 
        continue label35;
      } 
      break;
    } 
  }
  
  public void A06(0Tk param0Tk) {
    A00("removeObserver");
    0Tn 0Tn = (0Tn)this.A03.A01(param0Tk);
    if (0Tn != null) {
      0Tn.A00();
      0Tn.A01(false);
    } 
  }
  
  public final void A07(0Tk param0Tk) {
    A00("observeForever");
    0Tm 0Tm = new 0Tm(this, param0Tk);
    Object object = this.A03.A02(param0Tk, 0Tm);
    if (!(object instanceof 0To)) {
      if (object == null)
        0Tm.A01(true); 
      return;
    } 
    throw 001.A0O("Cannot add the same observer with different lifecycles");
  }
  
  public void A08(Object paramObject) {
    synchronized (this.A06) {
      Object object1 = this.A09;
      Object object2 = A0A;
      boolean bool = false;
      if (object1 == object2)
        bool = true; 
      this.A09 = paramObject;
      if (bool)
        18m.A00().A02(this.A07); 
      return;
    } 
  }
  
  public void A09(Object paramObject) {
    A00("setValue");
    this.A01++;
    this.A08 = paramObject;
    A05(null);
  }
  
  public void A0A() {}
  
  public void A0B() {}
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */