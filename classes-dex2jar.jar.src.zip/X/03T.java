package X;

import android.content.Context;
import android.content.Intent;

public abstract class 03T {
  public final 03U A00;
  
  public 03T(03U param03U) {
    this.A00 = param03U;
  }
  
  public boolean A01(Context paramContext, Intent paramIntent, 0G9 param0G9, Object paramObject) {
    // Byte code:
    //   0: aload_0
    //   1: getfield A00 : LX/03U;
    //   4: astore #9
    //   6: aload #9
    //   8: invokeinterface Dz2 : ()Z
    //   13: ifeq -> 388
    //   16: aload #9
    //   18: invokeinterface B5B : ()[LX/07Z;
    //   23: astore #10
    //   25: iconst_0
    //   26: istore #6
    //   28: iload #6
    //   30: istore #5
    //   32: aload #10
    //   34: ifnull -> 230
    //   37: aload #10
    //   39: arraylength
    //   40: istore #8
    //   42: iload #6
    //   44: istore #5
    //   46: iload #8
    //   48: ifle -> 230
    //   51: iconst_0
    //   52: istore #5
    //   54: aload #10
    //   56: iload #5
    //   58: aaload
    //   59: astore #11
    //   61: aload #11
    //   63: getfield A03 : Ljava/util/regex/Pattern;
    //   66: astore #12
    //   68: aload #12
    //   70: ifnull -> 92
    //   73: aload #12
    //   75: aload #4
    //   77: invokevirtual getClass : ()Ljava/lang/Class;
    //   80: invokevirtual getName : ()Ljava/lang/String;
    //   83: invokevirtual matcher : (Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    //   86: invokevirtual matches : ()Z
    //   89: ifeq -> 364
    //   92: aload_1
    //   93: aload_2
    //   94: aconst_null
    //   95: ldc 86400000
    //   97: invokestatic A00 : (Landroid/content/Context;Landroid/content/Intent;LX/11P;I)LX/0Hx;
    //   100: astore #14
    //   102: aload #11
    //   104: getfield A00 : LX/0FY;
    //   107: astore #12
    //   109: aload #12
    //   111: ifnull -> 217
    //   114: aload #14
    //   116: ifnull -> 364
    //   119: invokestatic A1F : ()Lorg/json/JSONObject;
    //   122: astore #13
    //   124: aload #13
    //   126: ldc 'caller_uid'
    //   128: aload #14
    //   130: getfield A00 : I
    //   133: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   136: pop
    //   137: aload #14
    //   139: invokevirtual A03 : ()Ljava/lang/String;
    //   142: astore #15
    //   144: aload #15
    //   146: ifnull -> 159
    //   149: aload #13
    //   151: ldc 'caller_package_name'
    //   153: aload #15
    //   155: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   158: pop
    //   159: aload #14
    //   161: getfield A02 : Ljava/lang/String;
    //   164: astore #15
    //   166: aload #15
    //   168: ifnull -> 181
    //   171: aload #13
    //   173: ldc 'caller_version_name'
    //   175: aload #15
    //   177: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   180: pop
    //   181: aload #14
    //   183: getfield A01 : Ljava/lang/String;
    //   186: astore #14
    //   188: aload #14
    //   190: ifnull -> 203
    //   193: aload #13
    //   195: ldc 'caller_domain'
    //   197: aload #14
    //   199: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   202: pop
    //   203: aload #12
    //   205: aconst_null
    //   206: aload #13
    //   208: invokevirtual A02 : (Landroid/content/Intent;Lorg/json/JSONObject;)Z
    //   211: ifne -> 217
    //   214: goto -> 364
    //   217: aload #11
    //   219: aload_2
    //   220: aload_3
    //   221: invokevirtual A01 : (Landroid/content/Intent;LX/0G9;)Z
    //   224: ifeq -> 364
    //   227: iconst_1
    //   228: istore #5
    //   230: iload #5
    //   232: ifne -> 338
    //   235: aload #9
    //   237: invokeinterface BJF : ()[LX/07c;
    //   242: astore_1
    //   243: aload_1
    //   244: arraylength
    //   245: istore #7
    //   247: iconst_0
    //   248: istore #5
    //   250: iload #5
    //   252: iload #7
    //   254: if_icmpge -> 388
    //   257: aload_1
    //   258: iload #5
    //   260: aaload
    //   261: astore_3
    //   262: aload_3
    //   263: getfield A02 : Ljava/lang/String;
    //   266: astore #9
    //   268: aload #9
    //   270: ifnull -> 289
    //   273: aload #9
    //   275: aload #4
    //   277: invokevirtual getClass : ()Ljava/lang/Class;
    //   280: invokevirtual getName : ()Ljava/lang/String;
    //   283: invokevirtual equals : (Ljava/lang/Object;)Z
    //   286: ifeq -> 355
    //   289: aload_3
    //   290: getfield A01 : Landroid/content/IntentFilter;
    //   293: astore #9
    //   295: aload #9
    //   297: ifnull -> 338
    //   300: aload #9
    //   302: aload_3
    //   303: getfield A00 : Landroid/content/ContentResolver;
    //   306: aload_2
    //   307: iconst_0
    //   308: ldc 'TAG'
    //   310: invokevirtual match : (Landroid/content/ContentResolver;Landroid/content/Intent;ZLjava/lang/String;)I
    //   313: istore #8
    //   315: iconst_0
    //   316: istore #6
    //   318: iload #8
    //   320: ifle -> 326
    //   323: iconst_1
    //   324: istore #6
    //   326: aload_3
    //   327: getfield A03 : Z
    //   330: ifeq -> 347
    //   333: iload #6
    //   335: ifne -> 355
    //   338: aload_0
    //   339: aload_2
    //   340: aload #4
    //   342: invokevirtual A03 : (Landroid/content/Intent;Ljava/lang/Object;)V
    //   345: iconst_0
    //   346: ireturn
    //   347: iload #6
    //   349: ifeq -> 355
    //   352: goto -> 338
    //   355: iload #5
    //   357: iconst_1
    //   358: iadd
    //   359: istore #5
    //   361: goto -> 250
    //   364: iload #5
    //   366: iconst_1
    //   367: iadd
    //   368: istore #7
    //   370: iload #6
    //   372: istore #5
    //   374: iload #7
    //   376: iload #8
    //   378: if_icmpge -> 230
    //   381: iload #7
    //   383: istore #5
    //   385: goto -> 54
    //   388: iconst_1
    //   389: ireturn
    //   390: astore #11
    //   392: goto -> 364
    // Exception table:
    //   from	to	target	type
    //   92	109	390	org/json/JSONException
    //   119	144	390	org/json/JSONException
    //   149	159	390	org/json/JSONException
    //   159	166	390	org/json/JSONException
    //   171	181	390	org/json/JSONException
    //   181	188	390	org/json/JSONException
    //   193	203	390	org/json/JSONException
    //   203	214	390	org/json/JSONException
  }
  
  public boolean A02(Context paramContext, Intent paramIntent, Object paramObject) {
    return A01(paramContext, paramIntent, null, paramObject);
  }
  
  public abstract void A03(Intent paramIntent, Object paramObject);
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\03T.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */