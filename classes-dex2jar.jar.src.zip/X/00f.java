package X;

public final class 00f {
  public final 0BA A00;
  
  public final 0BA A01;
  
  public 00f(0BA param0BA1, 0BA param0BA2) {
    this.A00 = param0BA1;
    this.A01 = param0BA2;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */