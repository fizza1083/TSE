package X;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;

public final class 03C {
  public int A00 = 5;
  
  public int A01;
  
  public int[] A02 = new int[5];
  
  public long[] A03 = new long[5];
  
  public 03D[] A04 = new 03D[5];
  
  public 03E[] A05 = new 03E[5];
  
  public String[] A06 = new String[5];
  
  public final void A00(03D param03D, 03E param03E, String paramString, TimeUnit paramTimeUnit, int paramInt, long paramLong) {
    int i = this.A01;
    int j = this.A00;
    if (i == j) {
      i = j + (j >> 1);
      long[] arrayOfLong = this.A03;
      if (arrayOfLong.length < i)
        this.A03 = Arrays.copyOf(arrayOfLong, i); 
      String[] arrayOfString1 = this.A06;
      if (arrayOfString1.length < i)
        this.A06 = Arrays.<String>copyOf(arrayOfString1, i); 
      03D[] arrayOf03D = this.A04;
      if (arrayOf03D.length < i)
        this.A04 = Arrays.<03D>copyOf(arrayOf03D, i); 
      int[] arrayOfInt = this.A02;
      if (arrayOfInt.length < i)
        this.A02 = Arrays.copyOf(arrayOfInt, i); 
      03E[] arrayOf03E = this.A05;
      if (arrayOf03E.length < i)
        this.A05 = Arrays.<03E>copyOf(arrayOf03E, i); 
      this.A00 = i;
    } 
    if (param03D != null && !param03D.A03)
      throw 001.A0S("PointData should be locked before passing to the storage"); 
    this.A03[this.A01] = paramTimeUnit.toNanos(paramLong);
    String[] arrayOfString = this.A06;
    i = this.A01;
    arrayOfString[i] = paramString;
    this.A04[i] = param03D;
    this.A02[i] = paramInt;
    this.A05[i] = param03E;
    this.A01 = i + 1;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\03C.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */