package X;

import android.os.SystemClock;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Iterator;
import java.util.List;

public final class 014 implements InvocationHandler {
  public final Object A00;
  
  public final Object A01;
  
  public final String A02;
  
  public 014(Class paramClass, Object paramObject, String paramString, boolean paramBoolean) {
    this.A02 = paramString;
    this.A01 = paramObject;
    this.A00 = Proxy.newProxyInstance(014.class.getClassLoader(), new Class[] { paramClass }, this);
    if (paramBoolean)
      00u.A02.add(paramString); 
  }
  
  private final Object A00(Method paramMethod, Object[] paramArrayOfObject) {
    Object object;
    try {
      long l1 = SystemClock.elapsedRealtime();
      object = paramMethod.invoke(this.A01, paramArrayOfObject);
      long l2 = SystemClock.elapsedRealtime();
      List list = 00u.A00;
      if ((list.isEmpty() ^ true) != 0) {
        Iterator<00r> iterator = list.iterator();
        while (iterator.hasNext())
          ((00r)iterator.next()).Ci8(object, this.A02, paramMethod, paramArrayOfObject, l2 - l1); 
      } 
    } catch (InvocationTargetException invocationTargetException) {
      Throwable throwable;
      if (invocationTargetException.getCause() != null) {
        throwable = invocationTargetException.getCause();
      } else {
        throwable = invocationTargetException.getTargetException();
      } 
      if (throwable != null)
        throw throwable; 
      throw invocationTargetException;
    } 
    return object;
  }
  
  public final 01p A01(Method paramMethod, Object[] paramArrayOfObject) {
    Boolean bool;
    try {
      return new 01p(A00(paramMethod, paramArrayOfObject));
    } finally {
      paramArrayOfObject = null;
      Class<?> clazz = paramMethod.getReturnType();
      Class<boolean> clazz1 = boolean.class;
      boolean bool1 = false;
    } 
    return new 01p(bool);
  }
  
  public final Object invoke(Object paramObject, Method paramMethod, Object[] paramArrayOfObject) {
    paramObject = 00u.A00;
    if ((paramObject.isEmpty() ^ true) != 0) {
      paramObject = paramObject.iterator();
      while (paramObject.hasNext()) {
        01p 01p = ((00r)paramObject.next()).AyX(this, this.A02, paramMethod, paramArrayOfObject);
        if (01p != null)
          return 01p.A00; 
      } 
    } 
    return A00(paramMethod, paramArrayOfObject);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\014.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */