package X;

public abstract class 04z {
  public static 04H A00(04H param04H, 04R param04R) {
    16F.A0E(param04R, 1);
    04H 04H1 = param04H;
    if (!16F.A0S(param04H.getKey(), param04R))
      04H1 = null; 
    return 04H1;
  }
  
  public static 04I A01(04H param04H, 04R param04R) {
    050 050;
    16F.A0E(param04R, 1);
    04H 04H1 = param04H;
    if (16F.A0S(param04H.getKey(), param04R))
      050 = 050.A00; 
    return 050;
  }
  
  public static 04I A02(04H param04H, 04I param04I) {
    16F.A0E(param04I, 1);
    04I 04I1 = param04H;
    if (param04I != 050.A00)
      04I1 = (04I)param04I.fold(param04H, 051.A00); 
    return 04I1;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\04z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */