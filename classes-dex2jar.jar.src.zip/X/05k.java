package X;

public abstract class 05k {
  public static final void A00(int paramInt) {
    if (paramInt >= 1)
      return; 
    throw 0XK.A03("Expected positive parallelism level, but got ", paramInt);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\05k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */