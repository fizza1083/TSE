package X;

import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public final class 03o implements 0si {
  public final 0qi A00;
  
  public 03o(0qi param0qi) {
    this.A00 = param0qi;
  }
  
  public static void A00(03o param03o) {
    Set<?> set;
    Iterator iterator;
    0jQ 0jQ = 0jQ.A00();
    StringBuilder stringBuilder = 001.A0s();
    stringBuilder.append("[");
    synchronized (03r.A00) {
      HashSet<?> hashSet = new HashSet(set);
      iterator = Collections.unmodifiableSet(hashSet).iterator();
      while (iterator.hasNext()) {
        stringBuilder.append(((0hr)iterator.next()).A01.replaceAll(",", "_"));
        stringBuilder.append(",");
      } 
      stringBuilder.append("]");
      0jQ.DXk(0qV.AA1, stringBuilder.toString().replace(",]", "]"));
      0qi 0qi1 = param03o.A00;
      0qi1.A08(0jQ, 0r7.A01, param03o);
      0qi1.A08(0jQ, 0r7.A02, param03o);
      return;
    } 
  }
  
  public final 0sj getName() {
    return 0sj.A0X;
  }
  
  public final void start() {
    03r.A01(new 03p(this));
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\03o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */