package X;

import java.util.Arrays;

public final class 03D {
  public int A00 = 0;
  
  public int[] A01 = new int[5];
  
  public String[] A02 = new String[10];
  
  public volatile boolean A03;
  
  public void addData(String paramString1, String paramString2, int paramInt) {
    if (!this.A03) {
      int i = this.A00;
      int[] arrayOfInt = this.A01;
      int j = arrayOfInt.length;
      if (i >= j) {
        i = j + (j >> 1);
        this.A01 = Arrays.copyOf(arrayOfInt, i);
        this.A02 = Arrays.<String>copyOf(this.A02, i * 2);
      } 
      i = this.A00;
      j = i * 2;
      String[] arrayOfString = this.A02;
      arrayOfString[j] = paramString1;
      arrayOfString[j + 1] = paramString2;
      this.A01[i] = paramInt;
      this.A00 = i + 1;
      return;
    } 
    throw 001.A0S("Attempted to modify locked instance of PointData");
  }
  
  public final boolean equals(Object paramObject) {
    int j;
    if (paramObject instanceof 03D) {
      paramObject = paramObject;
      j = this.A00;
      if (j == ((03D)paramObject).A00) {
        for (int k = 0; k < j * 2; k++) {
          String str1 = this.A02[k];
          String str2 = ((03D)paramObject).A02[k];
          if (str1 == null) {
            if (str2 != null)
              return false; 
          } else if (!str1.equals(str2)) {
            return false;
          } 
        } 
      } else {
        return false;
      } 
    } else {
      return false;
    } 
    int i = 0;
    while (i < j) {
      if (this.A01[i] == ((03D)paramObject).A01[i]) {
        i++;
        continue;
      } 
      return false;
    } 
    return true;
  }
  
  public final int hashCode() {
    int k;
    int m;
    int n = this.A00;
    byte b = 0;
    int i = 31;
    int j = 0;
    while (true) {
      k = i;
      m = b;
      if (j < n * 2) {
        String str = this.A02[j];
        k = i;
        if (str != null)
          k = i * 31 + str.hashCode(); 
        j++;
        i = k;
        continue;
      } 
      break;
    } 
    while (m < n) {
      k = k * 31 + this.A01[m];
      m++;
    } 
    return k;
  }
  
  public final String toString() {
    int k = this.A00;
    int i = 0;
    if (k == 1 && this.A01[0] == 1) {
      String[] arrayOfString = this.A02;
      if ("__key".equals(arrayOfString[0]))
        return arrayOfString[1]; 
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append('{');
    int j = 0;
    while (i < k) {
      stringBuilder.append('"');
      String[] arrayOfString = this.A02;
      stringBuilder.append(arrayOfString[j]);
      stringBuilder.append("\":\"");
      stringBuilder.append(arrayOfString[j + 1]);
      stringBuilder.append("\",");
      j += 2;
      i++;
    } 
    stringBuilder.replace(stringBuilder.length() - 1, stringBuilder.length(), "}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\03D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */