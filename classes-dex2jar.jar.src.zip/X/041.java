package X;

public abstract class 041 {
  public abstract String A01();
  
  public void A02(Object paramObject1, Object paramObject2, Object paramObject3, String paramString1, String paramString2) {}
  
  public void A03(Object paramObject1, Object paramObject2, String paramString1, String paramString2) {}
  
  public void A04(Object paramObject, String paramString1, String paramString2) {}
  
  public void A05(String paramString1, String paramString2) {}
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\041.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */