package X;

import java.nio.charset.Charset;

public abstract class 03R {
  public static final Charset A00;
  
  public static final Charset A01;
  
  public static final Charset A02;
  
  public static final Charset A03;
  
  public static final Charset A04;
  
  public static final Charset A05;
  
  static {
    Charset charset = Charset.forName("UTF-8");
    16F.A0A(charset);
    A05 = charset;
    charset = Charset.forName("UTF-16");
    16F.A0A(charset);
    A02 = charset;
    charset = Charset.forName("UTF-16BE");
    16F.A0A(charset);
    A03 = charset;
    charset = Charset.forName("UTF-16LE");
    16F.A0A(charset);
    A04 = charset;
    charset = Charset.forName("US-ASCII");
    16F.A0A(charset);
    A01 = charset;
    charset = Charset.forName("ISO-8859-1");
    16F.A0A(charset);
    A00 = charset;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\03R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */