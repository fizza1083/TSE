package X;

import com.facebook.common.stringformat.StringFormatUtil;
import java.io.File;
import java.io.IOException;

public final class 00H extends File {
  public final 00D mLocationScope;
  
  public 00H(00D param00D, File paramFile, boolean paramBoolean) {}
  
  public 00H(00D param00D, String paramString) {}
  
  public final boolean A00(boolean paramBoolean) {
    if (paramBoolean) {
      String str = this.mLocationScope.A00;
      File file = new File(str);
      if (file.exists()) {
        if (!file.isDirectory())
          throw 001.A0c(StringFormatUtil.formatStrLocaleSafe("FileLocationScope should contain a directory path but its path \n%s\n is not.", str)); 
      } else {
        throw 001.A0c(StringFormatUtil.formatStrLocaleSafe("FileLocationScope's path \n%s\n does not exist.", str));
      } 
    } 
    00D 00D1 = this.mLocationScope;
    try {
      String str = 00D1.A00;
      boolean bool = getCanonicalPath().startsWith(str);
      paramBoolean = true;
      return !bool ? false : paramBoolean;
    } catch (IOException iOException) {}
    return false;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00H.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */