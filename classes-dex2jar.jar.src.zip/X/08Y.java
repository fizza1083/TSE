package X;

public final class 08Y implements 08X {
  public Object A00;
  
  public boolean A01 = false;
  
  public final 08X A02;
  
  public 08Y(08X param08X) {
    this.A02 = param08X;
  }
  
  public final Object get() {
    if (!this.A01) {
      this.A00 = this.A02.get();
      this.A01 = true;
    } 
    return this.A00;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08Y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */