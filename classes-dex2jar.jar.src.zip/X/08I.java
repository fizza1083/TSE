package X;

import android.database.DataSetObservable;
import android.database.DataSetObserver;
import android.os.Parcelable;
import android.view.View;
import android.view.ViewGroup;

public abstract class 08I {
  public DataSetObserver A00;
  
  public final DataSetObservable A01 = new DataSetObservable();
  
  public float A02(int paramInt) {
    return 1.0F;
  }
  
  public Parcelable A03() {
    return null;
  }
  
  public void A04() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield A00 : Landroid/database/DataSetObserver;
    //   6: astore_1
    //   7: aload_1
    //   8: ifnull -> 15
    //   11: aload_1
    //   12: invokevirtual onChanged : ()V
    //   15: aload_0
    //   16: monitorexit
    //   17: aload_0
    //   18: getfield A01 : Landroid/database/DataSetObservable;
    //   21: invokevirtual notifyChanged : ()V
    //   24: return
    //   25: astore_1
    //   26: aload_0
    //   27: monitorexit
    //   28: aload_1
    //   29: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	25	finally
    //   11	15	25	finally
    //   15	17	25	finally
    //   26	28	25	finally
  }
  
  public void A05(Parcelable paramParcelable, ClassLoader paramClassLoader) {}
  
  public void A06(ViewGroup paramViewGroup) {}
  
  public void A07(ViewGroup paramViewGroup) {}
  
  public int A08(Object paramObject) {
    return -1;
  }
  
  public void A09(ViewGroup paramViewGroup, Object paramObject, int paramInt) {}
  
  public abstract int A0A();
  
  public CharSequence A0B(int paramInt) {
    return null;
  }
  
  public abstract Object A0C(ViewGroup paramViewGroup, int paramInt);
  
  public abstract void A0D(ViewGroup paramViewGroup, Object paramObject, int paramInt);
  
  public abstract boolean A0E(View paramView, Object paramObject);
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08I.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */