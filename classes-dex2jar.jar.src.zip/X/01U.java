package X;

import java.util.List;

public abstract class 01U extends 01V {
  public static final List A00 = 001.A0y();
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01U.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */