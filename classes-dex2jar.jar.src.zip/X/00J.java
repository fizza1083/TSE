package X;

import android.content.Context;
import android.util.Log;
import com.facebook.common.dextricks.DexStore;
import com.facebook.common.dextricks.MultiDexClassLoader;
import com.facebook.common.dextricks.fallback.FallbackDexLoader;
import java.io.IOException;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public final class 00J extends FallbackDexLoader {
  public static 00J A08;
  
  public final Context A00;
  
  public final 00G A01;
  
  public final Object A02 = 001.A0W();
  
  public final ThreadLocal A03 = new ThreadLocal();
  
  public final ThreadLocal A04 = new 00L(this);
  
  public final Set A05 = 001.A12();
  
  public volatile 14q A06;
  
  public volatile boolean A07 = false;
  
  public 00J(Context paramContext, 14q param14q) {
    Context context = paramContext.getApplicationContext();
    if (context != null)
      paramContext = context; 
    this.A00 = paramContext;
    this.A01 = 00G1;
    this.A06 = param14q;
  }
  
  public static 00J A00(Context paramContext, 14q param14q) {
    // Byte code:
    //   0: ldc X/00J
    //   2: monitorenter
    //   3: getstatic X/00J.A08 : LX/00J;
    //   6: astore_3
    //   7: aload_3
    //   8: astore_2
    //   9: aload_3
    //   10: ifnonnull -> 27
    //   13: new X/00J
    //   16: dup
    //   17: aload_0
    //   18: aload_1
    //   19: invokespecial <init> : (Landroid/content/Context;LX/14q;)V
    //   22: astore_2
    //   23: aload_2
    //   24: putstatic X/00J.A08 : LX/00J;
    //   27: aload_2
    //   28: aload_1
    //   29: putfield A06 : LX/14q;
    //   32: getstatic X/00J.A08 : LX/00J;
    //   35: putstatic com/facebook/common/dextricks/fallback/FallbackDexLoader.A00 : Lcom/facebook/common/dextricks/fallback/FallbackDexLoader;
    //   38: getstatic X/00J.A08 : LX/00J;
    //   41: astore_0
    //   42: ldc X/00J
    //   44: monitorexit
    //   45: aload_0
    //   46: areturn
    //   47: astore_0
    //   48: ldc X/00J
    //   50: monitorexit
    //   51: aload_0
    //   52: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	47	finally
    //   13	27	47	finally
    //   27	42	47	finally
  }
  
  private void A01(String paramString1, String paramString2) {
    if (!this.A07) {
      Log.w("AppModuleFallbackLoader", 0mt.A00("Flag is off, skipping doVerboseLongtailLoadReport.", new Object[0]));
      return;
    } 
    14q 14q1 = this.A06;
    if (14q1 != null) {
      String str2;
      String str1;
      String str3;
      if (paramString1.startsWith("X.")) {
        str2 = "unsymbolicated";
      } else {
        str2 = paramString1;
      } 
      String str4 = 0XK.A0b("longtail_report:class=", str2);
      ClassLoader classLoader = 001.A0M(this).getParent();
      if (classLoader instanceof MultiDexClassLoader) {
        str3 = 0XK.A0b("MDCL Dump: ", ((MultiDexClassLoader)classLoader).verboseDescription());
      } else {
        str3 = "Not using MultiDexClassLoader!";
      } 
      try {
        Context context = this.A00;
        DexStore dexStore = DexStore.findOpened(00A.A00(context).A03("longtail", 00E.A00().A03("longtail")));
        if (dexStore == null) {
          str1 = "Could not find longtail dex store!";
        } else {
          Map map = dexStore.getDiagnostics((Context)str1);
          StringBuilder stringBuilder = 001.A0v("longtail dex diagnostics:\n");
          Iterator iterator = 001.A16(map);
          while (iterator.hasNext()) {
            Map.Entry entry = 001.A1A(iterator);
            stringBuilder.append(0XK.A11(001.A0r(entry), "|", 001.A0q(entry), "\n"));
          } 
          String str = stringBuilder.toString();
        } 
      } catch (IOException iOException) {
        str1 = "Could not getLongtailDexDiagnostics!";
      } 
      paramString1 = 0XK.A19(paramString1, "|", paramString2, "|", str3, "|", str1);
      Log.w("AppModuleFallbackLoader", 0mt.A00("longtail report %s", new Object[] { paramString1 }));
      01O 01O = (01O)14q1.get();
      08V 08V = 08U.A01(str4, paramString1);
      08V.A00 = 1;
      01O.E59(new 08U(08V));
      return;
    } 
  }
  
  private void A02(String paramString1, String paramString2, String paramString3) {
    14q 14q1 = this.A06;
    if (14q1 != null && !paramString2.endsWith(".Canary")) {
      String str;
      if (paramString2.startsWith("X.")) {
        str = "unsymbolicated";
      } else {
        str = paramString2;
      } 
      Locale locale = Locale.US;
      paramString1 = String.format(locale, "unloaded_app_module=%s:class=%s", new Object[] { paramString1, str });
      paramString2 = String.format(locale, "class=%s, load_result=%s", new Object[] { paramString2, paramString3 });
      01O 01O = (01O)14q1.get();
      08V 08V = 08U.A01(paramString1, paramString2);
      08V.A06 = true;
      01O.E59(new 08U(08V));
    } 
  }
  
  public final boolean A03(String paramString1, String paramString2, Throwable paramThrowable) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: invokestatic currentThread : ()Ljava/lang/Thread;
    //   5: invokevirtual getId : ()J
    //   8: lstore #7
    //   10: aload_0
    //   11: getfield A05 : Ljava/util/Set;
    //   14: lload #7
    //   16: invokestatic valueOf : (J)Ljava/lang/Long;
    //   19: invokeinterface contains : (Ljava/lang/Object;)Z
    //   24: istore #9
    //   26: aload_0
    //   27: monitorexit
    //   28: iload #9
    //   30: ifne -> 71
    //   33: aload_0
    //   34: getfield A00 : Landroid/content/Context;
    //   37: invokestatic A00 : (Landroid/content/Context;)Z
    //   40: ifeq -> 71
    //   43: aload_0
    //   44: getfield A03 : Ljava/lang/ThreadLocal;
    //   47: astore_3
    //   48: aload_3
    //   49: invokevirtual get : ()Ljava/lang/Object;
    //   52: checkcast java/lang/String
    //   55: astore #10
    //   57: aload #10
    //   59: ifnull -> 73
    //   62: aload #10
    //   64: aload_1
    //   65: invokevirtual equals : (Ljava/lang/Object;)Z
    //   68: ifeq -> 73
    //   71: iconst_0
    //   72: ireturn
    //   73: aload_3
    //   74: aload_1
    //   75: invokevirtual set : (Ljava/lang/Object;)V
    //   78: aload_2
    //   79: astore_3
    //   80: aload_2
    //   81: ifnonnull -> 89
    //   84: aload_1
    //   85: invokestatic A0R : (Ljava/lang/String;)Ljava/lang/String;
    //   88: astore_3
    //   89: iconst_0
    //   90: istore #5
    //   92: iconst_0
    //   93: istore #6
    //   95: aload_3
    //   96: ifnull -> 71
    //   99: ldc_w 'UNAVAILABLE'
    //   102: astore #10
    //   104: aload #10
    //   106: astore_2
    //   107: iload #5
    //   109: istore #4
    //   111: aload_3
    //   112: astore #11
    //   114: aload_0
    //   115: getfield A02 : Ljava/lang/Object;
    //   118: astore #13
    //   120: aload #10
    //   122: astore_2
    //   123: iload #5
    //   125: istore #4
    //   127: aload_3
    //   128: astore #11
    //   130: aload #13
    //   132: monitorenter
    //   133: aload #10
    //   135: astore #11
    //   137: iload #6
    //   139: istore #5
    //   141: aload_3
    //   142: astore #12
    //   144: invokestatic A00 : ()LX/00E;
    //   147: astore #14
    //   149: aload #10
    //   151: astore #11
    //   153: iload #6
    //   155: istore #5
    //   157: aload_3
    //   158: astore #12
    //   160: aload #14
    //   162: aload_3
    //   163: invokevirtual A08 : (Ljava/lang/String;)Z
    //   166: ifeq -> 299
    //   169: aload #10
    //   171: astore #11
    //   173: iload #6
    //   175: istore #5
    //   177: aload_3
    //   178: astore #12
    //   180: aload_0
    //   181: getfield A04 : Ljava/lang/ThreadLocal;
    //   184: invokevirtual get : ()Ljava/lang/Object;
    //   187: checkcast java/util/Set
    //   190: astore_2
    //   191: aload #10
    //   193: astore #11
    //   195: iload #6
    //   197: istore #5
    //   199: aload_3
    //   200: astore #12
    //   202: aload_2
    //   203: invokevirtual getClass : ()Ljava/lang/Class;
    //   206: pop
    //   207: aload #10
    //   209: astore #11
    //   211: iload #6
    //   213: istore #5
    //   215: aload_3
    //   216: astore #12
    //   218: aload_2
    //   219: aload_3
    //   220: invokeinterface contains : (Ljava/lang/Object;)Z
    //   225: ifne -> 968
    //   228: aload #10
    //   230: astore #11
    //   232: iload #6
    //   234: istore #5
    //   236: aload_3
    //   237: astore #12
    //   239: ldc 'AppModuleFallbackLoader'
    //   241: ldc_w 'App module %s allowing recheck for %s'
    //   244: iconst_2
    //   245: anewarray java/lang/Object
    //   248: dup
    //   249: iconst_0
    //   250: aload_3
    //   251: aastore
    //   252: dup
    //   253: iconst_1
    //   254: aload_1
    //   255: aastore
    //   256: invokestatic A00 : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   259: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   262: pop
    //   263: aload #10
    //   265: astore #11
    //   267: iload #6
    //   269: istore #5
    //   271: aload_3
    //   272: astore #12
    //   274: aload_2
    //   275: aload_3
    //   276: invokeinterface add : (Ljava/lang/Object;)Z
    //   281: pop
    //   282: aload #10
    //   284: astore #11
    //   286: iload #6
    //   288: istore #5
    //   290: aload_3
    //   291: astore #12
    //   293: aload #13
    //   295: monitorexit
    //   296: goto -> 1088
    //   299: aload #10
    //   301: astore_2
    //   302: aload_3
    //   303: invokestatic A01 : (Ljava/lang/String;)Ljava/lang/Integer;
    //   306: astore #11
    //   308: aload #10
    //   310: astore_2
    //   311: aload #11
    //   313: getstatic X/0Xy.A01 : Ljava/lang/Integer;
    //   316: if_acmpeq -> 1171
    //   319: aload #10
    //   321: astore_2
    //   322: getstatic X/0Xy.A0C : Ljava/lang/Integer;
    //   325: astore #12
    //   327: iconst_0
    //   328: istore #4
    //   330: aload #11
    //   332: aload #12
    //   334: if_acmpne -> 340
    //   337: goto -> 1171
    //   340: aload #10
    //   342: astore_2
    //   343: aload_3
    //   344: invokestatic A00 : (Ljava/lang/String;)I
    //   347: istore #5
    //   349: aload #10
    //   351: astore_2
    //   352: aload #14
    //   354: iload #5
    //   356: invokestatic A01 : (LX/00E;I)Ljava/lang/Integer;
    //   359: astore #11
    //   361: iload #4
    //   363: ifne -> 432
    //   366: aload #10
    //   368: astore_2
    //   369: aload #11
    //   371: getstatic X/0Xy.A0C : Ljava/lang/Integer;
    //   374: if_acmpeq -> 432
    //   377: aload #10
    //   379: astore_2
    //   380: aload #11
    //   382: getstatic X/0Xy.A00 : Ljava/lang/Integer;
    //   385: if_acmpeq -> 432
    //   388: aload #10
    //   390: astore_2
    //   391: ldc 'AppModuleFallbackLoader'
    //   393: ldc_w 'App module %s is unavailable (download state = %s). Class load will fail for %s.'
    //   396: iconst_3
    //   397: anewarray java/lang/Object
    //   400: dup
    //   401: iconst_0
    //   402: aload_3
    //   403: aastore
    //   404: dup
    //   405: iconst_1
    //   406: aload #11
    //   408: invokestatic A00 : (Ljava/lang/Integer;)Ljava/lang/String;
    //   411: aastore
    //   412: dup
    //   413: iconst_2
    //   414: aload_1
    //   415: aastore
    //   416: invokestatic A00 : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   419: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   422: pop
    //   423: aload #10
    //   425: astore_2
    //   426: aload #13
    //   428: monitorexit
    //   429: goto -> 939
    //   432: aload #10
    //   434: astore_2
    //   435: aload_0
    //   436: getfield A01 : LX/00G;
    //   439: aload_3
    //   440: invokevirtual A03 : (Ljava/lang/String;)V
    //   443: ldc_w 'LOAD_SUCCESS'
    //   446: astore #12
    //   448: aload #12
    //   450: astore_2
    //   451: ldc 'AppModuleFallbackLoader'
    //   453: ldc_w 'Loaded app module %s for %s'
    //   456: iconst_2
    //   457: anewarray java/lang/Object
    //   460: dup
    //   461: iconst_0
    //   462: aload_3
    //   463: aastore
    //   464: dup
    //   465: iconst_1
    //   466: aload_1
    //   467: aastore
    //   468: invokestatic A00 : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   471: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   474: pop
    //   475: aload #12
    //   477: astore_2
    //   478: aload_0
    //   479: getfield A04 : Ljava/lang/ThreadLocal;
    //   482: invokevirtual get : ()Ljava/lang/Object;
    //   485: checkcast java/util/Set
    //   488: astore #10
    //   490: aload #12
    //   492: astore_2
    //   493: aload #10
    //   495: invokevirtual getClass : ()Ljava/lang/Class;
    //   498: pop
    //   499: aload #12
    //   501: astore_2
    //   502: aload #10
    //   504: aload_3
    //   505: invokeinterface add : (Ljava/lang/Object;)Z
    //   510: pop
    //   511: aload #12
    //   513: astore_2
    //   514: ldc 'longtail'
    //   516: aload_3
    //   517: invokevirtual equals : (Ljava/lang/Object;)Z
    //   520: istore #9
    //   522: iload #9
    //   524: ifeq -> 1058
    //   527: aload #12
    //   529: astore_2
    //   530: aload_0
    //   531: aload_1
    //   532: ldc_w 'LOAD_SUCCESS'
    //   535: invokespecial A01 : (Ljava/lang/String;Ljava/lang/String;)V
    //   538: aload #12
    //   540: astore_2
    //   541: invokestatic A00 : ()LX/00E;
    //   544: astore #11
    //   546: aload #12
    //   548: astore_2
    //   549: aload #11
    //   551: monitorenter
    //   552: aconst_null
    //   553: astore_2
    //   554: aload_2
    //   555: astore #10
    //   557: iload #5
    //   559: bipush #-3
    //   561: if_icmpeq -> 621
    //   564: aload_2
    //   565: astore #10
    //   567: iload #5
    //   569: bipush #-2
    //   571: if_icmpeq -> 621
    //   574: aload_2
    //   575: astore #10
    //   577: iload #5
    //   579: iconst_m1
    //   580: if_icmpeq -> 621
    //   583: aload_2
    //   584: astore #10
    //   586: iload #5
    //   588: invokestatic A02 : (I)Z
    //   591: ifeq -> 621
    //   594: aload #11
    //   596: getfield A06 : [LX/00F;
    //   599: iload #5
    //   601: aaload
    //   602: astore #10
    //   604: goto -> 621
    //   607: astore #10
    //   609: aload #12
    //   611: astore_2
    //   612: aload #11
    //   614: monitorexit
    //   615: aload #12
    //   617: astore_2
    //   618: aload #10
    //   620: athrow
    //   621: aload #12
    //   623: astore_2
    //   624: aload #11
    //   626: monitorexit
    //   627: aload #10
    //   629: ifnull -> 1058
    //   632: aload #12
    //   634: astore_2
    //   635: getstatic com/facebook/common/dextricks/classid/ClassId.sInitialized : Z
    //   638: ifeq -> 1058
    //   641: aload #12
    //   643: astore_2
    //   644: getstatic X/0EF.A00 : Z
    //   647: ifne -> 1058
    //   650: aload #12
    //   652: astore_2
    //   653: aload #10
    //   655: getfield A00 : [Ldalvik/system/DexFile;
    //   658: astore #11
    //   660: iconst_0
    //   661: istore #5
    //   663: aload #11
    //   665: ifnull -> 746
    //   668: aload #12
    //   670: astore_2
    //   671: ldc_w X/0EF
    //   674: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   677: astore #11
    //   679: iconst_0
    //   680: istore #4
    //   682: aload #11
    //   684: ifnull -> 1177
    //   687: aload #12
    //   689: astore_2
    //   690: aload #11
    //   692: instanceof com/facebook/common/dextricks/DexFileAccessLoggingClassLoader
    //   695: ifeq -> 733
    //   698: aload #12
    //   700: astore_2
    //   701: aload #10
    //   703: getfield A00 : [Ldalvik/system/DexFile;
    //   706: invokestatic A0D : (Ljava/lang/Object;)V
    //   709: aload #12
    //   711: astore_2
    //   712: aload #11
    //   714: checkcast com/facebook/common/dextricks/DexFileAccessLoggingClassLoader
    //   717: aload #10
    //   719: getfield A00 : [Ldalvik/system/DexFile;
    //   722: getstatic X/0EH.A00 : LX/0EH;
    //   725: invokeinterface subscribeToDexFileAccesses : ([Ldalvik/system/DexFile;Lcom/facebook/common/dextricks/DexFileAccessListener;)V
    //   730: iconst_1
    //   731: istore #4
    //   733: aload #12
    //   735: astore_2
    //   736: aload #11
    //   738: invokevirtual getParent : ()Ljava/lang/ClassLoader;
    //   741: astore #11
    //   743: goto -> 682
    //   746: aload #12
    //   748: astore_2
    //   749: ldc_w 'LongtailClassLoadsLogger'
    //   752: ldc_w 'Voltron loader didn't provide any Dex files for the longtail module'
    //   755: invokestatic A0F : (Ljava/lang/String;Ljava/lang/String;)V
    //   758: aload #12
    //   760: astore_2
    //   761: aload #10
    //   763: getfield A01 : [Ljava/lang/String;
    //   766: astore #11
    //   768: aload #11
    //   770: ifnull -> 1194
    //   773: aload #12
    //   775: astore_2
    //   776: aload #11
    //   778: arraylength
    //   779: istore #6
    //   781: aload #12
    //   783: astore_2
    //   784: iload #6
    //   786: newarray int
    //   788: astore #10
    //   790: iload #5
    //   792: istore #4
    //   794: iload #4
    //   796: iload #6
    //   798: if_icmpge -> 846
    //   801: aload #11
    //   803: iload #4
    //   805: aaload
    //   806: astore #14
    //   808: aload #12
    //   810: astore_2
    //   811: aload #10
    //   813: iload #4
    //   815: aload #14
    //   817: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
    //   820: invokestatic getDexSignature : (Ljava/lang/Class;)I
    //   823: iastore
    //   824: goto -> 1185
    //   827: astore #14
    //   829: aload #12
    //   831: astore_2
    //   832: ldc_w 'LongtailClassLoadsLogger'
    //   835: ldc_w 'Couldn't get dex signature for canary class'
    //   838: aload #14
    //   840: invokestatic A0I : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   843: goto -> 1185
    //   846: aload #12
    //   848: astore_2
    //   849: invokestatic A00 : ()LX/0p7;
    //   852: astore #11
    //   854: aload #11
    //   856: ifnull -> 1202
    //   859: aload #12
    //   861: astore_2
    //   862: aload #11
    //   864: new X/0k4
    //   867: dup
    //   868: aload #10
    //   870: invokespecial <init> : ([I)V
    //   873: invokevirtual A01 : (LX/0p8;)V
    //   876: aload #12
    //   878: astore_2
    //   879: iconst_1
    //   880: putstatic X/0EF.A00 : Z
    //   883: goto -> 1058
    //   886: aload #12
    //   888: astore_2
    //   889: ldc_w 'LongtailClassLoadsLogger'
    //   892: aload #10
    //   894: invokestatic A0F : (Ljava/lang/String;Ljava/lang/String;)V
    //   897: goto -> 1058
    //   900: astore #11
    //   902: ldc_w 'LOAD_FAIL'
    //   905: astore #10
    //   907: aload #10
    //   909: astore_2
    //   910: ldc 'AppModuleFallbackLoader'
    //   912: ldc_w 'Failed to load app module %s for %s'
    //   915: iconst_2
    //   916: anewarray java/lang/Object
    //   919: dup
    //   920: iconst_0
    //   921: aload_3
    //   922: aastore
    //   923: dup
    //   924: iconst_1
    //   925: aload_1
    //   926: aastore
    //   927: invokestatic A00 : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   930: aload #11
    //   932: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   935: pop
    //   936: goto -> 423
    //   939: ldc 'longtail'
    //   941: aload_3
    //   942: invokevirtual equals : (Ljava/lang/Object;)Z
    //   945: ifne -> 71
    //   948: ldc_w 'fb4a_stories_editor'
    //   951: aload_3
    //   952: invokevirtual equals : (Ljava/lang/Object;)Z
    //   955: ifne -> 71
    //   958: aload_0
    //   959: aload_3
    //   960: aload_1
    //   961: aload #10
    //   963: invokespecial A02 : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   966: iconst_0
    //   967: ireturn
    //   968: aload #10
    //   970: astore #11
    //   972: iload #6
    //   974: istore #5
    //   976: aload_3
    //   977: astore #12
    //   979: ldc 'AppModuleFallbackLoader'
    //   981: ldc_w 'App module %s already loaded. Class load will fail for %s'
    //   984: iconst_2
    //   985: anewarray java/lang/Object
    //   988: dup
    //   989: iconst_0
    //   990: aload_3
    //   991: aastore
    //   992: dup
    //   993: iconst_1
    //   994: aload_1
    //   995: aastore
    //   996: invokestatic A00 : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   999: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   1002: pop
    //   1003: aload #10
    //   1005: astore #11
    //   1007: iload #6
    //   1009: istore #5
    //   1011: aload_3
    //   1012: astore #12
    //   1014: ldc 'longtail'
    //   1016: aload_3
    //   1017: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1020: ifeq -> 1042
    //   1023: aload #10
    //   1025: astore #11
    //   1027: iload #6
    //   1029: istore #5
    //   1031: aload_3
    //   1032: astore #12
    //   1034: aload_0
    //   1035: aload_1
    //   1036: ldc_w 'UNAVAILABLE'
    //   1039: invokespecial A01 : (Ljava/lang/String;Ljava/lang/String;)V
    //   1042: aload #10
    //   1044: astore #11
    //   1046: iload #6
    //   1048: istore #5
    //   1050: aload_3
    //   1051: astore #12
    //   1053: aload #13
    //   1055: monitorexit
    //   1056: iconst_0
    //   1057: ireturn
    //   1058: aload #12
    //   1060: astore_2
    //   1061: aload #13
    //   1063: monitorexit
    //   1064: iload #9
    //   1066: ifne -> 1088
    //   1069: ldc_w 'fb4a_stories_editor'
    //   1072: aload_3
    //   1073: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1076: ifne -> 1088
    //   1079: aload_0
    //   1080: aload_3
    //   1081: aload_1
    //   1082: ldc_w 'LOAD_SUCCESS'
    //   1085: invokespecial A02 : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   1088: iconst_1
    //   1089: ireturn
    //   1090: astore #10
    //   1092: iconst_1
    //   1093: istore #4
    //   1095: goto -> 1110
    //   1098: astore #10
    //   1100: aload #12
    //   1102: astore_3
    //   1103: iload #5
    //   1105: istore #4
    //   1107: aload #11
    //   1109: astore_2
    //   1110: aload_2
    //   1111: astore #11
    //   1113: iload #4
    //   1115: istore #5
    //   1117: aload_3
    //   1118: astore #12
    //   1120: aload #13
    //   1122: monitorexit
    //   1123: aload_3
    //   1124: astore #11
    //   1126: aload #10
    //   1128: athrow
    //   1129: astore_3
    //   1130: iload #4
    //   1132: ifeq -> 1164
    //   1135: ldc 'longtail'
    //   1137: aload #11
    //   1139: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1142: ifne -> 1164
    //   1145: ldc_w 'fb4a_stories_editor'
    //   1148: aload #11
    //   1150: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1153: ifne -> 1164
    //   1156: aload_0
    //   1157: aload #11
    //   1159: aload_1
    //   1160: aload_2
    //   1161: invokespecial A02 : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   1164: aload_3
    //   1165: athrow
    //   1166: astore_1
    //   1167: aload_0
    //   1168: monitorexit
    //   1169: aload_1
    //   1170: athrow
    //   1171: iconst_1
    //   1172: istore #4
    //   1174: goto -> 340
    //   1177: iload #4
    //   1179: ifeq -> 758
    //   1182: goto -> 876
    //   1185: iload #4
    //   1187: iconst_1
    //   1188: iadd
    //   1189: istore #4
    //   1191: goto -> 794
    //   1194: ldc_w 'No canary class info in voltron metadata'
    //   1197: astore #10
    //   1199: goto -> 886
    //   1202: ldc_w 'Couldn't install the PluginClassLoader'
    //   1205: astore #10
    //   1207: goto -> 886
    // Exception table:
    //   from	to	target	type
    //   2	26	1166	finally
    //   114	120	1129	finally
    //   130	133	1129	finally
    //   144	149	1098	finally
    //   160	169	1098	finally
    //   180	191	1098	finally
    //   202	207	1098	finally
    //   218	228	1098	finally
    //   239	263	1098	finally
    //   274	282	1098	finally
    //   293	296	1098	finally
    //   302	308	1090	finally
    //   311	319	1090	finally
    //   322	327	1090	finally
    //   343	349	1090	finally
    //   352	361	1090	finally
    //   369	377	1090	finally
    //   380	388	1090	finally
    //   391	423	1090	finally
    //   426	429	1090	finally
    //   435	443	900	java/io/IOException
    //   435	443	1090	finally
    //   451	475	900	java/io/IOException
    //   451	475	1090	finally
    //   478	490	900	java/io/IOException
    //   478	490	1090	finally
    //   493	499	900	java/io/IOException
    //   493	499	1090	finally
    //   502	511	900	java/io/IOException
    //   502	511	1090	finally
    //   514	522	900	java/io/IOException
    //   514	522	1090	finally
    //   530	538	900	java/io/IOException
    //   530	538	1090	finally
    //   541	546	900	java/io/IOException
    //   541	546	1090	finally
    //   549	552	900	java/io/IOException
    //   549	552	1090	finally
    //   586	604	607	finally
    //   612	615	900	java/io/IOException
    //   612	615	1090	finally
    //   618	621	900	java/io/IOException
    //   618	621	1090	finally
    //   624	627	900	java/io/IOException
    //   624	627	1090	finally
    //   635	641	900	java/io/IOException
    //   635	641	1090	finally
    //   644	650	900	java/io/IOException
    //   644	650	1090	finally
    //   653	660	900	java/io/IOException
    //   653	660	1090	finally
    //   671	679	900	java/io/IOException
    //   671	679	1090	finally
    //   690	698	900	java/io/IOException
    //   690	698	1090	finally
    //   701	709	900	java/io/IOException
    //   701	709	1090	finally
    //   712	730	900	java/io/IOException
    //   712	730	1090	finally
    //   736	743	900	java/io/IOException
    //   736	743	1090	finally
    //   749	758	900	java/io/IOException
    //   749	758	1090	finally
    //   761	768	900	java/io/IOException
    //   761	768	1090	finally
    //   776	781	900	java/io/IOException
    //   776	781	1090	finally
    //   784	790	900	java/io/IOException
    //   784	790	1090	finally
    //   811	824	827	java/lang/ClassNotFoundException
    //   811	824	900	java/io/IOException
    //   811	824	1090	finally
    //   832	843	900	java/io/IOException
    //   832	843	1090	finally
    //   849	854	900	java/io/IOException
    //   849	854	1090	finally
    //   862	876	900	java/io/IOException
    //   862	876	1090	finally
    //   879	883	900	java/io/IOException
    //   879	883	1090	finally
    //   889	897	900	java/io/IOException
    //   889	897	1090	finally
    //   910	936	1090	finally
    //   979	1003	1098	finally
    //   1014	1023	1098	finally
    //   1034	1042	1098	finally
    //   1053	1056	1098	finally
    //   1061	1064	1090	finally
    //   1120	1123	1098	finally
    //   1126	1129	1129	finally
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00J.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */