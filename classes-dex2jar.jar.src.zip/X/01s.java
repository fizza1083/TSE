package X;

import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ConcurrentModificationException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

public final class 01s implements 01t {
  public final Map A00 = new HashMap<Object, Object>(4);
  
  public volatile boolean A01 = false;
  
  public volatile boolean A02 = false;
  
  public 01s(0jZ param0jZ) {}
  
  private 01v A00(Map paramMap) {
    01v<String> 01v = new 01v();
    0jZ 0jZ1 = this.A03;
    synchronized (0jZ1.A03) {
      if (this.A02) {
        Map map = 0jZ1.A05;
        01v.addAll(map.keySet());
        map.clear();
      } 
      for (Map.Entry entry : paramMap.entrySet()) {
        String str = (String)entry.getKey();
        entry = (Map.Entry)entry.getValue();
        if (entry == 0jZ.A0D) {
          0jZ1.A05.remove(str);
        } else {
          entry.getClass();
          Map<String, Map.Entry> map = 0jZ1.A05;
          if (!entry.equals(map.get(str))) {
            map.put(str, entry);
          } else {
            continue;
          } 
        } 
        01v.add(str);
      } 
      AtomicBoolean atomicBoolean = 0jZ1.A08;
      boolean bool1 = 01v.isEmpty();
      boolean bool = false;
      if (!bool1)
        bool = true; 
      atomicBoolean.compareAndSet(false, bool);
      this.A02 = false;
      paramMap.clear();
      return 01v;
    } 
  }
  
  private void A01() {
    if (!this.A01)
      return; 
    throw new ConcurrentModificationException("Editors shouldn't be modified during commit!");
  }
  
  private final void A02() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: iconst_0
    //   4: putfield A01 : Z
    //   7: aload_0
    //   8: monitorexit
    //   9: return
    //   10: astore_1
    //   11: aload_0
    //   12: monitorexit
    //   13: aload_1
    //   14: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	10	finally
  }
  
  public static boolean A03(01s param01s) {
    0jZ 0jZ1 = param01s.A03;
    AtomicBoolean atomicBoolean = 0jZ1.A08;
    if (atomicBoolean.get())
      synchronized (0jZ1.A03) {
        atomicBoolean.set(false);
        HashMap<Object, Object> hashMap = new HashMap<Object, Object>(0jZ1.A05);
        try {
          0pS 0pS = 0jZ1.A02;
          null = 0pS.A01.get();
          File file = File.createTempFile(0XK.A0b(null.getName(), "."), ".tmp", null.getParentFile());
          Object object = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file), 512));
          try {
            object.writeByte(1);
            object.writeInt(hashMap.size());
            for (Map.Entry<Object, Object> entry : hashMap.entrySet()) {
              byte b;
              String str = (String)entry.getKey();
              entry = (Map.Entry<Object, Object>)entry.getValue();
              if (entry instanceof Boolean) {
                b = 0;
              } else if (entry instanceof Integer) {
                b = 1;
              } else if (entry instanceof Long) {
                b = 2;
              } else if (entry instanceof Float) {
                b = 3;
              } else if (entry instanceof Double) {
                b = 4;
              } else if (entry instanceof String) {
                b = 5;
              } else if (entry instanceof Set) {
                b = 6;
              } else {
                null = 001.A0s();
                002.A0s(entry, "Unsupported type: ", (StringBuilder)null);
                throw 001.A0O(null.toString());
              } 
              object.write(b);
              object.writeUTF(str);
              switch (b) {
                case 5:
                  object.writeUTF((String)entry);
                  continue;
                case 4:
                  object.writeDouble(((Double)entry).doubleValue());
                  continue;
                case 3:
                  object.writeFloat(((Float)entry).floatValue());
                  continue;
                case 2:
                  object.writeLong(((Long)entry).longValue());
                  continue;
                case 1:
                  object.writeInt(((Integer)entry).intValue());
                  continue;
                case 0:
                  object.writeBoolean(((Boolean)entry).booleanValue());
                  continue;
              } 
              Set set = (Set)entry;
              object.writeInt(set.size());
              Iterator<String> iterator = set.iterator();
              while (iterator.hasNext())
                object.writeUTF(iterator.next()); 
            } 
            object.close();
            object = 0pS.A00;
            /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
          } finally {
            null = null;
          } 
          throw null;
        } catch (IOException null) {
          0pd.A0J("LightSharedPreferencesImpl", "Commit to disk failed.", (Throwable)null);
          return false;
        } 
      }  
    return true;
  }
  
  public final 01t AON() {
    A01();
    this.A02 = true;
    return this;
  }
  
  public final boolean APn(int paramInt) {
    // Byte code:
    //   0: iload_1
    //   1: ifeq -> 22
    //   4: invokestatic myLooper : ()Landroid/os/Looper;
    //   7: invokestatic getMainLooper : ()Landroid/os/Looper;
    //   10: if_acmpne -> 22
    //   13: ldc_w 'LightSharedPreferencesImpl'
    //   16: ldc_w 'commit is called on the main thread.'
    //   19: invokestatic A0H : (Ljava/lang/String;Ljava/lang/String;)V
    //   22: aload_0
    //   23: monitorenter
    //   24: aload_0
    //   25: getfield A01 : Z
    //   28: ifne -> 88
    //   31: aload_0
    //   32: iconst_1
    //   33: putfield A01 : Z
    //   36: aload_0
    //   37: getfield A00 : Ljava/util/Map;
    //   40: astore_3
    //   41: aload_0
    //   42: monitorexit
    //   43: aload_0
    //   44: aload_3
    //   45: invokespecial A00 : (Ljava/util/Map;)LX/01v;
    //   48: astore_3
    //   49: aload_3
    //   50: invokevirtual isEmpty : ()Z
    //   53: ifne -> 75
    //   56: aload_0
    //   57: getfield A03 : LX/0jZ;
    //   60: aload_3
    //   61: invokestatic A03 : (LX/0jZ;Ljava/util/Set;)V
    //   64: aload_0
    //   65: invokestatic A03 : (LX/01s;)Z
    //   68: istore_2
    //   69: aload_0
    //   70: invokespecial A02 : ()V
    //   73: iload_2
    //   74: ireturn
    //   75: aload_0
    //   76: invokespecial A02 : ()V
    //   79: iconst_1
    //   80: ireturn
    //   81: astore_3
    //   82: aload_0
    //   83: invokespecial A02 : ()V
    //   86: aload_3
    //   87: athrow
    //   88: ldc_w 'Trying to freeze an editor that is already frozen!'
    //   91: invokestatic A0Z : (Ljava/lang/String;)Ljava/lang/RuntimeException;
    //   94: athrow
    //   95: astore_3
    //   96: aload_0
    //   97: monitorexit
    //   98: aload_3
    //   99: athrow
    // Exception table:
    //   from	to	target	type
    //   24	41	95	finally
    //   43	69	81	finally
    //   88	95	95	finally
  }
  
  public final 01t DXz(String paramString, boolean paramBoolean) {
    A01();
    Map<String, Boolean> map = this.A00;
    paramString.getClass();
    map.put(paramString, Boolean.valueOf(paramBoolean));
    return this;
  }
  
  public final 01t DY3(String paramString, double paramDouble) {
    A01();
    Map<String, Double> map = this.A00;
    paramString.getClass();
    map.put(paramString, Double.valueOf(paramDouble));
    return this;
  }
  
  public final 01t DY9(String paramString, float paramFloat) {
    A01();
    Map<String, Float> map = this.A00;
    paramString.getClass();
    map.put(paramString, Float.valueOf(paramFloat));
    return this;
  }
  
  public final 01t DYB(String paramString, int paramInt) {
    A01();
    Map<String, Integer> map = this.A00;
    paramString.getClass();
    map.put(paramString, Integer.valueOf(paramInt));
    return this;
  }
  
  public final 01t DYE(String paramString, long paramLong) {
    A01();
    Map<String, Long> map = this.A00;
    paramString.getClass();
    map.put(paramString, Long.valueOf(paramLong));
    return this;
  }
  
  public final 01t DYI(String paramString1, String paramString2) {
    Map<String, Object> map;
    A01();
    if (paramString2 == null) {
      map = this.A00;
      paramString1.getClass();
      map.put(paramString1, 0jZ.A0D);
      return this;
    } 
    Map<String, Map<String, Object>> map1 = this.A00;
    paramString1.getClass();
    map1.put(paramString1, map);
    return this;
  }
  
  public final 01t DYM(String paramString, Set paramSet) {
    A01();
    Map<String, Set> map = this.A00;
    paramString.getClass();
    map.put(paramString, paramSet);
    return this;
  }
  
  public final 01t Dce(String paramString) {
    A01();
    Map<String, Object> map = this.A00;
    paramString.getClass();
    map.put(paramString, 0jZ.A0D);
    return this;
  }
  
  public final void apply() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield A01 : Z
    //   6: ifne -> 73
    //   9: aload_0
    //   10: iconst_1
    //   11: putfield A01 : Z
    //   14: aload_0
    //   15: getfield A00 : Ljava/util/Map;
    //   18: astore_1
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_0
    //   22: aload_1
    //   23: invokespecial A00 : (Ljava/util/Map;)LX/01v;
    //   26: astore_1
    //   27: aload_1
    //   28: invokevirtual isEmpty : ()Z
    //   31: ifne -> 61
    //   34: aload_0
    //   35: getfield A03 : LX/0jZ;
    //   38: astore_2
    //   39: aload_2
    //   40: aload_1
    //   41: invokestatic A03 : (LX/0jZ;Ljava/util/Set;)V
    //   44: aload_2
    //   45: getfield A07 : Ljava/util/concurrent/Executor;
    //   48: new X/09x
    //   51: dup
    //   52: aload_0
    //   53: invokespecial <init> : (LX/01s;)V
    //   56: invokeinterface execute : (Ljava/lang/Runnable;)V
    //   61: aload_0
    //   62: invokespecial A02 : ()V
    //   65: return
    //   66: astore_1
    //   67: aload_0
    //   68: invokespecial A02 : ()V
    //   71: aload_1
    //   72: athrow
    //   73: ldc_w 'Trying to freeze an editor that is already frozen!'
    //   76: invokestatic A0Z : (Ljava/lang/String;)Ljava/lang/RuntimeException;
    //   79: athrow
    //   80: astore_1
    //   81: aload_0
    //   82: monitorexit
    //   83: aload_1
    //   84: athrow
    // Exception table:
    //   from	to	target	type
    //   2	19	80	finally
    //   21	61	66	finally
    //   73	80	80	finally
  }
  
  public final boolean commit() {
    return APn(this.A03.A01);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */