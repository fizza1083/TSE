package X;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public final class 08q {
  public static final 08q A02;
  
  public final Map A00;
  
  public final Set A01;
  
  static {
    1AH 1AH = 1AH.A00;
    01o 01o = 01o.A00;
    16F.A0I(01o, "null cannot be cast to non-null type kotlin.collections.Map<K of kotlin.collections.MapsKt__MapsKt.emptyMap, V of kotlin.collections.MapsKt__MapsKt.emptyMap>");
    A02 = new 08q(01o, 1AH);
  }
  
  public 08q(Map paramMap, Set paramSet) {
    this.A01 = paramSet;
    LinkedHashMap linkedHashMap = 001.A18();
    Iterator iterator = 001.A16(paramMap);
    while (iterator.hasNext()) {
      Map.Entry entry = 001.A1A(iterator);
      linkedHashMap.put(entry.getKey(), entry.getValue());
    } 
    this.A00 = linkedHashMap;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */