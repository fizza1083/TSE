package X;

public abstract class 000 {
  public static String A00(int paramInt) {
    switch (paramInt) {
      default:
        return "schema_version";
      case 264:
        return "notification";
      case 263:
        return "network_info";
      case 262:
        return "mobileconfig";
      case 261:
        return "mobile_config";
      case 260:
        return "is_low_memory";
      case 259:
        return "iab_session_id";
      case 258:
        return "friendlyName";
      case 257:
        return "effect_session_id";
      case 256:
        return "connection_state";
      case 255:
        return "com.instagram.barcelona";
      case 254:
        return "com.instagram.android";
      case 253:
        return "com.facebook.work";
      case 252:
        return "com.facebook.stella_debug";
      case 251:
        return "com.facebook.";
      case 250:
        return "com.android.vending";
      case 249:
        return "collapse_key";
      case 248:
        return "client_event";
      case 247:
        return "attempt_number";
      case 246:
        return "application/x-www-form-urlencoded";
      case 245:
        return "android.os.SystemProperties";
      case 244:
        return "android.intent.action.SEND";
      case 243:
        return "android.intent.action.SCREEN_OFF";
      case 242:
        return "android.intent.action.BATTERY_CHANGED";
      case 241:
        return "access_token";
      case 240:
        return "MQTT_SUBSCRIPTION";
      case 239:
        return "ExecutionException";
      case 238:
        return "BEGIN_OBJECT";
      case 237:
        return "4_frame_drop_uncapped";
      case 236:
        return "/sys/devices/system/cpu/present";
      case 235:
        return "wait_time_ms";
      case 234:
        return "universal";
      case 233:
        return "trace_id";
      case 232:
        return "test-keys";
      case 231:
        return "succeeded";
      case 230:
        return "string1";
      case 229:
        return "sso_data";
      case 228:
        return "service_name";
      case 227:
        return "retry_count";
      case 226:
        return "result_code";
      case 225:
        return "required";
      case 224:
        return "request_failed";
      case 223:
        return "report_source";
      case 222:
        return "product_session_id";
      case 221:
        return "package";
      case 220:
        return "null cannot be cast to non-null type java.lang.String";
      case 219:
        return "notification_source";
      case 218:
        return "not_connected";
      case 217:
        return "moduleName";
      case 216:
        return "manufacturer";
      case 215:
        return "lacrima";
      case 214:
        return "is_connected";
      case 213:
        return "importance";
      case 212:
        return "healthstats";
      case 211:
        return "fb4a_stories_editor";
      case 210:
        return "facebook.com";
      case 209:
        return "expect_activity_not_found";
      case 208:
        return "error_count";
      case 207:
        return "display";
      case 206:
        return "device_model";
      case 205:
        return "condition";
      case 204:
        return "com.google.android.gms";
      case 203:
        return "com.facebook.stella";
      case 202:
        return "com.facebook.orca";
      case 201:
        return "com.facebook.bishop";
      case 200:
        return "com.facebook.appmanager";
      case 199:
        return "com.facebook.akira";
      case 198:
        return "com.facebook.adsmanager";
      case 197:
        return "cold_start_mode";
      case 196:
        return "clipboard";
      case 195:
        return "asl_app_in_foreground_v2";
      case 194:
        return "art.gc.gc-time";
      case 193:
        return "art.gc.gc-count";
      case 192:
        return "art.gc.blocking-gc-time";
      case 191:
        return "art.gc.blocking-gc-count";
      case 190:
        return "anr_looper_history";
      case 189:
        return "androidx.lifecycle.BundlableSavedStateRegistry.key";
      case 188:
        return "android.permission.POST_NOTIFICATIONS";
      case 187:
        return "android.permission.ACCESS_NETWORK_STATE";
      case 186:
        return "android.permission.ACCESS_FINE_LOCATION";
      case 185:
        return "analytics";
      case 184:
        return "algorithm";
      case 183:
        return "address";
      case 182:
        return "addSuppressed";
      case 181:
        return "[%d] %s";
      case 180:
        return "Unknown type ";
      case 179:
        return "Unknown message type: ";
      case 178:
        return "This method must be called on behalf of an IPC transaction from binder thread.";
      case 177:
        return "SecurePendingIntent";
      case 176:
        return "SESSION_ID";
      case 175:
        return "SERVER_FETCH";
      case 174:
        return "REMOTE_EXCEPTION";
      case 173:
        return "Profilo";
      case 172:
        return "Negative size: ";
      case 171:
        return "MobileConfig";
      case 170:
        return "Message";
      case 169:
        return "Invalid mode: ";
      case 168:
        return "Infinity";
      case 167:
        return "IN_PROGRESS";
      case 166:
        return "File exists: ";
      case 165:
        return "Error: ";
      case 164:
        return "CURRENT";
      case 163:
        return "882a8490361da98702bf97a021ddc14d";
      case 162:
        return "62f8ce9f74b12f84c123cc23437a4a32";
      case 161:
        return "487.0.0.0.62";
      case 160:
        return "/sys/devices/system/cpu/";
      case 159:
        return "/proc/self/statm";
      case 158:
        return ", tags=";
      case 157:
        return ", source=";
      case 156:
        return ", right=";
      case 155:
        return ", flags=";
      case 154:
        return ", data=";
      case 153:
        return "%s (%s) must not be negative";
      case 152:
        return " position=";
      case 151:
        return " not found";
      case 150:
        return " instead";
      case 149:
        return " filter=";
      case 148:
        return " doesn't exist";
      case 147:
        return "year_class";
      case 146:
        return "workplace.com";
      case 145:
        return "ui_components";
      case 144:
        return "target_tab_name";
      case 143:
        return "startReason";
      case 142:
        return "quicksilver";
      case 141:
        return "product_name";
      case 140:
        return "permissions";
      case 139:
        return "perf_task_clock";
      case 138:
        return "perf_cpu_clock";
      case 137:
        return "others";
      case 136:
        return "oom_score_adj";
      case 135:
        return "onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager.";
      case 134:
        return "null cannot be cast to non-null type kotlin.sequences.Sequence<T of kotlin.sequences.SequencesKt___SequencesKt.filterNotNull>";
      case 133:
        return "null cannot be cast to non-null type android.content.Intent";
      case 132:
        return "null cannot be cast to non-null type android.app.Application";
      case 131:
        return "network_subtype";
      case 130:
        return "native_heap_size_kb";
      case 129:
        return "native_heap_allocated_size_kb";
      case 128:
        return "message_type";
      case 127:
        return "maxSize <= 0";
      case 126:
        return "linkToDeath failed";
      case 125:
        return "java_heap_max_size_kb";
      case 124:
        return "java_heap_allocated_size_kb";
      case 123:
        return "invalid";
      case 122:
        return "interrupted";
      case 121:
        return "input_method";
      case 120:
        return "initial_delay";
      case 119:
        return "image/*";
      case 118:
        return "https://";
      case 117:
        return "google";
      case 116:
        return "font_weight";
      case 115:
        return "error_domain";
      case 114:
        return "disconnected";
      case 113:
        return "device_type";
      case 112:
        return "connected";
      case 111:
        return "com.facebook.wakizashi";
      case 110:
        return "com.facebook.lite";
      case 109:
        return "com.facebook";
      case 108:
        return "cold_start";
      case 107:
        return "client_time";
      case 106:
        return "checkpoint";
      case 105:
        return "call_trigger";
      case 104:
        return "authentication";
      case 103:
        return "attribution_id";
      case 102:
        return "attachment_index";
      case 101:
        return "app_package_name";
      case 100:
        return "app_backgrounded";
      case 99:
        return "android.permission.READ_PHONE_STATE";
      case 98:
        return "android.permission.READ_CALL_LOG";
      case 97:
        return "android.intent.extra.INITIAL_INTENTS";
      case 96:
        return "android.intent.category.LAUNCHER";
      case 95:
        return "Unexpected state: ";
      case 94:
        return "TIMEOUT";
      case 93:
        return "Service disconnected";
      case 92:
        return "Optional.absent()";
      case 91:
        return "Must add a clock to the object pool builder";
      case 90:
        return "Missing ";
      case 89:
        return "List is empty.";
      case 88:
        return "Fragment ";
      case 87:
        return "Exception";
      case 86:
        return "EndToEnd-Test";
      case 85:
        return "Context cannot be null";
      case 84:
        return "Content-Encoding";
      case 83:
        return "Check failed.";
      case 82:
        return "Char sequence is empty.";
      case 81:
        return "Array is empty.";
      case 80:
        return "AppComponentManager";
      case 79:
        return "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
      case 78:
        return "350685531728";
      case 77:
        return "/proc/meminfo";
      case 76:
        return ", instanceKey=";
      case 75:
        return "(null)";
      case 74:
        return " failed";
      case 73:
        return " does not exist";
      case 72:
        return "unreachable";
      case 71:
        return "start_timestamp";
      case 70:
        return "stackTrace";
      case 69:
        return "sso_settings_v2";
      case 68:
        return "short";
      case 67:
        return "session_key";
      case 66:
        return "scroll";
      case 65:
        return "process_name";
      case 64:
        return "native_version_override";
      case 63:
        return "module_name";
      case 62:
        return "http://schemas.android.com/apk/res/android";
      case 61:
        return "effect_id";
      case 60:
        return "connection_quality";
      case 59:
        return "com.instagram.lite";
      case 58:
        return "com.facebook.katana";
      case 57:
        return "camera_session_id";
      case 56:
        return "attempt_count";
      case 55:
        return "asl_session_id";
      case 54:
        return "app_version";
      case 53:
        return "annotation";
      case 52:
        return "android.permission.WRITE_CONTACTS";
      case 51:
        return "android.intent.action.SEND_MULTIPLE";
      case 50:
        return "android.intent.action.MAIN";
      case 49:
        return "android.intent.action.BOOT_COMPLETED";
      case 48:
        return "View ";
      case 47:
        return "SecurityException";
      case 46:
        return "Optional.of(";
      case 45:
        return "No start tag found";
      case 44:
        return "Content-Type";
      case 43:
        return ", state=";
      case 42:
        return " with ";
      case 41:
        return " AND ";
      case 40:
        return "stack_trace";
      case 39:
        return "navigation_module";
      case 38:
        return "long";
      case 37:
        return "inspiration_session_id";
      case 36:
        return "connection_bandwidth";
      case 35:
        return "com.whatsapp";
      case 34:
        return "com.facebook.orca.ACTION_NETWORK_CONNECTIVITY_CHANGED";
      case 33:
        return "com.facebook.messenger";
      case 32:
        return "android.permission.WRITE_EXTERNAL_STORAGE";
      case 31:
        return "android.permission.READ_CALENDAR";
      case 30:
        return "android.permission.ACCESS_COARSE_LOCATION";
      case 29:
        return "android.net.conn.CONNECTIVITY_CHANGE";
      case 28:
        return "Optional.get() cannot be called on an absent value";
      case 27:
        return "Operation is not supported for read-only collection";
      case 26:
        return " and ";
      case 25:
        return "thread_type";
      case 24:
        return "thread_name";
      case 23:
        return "thread_count";
      case 22:
        return "graphql_story_id";
      case 21:
        return "connectivity";
      case 20:
        return "com.oculus.twilight";
      case 19:
        return "com.facebook.workchat";
      case 18:
        return "com.facebook.auth.login";
      case 17:
        return "android.permission.WRITE_CALENDAR";
      case 16:
        return "android.permission.CAMERA";
      case 15:
        return "android.intent.action.USER_PRESENT";
      case 14:
        return "UTF-8 not supported";
      case 13:
        return "Failed requirement.";
      case 12:
        return "An operation is not implemented.";
      case 11:
        return ", reason=";
      case 10:
        return "shared_call_id";
      case 9:
        return "null cannot be cast to non-null type android.net.ConnectivityManager";
      case 8:
        return "android.intent.action.MY_PACKAGE_REPLACED";
      case 7:
        return "android.permission.READ_EXTERNAL_STORAGE";
      case 6:
        return "android.permission.READ_CONTACTS";
      case 5:
        return "android.permission.CALL_PHONE";
      case 4:
        return "null cannot be cast to non-null type android.app.ActivityManager";
      case 3:
        return "android.intent.extra.STREAM";
      case 2:
        return "Nested Switch Binding Exception: ";
      case 1:
        return "android.permission.RECORD_AUDIO";
      case 0:
        break;
    } 
    return "null cannot be cast to non-null type kotlin.Int";
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\000.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */