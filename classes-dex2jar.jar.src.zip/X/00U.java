package X;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public abstract class 00U<E> extends 00V<E> implements List<E>, 16M {
  public final void add(int paramInt, Object paramObject) {
    throw 002.A0b();
  }
  
  public final boolean addAll(int paramInt, Collection paramCollection) {
    throw 002.A0b();
  }
  
  public final boolean equals(Object paramObject) {
    if (paramObject != this)
      if (paramObject instanceof List) {
        paramObject = paramObject;
        16F.A0E(paramObject, 1);
        if (size() == paramObject.size()) {
          paramObject = paramObject.iterator();
          Iterator iterator = super.iterator();
          label10: while (iterator.hasNext()) {
            if (!16F.A0S(iterator.next(), paramObject.next()))
              break label10; 
          } 
        } else {
          return false;
        } 
      } else {
        return false;
      }  
    return true;
  }
  
  public abstract Object get(int paramInt);
  
  public final int hashCode() {
    Iterator iterator = super.iterator();
    int i;
    for (i = 1; iterator.hasNext(); i = i * 31 + 002.A05(iterator.next()));
    return i;
  }
  
  public int indexOf(Object paramObject) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual iterator : ()Ljava/util/Iterator;
    //   4: astore #4
    //   6: iconst_0
    //   7: istore_2
    //   8: aload #4
    //   10: invokeinterface hasNext : ()Z
    //   15: ifeq -> 41
    //   18: iload_2
    //   19: istore_3
    //   20: aload #4
    //   22: invokeinterface next : ()Ljava/lang/Object;
    //   27: aload_1
    //   28: invokestatic A0S : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   31: ifne -> 43
    //   34: iload_2
    //   35: iconst_1
    //   36: iadd
    //   37: istore_2
    //   38: goto -> 8
    //   41: iconst_m1
    //   42: istore_3
    //   43: iload_3
    //   44: ireturn
  }
  
  public Iterator iterator() {
    return new 09u(this);
  }
  
  public int lastIndexOf(Object paramObject) {
    ListIterator listIterator = listIterator(size());
    while (listIterator.hasPrevious()) {
      if (16F.A0S(listIterator.previous(), paramObject))
        return listIterator.nextIndex(); 
    } 
    return -1;
  }
  
  public ListIterator listIterator() {
    return new 159(this, 0);
  }
  
  public ListIterator listIterator(int paramInt) {
    return new 159(this, paramInt);
  }
  
  public final Object remove(int paramInt) {
    throw 002.A0b();
  }
  
  public final Object set(int paramInt, Object paramObject) {
    throw 002.A0b();
  }
  
  public List subList(int paramInt1, int paramInt2) {
    return new 0oh(this, paramInt1, paramInt2);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00U.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */