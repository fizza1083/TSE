package X;

public final class 04o {
  public final String A00;
  
  public 04o(String paramString) {
    this.A00 = paramString;
  }
  
  public static 04o A00(String paramString) {
    return new 04o(paramString);
  }
  
  public final String toString() {
    return 0XK.A0P(this.A00, '<', '>');
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\04o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */