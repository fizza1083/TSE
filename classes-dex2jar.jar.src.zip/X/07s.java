package X;

import android.os.Bundle;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat;
import androidx.viewpager.widget.ViewPager;

public final class 07s extends 07t {
  public 07s(ViewPager paramViewPager) {}
  
  public final void A0V(View paramView, AccessibilityEvent paramAccessibilityEvent) {
    super.A0V(paramView, paramAccessibilityEvent);
    paramAccessibilityEvent.setClassName(ViewPager.class.getName());
    ViewPager viewPager = this.A00;
    08I 08I = viewPager.A0F;
    boolean bool = true;
    if (08I == null || 08I.A0A() <= 1)
      bool = false; 
    paramAccessibilityEvent.setScrollable(bool);
    if (paramAccessibilityEvent.getEventType() == 4096) {
      08I = viewPager.A0F;
      if (08I != null) {
        paramAccessibilityEvent.setItemCount(08I.A0A());
        paramAccessibilityEvent.setFromIndex(viewPager.A04);
        paramAccessibilityEvent.setToIndex(viewPager.A04);
      } 
    } 
  }
  
  public final void A0Y(View paramView, AccessibilityNodeInfoCompat paramAccessibilityNodeInfoCompat) {
    super.A0Y(paramView, paramAccessibilityNodeInfoCompat);
    paramAccessibilityNodeInfoCompat.setClassName(ViewPager.class.getName());
    ViewPager viewPager = this.A00;
    08I 08I = viewPager.A0F;
    boolean bool = true;
    if (08I == null || 08I.A0A() <= 1)
      bool = false; 
    paramAccessibilityNodeInfoCompat.mInfo.setScrollable(bool);
    if (viewPager.canScrollHorizontally(1))
      paramAccessibilityNodeInfoCompat.addAction(4096); 
    if (viewPager.canScrollHorizontally(-1))
      paramAccessibilityNodeInfoCompat.addAction(8192); 
  }
  
  public final boolean A0Z(View paramView, int paramInt, Bundle paramBundle) {
    if (!super.A0Z(paramView, paramInt, paramBundle)) {
      ViewPager viewPager;
      if (paramInt != 4096) {
        if (paramInt == 8192) {
          viewPager = this.A00;
          if (viewPager.canScrollHorizontally(-1)) {
            paramInt = viewPager.A04 - 1;
          } else {
            return false;
          } 
        } else {
          return false;
        } 
      } else {
        viewPager = this.A00;
        if (viewPager.canScrollHorizontally(1)) {
          paramInt = viewPager.A04 + 1;
        } else {
          return false;
        } 
      } 
      viewPager.A0G(paramInt);
    } 
    return true;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */