package X;

import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class 08S {
  public static final ArrayList A00 = 001.A0y();
  
  public static final AtomicInteger A01 = new AtomicInteger();
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08S.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */