package X;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ComponentInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageItemInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.BaseBundle;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public abstract class 08k implements 08l {
  public final 08i A00;
  
  public final 11P A01;
  
  public final Integer A02;
  
  public 08k(08i param08i, 11P param11P, Integer paramInteger) {
    this.A00 = param08i;
    this.A01 = param11P;
    this.A02 = paramInteger;
  }
  
  public static Intent A01(List<Intent> paramList) {
    Intent[] arrayOfIntent = new Intent[001.A07(paramList)];
    for (int i = 0; i < paramList.size() - 1; i = j) {
      int j = i + 1;
      arrayOfIntent[i] = paramList.get(j);
    } 
    Intent intent = Intent.createChooser(paramList.get(0), "Choose an app to launch.");
    intent.putExtra("android.intent.extra.INITIAL_INTENTS", (Parcelable[])arrayOfIntent);
    return intent;
  }
  
  public static String A02(Intent paramIntent) {
    if (paramIntent == null)
      return "null"; 
    StringBuilder stringBuilder = 001.A0s();
    stringBuilder.append("intent(");
    stringBuilder.append("action = ");
    stringBuilder.append(paramIntent.getAction());
    stringBuilder.append(", data= ");
    stringBuilder.append(paramIntent.getData());
    stringBuilder.append(", type= ");
    stringBuilder.append(paramIntent.getType());
    if (paramIntent.getComponent() != null) {
      stringBuilder.append(", component = ");
      stringBuilder.append(paramIntent.getComponent());
    } 
    Bundle bundle = paramIntent.getExtras();
    if (bundle != null) {
      stringBuilder.append(", extras = [");
      Iterator<String> iterator = 001.A13((BaseBundle)bundle);
      while (iterator.hasNext()) {
        String str = iterator.next();
        stringBuilder.append(str);
        stringBuilder.append(" = ");
        stringBuilder.append(bundle.get(str));
        stringBuilder.append(", ");
      } 
      stringBuilder.append("]");
    } 
    return 001.A0l(")", stringBuilder);
  }
  
  public static ArrayList A03(Intent paramIntent, List paramList) {
    ArrayList<Intent> arrayList = 002.A0f(paramList);
    for (PackageItemInfo packageItemInfo : paramList) {
      Intent intent = new Intent(paramIntent);
      intent.setComponent(new ComponentName(packageItemInfo.packageName, packageItemInfo.name));
      intent.setPackage(packageItemInfo.packageName);
      arrayList.add(intent);
    } 
    return arrayList;
  }
  
  public static boolean A04(Context paramContext, Intent paramIntent) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getComponent : ()Landroid/content/ComponentName;
    //   4: astore_2
    //   5: aload_2
    //   6: ifnull -> 20
    //   9: aload_2
    //   10: invokevirtual getPackageName : ()Ljava/lang/String;
    //   13: astore_3
    //   14: aload_3
    //   15: astore_2
    //   16: aload_3
    //   17: ifnonnull -> 33
    //   20: aload_1
    //   21: invokevirtual getPackage : ()Ljava/lang/String;
    //   24: astore_1
    //   25: aload_1
    //   26: astore_2
    //   27: aload_1
    //   28: ifnonnull -> 33
    //   31: iconst_0
    //   32: ireturn
    //   33: aload_0
    //   34: ifnull -> 46
    //   37: aload_2
    //   38: aload_0
    //   39: invokevirtual getPackageName : ()Ljava/lang/String;
    //   42: invokevirtual equals : (Ljava/lang/Object;)Z
    //   45: ireturn
    //   46: ldc 'context is null, did your Fragment destroy activity already?'
    //   48: invokestatic A0O : (Ljava/lang/String;)Ljava/lang/IllegalArgumentException;
    //   51: athrow
  }
  
  public final ArrayList A06(Context paramContext, Intent paramIntent) {
    List<0Gm> list;
    String str2 = paramIntent.getPackage();
    ComponentName componentName = paramIntent.getComponent();
    String str1 = str2;
    if (componentName != null) {
      String str = componentName.getPackageName();
      str1 = str2;
      if (!TextUtils.isEmpty(str))
        str1 = str; 
    } 
    try {
      PackageInfo packageInfo;
      if (!TextUtils.isEmpty(str1)) {
        list = Collections.singletonList(11Q.A02(paramContext, str1, 64));
      } else {
        16F.A0E(paramContext, 0);
        PackageManager packageManager = paramContext.getPackageManager();
        if (Build.VERSION.SDK_INT >= 33) {
          list = packageManager.getInstalledPackages(PackageManager.PackageInfoFlags.of(134217728L));
        } else {
          list = list.getInstalledPackages(134217728);
        } 
        16F.A0D(list);
        ArrayList<0Gm> arrayList2 = 154.A15(list);
        Iterator<PackageInfo> iterator1 = list.iterator();
        while (true) {
          list = arrayList2;
          if (iterator1.hasNext()) {
            packageInfo = iterator1.next();
            16F.A0D(packageInfo);
            arrayList2.add(new 0Gm(packageInfo));
            continue;
          } 
          break;
        } 
      } 
      ArrayList<0Gm> arrayList1 = 002.A0f((List)packageInfo);
      Iterator<0Gm> iterator = packageInfo.iterator();
      while (true) {
        list = arrayList1;
        if (iterator.hasNext()) {
          0Gm 0Gm = iterator.next();
          if (A0B(paramContext, 0Gm))
            arrayList1.add(0Gm); 
          continue;
        } 
        break;
      } 
    } catch (android.content.pm.PackageManager.NameNotFoundException|RuntimeException nameNotFoundException) {
      this.A01.DfI("BaseIntentScope", "Error querying PackageManager.", (Throwable)nameNotFoundException);
      list = 001.A0y();
    } 
    ArrayList<Intent> arrayList = 001.A0z(list.size());
    for (0Gm 0Gm : list) {
      Intent intent = new Intent(paramIntent);
      intent.setPackage(0Gm.A02);
      arrayList.add(intent);
    } 
    return arrayList;
  }
  
  public final List A07(Context paramContext, Intent paramIntent) {
    List<?> list = 11Q.A03(paramContext, paramIntent, 65600);
    if (list == null)
      return Collections.emptyList(); 
    ArrayList<?> arrayList = 001.A0z(1);
    Iterator<?> iterator = list.iterator();
    while (true) {
      ActivityInfo activityInfo;
      list = arrayList;
      if (iterator.hasNext()) {
        activityInfo = ((ResolveInfo)iterator.next()).activityInfo;
        if (activityInfo != null && ((ComponentInfo)activityInfo).applicationInfo != null)
          arrayList.add(activityInfo); 
        continue;
      } 
      return (List)activityInfo;
    } 
  }
  
  public final List A08(Context paramContext, Intent paramIntent) {
    List<?> list = 11Q.A04(paramContext, paramIntent, 65600);
    if (list == null)
      return Collections.emptyList(); 
    ArrayList<?> arrayList = 001.A0z(1);
    Iterator<?> iterator = list.iterator();
    while (true) {
      ServiceInfo serviceInfo;
      list = arrayList;
      if (iterator.hasNext()) {
        serviceInfo = ((ResolveInfo)iterator.next()).serviceInfo;
        if (serviceInfo != null && ((ComponentInfo)serviceInfo).applicationInfo != null)
          arrayList.add(serviceInfo); 
        continue;
      } 
      return (List)serviceInfo;
    } 
  }
  
  public final boolean A09() {
    synchronized (this.A00) {
      Integer integer = null.A00;
      return 001.A1Y(integer, 0Xy.A0N);
    } 
  }
  
  public final boolean A0A() {
    synchronized (this.A00) {
      Integer integer = null.A00;
      return 001.A1Y(integer, 0Xy.A00);
    } 
  }
  
  public abstract boolean A0B(Context paramContext, 0Gm param0Gm);
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */