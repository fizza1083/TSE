package X;

import android.util.Base64;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public abstract class 07f {
  public static final byte[] A00 = new byte[] { 
      48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 
      97, 98, 99, 100, 101, 102 };
  
  public static String A00(String paramString) {
    try {
      return A04(paramString.getBytes("utf-8"), "MD5");
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      throw 001.A0b(unsupportedEncodingException);
    } 
  }
  
  public static String A01(String paramString) {
    try {
      return A04(paramString.getBytes("utf-8"), "SHA-1");
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      throw 001.A0b(unsupportedEncodingException);
    } 
  }
  
  public static String A02(byte[] paramArrayOfbyte) {
    int j = paramArrayOfbyte.length;
    StringBuilder stringBuilder = 001.A0t(j);
    for (int i = 0; i < j; i++) {
      int k = paramArrayOfbyte[i] & 0xFF;
      byte[] arrayOfByte = A00;
      stringBuilder.append((char)arrayOfByte[k >>> 4]);
      stringBuilder.append((char)arrayOfByte[k & 0xF]);
    } 
    return stringBuilder.toString();
  }
  
  public static String A03(byte[] paramArrayOfbyte) {
    try {
      MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
      messageDigest.update(paramArrayOfbyte, 0, paramArrayOfbyte.length);
      return Base64.encodeToString(messageDigest.digest(), 11);
    } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
      throw 001.A0b(noSuchAlgorithmException);
    } 
  }
  
  public static String A04(byte[] paramArrayOfbyte, String paramString) {
    try {
      MessageDigest messageDigest = MessageDigest.getInstance(paramString);
      messageDigest.update(paramArrayOfbyte, 0, paramArrayOfbyte.length);
      return A02(messageDigest.digest());
    } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
      throw 001.A0b(noSuchAlgorithmException);
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      throw 001.A0b(unsupportedEncodingException);
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */