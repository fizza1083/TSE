package X;

public abstract class 04P implements 04R {
  public final 04R A00;
  
  public final 0BQ A01;
  
  public 04P(04R param04R, 0BQ param0BQ) {
    this.A01 = param0BQ;
    04R 04R1 = param04R;
    if (param04R instanceof 04P)
      04R1 = null; 
    this.A00 = 04R1;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\04P.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */