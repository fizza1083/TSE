package X;

public interface 06s extends 0BG {
  Object invoke(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6);
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\06s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */