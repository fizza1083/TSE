package X;

import android.os.ConditionVariable;
import java.util.concurrent.CountDownLatch;

public abstract class 00N {
  public static final ConditionVariable A00 = new ConditionVariable();
  
  public static final ConditionVariable A01 = new ConditionVariable();
  
  public static final CountDownLatch A02 = new CountDownLatch(2);
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00N.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */