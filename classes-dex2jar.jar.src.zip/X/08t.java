package X;

public enum 08t {
  A01, A02, A03, A04, A05, A06, A07, A08, A09;
  
  static {
    08t 08t1 = new 08t("PENALTY_LOG", 0);
    A09 = 08t1;
    08t 08t2 = new 08t("PENALTY_DEATH", 1);
    A08 = 08t2;
    08t 08t3 = new 08t("DETECT_FRAGMENT_REUSE", 2);
    A01 = 08t3;
    08t 08t4 = new 08t("DETECT_FRAGMENT_TAG_USAGE", 3);
    A02 = 08t4;
    08t 08t5 = new 08t("DETECT_WRONG_NESTED_HIERARCHY", 4);
    A07 = 08t5;
    08t 08t6 = new 08t("DETECT_RETAIN_INSTANCE_USAGE", 5);
    A03 = 08t6;
    08t 08t7 = new 08t("DETECT_SET_USER_VISIBLE_HINT", 6);
    A04 = 08t7;
    08t 08t8 = new 08t("DETECT_TARGET_FRAGMENT_USAGE", 7);
    A05 = 08t8;
    08t 08t9 = new 08t("DETECT_WRONG_FRAGMENT_CONTAINER", 8);
    A06 = 08t9;
    A00 = new 08t[] { 08t1, 08t2, 08t3, 08t4, 08t5, 08t6, 08t7, 08t8, 08t9 };
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */