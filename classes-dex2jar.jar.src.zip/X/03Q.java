package X;

public final class 03Q implements Runnable {
  public static final String __redex_internal_original_name = "PeriodicDetector$1";
  
  public 03Q(03O param03O) {}
  
  public final void run() {
    this.A00.onTriggered();
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\03Q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */