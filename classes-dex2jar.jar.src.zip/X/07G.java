package X;

public class 07G extends 07H {
  public 07G(Class paramClass, String paramString1, String paramString2, int paramInt) {
    super(paramClass, 0BH.NO_RECEIVER, paramString1, paramString2, paramInt);
  }
  
  public void A02(Object paramObject1, Object paramObject2) {
    A01();
    throw 0GH.createAndThrow();
  }
  
  public Object get(Object paramObject) {
    BEQ();
    throw 0GH.createAndThrow();
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07G.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */