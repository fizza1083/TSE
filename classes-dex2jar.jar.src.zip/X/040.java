package X;

public final class 040 extends 041 {
  public final String A01() {
    return "";
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\040.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */