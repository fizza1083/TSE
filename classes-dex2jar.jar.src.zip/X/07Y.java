package X;

import java.util.Map;

public final class 07Y implements 03U {
  public final 07Z[] B5B() {
    return 09g.A02().B5B();
  }
  
  public final Map B65() {
    return 09g.A02().B65();
  }
  
  public final 07c[] BJF() {
    return 09g.A02().BJF();
  }
  
  public final boolean Dyz() {
    return 09g.A02().Dyz();
  }
  
  public final boolean Dz2() {
    return 09g.A02().Dz2();
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07Y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */