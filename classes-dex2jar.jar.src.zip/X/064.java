package X;

public final class 064 extends 0BC implements 053 {
  public static final 064 A00 = new 064();
  
  public 064() {
    super(2);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\064.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */