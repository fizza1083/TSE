package X;

public interface 016 {
  boolean boolOverrideForParam(long paramLong, boolean paramBoolean);
  
  double doubleOverrideForParam(long paramLong, double paramDouble);
  
  String experimentOverrideForUniverse(String paramString);
  
  String groupOverrideForUniverse(String paramString);
  
  boolean hasBoolOverrideForParam(long paramLong);
  
  boolean hasDoubleOverrideForParam(long paramLong);
  
  boolean hasIntOverrideForParam(long paramLong);
  
  boolean hasOverrideForUniverse(String paramString);
  
  boolean hasOverridesFile();
  
  boolean hasStringOverrideForParam(long paramLong);
  
  long intOverrideForParam(long paramLong1, long paramLong2);
  
  void removeAllOverrides();
  
  void removeOverrideForParam(long paramLong);
  
  void removeOverridesForQEUniverse(String paramString);
  
  String stringOverrideForParam(long paramLong, String paramString);
  
  void updateOverrideForParam(long paramLong, double paramDouble);
  
  void updateOverrideForParam(long paramLong1, long paramLong2);
  
  void updateOverrideForParam(long paramLong, String paramString);
  
  void updateOverrideForParam(long paramLong, boolean paramBoolean);
  
  void updateOverrideForQE(String paramString1, String paramString2, String paramString3);
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\016.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */