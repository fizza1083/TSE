package X;

import android.app.Application;
import android.content.Context;
import android.content.ContextWrapper;
import androidx.fragment.app.Fragment;

public final class 093 implements 0Bt, 0Bu, 0Bv {
  public 1A2 A00 = null;
  
  public 0CI A01 = null;
  
  public 0Db A02;
  
  public final Fragment A03;
  
  public final 0DY A04;
  
  public final Runnable A05;
  
  public 093(Fragment paramFragment, 0DY param0DY, Runnable paramRunnable) {
    this.A03 = paramFragment;
    this.A04 = param0DY;
    this.A05 = paramRunnable;
  }
  
  public final void A00() {
    if (this.A00 == null) {
      this.A00 = new 1A2(this, true);
      0CI 0CI1 = new 0CI(this);
      this.A01 = 0CI1;
      0CI1.A00();
      this.A05.run();
    } 
  }
  
  public final 0Dd getDefaultViewModelCreationExtras() {
    // Byte code:
    //   0: aload_0
    //   1: getfield A03 : Landroidx/fragment/app/Fragment;
    //   4: astore_3
    //   5: aload_3
    //   6: invokevirtual requireContext : ()Landroid/content/Context;
    //   9: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   12: astore_1
    //   13: aload_1
    //   14: instanceof android/content/ContextWrapper
    //   17: ifeq -> 40
    //   20: aload_1
    //   21: astore_2
    //   22: aload_1
    //   23: instanceof android/app/Application
    //   26: ifne -> 42
    //   29: aload_1
    //   30: checkcast android/content/ContextWrapper
    //   33: invokevirtual getBaseContext : ()Landroid/content/Context;
    //   36: astore_1
    //   37: goto -> 13
    //   40: aconst_null
    //   41: astore_2
    //   42: new X/0Df
    //   45: dup
    //   46: invokespecial <init> : ()V
    //   49: astore_1
    //   50: aload_2
    //   51: ifnull -> 62
    //   54: aload_1
    //   55: getstatic X/0EJ.A02 : LX/0Cd;
    //   58: aload_2
    //   59: invokevirtual A01 : (LX/0Cd;Ljava/lang/Object;)V
    //   62: aload_1
    //   63: getstatic X/0Ca.A01 : LX/0Cd;
    //   66: aload_3
    //   67: invokevirtual A01 : (LX/0Cd;Ljava/lang/Object;)V
    //   70: aload_1
    //   71: getstatic X/0Ca.A02 : LX/0Cd;
    //   74: aload_0
    //   75: invokevirtual A01 : (LX/0Cd;Ljava/lang/Object;)V
    //   78: aload_3
    //   79: getfield mArguments : Landroid/os/Bundle;
    //   82: astore_2
    //   83: aload_2
    //   84: ifnull -> 95
    //   87: aload_1
    //   88: getstatic X/0Ca.A00 : LX/0Cd;
    //   91: aload_2
    //   92: invokevirtual A01 : (LX/0Cd;Ljava/lang/Object;)V
    //   95: aload_1
    //   96: areturn
  }
  
  public final 0Db getDefaultViewModelProviderFactory() {
    Fragment fragment = this.A03;
    0Db 0Db2 = fragment.getDefaultViewModelProviderFactory();
    0Db 0Db1 = 0Db2;
    if (0Db2.equals(fragment.mDefaultFactory)) {
      0Db2 = this.A02;
      0Db1 = 0Db2;
      if (0Db2 == null) {
        0Db 0Db3 = null;
        Context context = fragment.requireContext().getApplicationContext();
        while (true) {
          Application application;
          0Db2 = 0Db3;
          if (context instanceof ContextWrapper)
            if (context instanceof Application) {
              application = (Application)context;
            } else {
              context = ((ContextWrapper)context).getBaseContext();
              continue;
            }  
          0Db1 = new 0VN(application, fragment.mArguments, (0Bv)fragment);
          this.A02 = 0Db1;
          return 0Db1;
        } 
      } 
      return 0Db1;
    } 
    this.A02 = 0Db1;
    return 0Db1;
  }
  
  public final 0cs getLifecycle() {
    A00();
    return this.A00;
  }
  
  public final 0CJ getSavedStateRegistry() {
    A00();
    return this.A01.A01;
  }
  
  public final 0DY getViewModelStore() {
    A00();
    return this.A04;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\093.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */