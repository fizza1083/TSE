package X;

import android.content.Context;
import java.lang.reflect.Field;

public final class 00z extends 00w {
  public 00z() {
    super("window", null, null, null);
  }
  
  public final void A01(Context paramContext, 013 param013) {
    Class clazz = param013.A01("android.view.WindowManagerGlobal");
    if (clazz != null) {
      Field field = param013.A03(clazz, "sWindowManagerService");
      if (field != null)
        try {
          Object object = field.get(null);
          if (object != null) {
            Class clazz1 = param013.A01("android.view.IWindowManager");
            if (clazz1 != null) {
              Object object1 = 00w.A00(this, clazz1, object);
              if (object1 != null)
                field.set(null, object1); 
            } 
          } 
          return;
        } catch (Exception exception) {
          return;
        }  
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */