package X;

import java.util.NoSuchElementException;

public abstract class 06d extends 06e {
  public static final double A00(double paramDouble1, double paramDouble2, double paramDouble3) {
    if (paramDouble2 <= paramDouble3)
      return (paramDouble1 < paramDouble2) ? paramDouble2 : ((paramDouble1 > paramDouble3) ? paramDouble3 : paramDouble1); 
    StringBuilder stringBuilder = 001.A0s();
    stringBuilder.append("Cannot coerce value to an empty range: maximum ");
    stringBuilder.append(paramDouble3);
    stringBuilder.append(" is less than minimum ");
    stringBuilder.append(paramDouble2);
    throw 001.A0O(001.A0n(stringBuilder, '.'));
  }
  
  public static final float A01(float paramFloat1, float paramFloat2, float paramFloat3) {
    if (paramFloat2 <= paramFloat3)
      return (paramFloat1 < paramFloat2) ? paramFloat2 : ((paramFloat1 > paramFloat3) ? paramFloat3 : paramFloat1); 
    throw 001.A0O(0XK.A0f("Cannot coerce value to an empty range: maximum ", " is less than minimum ", '.', paramFloat3, paramFloat2));
  }
  
  public static final int A02(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt2 <= paramInt3)
      return (paramInt1 < paramInt2) ? paramInt2 : ((paramInt1 > paramInt3) ? paramInt3 : paramInt1); 
    throw 001.A0O(0XK.A0h("Cannot coerce value to an empty range: maximum ", " is less than minimum ", '.', paramInt3, paramInt2));
  }
  
  public static final int A03(0Dr param0Dr, 06f param06f) {
    16F.A0E(param0Dr, 1);
    try {
      return 16P.A00(param0Dr, param06f);
    } catch (IllegalArgumentException illegalArgumentException) {
      throw new NoSuchElementException(illegalArgumentException.getMessage());
    } 
  }
  
  public static final int A04(06h param06h, int paramInt) {
    Comparable comparable;
    if (param06h instanceof 08L) {
      comparable = A07(Integer.valueOf(paramInt), (08L)param06h);
    } else if (!param06h.isEmpty()) {
      Comparable comparable1 = param06h.BjV();
      comparable = comparable1;
      if (paramInt >= ((Number)comparable1).intValue()) {
        comparable = param06h.B97();
        int i = paramInt;
        return (paramInt > ((Number)comparable).intValue()) ? 001.A03(comparable) : i;
      } 
    } else {
      throw A08(param06h);
    } 
    return 001.A03(comparable);
  }
  
  public static final long A05(long paramLong1, long paramLong2, long paramLong3) {
    if (paramLong2 <= paramLong3)
      return (paramLong1 < paramLong2) ? paramLong2 : ((paramLong1 > paramLong3) ? paramLong3 : paramLong1); 
    StringBuilder stringBuilder = 001.A0s();
    stringBuilder.append("Cannot coerce value to an empty range: maximum ");
    stringBuilder.append(paramLong3);
    stringBuilder.append(" is less than minimum ");
    stringBuilder.append(paramLong2);
    throw 001.A0O(001.A0n(stringBuilder, '.'));
  }
  
  public static final long A06(06h param06h, long paramLong) {
    Comparable comparable;
    if (!param06h.isEmpty()) {
      Comparable comparable1 = param06h.BjV();
      comparable = comparable1;
      if (paramLong >= 001.A08(comparable1)) {
        comparable = param06h.B97();
        long l = paramLong;
        return (paramLong > 001.A08(comparable)) ? 001.A08(comparable) : l;
      } 
    } else {
      throw A08(param06h);
    } 
    return 001.A08(comparable);
  }
  
  public static final Comparable A07(Comparable paramComparable, 08L param08L) {
    16F.A0E(param08L, 1);
    if (!param08L.isEmpty()) {
      float f = param08L.A01;
      Float float_ = Float.valueOf(f);
      Number number = (Number)paramComparable;
      if (number.floatValue() > f || f <= number.floatValue()) {
        f = param08L.A00;
        float_ = Float.valueOf(f);
        if (f > number.floatValue() || number.floatValue() <= f)
          return paramComparable; 
      } 
      return float_;
    } 
    throw A08(param08L);
  }
  
  public static IllegalArgumentException A08(Object paramObject) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Cannot coerce value to an empty range: ");
    stringBuilder.append(paramObject);
    stringBuilder.append('.');
    return new IllegalArgumentException(stringBuilder.toString());
  }
  
  public static final 06g A09(06g param06g, int paramInt) {
    int j = param06g.A00;
    int k = param06g.A01;
    int i = paramInt;
    if (param06g.A02 <= 0)
      i = -paramInt; 
    return new 06g(j, k, i);
  }
  
  public static final 06f A0A(int paramInt1, int paramInt2) {
    return (paramInt2 <= Integer.MIN_VALUE) ? 06f.A00 : new 06f(paramInt1, paramInt2 - 1);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\06d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */