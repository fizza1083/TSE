package X;

import java.io.Closeable;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.channels.FileLock;

public final class 00t implements Closeable {
  public final FileOutputStream A00;
  
  public final FileLock A01;
  
  public 00t(File paramFile) {
    null = 001.A0H(paramFile);
    this.A00 = null;
    try {
      FileLock fileLock = null.getChannel().lock();
      if (fileLock == null)
        null.close(); 
      return;
    } finally {
      this.A00.close();
    } 
  }
  
  public final void close() {
    try {
      FileLock fileLock = this.A01;
      if (fileLock != null)
        fileLock.release(); 
      return;
    } finally {
      this.A00.close();
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */