package X;

public abstract class 05A extends 05B implements 0BE {
  public final int arity;
  
  public 05A(05D param05D, int paramInt) {
    super(param05D);
    this.arity = paramInt;
  }
  
  public final int getArity() {
    return this.arity;
  }
  
  public final String toString() {
    if (this.completion == null) {
      String str = 16I.A00(this);
      16F.A0A(str);
      return str;
    } 
    return super.toString();
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\05A.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */