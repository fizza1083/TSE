package X;

import com.facebook.profilo.writer.NativeTraceWriterCallbacks;

public final class 04i implements NativeTraceWriterCallbacks {
  public int A00;
  
  public long A01;
  
  public Throwable A02;
  
  public boolean A03;
  
  public boolean A04;
  
  public boolean A05;
  
  public final NativeTraceWriterCallbacks A06;
  
  public final boolean A07;
  
  public 04i(NativeTraceWriterCallbacks paramNativeTraceWriterCallbacks, boolean paramBoolean) {
    this.A07 = paramBoolean;
    this.A06 = paramNativeTraceWriterCallbacks;
  }
  
  public final void A00() {
    if (this.A07) {
      if (this.A05) {
        this.A06.onTraceWriteException(this.A01, this.A02);
        return;
      } 
    } else {
      return;
    } 
    if (this.A04) {
      this.A06.onTraceWriteEnd(this.A01);
      return;
    } 
    if (this.A03) {
      this.A06.onTraceWriteAbort(this.A01, this.A00);
      return;
    } 
  }
  
  public final void onTraceWriteAbort(long paramLong, int paramInt) {
    if (this.A07) {
      this.A03 = true;
      this.A00 = paramInt;
      this.A01 = paramLong;
      return;
    } 
    this.A06.onTraceWriteAbort(paramLong, paramInt);
  }
  
  public final void onTraceWriteEnd(long paramLong) {
    if (this.A07) {
      this.A04 = true;
      this.A01 = paramLong;
      return;
    } 
    this.A06.onTraceWriteEnd(paramLong);
  }
  
  public final void onTraceWriteException(long paramLong, Throwable paramThrowable) {
    if (this.A07) {
      this.A05 = true;
      this.A02 = paramThrowable;
      this.A01 = paramLong;
      return;
    } 
    this.A06.onTraceWriteException(paramLong, paramThrowable);
  }
  
  public final void onTraceWriteStart(long paramLong, int paramInt) {
    this.A06.onTraceWriteStart(paramLong, paramInt);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\04i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */