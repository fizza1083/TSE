package X;

public final class 07D extends 07E {
  public 07D() {}
  
  public 07D(int paramInt) {}
  
  public static final int A00(double paramDouble) {
    if (!Double.isNaN(paramDouble))
      return (paramDouble > 2.147483647E9D) ? Integer.MAX_VALUE : ((paramDouble < -2.147483648E9D) ? Integer.MIN_VALUE : (int)Math.round(paramDouble)); 
    throw 001.A0O("Cannot round NaN value.");
  }
  
  public static final int A01(float paramFloat) {
    if (!Float.isNaN(paramFloat))
      return Math.round(paramFloat); 
    throw 001.A0O("Cannot round NaN value.");
  }
  
  public static final long A02(double paramDouble) {
    if (!Double.isNaN(paramDouble))
      return Math.round(paramDouble); 
    throw 001.A0O("Cannot round NaN value.");
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */