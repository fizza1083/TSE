package X;

import com.facebook.quicklog.QuickPerformanceLogger;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.IntBuffer;

public final class 06G implements 06I {
  public static final Integer A0B = 0Xy.A00;
  
  public int A00 = 0;
  
  public int A01 = 0;
  
  public IntBuffer A02;
  
  public 06K A03;
  
  public 06L A04;
  
  public final 0BX A05;
  
  public final 0BX A06;
  
  public final 14q A07;
  
  public final int A08;
  
  public final int A09;
  
  public final 14q A0A;
  
  public int mNextEventId = 1;
  
  public 06G(14q param14q1, 14q param14q2, int paramInt1, int paramInt2, boolean paramBoolean) {
    this.A09 = paramInt1 * 2 * 3 * 4;
    this.A08 = paramInt2;
    this.A07 = param14q1;
    this.A0A = param14q2;
    if (paramBoolean) {
      this.A06 = new 0BX();
      0BX 0BX1 = new 0BX();
    } else {
      param14q1 = null;
    } 
    this.A05 = (0BX)param14q1;
  }
  
  private int A00(String paramString, int paramInt1, int paramInt2) {
    06K 06K1 = this.A03;
    if (06K1 != null) {
      int i = 0;
      while (true) {
        int j = 06K.A00(06K1, paramInt1, paramInt2, i);
        int k = 06K1.A00;
        IntBuffer intBuffer = 06K1.A01;
        intBuffer.position((k * i + j) * 3);
        j = intBuffer.get();
        k = intBuffer.get();
        if (paramInt1 == j && paramInt2 == k) {
          j = intBuffer.get();
          if (j != 0) {
            k = (0x70000000 & j) >>> 28;
            if (k >= 5) {
              14q 14q1 = this.A07;
              if (14q1 != null)
                ((07F)14q1.get()).DfT(paramInt1, paramString, "exceeded number of annotations per event"); 
              return -1;
            } 
          } else {
            return -1;
          } 
        } else {
          if (++i < 2)
            continue; 
          return -1;
        } 
        i = j & 0xFFFFFFF;
        boolean bool = unpackEndsOnEndsAllFlag(j);
        06K 06K2 = this.A03;
        j = packEventValue(i, k + 1, bool);
        if (j != 0) {
          06K.A01(06K2, paramInt1, paramInt2, j, 0, 0);
          return i;
        } 
        throw 001.A0O("Value 0 is reserved and can't be put into the map");
      } 
    } 
    return -1;
  }
  
  private void A01(int paramInt1, int paramInt2) {
    0BX 0BX1 = this.A05;
    if (0BX1 != null) {
      0BX 0BX2 = this.A06;
      if (0BX2 != null) {
        if (0BX2.A01(paramInt1, paramInt2))
          this.A01--; 
        if (0BX1.A01(paramInt1, paramInt2))
          this.A00--; 
        IntBuffer intBuffer = this.A02;
        if (intBuffer != null)
          intBuffer.put(2, this.A00 + this.A01); 
      } 
    } 
  }
  
  public static 0C4[] A02(0BZ param0BZ, RandomAccessFile paramRandomAccessFile, long paramLong1, long paramLong2) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: \r\n\tat com.googlecode.dex2jar.ir.ts.NewTransformer.transform(NewTransformer.java:134)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:148)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public static 0C4[] A03(0BZ param0BZ, String paramString) {
    try {
      RandomAccessFile randomAccessFile;
    } finally {
      paramString = null;
      param0BZ.A01();
      param0BZ.A0C = false;
      param0BZ.A0A = paramString.getMessage();
    } 
  }
  
  public static int packEventValue(int paramInt1, int paramInt2, boolean paramBoolean) {
    paramInt2 = paramInt1 | paramInt2 << 28;
    paramInt1 = paramInt2;
    if (paramBoolean)
      paramInt1 = paramInt2 | Integer.MIN_VALUE; 
    return paramInt1;
  }
  
  public static int[] readStorage(String paramString, 0BZ param0BZ) {
    0C4[] arrayOf0C4 = A03(param0BZ, paramString);
    int j = arrayOf0C4.length;
    int[] arrayOfInt = new int[j];
    for (int i = 0; i < j; i++)
      arrayOfInt[i] = (arrayOf0C4[i]).A05; 
    return arrayOfInt;
  }
  
  public static int unpackAnnotationsCount(int paramInt) {
    return (paramInt & 0x70000000) >>> 28;
  }
  
  public static boolean unpackEndsOnEndsAllFlag(int paramInt) {
    boolean bool = false;
    if ((paramInt & Integer.MIN_VALUE) != 0)
      bool = true; 
    return bool;
  }
  
  public static int unpackEventId(int paramInt) {
    return paramInt & 0xFFFFFFF;
  }
  
  public final long BkH() {
    byte b;
    06K 06K1 = this.A03;
    int i = 0;
    if (06K1 != null) {
      b = this.A09;
    } else {
      b = 0;
    } 
    if (this.A04 != null)
      i = this.A08; 
    return (b + 16 + i);
  }
  
  public final Integer BkQ() {
    return A0B;
  }
  
  public final int BkR() {
    return 2;
  }
  
  public final void C0z(File paramFile, String paramString) {
    String str = 0XK.A11(paramFile.getAbsolutePath(), "/", "qpl_v2_", paramString);
    try {
      RandomAccessFile randomAccessFile = new RandomAccessFile(str, "rw");
      try {
        createFile(randomAccessFile, 0L);
        return;
      } finally {
        try {
          randomAccessFile.close();
        } finally {
          randomAccessFile = null;
        } 
      } 
    } catch (IOException iOException) {
      return;
    } 
  }
  
  public final void C10(RandomAccessFile paramRandomAccessFile, long paramLong) {
    createFile(paramRandomAccessFile, paramLong);
  }
  
  public final void Dbv(int paramInt1, int paramInt2, String paramString, int paramInt3) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_3
    //   4: iload_1
    //   5: iload_2
    //   6: invokespecial A00 : (Ljava/lang/String;II)I
    //   9: istore_2
    //   10: iload_2
    //   11: iconst_m1
    //   12: if_icmpeq -> 121
    //   15: aload_0
    //   16: getfield A04 : LX/06L;
    //   19: astore #5
    //   21: aload #5
    //   23: ifnull -> 121
    //   26: getstatic X/06L.A04 : Ljava/nio/ByteBuffer;
    //   29: astore #6
    //   31: aload #6
    //   33: iconst_0
    //   34: invokevirtual position : (I)Ljava/nio/Buffer;
    //   37: pop
    //   38: aload #6
    //   40: iload #4
    //   42: invokevirtual putInt : (I)Ljava/nio/ByteBuffer;
    //   45: pop
    //   46: aload #5
    //   48: aload_3
    //   49: aload #6
    //   51: invokevirtual array : ()[B
    //   54: iload_2
    //   55: iconst_1
    //   56: invokestatic A00 : (LX/06L;Ljava/lang/String;[BII)I
    //   59: istore_2
    //   60: aload_0
    //   61: getfield A07 : LX/14q;
    //   64: astore #5
    //   66: aload #5
    //   68: ifnull -> 121
    //   71: iload_2
    //   72: iconst_2
    //   73: iand
    //   74: ifeq -> 96
    //   77: aload #5
    //   79: invokeinterface get : ()Ljava/lang/Object;
    //   84: checkcast X/07F
    //   87: iload_1
    //   88: aload_3
    //   89: ldc 'key'
    //   91: invokeinterface DfW : (ILjava/lang/String;Ljava/lang/String;)V
    //   96: iload_2
    //   97: iconst_4
    //   98: iand
    //   99: ifeq -> 121
    //   102: aload #5
    //   104: invokeinterface get : ()Ljava/lang/Object;
    //   109: checkcast X/07F
    //   112: iload_1
    //   113: aload_3
    //   114: ldc 'value'
    //   116: invokeinterface DfW : (ILjava/lang/String;Ljava/lang/String;)V
    //   121: aload_0
    //   122: monitorexit
    //   123: return
    //   124: astore_3
    //   125: aload_0
    //   126: monitorexit
    //   127: aload_3
    //   128: athrow
    // Exception table:
    //   from	to	target	type
    //   2	10	124	finally
    //   15	21	124	finally
    //   26	66	124	finally
    //   77	96	124	finally
    //   102	121	124	finally
  }
  
  public final void Dbw(int paramInt1, int paramInt2, String paramString1, String paramString2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_3
    //   4: iload_1
    //   5: iload_2
    //   6: invokespecial A00 : (Ljava/lang/String;II)I
    //   9: istore_2
    //   10: iload_2
    //   11: iconst_m1
    //   12: if_icmpeq -> 114
    //   15: aload_0
    //   16: getfield A04 : LX/06L;
    //   19: astore #6
    //   21: aload #6
    //   23: ifnull -> 114
    //   26: aload #4
    //   28: astore #5
    //   30: aload #4
    //   32: ifnonnull -> 39
    //   35: ldc 'null'
    //   37: astore #5
    //   39: aload #6
    //   41: aload_3
    //   42: aload #5
    //   44: invokevirtual getBytes : ()[B
    //   47: iload_2
    //   48: iconst_0
    //   49: invokestatic A00 : (LX/06L;Ljava/lang/String;[BII)I
    //   52: istore_2
    //   53: aload_0
    //   54: getfield A07 : LX/14q;
    //   57: astore #4
    //   59: aload #4
    //   61: ifnull -> 114
    //   64: iload_2
    //   65: iconst_2
    //   66: iand
    //   67: ifeq -> 89
    //   70: aload #4
    //   72: invokeinterface get : ()Ljava/lang/Object;
    //   77: checkcast X/07F
    //   80: iload_1
    //   81: aload_3
    //   82: ldc 'key'
    //   84: invokeinterface DfW : (ILjava/lang/String;Ljava/lang/String;)V
    //   89: iload_2
    //   90: iconst_4
    //   91: iand
    //   92: ifeq -> 114
    //   95: aload #4
    //   97: invokeinterface get : ()Ljava/lang/Object;
    //   102: checkcast X/07F
    //   105: iload_1
    //   106: aload_3
    //   107: ldc 'value'
    //   109: invokeinterface DfW : (ILjava/lang/String;Ljava/lang/String;)V
    //   114: aload_0
    //   115: monitorexit
    //   116: return
    //   117: astore_3
    //   118: aload_0
    //   119: monitorexit
    //   120: aload_3
    //   121: athrow
    // Exception table:
    //   from	to	target	type
    //   2	10	117	finally
    //   15	21	117	finally
    //   39	59	117	finally
    //   70	89	117	finally
    //   95	114	117	finally
  }
  
  public final void Dbx(int paramInt1, int paramInt2) {
    Dby(paramInt1, paramInt2);
  }
  
  public final void Dby(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield A03 : LX/06K;
    //   6: astore #7
    //   8: aload #7
    //   10: ifnull -> 112
    //   13: iconst_0
    //   14: istore_3
    //   15: aload #7
    //   17: iload_1
    //   18: iload_2
    //   19: iload_3
    //   20: invokestatic A00 : (LX/06K;III)I
    //   23: istore #4
    //   25: aload #7
    //   27: getfield A00 : I
    //   30: iload_3
    //   31: imul
    //   32: iload #4
    //   34: iadd
    //   35: iconst_3
    //   36: imul
    //   37: istore #4
    //   39: aload #7
    //   41: getfield A01 : Ljava/nio/IntBuffer;
    //   44: astore #8
    //   46: aload #8
    //   48: iload #4
    //   50: invokevirtual position : (I)Ljava/nio/Buffer;
    //   53: pop
    //   54: aload #8
    //   56: invokevirtual get : ()I
    //   59: istore #5
    //   61: aload #8
    //   63: invokevirtual get : ()I
    //   66: istore #6
    //   68: aload #8
    //   70: invokevirtual get : ()I
    //   73: pop
    //   74: iload_1
    //   75: iload #5
    //   77: if_icmpne -> 122
    //   80: iload_2
    //   81: iload #6
    //   83: if_icmpne -> 122
    //   86: goto -> 89
    //   89: aload #8
    //   91: iload #4
    //   93: invokevirtual position : (I)Ljava/nio/Buffer;
    //   96: pop
    //   97: aload #8
    //   99: getstatic X/06K.A02 : [I
    //   102: invokevirtual put : ([I)Ljava/nio/IntBuffer;
    //   105: pop
    //   106: aload_0
    //   107: iload_1
    //   108: iload_2
    //   109: invokespecial A01 : (II)V
    //   112: aload_0
    //   113: monitorexit
    //   114: return
    //   115: astore #7
    //   117: aload_0
    //   118: monitorexit
    //   119: aload #7
    //   121: athrow
    //   122: iload_3
    //   123: iconst_1
    //   124: iadd
    //   125: istore_3
    //   126: iload_3
    //   127: iconst_2
    //   128: if_icmpge -> 106
    //   131: goto -> 15
    // Exception table:
    //   from	to	target	type
    //   2	8	115	finally
    //   15	74	115	finally
    //   89	106	115	finally
    //   106	112	115	finally
  }
  
  public final void Dbz(int paramInt1, int paramInt2, String paramString) {}
  
  public final void Dc0(int paramInt1, int paramInt2, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield A03 : LX/06K;
    //   6: astore #6
    //   8: aload #6
    //   10: ifnull -> 199
    //   13: aload_0
    //   14: invokevirtual nextEventId : ()I
    //   17: istore #5
    //   19: iload #5
    //   21: istore #4
    //   23: iload_3
    //   24: ifeq -> 34
    //   27: iload #5
    //   29: ldc -2147483648
    //   31: ior
    //   32: istore #4
    //   34: iload #4
    //   36: ifeq -> 193
    //   39: aload #6
    //   41: iload_1
    //   42: iload_2
    //   43: iload #4
    //   45: iconst_0
    //   46: iconst_0
    //   47: invokestatic A01 : (LX/06K;IIIII)I
    //   50: istore #4
    //   52: iload #4
    //   54: ifeq -> 100
    //   57: aload_0
    //   58: getfield A07 : LX/14q;
    //   61: astore #6
    //   63: aload #6
    //   65: ifnull -> 100
    //   68: aload #6
    //   70: invokeinterface get : ()Ljava/lang/Object;
    //   75: checkcast X/07F
    //   78: iload #4
    //   80: iconst_2
    //   81: aload_0
    //   82: getfield A09 : I
    //   85: iconst_4
    //   86: idiv
    //   87: iconst_3
    //   88: idiv
    //   89: iconst_2
    //   90: idiv
    //   91: aload_0
    //   92: getfield A08 : I
    //   95: invokeinterface DfU : (IIII)V
    //   100: aload_0
    //   101: getfield A05 : LX/0BX;
    //   104: astore #6
    //   106: aload #6
    //   108: ifnull -> 199
    //   111: aload_0
    //   112: getfield A06 : LX/0BX;
    //   115: astore #7
    //   117: aload #7
    //   119: ifnull -> 199
    //   122: iload_3
    //   123: ifeq -> 146
    //   126: aload_0
    //   127: aload_0
    //   128: getfield A01 : I
    //   131: iconst_1
    //   132: iadd
    //   133: putfield A01 : I
    //   136: aload #7
    //   138: iload_1
    //   139: iload_2
    //   140: invokevirtual A00 : (II)V
    //   143: goto -> 163
    //   146: aload_0
    //   147: aload_0
    //   148: getfield A00 : I
    //   151: iconst_1
    //   152: iadd
    //   153: putfield A00 : I
    //   156: aload #6
    //   158: iload_1
    //   159: iload_2
    //   160: invokevirtual A00 : (II)V
    //   163: aload_0
    //   164: getfield A02 : Ljava/nio/IntBuffer;
    //   167: astore #6
    //   169: aload #6
    //   171: ifnull -> 199
    //   174: aload #6
    //   176: iconst_2
    //   177: aload_0
    //   178: getfield A00 : I
    //   181: aload_0
    //   182: getfield A01 : I
    //   185: iadd
    //   186: invokevirtual put : (II)Ljava/nio/IntBuffer;
    //   189: pop
    //   190: goto -> 199
    //   193: ldc 'Value 0 is reserved and can't be put into the map'
    //   195: invokestatic A0O : (Ljava/lang/String;)Ljava/lang/IllegalArgumentException;
    //   198: athrow
    //   199: aload_0
    //   200: monitorexit
    //   201: return
    //   202: astore #6
    //   204: aload_0
    //   205: monitorexit
    //   206: aload #6
    //   208: athrow
    // Exception table:
    //   from	to	target	type
    //   2	8	202	finally
    //   13	19	202	finally
    //   39	52	202	finally
    //   57	63	202	finally
    //   68	100	202	finally
    //   100	106	202	finally
    //   111	117	202	finally
    //   126	143	202	finally
    //   146	163	202	finally
    //   163	169	202	finally
    //   174	190	202	finally
    //   193	199	202	finally
  }
  
  public final void Dc1() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield A03 : LX/06K;
    //   6: astore #6
    //   8: aload #6
    //   10: ifnull -> 184
    //   13: aload #6
    //   15: getfield A01 : Ljava/nio/IntBuffer;
    //   18: astore #7
    //   20: aload #7
    //   22: iconst_0
    //   23: invokevirtual position : (I)Ljava/nio/Buffer;
    //   26: pop
    //   27: iconst_0
    //   28: istore_1
    //   29: goto -> 194
    //   32: aload #6
    //   34: getfield A00 : I
    //   37: istore_3
    //   38: iload_2
    //   39: iload_3
    //   40: if_icmpge -> 122
    //   43: aload #7
    //   45: invokevirtual get : ()I
    //   48: istore #4
    //   50: aload #7
    //   52: invokevirtual get : ()I
    //   55: pop
    //   56: aload #7
    //   58: invokevirtual get : ()I
    //   61: istore #5
    //   63: iload #4
    //   65: ifeq -> 199
    //   68: iload #5
    //   70: ifeq -> 199
    //   73: iload #5
    //   75: invokestatic unpackEndsOnEndsAllFlag : (I)Z
    //   78: iconst_1
    //   79: if_icmpne -> 199
    //   82: aload #7
    //   84: invokevirtual position : ()I
    //   87: istore #4
    //   89: aload #7
    //   91: iload_1
    //   92: iload_3
    //   93: imul
    //   94: iload_2
    //   95: iadd
    //   96: iconst_3
    //   97: imul
    //   98: invokevirtual position : (I)Ljava/nio/Buffer;
    //   101: pop
    //   102: aload #7
    //   104: getstatic X/06K.A02 : [I
    //   107: invokevirtual put : ([I)Ljava/nio/IntBuffer;
    //   110: pop
    //   111: aload #7
    //   113: iload #4
    //   115: invokevirtual position : (I)Ljava/nio/Buffer;
    //   118: pop
    //   119: goto -> 199
    //   122: iload_1
    //   123: iconst_1
    //   124: iadd
    //   125: istore_2
    //   126: iload_2
    //   127: istore_1
    //   128: iload_2
    //   129: iconst_2
    //   130: if_icmplt -> 194
    //   133: aload_0
    //   134: getfield A05 : LX/0BX;
    //   137: ifnull -> 184
    //   140: aload_0
    //   141: getfield A06 : LX/0BX;
    //   144: astore #6
    //   146: aload #6
    //   148: ifnull -> 184
    //   151: aload_0
    //   152: iconst_0
    //   153: putfield A01 : I
    //   156: aload #6
    //   158: iconst_0
    //   159: putfield A00 : I
    //   162: aload_0
    //   163: getfield A02 : Ljava/nio/IntBuffer;
    //   166: astore #6
    //   168: aload #6
    //   170: ifnull -> 184
    //   173: aload #6
    //   175: iconst_2
    //   176: aload_0
    //   177: getfield A00 : I
    //   180: invokevirtual put : (II)Ljava/nio/IntBuffer;
    //   183: pop
    //   184: aload_0
    //   185: monitorexit
    //   186: return
    //   187: astore #6
    //   189: aload_0
    //   190: monitorexit
    //   191: aload #6
    //   193: athrow
    //   194: iconst_0
    //   195: istore_2
    //   196: goto -> 32
    //   199: iload_2
    //   200: iconst_1
    //   201: iadd
    //   202: istore_2
    //   203: goto -> 32
    // Exception table:
    //   from	to	target	type
    //   2	8	187	finally
    //   13	27	187	finally
    //   32	38	187	finally
    //   43	63	187	finally
    //   73	119	187	finally
    //   133	146	187	finally
    //   151	168	187	finally
    //   173	184	187	finally
  }
  
  public final void Dc2(int paramInt1, int paramInt2, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield A03 : LX/06K;
    //   6: astore #9
    //   8: aload #9
    //   10: ifnull -> 262
    //   13: iconst_0
    //   14: istore #4
    //   16: aload #9
    //   18: iload_1
    //   19: iload_2
    //   20: iload #4
    //   22: invokestatic A00 : (LX/06K;III)I
    //   25: istore #5
    //   27: aload #9
    //   29: getfield A00 : I
    //   32: iload #4
    //   34: imul
    //   35: iload #5
    //   37: iadd
    //   38: iconst_3
    //   39: imul
    //   40: istore #5
    //   42: aload #9
    //   44: getfield A01 : Ljava/nio/IntBuffer;
    //   47: astore #10
    //   49: aload #10
    //   51: iload #5
    //   53: invokevirtual position : (I)Ljava/nio/Buffer;
    //   56: pop
    //   57: aload #10
    //   59: invokevirtual get : ()I
    //   62: istore #6
    //   64: aload #10
    //   66: invokevirtual get : ()I
    //   69: istore #7
    //   71: aload #10
    //   73: invokevirtual get : ()I
    //   76: istore #8
    //   78: iload_1
    //   79: iload #6
    //   81: if_icmpne -> 272
    //   84: iload_2
    //   85: iload #7
    //   87: if_icmpne -> 272
    //   90: goto -> 93
    //   93: aload #10
    //   95: iload #5
    //   97: invokevirtual position : (I)Ljava/nio/Buffer;
    //   100: pop
    //   101: aload #10
    //   103: getstatic X/06K.A02 : [I
    //   106: invokevirtual put : ([I)Ljava/nio/IntBuffer;
    //   109: pop
    //   110: iload #8
    //   112: ifeq -> 157
    //   115: aload_0
    //   116: getfield A03 : LX/06K;
    //   119: astore #9
    //   121: iload #8
    //   123: ldc 268435455
    //   125: iand
    //   126: iload #8
    //   128: ldc 1879048192
    //   130: iand
    //   131: bipush #28
    //   133: iushr
    //   134: iload_3
    //   135: invokestatic packEventValue : (IIZ)I
    //   138: istore #4
    //   140: iload #4
    //   142: ifeq -> 256
    //   145: aload #9
    //   147: iload_1
    //   148: iload_2
    //   149: iload #4
    //   151: iconst_0
    //   152: iconst_0
    //   153: invokestatic A01 : (LX/06K;IIIII)I
    //   156: pop
    //   157: aload_0
    //   158: iload_1
    //   159: iload_2
    //   160: invokespecial A01 : (II)V
    //   163: aload_0
    //   164: getfield A05 : LX/0BX;
    //   167: astore #9
    //   169: aload #9
    //   171: ifnull -> 262
    //   174: aload_0
    //   175: getfield A06 : LX/0BX;
    //   178: astore #10
    //   180: aload #10
    //   182: ifnull -> 262
    //   185: iload_3
    //   186: ifeq -> 209
    //   189: aload_0
    //   190: aload_0
    //   191: getfield A01 : I
    //   194: iconst_1
    //   195: iadd
    //   196: putfield A01 : I
    //   199: aload #10
    //   201: iload_1
    //   202: iload_2
    //   203: invokevirtual A00 : (II)V
    //   206: goto -> 226
    //   209: aload_0
    //   210: aload_0
    //   211: getfield A00 : I
    //   214: iconst_1
    //   215: iadd
    //   216: putfield A00 : I
    //   219: aload #9
    //   221: iload_1
    //   222: iload_2
    //   223: invokevirtual A00 : (II)V
    //   226: aload_0
    //   227: getfield A02 : Ljava/nio/IntBuffer;
    //   230: astore #9
    //   232: aload #9
    //   234: ifnull -> 262
    //   237: aload #9
    //   239: iconst_2
    //   240: aload_0
    //   241: getfield A00 : I
    //   244: aload_0
    //   245: getfield A01 : I
    //   248: iadd
    //   249: invokevirtual put : (II)Ljava/nio/IntBuffer;
    //   252: pop
    //   253: goto -> 262
    //   256: ldc 'Value 0 is reserved and can't be put into the map'
    //   258: invokestatic A0O : (Ljava/lang/String;)Ljava/lang/IllegalArgumentException;
    //   261: athrow
    //   262: aload_0
    //   263: monitorexit
    //   264: return
    //   265: astore #9
    //   267: aload_0
    //   268: monitorexit
    //   269: aload #9
    //   271: athrow
    //   272: iload #4
    //   274: iconst_1
    //   275: iadd
    //   276: istore #4
    //   278: iload #4
    //   280: iconst_2
    //   281: if_icmpge -> 157
    //   284: goto -> 16
    // Exception table:
    //   from	to	target	type
    //   2	8	265	finally
    //   16	78	265	finally
    //   93	110	265	finally
    //   115	140	265	finally
    //   145	157	265	finally
    //   157	169	265	finally
    //   174	180	265	finally
    //   189	206	265	finally
    //   209	226	265	finally
    //   226	232	265	finally
    //   237	253	265	finally
    //   256	262	265	finally
  }
  
  public void createFile(RandomAccessFile paramRandomAccessFile, long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: lload_2
    //   3: l2i
    //   4: bipush #16
    //   6: iadd
    //   7: istore #5
    //   9: aload_0
    //   10: getfield A09 : I
    //   13: istore #6
    //   15: iload #6
    //   17: iload #5
    //   19: iadd
    //   20: istore #4
    //   22: aload_1
    //   23: lload_2
    //   24: invokevirtual seek : (J)V
    //   27: aload_1
    //   28: iconst_3
    //   29: invokevirtual writeInt : (I)V
    //   32: aload_1
    //   33: iload #4
    //   35: invokevirtual writeInt : (I)V
    //   38: aload_1
    //   39: iconst_m1
    //   40: invokevirtual writeInt : (I)V
    //   43: aload_1
    //   44: iconst_m1
    //   45: invokevirtual writeInt : (I)V
    //   48: aload_1
    //   49: invokevirtual getChannel : ()Ljava/nio/channels/FileChannel;
    //   52: astore #7
    //   54: getstatic java/nio/channels/FileChannel$MapMode.READ_WRITE : Ljava/nio/channels/FileChannel$MapMode;
    //   57: astore #8
    //   59: aload_0
    //   60: aload #7
    //   62: aload #8
    //   64: lload_2
    //   65: ldc2_w 16
    //   68: invokevirtual map : (Ljava/nio/channels/FileChannel$MapMode;JJ)Ljava/nio/MappedByteBuffer;
    //   71: invokevirtual asIntBuffer : ()Ljava/nio/IntBuffer;
    //   74: putfield A02 : Ljava/nio/IntBuffer;
    //   77: iload #6
    //   79: ifle -> 108
    //   82: aload_0
    //   83: new X/06K
    //   86: dup
    //   87: aload_1
    //   88: invokevirtual getChannel : ()Ljava/nio/channels/FileChannel;
    //   91: aload #8
    //   93: iload #5
    //   95: i2l
    //   96: iload #6
    //   98: i2l
    //   99: invokevirtual map : (Ljava/nio/channels/FileChannel$MapMode;JJ)Ljava/nio/MappedByteBuffer;
    //   102: invokespecial <init> : (Ljava/nio/ByteBuffer;)V
    //   105: putfield A03 : LX/06K;
    //   108: aload_0
    //   109: getfield A08 : I
    //   112: istore #5
    //   114: iload #5
    //   116: bipush #12
    //   118: if_icmple -> 150
    //   121: aload_0
    //   122: new X/06L
    //   125: dup
    //   126: aload_1
    //   127: invokevirtual getChannel : ()Ljava/nio/channels/FileChannel;
    //   130: getstatic java/nio/channels/FileChannel$MapMode.READ_WRITE : Ljava/nio/channels/FileChannel$MapMode;
    //   133: iload #4
    //   135: i2l
    //   136: iload #5
    //   138: i2l
    //   139: invokevirtual map : (Ljava/nio/channels/FileChannel$MapMode;JJ)Ljava/nio/MappedByteBuffer;
    //   142: iload #5
    //   144: invokespecial <init> : (Ljava/nio/ByteBuffer;I)V
    //   147: putfield A04 : LX/06L;
    //   150: aload_0
    //   151: monitorexit
    //   152: return
    //   153: astore_1
    //   154: aload_0
    //   155: monitorexit
    //   156: aload_1
    //   157: athrow
    //   158: astore_1
    //   159: goto -> 150
    // Exception table:
    //   from	to	target	type
    //   9	15	153	finally
    //   22	77	158	java/io/IOException
    //   22	77	153	finally
    //   82	108	158	java/io/IOException
    //   82	108	153	finally
    //   108	114	158	java/io/IOException
    //   108	114	153	finally
    //   121	150	158	java/io/IOException
    //   121	150	153	finally
  }
  
  public void createFile(String paramString) {
    /* monitor enter ThisExpression{ObjectType{X/06G}} */
    try {
      RandomAccessFile randomAccessFile = new RandomAccessFile(paramString, "rw");
      try {
        createFile(randomAccessFile, 0L);
      } finally {
        try {
          randomAccessFile.close();
        } finally {
          randomAccessFile = null;
        } 
      } 
    } finally {}
    /* monitor exit ThisExpression{ObjectType{X/06G}} */
  }
  
  public int nextEventId() {
    int j = this.mNextEventId + 1;
    this.mNextEventId = j;
    int i = j;
    if ((0x70000000 & j) != 0) {
      this.mNextEventId = 1;
      i = 1;
    } 
    return i;
  }
  
  public final void setQuickPerformanceLogger(QuickPerformanceLogger paramQuickPerformanceLogger) {}
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\06G.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */