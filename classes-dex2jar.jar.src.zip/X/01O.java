package X;

public interface 01O {
  @Deprecated
  void DfF(0R9 param0R9, String paramString1, String paramString2);
  
  @Deprecated
  void DfG(0R9 param0R9, String paramString1, String paramString2, Throwable paramThrowable);
  
  void Dfl(Throwable paramThrowable);
  
  @Deprecated
  void E59(08U param08U);
  
  @Deprecated
  void E5B(String paramString1, String paramString2);
  
  @Deprecated
  void E5C(String paramString1, String paramString2, int paramInt);
  
  @Deprecated
  void E5D(String paramString, Throwable paramThrowable, int paramInt);
  
  @Deprecated
  void E5E(int paramInt, String paramString1, Throwable paramThrowable, String paramString2);
  
  @Deprecated
  void E5F(08U param08U);
  
  @Deprecated
  void E5H(String paramString1, String paramString2);
  
  @Deprecated
  void E5I(String paramString1, String paramString2, Throwable paramThrowable);
  
  @Deprecated
  void E5J(String paramString, Throwable paramThrowable);
  
  void E7s(String paramString1, String paramString2, String paramString3);
  
  @Deprecated
  void softReport(String paramString1, String paramString2, Throwable paramThrowable);
  
  @Deprecated
  void softReport(String paramString, Throwable paramThrowable);
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01O.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */