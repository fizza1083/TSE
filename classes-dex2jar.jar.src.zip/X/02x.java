package X;

import android.content.Context;

public final class 02x {
  public static 02x A04;
  
  public Context A00;
  
  public final int A01;
  
  public final 0pM A02;
  
  public final String A03;
  
  public 02x(Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: ldc X/02y
    //   6: monitorenter
    //   7: getstatic X/02y.A01 : LX/02y;
    //   10: astore #4
    //   12: aload #4
    //   14: astore_3
    //   15: aload #4
    //   17: ifnonnull -> 33
    //   20: new X/02y
    //   23: dup
    //   24: aload_1
    //   25: invokespecial <init> : (Landroid/content/Context;)V
    //   28: astore_3
    //   29: aload_3
    //   30: putstatic X/02y.A01 : LX/02y;
    //   33: ldc X/02y
    //   35: monitorexit
    //   36: aload_0
    //   37: aload_3
    //   38: getfield A00 : LX/0pM;
    //   41: putfield A02 : LX/0pM;
    //   44: aload_0
    //   45: ldc '487.0.0.0.62'
    //   47: putfield A03 : Ljava/lang/String;
    //   50: aload_0
    //   51: invokestatic A01 : ()I
    //   54: putfield A01 : I
    //   57: aload_0
    //   58: getfield A02 : LX/0pM;
    //   61: astore_3
    //   62: aload_3
    //   63: ldc 'native_version'
    //   65: iconst_m1
    //   66: invokeinterface getInt : (Ljava/lang/String;I)I
    //   71: istore_2
    //   72: iload_2
    //   73: iconst_m1
    //   74: if_icmpeq -> 85
    //   77: iload_2
    //   78: aload_0
    //   79: getfield A01 : I
    //   82: if_icmpeq -> 119
    //   85: aload_3
    //   86: invokeinterface Ac8 : ()LX/01t;
    //   91: astore_3
    //   92: aload_3
    //   93: invokeinterface AON : ()LX/01t;
    //   98: pop
    //   99: aload_3
    //   100: ldc 'native_version'
    //   102: aload_0
    //   103: getfield A01 : I
    //   106: invokeinterface DYB : (Ljava/lang/String;I)LX/01t;
    //   111: pop
    //   112: aload_3
    //   113: invokeinterface commit : ()Z
    //   118: pop
    //   119: aload_0
    //   120: aload_1
    //   121: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   124: putfield A00 : Landroid/content/Context;
    //   127: return
    //   128: astore_1
    //   129: ldc X/02y
    //   131: monitorexit
    //   132: aload_1
    //   133: athrow
    // Exception table:
    //   from	to	target	type
    //   7	12	128	finally
    //   20	33	128	finally
  }
  
  public static 02x A00(Context paramContext) {
    // Byte code:
    //   0: ldc X/02x
    //   2: monitorenter
    //   3: getstatic X/02x.A04 : LX/02x;
    //   6: astore_2
    //   7: aload_2
    //   8: astore_1
    //   9: aload_2
    //   10: ifnonnull -> 26
    //   13: new X/02x
    //   16: dup
    //   17: aload_0
    //   18: invokespecial <init> : (Landroid/content/Context;)V
    //   21: astore_1
    //   22: aload_1
    //   23: putstatic X/02x.A04 : LX/02x;
    //   26: ldc X/02x
    //   28: monitorexit
    //   29: aload_1
    //   30: areturn
    //   31: astore_0
    //   32: ldc X/02x
    //   34: monitorexit
    //   35: aload_0
    //   36: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	31	finally
    //   13	26	31	finally
  }
  
  public final int A01() {
    return this.A02.getInt("activated", 0);
  }
  
  public final int A02() {
    return (A01() == 0) ? this.A02.getInt("native_version_override", this.A01) : A01();
  }
  
  public final int A03() {
    return this.A02.getInt("next", 0);
  }
  
  public final void A04() {
    01t 01t = this.A02.Ac8();
    01t.Dce("next");
    01t.Dce("next_js_file_size");
    01t.apply();
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\02x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */