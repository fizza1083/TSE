package X;

import com.facebook.fury.context.ReqContext;
import com.facebook.fury.context.ReqContextExtensions;
import com.facebook.fury.context.ReqContextLifecycleCallbacks;
import com.facebook.fury.context.ReqContextLog;
import com.facebook.fury.context.ReqContextsCallbacks;
import com.facebook.fury.context.ReqContextsPlugin;
import com.facebook.fury.context.ThreadIdProvider;
import com.facebook.fury.props.ReqPropsProvider;
import java.util.concurrent.atomic.AtomicReference;

public final class 015 implements ReqContextsCallbacks {
  public static final ReqContextsCallbacks A00;
  
  public static final AtomicReference A01;
  
  public static final ThreadIdProvider A02;
  
  public static volatile ReqContextExtensions A03;
  
  public static volatile ReqContextLifecycleCallbacks A04;
  
  public static volatile ReqContextLog A05;
  
  public static volatile ThreadIdProvider A06;
  
  public static volatile ReqPropsProvider A07;
  
  static {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: \r\n\tat com.googlecode.dex2jar.ir.ts.NewTransformer.transform(NewTransformer.java:134)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:148)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public static ReqContext A00() {
    return ((ReqContextsPlugin)A01.get()).getActive();
  }
  
  public static ReqContext A01(ReqContext paramReqContext, String paramString, int paramInt) {
    ReqContext reqContext2 = paramReqContext;
    A06(paramReqContext, "ReqContext");
    A06(paramString, "tag");
    ReqContextsPlugin reqContextsPlugin = A01.get();
    ReqContext reqContext1 = reqContext2;
    if (paramReqContext instanceof 01L)
      reqContext1 = ((01L)reqContext2).A00; 
    if (!reqContextsPlugin.accepts(reqContext1))
      return A04(reqContext1.getTag(), paramInt); 
    0uD 0uD = 0uE.A00();
    if (0uD == 0uD.A03)
      return 01D.A00; 
    reqContext2 = A00();
    if (reqContext2 != null && 0uD != 0uD.A02 && reqContext1.hasSameProps(reqContext2)) {
      ReqPropsProvider reqPropsProvider = A07;
      if (reqPropsProvider == null || (reqPropsProvider.canEnhanceCurrentScope(reqContext2, 1, paramInt) ^ true) != 0)
        return new 01L(reqContext2); 
    } 
    return reqContextsPlugin.continueReqContext(reqContext1, paramString, 1, paramInt, 0uD);
  }
  
  public static ReqContext A02(ReqContext paramReqContext, String paramString, int paramInt) {
    ReqContext reqContext2 = paramReqContext;
    A06(paramReqContext, "ReqContext");
    A06(paramString, "tag");
    ReqContextsPlugin reqContextsPlugin = A01.get();
    ReqContext reqContext1 = reqContext2;
    if (paramReqContext instanceof 01L)
      reqContext1 = ((01L)reqContext2).A00; 
    if (!reqContextsPlugin.accepts(reqContext1)) {
      ReqContextLog reqContextLog = A05;
      if (reqContextLog != null)
        reqContextLog.d("ReqContexts", "continueFromIndirect() replaced by create()"); 
      return A04(reqContext1.getTag(), paramInt);
    } 
    0uD 0uD = 0uE.A00();
    if (0uD == 0uD.A03)
      return 01D.A00; 
    reqContext2 = A00();
    if (reqContext2 != null && 0uD != 0uD.A02 && reqContext1.hasSameProps(reqContext2)) {
      ReqPropsProvider reqPropsProvider = A07;
      if (reqPropsProvider == null || (reqPropsProvider.canEnhanceCurrentScope(reqContext2, 1, paramInt) ^ true) != 0)
        return new 01L(reqContext2); 
    } 
    return reqContextsPlugin.continueReqContext(reqContext1, paramString, 0, paramInt, 0uD);
  }
  
  public static ReqContext A03(String paramString, int paramInt) {
    A06(paramString, "tag");
    ReqContext reqContext = A04(paramString, paramInt);
    reqContext.close();
    return reqContext;
  }
  
  public static ReqContext A04(String paramString, int paramInt) {
    A06(paramString, "tag");
    0uD 0uD = 0uE.A00();
    if (0uD == 0uD.A03)
      return 01D.A00; 
    ReqContext reqContext = A00();
    if (reqContext != null && 0uE.A00() != 0uD.A02) {
      ReqPropsProvider reqPropsProvider = A07;
      if (reqPropsProvider == null || (reqPropsProvider.canEnhanceCurrentScope(reqContext, 3, paramInt) ^ true) != 0)
        return new 01L(reqContext); 
    } 
    return ((ReqContextsPlugin)A01.get()).create(paramString, paramInt, 0uD);
  }
  
  public static void A05(ReqContext paramReqContext, Throwable paramThrowable) {
    A06(paramReqContext, "ReqContext");
    ReqContextsPlugin reqContextsPlugin = A01.get();
    ReqContext reqContext = paramReqContext;
    if (paramReqContext instanceof 01L)
      reqContext = ((01L)paramReqContext).A00; 
    if (!reqContextsPlugin.accepts(reqContext)) {
      ReqContextLog reqContextLog = A05;
      if (reqContextLog != null)
        reqContextLog.w("ReqContexts", "fail() skipped"); 
      return;
    } 
    reqContextsPlugin.fail(reqContext, paramThrowable);
  }
  
  public static void A06(Object paramObject, String paramString) {
    if (paramObject != null)
      return; 
    throw 001.A0O(String.format("%s cannot be null.", new Object[] { paramString }));
  }
  
  public final long getCurrentThreadId() {
    return A06.getCurrentThreadId();
  }
  
  public final int getTrackingPolicy() {
    return (0uE.A00()).mValue;
  }
  
  public final ReqContextLifecycleCallbacks provideLifecycleCallbacks() {
    return A04;
  }
  
  public final ReqContextExtensions provideReqContextExtensions() {
    return A03;
  }
  
  public final ReqPropsProvider provideReqPropsProvider() {
    return A07;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\015.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */