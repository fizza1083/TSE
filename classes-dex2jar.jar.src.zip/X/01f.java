package X;

import android.content.Context;
import com.facebook.common.build.BuildConstants;
import java.io.File;

public final class 01f {
  public static 01f A03;
  
  public String A00;
  
  public final int A01;
  
  public final File A02;
  
  public 01f(File paramFile, String paramString) {
    this.A02 = paramFile;
    this.A01 = BuildConstants.A01();
    this.A00 = paramString;
  }
  
  public static 01f A00(Context paramContext) {
    // Byte code:
    //   0: ldc X/01f
    //   2: monitorenter
    //   3: getstatic X/01f.A03 : LX/01f;
    //   6: astore_3
    //   7: aload_3
    //   8: astore_2
    //   9: aload_3
    //   10: ifnonnull -> 172
    //   13: aload_0
    //   14: ldc 998546933
    //   16: invokestatic A00 : (Landroid/content/Context;I)Ljava/io/File;
    //   19: ldc 'ota_version'
    //   21: invokestatic A0E : (Ljava/io/File;Ljava/lang/String;)Ljava/io/File;
    //   24: astore #5
    //   26: aload #5
    //   28: invokevirtual canRead : ()Z
    //   31: istore_1
    //   32: ldc '0'
    //   34: astore_3
    //   35: aload_3
    //   36: astore_0
    //   37: iload_1
    //   38: ifeq -> 157
    //   41: aconst_null
    //   42: astore #4
    //   44: aload #4
    //   46: astore_0
    //   47: aload #5
    //   49: invokestatic A0E : (Ljava/io/File;)Ljava/io/BufferedReader;
    //   52: astore #6
    //   54: aload #6
    //   56: invokevirtual readLine : ()Ljava/lang/String;
    //   59: astore_2
    //   60: aload_2
    //   61: astore_0
    //   62: aload #6
    //   64: invokevirtual close : ()V
    //   67: goto -> 95
    //   70: astore_2
    //   71: aload #6
    //   73: invokevirtual close : ()V
    //   76: goto -> 90
    //   79: astore #6
    //   81: aload #4
    //   83: astore_0
    //   84: aload_2
    //   85: aload #6
    //   87: invokestatic A00 : (Ljava/lang/Throwable;Ljava/lang/Throwable;)V
    //   90: aload #4
    //   92: astore_0
    //   93: aload_2
    //   94: athrow
    //   95: ldc '-1'
    //   97: astore #4
    //   99: aload #4
    //   101: astore_0
    //   102: aload_2
    //   103: ifnull -> 195
    //   106: aload #4
    //   108: astore_0
    //   109: aload_2
    //   110: invokevirtual isEmpty : ()Z
    //   113: ifne -> 195
    //   116: aload_2
    //   117: ldc '-'
    //   119: iconst_2
    //   120: invokevirtual split : (Ljava/lang/String;I)[Ljava/lang/String;
    //   123: astore_2
    //   124: aload #4
    //   126: astore_0
    //   127: aload_2
    //   128: arraylength
    //   129: iconst_2
    //   130: if_icmpne -> 195
    //   133: aload_3
    //   134: astore_0
    //   135: aload_2
    //   136: iconst_0
    //   137: aaload
    //   138: invokestatic A01 : ()I
    //   141: invokestatic toString : (I)Ljava/lang/String;
    //   144: invokevirtual equals : (Ljava/lang/Object;)Z
    //   147: ifeq -> 157
    //   150: aload_2
    //   151: iconst_1
    //   152: aaload
    //   153: astore_0
    //   154: goto -> 195
    //   157: new X/01f
    //   160: dup
    //   161: aload #5
    //   163: aload_0
    //   164: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   167: astore_2
    //   168: aload_2
    //   169: putstatic X/01f.A03 : LX/01f;
    //   172: ldc X/01f
    //   174: monitorexit
    //   175: aload_2
    //   176: areturn
    //   177: astore_0
    //   178: ldc X/01f
    //   180: monitorexit
    //   181: aload_0
    //   182: athrow
    //   183: astore_0
    //   184: aload_3
    //   185: astore_0
    //   186: goto -> 157
    //   189: astore_2
    //   190: aload_0
    //   191: astore_2
    //   192: goto -> 95
    //   195: goto -> 157
    // Exception table:
    //   from	to	target	type
    //   3	7	177	finally
    //   13	32	177	finally
    //   47	54	183	java/io/FileNotFoundException
    //   47	54	189	java/io/IOException
    //   47	54	177	finally
    //   54	60	70	finally
    //   62	67	183	java/io/FileNotFoundException
    //   62	67	189	java/io/IOException
    //   62	67	177	finally
    //   71	76	79	finally
    //   84	90	183	java/io/FileNotFoundException
    //   84	90	189	java/io/IOException
    //   84	90	177	finally
    //   93	95	183	java/io/FileNotFoundException
    //   93	95	189	java/io/IOException
    //   93	95	177	finally
    //   109	124	177	finally
    //   127	133	177	finally
    //   135	150	177	finally
    //   157	172	177	finally
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */