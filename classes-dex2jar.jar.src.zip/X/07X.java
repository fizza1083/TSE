package X;

public final class 07X implements Runnable {
  public static final String __redex_internal_original_name = "FsStats$FsStatsReporter$1";
  
  public 07X(07W param07W) {}
  
  public final void run() {
    07W 07W1 = this.A00;
    07W1.A03.set(049.A01().A06(0Xy.A00) >> 10L);
    07W1.A00.open();
    07W1.A02.set(false);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07X.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */