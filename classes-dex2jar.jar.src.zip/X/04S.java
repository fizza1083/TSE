package X;

import java.util.Map;
import java.util.WeakHashMap;

public final class 04S {
  public static 04S A03;
  
  public long A00 = 0L;
  
  public final Map A01 = new WeakHashMap<Object, Object>();
  
  public volatile 04W A02 = new 04U(this);
  
  public static 04S A00() {
    // Byte code:
    //   0: ldc X/04S
    //   2: monitorenter
    //   3: getstatic X/04S.A03 : LX/04S;
    //   6: astore_1
    //   7: aload_1
    //   8: astore_0
    //   9: aload_1
    //   10: ifnonnull -> 25
    //   13: new X/04S
    //   16: dup
    //   17: invokespecial <init> : ()V
    //   20: astore_0
    //   21: aload_0
    //   22: putstatic X/04S.A03 : LX/04S;
    //   25: ldc X/04S
    //   27: monitorexit
    //   28: aload_0
    //   29: areturn
    //   30: astore_0
    //   31: ldc X/04S
    //   33: monitorexit
    //   34: aload_0
    //   35: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	30	finally
    //   13	25	30	finally
  }
  
  public final void A01(04Y param04Y, Object paramObject, int paramInt) {
    synchronized (this.A01) {
      this.A00++;
      null.put(paramObject, new 04a(param04Y, this.A02.E8L(), paramInt, this.A00));
      return;
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\04S.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */