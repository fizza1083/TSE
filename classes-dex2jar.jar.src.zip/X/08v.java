package X;

import android.os.BadParcelableException;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentState;

public final class 08v {
  public int A00 = -1;
  
  public boolean A01 = false;
  
  public final Fragment A02;
  
  public final 0D4 A03;
  
  public final 0D0 A04;
  
  public 08v(Bundle paramBundle, 0D4 param0D4, 0D8 param0D8, 0D0 param0D0, ClassLoader paramClassLoader) {
    this.A03 = param0D4;
    this.A04 = param0D0;
    Fragment fragment = ((FragmentState)paramBundle.getParcelable("state")).A00(param0D8);
    this.A02 = fragment;
    fragment.mSavedFragmentState = paramBundle;
    paramBundle = paramBundle.getBundle("arguments");
    if (paramBundle != null)
      paramBundle.setClassLoader(paramClassLoader); 
    fragment.setArguments(paramBundle);
  }
  
  public 08v(Bundle paramBundle, Fragment paramFragment, 0D4 param0D4, 0D0 param0D0) {
    this.A03 = param0D4;
    this.A04 = param0D0;
    this.A02 = paramFragment;
    paramFragment.mSavedViewState = null;
    paramFragment.mSavedViewRegistryState = null;
    paramFragment.mBackStackNesting = 0;
    paramFragment.mInLayout = false;
    paramFragment.mAdded = false;
    Fragment fragment = paramFragment.mTarget;
    if (fragment != null) {
      String str = fragment.mWho;
    } else {
      fragment = null;
    } 
    paramFragment.mTargetWho = (String)fragment;
    paramFragment.mTarget = null;
    paramFragment.mSavedFragmentState = paramBundle;
    paramFragment.mArguments = paramBundle.getBundle("arguments");
  }
  
  public 08v(Fragment paramFragment, 0D4 param0D4, 0D0 param0D0) {
    this.A03 = param0D4;
    this.A04 = param0D0;
    this.A02 = paramFragment;
  }
  
  private final void A00() {
    Fragment fragment = this.A02;
    View view = fragment.mView;
    if (view != null) {
      SparseArray sparseArray = new SparseArray();
      view.saveHierarchyState(sparseArray);
      if (sparseArray.size() > 0)
        fragment.mSavedViewState = sparseArray; 
      Bundle bundle = new Bundle();
      fragment.mViewLifecycleOwner.A01.A02(bundle);
      if (!bundle.isEmpty())
        fragment.mSavedViewRegistryState = bundle; 
    } 
  }
  
  public final Bundle A01() {
    Bundle bundle1 = new Bundle();
    Fragment fragment = this.A02;
    if (fragment.mState == -1) {
      Bundle bundle = fragment.mSavedFragmentState;
      if (bundle != null)
        bundle1.putAll(bundle); 
    } 
    bundle1.putParcelable("state", (Parcelable)new FragmentState(fragment));
    if (fragment.mState > -1) {
      Bundle bundle4 = new Bundle();
      fragment.onSaveInstanceState(bundle4);
      if (!bundle4.isEmpty())
        bundle1.putBundle("savedInstanceState", bundle4); 
      this.A03.A04(bundle4, fragment, false);
      bundle4 = new Bundle();
      fragment.mSavedStateRegistryController.A02(bundle4);
      if (!bundle4.isEmpty())
        bundle1.putBundle("registryState", bundle4); 
      bundle4 = fragment.mChildFragmentManager.A0M();
      if (!bundle4.isEmpty())
        bundle1.putBundle("childFragmentManager", bundle4); 
      if (fragment.mView != null)
        A00(); 
      SparseArray sparseArray = fragment.mSavedViewState;
      if (sparseArray != null)
        bundle1.putSparseParcelableArray("viewState", sparseArray); 
      Bundle bundle3 = fragment.mSavedViewRegistryState;
      if (bundle3 != null)
        bundle1.putBundle("viewRegistryState", bundle3); 
    } 
    Bundle bundle2 = fragment.mArguments;
    if (bundle2 != null)
      bundle1.putBundle("arguments", bundle2); 
    return bundle1;
  }
  
  public final void A02() {
    // Byte code:
    //   0: aload_0
    //   1: getfield A02 : Landroidx/fragment/app/Fragment;
    //   4: astore #7
    //   6: aload #7
    //   8: getfield mContainer : Landroid/view/ViewGroup;
    //   11: astore #5
    //   13: aload #5
    //   15: ifnull -> 339
    //   18: aload #5
    //   20: ldc 2131365349
    //   22: invokevirtual getTag : (I)Ljava/lang/Object;
    //   25: astore #6
    //   27: aload #6
    //   29: instanceof androidx/fragment/app/Fragment
    //   32: ifeq -> 308
    //   35: aload #6
    //   37: checkcast androidx/fragment/app/Fragment
    //   40: astore #6
    //   42: aload #6
    //   44: ifnull -> 308
    //   47: aload #6
    //   49: astore #5
    //   51: aload #7
    //   53: getfield mParentFragment : Landroidx/fragment/app/Fragment;
    //   56: astore #6
    //   58: aload #5
    //   60: ifnull -> 130
    //   63: aload #5
    //   65: aload #6
    //   67: invokevirtual equals : (Ljava/lang/Object;)Z
    //   70: ifne -> 130
    //   73: aload #7
    //   75: getfield mContainerId : I
    //   78: istore_1
    //   79: getstatic X/08p.A01 : LX/08p;
    //   82: astore #6
    //   84: new X/19w
    //   87: dup
    //   88: aload #7
    //   90: aload #5
    //   92: iload_1
    //   93: invokespecial <init> : (Landroidx/fragment/app/Fragment;Landroidx/fragment/app/Fragment;I)V
    //   96: astore #5
    //   98: aload #7
    //   100: invokestatic A00 : (Landroidx/fragment/app/Fragment;)LX/08q;
    //   103: astore #6
    //   105: aload #6
    //   107: getfield A01 : Ljava/util/Set;
    //   110: getstatic X/08t.A07 : LX/08t;
    //   113: invokeinterface contains : (Ljava/lang/Object;)Z
    //   118: ifeq -> 130
    //   121: aload #6
    //   123: aload #5
    //   125: aload #7
    //   127: invokestatic A0l : (LX/08q;LX/08s;Ljava/lang/Object;)V
    //   130: aload_0
    //   131: getfield A04 : LX/0D0;
    //   134: astore #6
    //   136: aload #7
    //   138: getfield mContainer : Landroid/view/ViewGroup;
    //   141: astore #5
    //   143: iconst_m1
    //   144: istore_3
    //   145: iload_3
    //   146: istore_1
    //   147: aload #5
    //   149: ifnull -> 223
    //   152: aload #6
    //   154: getfield A01 : Ljava/util/ArrayList;
    //   157: astore #6
    //   159: aload #6
    //   161: aload #7
    //   163: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   166: istore #4
    //   168: iload #4
    //   170: iconst_1
    //   171: isub
    //   172: istore_2
    //   173: iload #4
    //   175: istore_1
    //   176: iload_2
    //   177: iflt -> 245
    //   180: aload #6
    //   182: iload_2
    //   183: invokevirtual get : (I)Ljava/lang/Object;
    //   186: checkcast androidx/fragment/app/Fragment
    //   189: astore #8
    //   191: aload #8
    //   193: getfield mContainer : Landroid/view/ViewGroup;
    //   196: aload #5
    //   198: if_acmpne -> 238
    //   201: aload #8
    //   203: getfield mView : Landroid/view/View;
    //   206: astore #8
    //   208: aload #8
    //   210: ifnull -> 238
    //   213: aload #5
    //   215: aload #8
    //   217: invokevirtual indexOfChild : (Landroid/view/View;)I
    //   220: iconst_1
    //   221: iadd
    //   222: istore_1
    //   223: aload #7
    //   225: getfield mContainer : Landroid/view/ViewGroup;
    //   228: aload #7
    //   230: getfield mView : Landroid/view/View;
    //   233: iload_1
    //   234: invokevirtual addView : (Landroid/view/View;I)V
    //   237: return
    //   238: iload_2
    //   239: iconst_1
    //   240: isub
    //   241: istore_2
    //   242: goto -> 173
    //   245: iload_1
    //   246: iconst_1
    //   247: iadd
    //   248: istore_2
    //   249: iload_3
    //   250: istore_1
    //   251: iload_2
    //   252: aload #6
    //   254: invokevirtual size : ()I
    //   257: if_icmpge -> 223
    //   260: aload #6
    //   262: iload_2
    //   263: invokevirtual get : (I)Ljava/lang/Object;
    //   266: checkcast androidx/fragment/app/Fragment
    //   269: astore #8
    //   271: iload_2
    //   272: istore_1
    //   273: aload #8
    //   275: getfield mContainer : Landroid/view/ViewGroup;
    //   278: aload #5
    //   280: if_acmpne -> 245
    //   283: aload #8
    //   285: getfield mView : Landroid/view/View;
    //   288: astore #8
    //   290: iload_2
    //   291: istore_1
    //   292: aload #8
    //   294: ifnull -> 245
    //   297: aload #5
    //   299: aload #8
    //   301: invokevirtual indexOfChild : (Landroid/view/View;)I
    //   304: istore_1
    //   305: goto -> 223
    //   308: aload #5
    //   310: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   313: astore #5
    //   315: aload #5
    //   317: instanceof android/view/View
    //   320: ifeq -> 333
    //   323: aload #5
    //   325: checkcast android/view/View
    //   328: astore #5
    //   330: goto -> 13
    //   333: aconst_null
    //   334: astore #5
    //   336: goto -> 13
    //   339: aconst_null
    //   340: astore #5
    //   342: goto -> 51
  }
  
  public final void A03() {
    Fragment fragment = this.A02;
    if (fragment.mFromLayout && fragment.mInLayout && !fragment.mPerformedCreateView) {
      Bundle bundle = fragment.mSavedFragmentState;
      if (bundle != null) {
        bundle = bundle.getBundle("savedInstanceState");
      } else {
        bundle = null;
      } 
      LayoutInflater layoutInflater = fragment.onGetLayoutInflater(bundle);
      fragment.mLayoutInflater = layoutInflater;
      fragment.performCreateView(layoutInflater, null, bundle);
      View view = fragment.mView;
      if (view != null) {
        view.setSaveFromParentEnabled(false);
        fragment.mView.setTag(2131365349, fragment);
        if (fragment.mHidden)
          fragment.mView.setVisibility(8); 
        fragment.performViewCreated();
        this.A03.A00(bundle, fragment.mView, fragment, false);
        fragment.mState = 2;
      } 
    } 
  }
  
  public final void A04() {
    // Byte code:
    //   0: aload_0
    //   1: getfield A01 : Z
    //   4: ifne -> 2802
    //   7: aload_0
    //   8: iconst_1
    //   9: putfield A01 : Z
    //   12: iconst_0
    //   13: istore #4
    //   15: aload_0
    //   16: getfield A02 : Landroidx/fragment/app/Fragment;
    //   19: astore #10
    //   21: aload #10
    //   23: getfield mFragmentManager : LX/0Cy;
    //   26: ifnonnull -> 2048
    //   29: aload #10
    //   31: getfield mState : I
    //   34: istore_1
    //   35: aload #10
    //   37: getfield mState : I
    //   40: istore_2
    //   41: iload_1
    //   42: iload_2
    //   43: if_icmpeq -> 2582
    //   46: iload_1
    //   47: iload_2
    //   48: if_icmple -> 2845
    //   51: iload_2
    //   52: iconst_1
    //   53: iadd
    //   54: tableswitch default -> 2808, 0 -> 660, 1 -> 921, 2 -> 165, 3 -> 1002, 4 -> 100, 5 -> 1047, 6 -> 2819, 7 -> 1065
    //   100: aload #10
    //   102: getfield mView : Landroid/view/View;
    //   105: ifnull -> 2814
    //   108: aload #10
    //   110: getfield mContainer : Landroid/view/ViewGroup;
    //   113: astore #7
    //   115: aload #7
    //   117: ifnull -> 2814
    //   120: aload #7
    //   122: aload #10
    //   124: invokevirtual getParentFragmentManager : ()LX/0Cy;
    //   127: invokestatic A00 : (Landroid/view/ViewGroup;LX/0Cy;)LX/097;
    //   130: astore #7
    //   132: aload #10
    //   134: getfield mView : Landroid/view/View;
    //   137: invokevirtual getVisibility : ()I
    //   140: invokestatic A00 : (I)Ljava/lang/Integer;
    //   143: astore #8
    //   145: aload #8
    //   147: iconst_0
    //   148: invokestatic A0E : (Ljava/lang/Object;I)V
    //   151: aload_0
    //   152: aload #7
    //   154: aload #8
    //   156: getstatic X/0Xy.A01 : Ljava/lang/Integer;
    //   159: invokestatic A03 : (LX/08v;LX/097;Ljava/lang/Integer;Ljava/lang/Integer;)V
    //   162: goto -> 2814
    //   165: aload_0
    //   166: invokevirtual A03 : ()V
    //   169: aload #10
    //   171: getfield mFromLayout : Z
    //   174: ifne -> 2808
    //   177: aload #10
    //   179: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   182: astore #8
    //   184: aconst_null
    //   185: astore #7
    //   187: aload #8
    //   189: ifnull -> 2825
    //   192: aload #8
    //   194: ldc 'savedInstanceState'
    //   196: invokevirtual getBundle : (Ljava/lang/String;)Landroid/os/Bundle;
    //   199: astore #8
    //   201: aload #10
    //   203: aload #8
    //   205: invokevirtual onGetLayoutInflater : (Landroid/os/Bundle;)Landroid/view/LayoutInflater;
    //   208: astore #11
    //   210: aload #10
    //   212: aload #11
    //   214: putfield mLayoutInflater : Landroid/view/LayoutInflater;
    //   217: aload #10
    //   219: getfield mContainer : Landroid/view/ViewGroup;
    //   222: astore #9
    //   224: aload #9
    //   226: ifnull -> 232
    //   229: goto -> 2831
    //   232: aload #10
    //   234: getfield mContainerId : I
    //   237: istore_1
    //   238: iload_1
    //   239: ifeq -> 484
    //   242: iload_1
    //   243: iconst_m1
    //   244: if_icmpeq -> 379
    //   247: aload #10
    //   249: getfield mFragmentManager : LX/0Cy;
    //   252: getfield A08 : LX/0Cv;
    //   255: iload_1
    //   256: invokevirtual A00 : (I)Landroid/view/View;
    //   259: checkcast android/view/ViewGroup
    //   262: astore #9
    //   264: aload #9
    //   266: ifnonnull -> 414
    //   269: aload #9
    //   271: astore #7
    //   273: aload #10
    //   275: getfield mRestored : Z
    //   278: ifne -> 484
    //   281: aload #9
    //   283: astore #7
    //   285: aload #10
    //   287: getfield mInDynamicContainer : Z
    //   290: ifne -> 484
    //   293: aload #10
    //   295: invokevirtual requireContext : ()Landroid/content/Context;
    //   298: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   301: aload #10
    //   303: getfield mContainerId : I
    //   306: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   309: astore #7
    //   311: goto -> 319
    //   314: ldc_w 'unknown'
    //   317: astore #7
    //   319: invokestatic A0s : ()Ljava/lang/StringBuilder;
    //   322: astore #8
    //   324: aload #8
    //   326: ldc_w 'No view found for id 0x'
    //   329: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   332: pop
    //   333: aload #8
    //   335: aload #10
    //   337: getfield mContainerId : I
    //   340: invokestatic toHexString : (I)Ljava/lang/String;
    //   343: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   346: pop
    //   347: aload #8
    //   349: ldc_w ' ('
    //   352: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   355: pop
    //   356: aload #8
    //   358: aload #7
    //   360: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   363: pop
    //   364: aload #10
    //   366: ldc_w ') for fragment '
    //   369: aload #8
    //   371: invokestatic A0J : (Ljava/lang/Object;Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/IllegalArgumentException;
    //   374: astore #7
    //   376: goto -> 918
    //   379: invokestatic A0s : ()Ljava/lang/StringBuilder;
    //   382: astore #7
    //   384: aload #7
    //   386: ldc_w 'Cannot create fragment '
    //   389: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   392: pop
    //   393: aload #7
    //   395: aload #10
    //   397: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   400: pop
    //   401: ldc_w ' for a container view with no id'
    //   404: aload #7
    //   406: invokestatic A0K : (Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/IllegalArgumentException;
    //   409: astore #7
    //   411: goto -> 918
    //   414: aload #9
    //   416: astore #7
    //   418: aload #9
    //   420: instanceof androidx/fragment/app/FragmentContainerView
    //   423: ifne -> 484
    //   426: getstatic X/08p.A01 : LX/08p;
    //   429: astore #7
    //   431: new X/091
    //   434: dup
    //   435: aload #9
    //   437: aload #10
    //   439: invokespecial <init> : (Landroid/view/ViewGroup;Landroidx/fragment/app/Fragment;)V
    //   442: astore #12
    //   444: aload #10
    //   446: invokestatic A00 : (Landroidx/fragment/app/Fragment;)LX/08q;
    //   449: astore #13
    //   451: aload #9
    //   453: astore #7
    //   455: aload #13
    //   457: getfield A01 : Ljava/util/Set;
    //   460: getstatic X/08t.A06 : LX/08t;
    //   463: invokeinterface contains : (Ljava/lang/Object;)Z
    //   468: ifeq -> 484
    //   471: aload #13
    //   473: aload #12
    //   475: aload #10
    //   477: invokestatic A0l : (LX/08q;LX/08s;Ljava/lang/Object;)V
    //   480: aload #9
    //   482: astore #7
    //   484: aload #10
    //   486: aload #7
    //   488: putfield mContainer : Landroid/view/ViewGroup;
    //   491: aload #10
    //   493: aload #11
    //   495: aload #7
    //   497: aload #8
    //   499: invokevirtual performCreateView : (Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)V
    //   502: aload #10
    //   504: getfield mView : Landroid/view/View;
    //   507: astore #9
    //   509: aload #9
    //   511: ifnull -> 1685
    //   514: aload #9
    //   516: iconst_0
    //   517: invokevirtual setSaveFromParentEnabled : (Z)V
    //   520: aload #10
    //   522: getfield mView : Landroid/view/View;
    //   525: ldc 2131365349
    //   527: aload #10
    //   529: invokevirtual setTag : (ILjava/lang/Object;)V
    //   532: aload #7
    //   534: ifnull -> 541
    //   537: aload_0
    //   538: invokevirtual A02 : ()V
    //   541: aload #10
    //   543: getfield mHidden : Z
    //   546: ifeq -> 559
    //   549: aload #10
    //   551: getfield mView : Landroid/view/View;
    //   554: bipush #8
    //   556: invokevirtual setVisibility : (I)V
    //   559: aload #10
    //   561: getfield mView : Landroid/view/View;
    //   564: invokevirtual isAttachedToWindow : ()Z
    //   567: istore #5
    //   569: aload #10
    //   571: getfield mView : Landroid/view/View;
    //   574: astore #7
    //   576: iload #5
    //   578: ifeq -> 641
    //   581: aload #7
    //   583: invokevirtual requestApplyInsets : ()V
    //   586: aload #10
    //   588: invokevirtual performViewCreated : ()V
    //   591: aload_0
    //   592: getfield A03 : LX/0D4;
    //   595: aload #8
    //   597: aload #10
    //   599: getfield mView : Landroid/view/View;
    //   602: aload #10
    //   604: iconst_0
    //   605: invokevirtual A00 : (Landroid/os/Bundle;Landroid/view/View;Landroidx/fragment/app/Fragment;Z)V
    //   608: aload #10
    //   610: getfield mView : Landroid/view/View;
    //   613: invokevirtual getVisibility : ()I
    //   616: istore_1
    //   617: aload #10
    //   619: aload #10
    //   621: getfield mView : Landroid/view/View;
    //   624: invokevirtual getAlpha : ()F
    //   627: invokevirtual setPostOnViewCreatedAlpha : (F)V
    //   630: aload #10
    //   632: getfield mContainer : Landroid/view/ViewGroup;
    //   635: ifnull -> 1685
    //   638: goto -> 2838
    //   641: aload #7
    //   643: new X/1Bh
    //   646: dup
    //   647: iconst_1
    //   648: aload #7
    //   650: aload_0
    //   651: invokespecial <init> : (ILjava/lang/Object;Ljava/lang/Object;)V
    //   654: invokevirtual addOnAttachStateChangeListener : (Landroid/view/View$OnAttachStateChangeListener;)V
    //   657: goto -> 586
    //   660: aload #10
    //   662: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   665: astore #8
    //   667: aload #8
    //   669: ifnull -> 834
    //   672: aload_0
    //   673: getfield A04 : LX/0D0;
    //   676: astore #7
    //   678: aload #8
    //   680: getfield mWho : Ljava/lang/String;
    //   683: astore #8
    //   685: aload #7
    //   687: getfield A02 : Ljava/util/HashMap;
    //   690: aload #8
    //   692: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   695: checkcast X/08v
    //   698: astore #7
    //   700: aload #7
    //   702: ifnull -> 785
    //   705: aload #10
    //   707: aload #10
    //   709: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   712: getfield mWho : Ljava/lang/String;
    //   715: putfield mTargetWho : Ljava/lang/String;
    //   718: aload #10
    //   720: aconst_null
    //   721: putfield mTarget : Landroidx/fragment/app/Fragment;
    //   724: aload #7
    //   726: invokevirtual A04 : ()V
    //   729: aload #10
    //   731: getfield mFragmentManager : LX/0Cy;
    //   734: astore #7
    //   736: aload #10
    //   738: aload #7
    //   740: getfield A09 : LX/0Cu;
    //   743: putfield mHost : LX/0Cu;
    //   746: aload #10
    //   748: aload #7
    //   750: getfield A06 : Landroidx/fragment/app/Fragment;
    //   753: putfield mParentFragment : Landroidx/fragment/app/Fragment;
    //   756: aload_0
    //   757: getfield A03 : LX/0D4;
    //   760: astore #7
    //   762: aload #7
    //   764: aload #10
    //   766: invokevirtual A05 : (Landroidx/fragment/app/Fragment;)V
    //   769: aload #10
    //   771: invokevirtual performAttach : ()V
    //   774: aload #7
    //   776: aload #10
    //   778: iconst_0
    //   779: invokevirtual A07 : (Landroidx/fragment/app/Fragment;Z)V
    //   782: goto -> 2808
    //   785: ldc_w 'Fragment '
    //   788: invokestatic A0u : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   791: astore #7
    //   793: aload #7
    //   795: aload #10
    //   797: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   800: pop
    //   801: aload #7
    //   803: ldc_w ' declared target fragment '
    //   806: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   809: pop
    //   810: aload #7
    //   812: aload #10
    //   814: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   817: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   820: pop
    //   821: ldc_w ' that does not belong to this FragmentManager!'
    //   824: aload #7
    //   826: invokestatic A0N : (Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/IllegalStateException;
    //   829: astore #7
    //   831: goto -> 918
    //   834: aload #10
    //   836: getfield mTargetWho : Ljava/lang/String;
    //   839: astore #7
    //   841: aload #7
    //   843: ifnull -> 729
    //   846: aload_0
    //   847: getfield A04 : LX/0D0;
    //   850: getfield A02 : Ljava/util/HashMap;
    //   853: aload #7
    //   855: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   858: checkcast X/08v
    //   861: astore #8
    //   863: aload #8
    //   865: astore #7
    //   867: aload #8
    //   869: ifnonnull -> 724
    //   872: ldc_w 'Fragment '
    //   875: invokestatic A0u : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   878: astore #7
    //   880: aload #7
    //   882: aload #10
    //   884: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   887: pop
    //   888: aload #7
    //   890: ldc_w ' declared target fragment '
    //   893: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   896: pop
    //   897: aload #7
    //   899: aload #10
    //   901: getfield mTargetWho : Ljava/lang/String;
    //   904: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   907: pop
    //   908: ldc_w ' that does not belong to this FragmentManager!'
    //   911: aload #7
    //   913: invokestatic A0N : (Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/IllegalStateException;
    //   916: astore #7
    //   918: aload #7
    //   920: athrow
    //   921: aconst_null
    //   922: astore #7
    //   924: aload #10
    //   926: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   929: astore #8
    //   931: aload #8
    //   933: ifnull -> 945
    //   936: aload #8
    //   938: ldc 'savedInstanceState'
    //   940: invokevirtual getBundle : (Ljava/lang/String;)Landroid/os/Bundle;
    //   943: astore #7
    //   945: aload #10
    //   947: getfield mIsCreated : Z
    //   950: ifne -> 988
    //   953: aload_0
    //   954: getfield A03 : LX/0D4;
    //   957: astore #8
    //   959: aload #8
    //   961: aload #7
    //   963: aload #10
    //   965: invokevirtual A02 : (Landroid/os/Bundle;Landroidx/fragment/app/Fragment;)V
    //   968: aload #10
    //   970: aload #7
    //   972: invokevirtual performCreate : (Landroid/os/Bundle;)V
    //   975: aload #8
    //   977: aload #7
    //   979: aload #10
    //   981: iconst_0
    //   982: invokevirtual A03 : (Landroid/os/Bundle;Landroidx/fragment/app/Fragment;Z)V
    //   985: goto -> 2808
    //   988: aload #10
    //   990: iconst_1
    //   991: putfield mState : I
    //   994: aload #10
    //   996: invokevirtual restoreChildFragmentState : ()V
    //   999: goto -> 2808
    //   1002: aconst_null
    //   1003: astore #7
    //   1005: aload #10
    //   1007: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1010: astore #8
    //   1012: aload #8
    //   1014: ifnull -> 1026
    //   1017: aload #8
    //   1019: ldc 'savedInstanceState'
    //   1021: invokevirtual getBundle : (Ljava/lang/String;)Landroid/os/Bundle;
    //   1024: astore #7
    //   1026: aload #10
    //   1028: aload #7
    //   1030: invokevirtual performActivityCreated : (Landroid/os/Bundle;)V
    //   1033: aload_0
    //   1034: getfield A03 : LX/0D4;
    //   1037: aload #7
    //   1039: aload #10
    //   1041: invokevirtual A01 : (Landroid/os/Bundle;Landroidx/fragment/app/Fragment;)V
    //   1044: goto -> 2808
    //   1047: aload #10
    //   1049: invokevirtual performStart : ()V
    //   1052: aload_0
    //   1053: getfield A03 : LX/0D4;
    //   1056: aload #10
    //   1058: iconst_0
    //   1059: invokevirtual A0C : (Landroidx/fragment/app/Fragment;Z)V
    //   1062: goto -> 2808
    //   1065: aload #10
    //   1067: invokevirtual getFocusedView : ()Landroid/view/View;
    //   1070: astore #8
    //   1072: aload #8
    //   1074: ifnull -> 1143
    //   1077: aload #8
    //   1079: aload #10
    //   1081: getfield mView : Landroid/view/View;
    //   1084: if_acmpeq -> 1121
    //   1087: aload #8
    //   1089: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   1092: astore #7
    //   1094: aload #7
    //   1096: ifnull -> 1143
    //   1099: aload #7
    //   1101: aload #10
    //   1103: getfield mView : Landroid/view/View;
    //   1106: if_acmpeq -> 1121
    //   1109: aload #7
    //   1111: invokeinterface getParent : ()Landroid/view/ViewParent;
    //   1116: astore #7
    //   1118: goto -> 1094
    //   1121: aload #8
    //   1123: invokevirtual requestFocus : ()Z
    //   1126: pop
    //   1127: iconst_2
    //   1128: invokestatic A0H : (I)Z
    //   1131: ifeq -> 1143
    //   1134: aload #10
    //   1136: getfield mView : Landroid/view/View;
    //   1139: invokevirtual findFocus : ()Landroid/view/View;
    //   1142: pop
    //   1143: aload #10
    //   1145: aconst_null
    //   1146: invokevirtual setFocusedView : (Landroid/view/View;)V
    //   1149: aload #10
    //   1151: invokevirtual performResume : ()V
    //   1154: aload_0
    //   1155: getfield A03 : LX/0D4;
    //   1158: aload #10
    //   1160: iconst_0
    //   1161: invokevirtual A0B : (Landroidx/fragment/app/Fragment;Z)V
    //   1164: aload_0
    //   1165: getfield A04 : LX/0D0;
    //   1168: astore #7
    //   1170: aload #10
    //   1172: getfield mWho : Ljava/lang/String;
    //   1175: astore #8
    //   1177: aload #7
    //   1179: getfield A03 : Ljava/util/HashMap;
    //   1182: aload #8
    //   1184: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1187: pop
    //   1188: aload #10
    //   1190: aconst_null
    //   1191: putfield mSavedFragmentState : Landroid/os/Bundle;
    //   1194: aload #10
    //   1196: aconst_null
    //   1197: putfield mSavedViewState : Landroid/util/SparseArray;
    //   1200: aload #10
    //   1202: aconst_null
    //   1203: putfield mSavedViewRegistryState : Landroid/os/Bundle;
    //   1206: goto -> 2808
    //   1209: aload #10
    //   1211: getfield mBeingSaved : Z
    //   1214: ifeq -> 1265
    //   1217: aload_0
    //   1218: getfield A04 : LX/0D0;
    //   1221: astore #8
    //   1223: aload #10
    //   1225: getfield mWho : Ljava/lang/String;
    //   1228: astore #7
    //   1230: aload #8
    //   1232: getfield A03 : Ljava/util/HashMap;
    //   1235: astore #8
    //   1237: aload #8
    //   1239: aload #7
    //   1241: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1244: checkcast android/os/Bundle
    //   1247: ifnonnull -> 1265
    //   1250: aload #8
    //   1252: aload #10
    //   1254: getfield mWho : Ljava/lang/String;
    //   1257: aload_0
    //   1258: invokevirtual A01 : ()Landroid/os/Bundle;
    //   1261: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1264: pop
    //   1265: aload #10
    //   1267: getfield mRemoving : Z
    //   1270: istore #6
    //   1272: iconst_1
    //   1273: istore #5
    //   1275: iload #6
    //   1277: ifeq -> 2899
    //   1280: aload #10
    //   1282: getfield mBackStackNesting : I
    //   1285: invokestatic A13 : (I)Z
    //   1288: istore #6
    //   1290: iconst_1
    //   1291: istore_1
    //   1292: iload #6
    //   1294: ifeq -> 2901
    //   1297: goto -> 2899
    //   1300: aload_0
    //   1301: getfield A04 : LX/0D0;
    //   1304: astore #7
    //   1306: aload #7
    //   1308: getfield A00 : LX/0DZ;
    //   1311: astore #8
    //   1313: aload #8
    //   1315: getfield A03 : Ljava/util/HashMap;
    //   1318: aload #10
    //   1320: getfield mWho : Ljava/lang/String;
    //   1323: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   1326: ifeq -> 1427
    //   1329: aload #8
    //   1331: getfield A05 : Z
    //   1334: ifeq -> 1427
    //   1337: aload #8
    //   1339: getfield A00 : Z
    //   1342: ifne -> 1427
    //   1345: aload #10
    //   1347: getfield mTargetWho : Ljava/lang/String;
    //   1350: astore #8
    //   1352: aload #8
    //   1354: ifnull -> 1386
    //   1357: aload #7
    //   1359: aload #8
    //   1361: invokevirtual A00 : (Ljava/lang/String;)Landroidx/fragment/app/Fragment;
    //   1364: astore #7
    //   1366: aload #7
    //   1368: ifnull -> 1386
    //   1371: aload #7
    //   1373: getfield mRetainInstance : Z
    //   1376: ifeq -> 1386
    //   1379: aload #10
    //   1381: aload #7
    //   1383: putfield mTarget : Landroidx/fragment/app/Fragment;
    //   1386: aload #10
    //   1388: iconst_0
    //   1389: putfield mState : I
    //   1392: goto -> 2808
    //   1395: aload #10
    //   1397: getfield mBeingSaved : Z
    //   1400: ifne -> 1427
    //   1403: aload_0
    //   1404: getfield A04 : LX/0D0;
    //   1407: astore #7
    //   1409: aload #10
    //   1411: getfield mWho : Ljava/lang/String;
    //   1414: astore #8
    //   1416: aload #7
    //   1418: getfield A03 : Ljava/util/HashMap;
    //   1421: aload #8
    //   1423: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1426: pop
    //   1427: aload #10
    //   1429: getfield mHost : LX/0Cu;
    //   1432: astore #7
    //   1434: aload #7
    //   1436: instanceof X/0Bt
    //   1439: ifeq -> 1457
    //   1442: aload_0
    //   1443: getfield A04 : LX/0D0;
    //   1446: getfield A00 : LX/0DZ;
    //   1449: getfield A00 : Z
    //   1452: istore #5
    //   1454: goto -> 1484
    //   1457: aload #7
    //   1459: getfield A01 : Landroid/content/Context;
    //   1462: astore #7
    //   1464: aload #7
    //   1466: instanceof android/app/Activity
    //   1469: ifeq -> 1484
    //   1472: aload #7
    //   1474: checkcast android/app/Activity
    //   1477: invokevirtual isChangingConfigurations : ()Z
    //   1480: iconst_1
    //   1481: ixor
    //   1482: istore #5
    //   1484: iload_1
    //   1485: ifeq -> 2908
    //   1488: aload #10
    //   1490: getfield mBeingSaved : Z
    //   1493: ifeq -> 1499
    //   1496: goto -> 2908
    //   1499: aload_0
    //   1500: getfield A04 : LX/0D0;
    //   1503: getfield A00 : LX/0DZ;
    //   1506: aload #10
    //   1508: getfield mWho : Ljava/lang/String;
    //   1511: iconst_0
    //   1512: invokestatic A00 : (LX/0DZ;Ljava/lang/String;Z)V
    //   1515: aload #10
    //   1517: invokevirtual performDestroy : ()V
    //   1520: aload_0
    //   1521: getfield A03 : LX/0D4;
    //   1524: aload #10
    //   1526: iconst_0
    //   1527: invokevirtual A08 : (Landroidx/fragment/app/Fragment;Z)V
    //   1530: aload_0
    //   1531: getfield A04 : LX/0D0;
    //   1534: astore #7
    //   1536: aload #7
    //   1538: invokevirtual A02 : ()Ljava/util/ArrayList;
    //   1541: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1544: astore #8
    //   1546: aload #8
    //   1548: invokeinterface hasNext : ()Z
    //   1553: ifeq -> 1612
    //   1556: aload #8
    //   1558: invokeinterface next : ()Ljava/lang/Object;
    //   1563: checkcast X/08v
    //   1566: astore #9
    //   1568: aload #9
    //   1570: ifnull -> 1546
    //   1573: aload #9
    //   1575: getfield A02 : Landroidx/fragment/app/Fragment;
    //   1578: astore #9
    //   1580: aload #10
    //   1582: getfield mWho : Ljava/lang/String;
    //   1585: aload #9
    //   1587: getfield mTargetWho : Ljava/lang/String;
    //   1590: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1593: ifeq -> 1546
    //   1596: aload #9
    //   1598: aload #10
    //   1600: putfield mTarget : Landroidx/fragment/app/Fragment;
    //   1603: aload #9
    //   1605: aconst_null
    //   1606: putfield mTargetWho : Ljava/lang/String;
    //   1609: goto -> 1546
    //   1612: aload #10
    //   1614: getfield mTargetWho : Ljava/lang/String;
    //   1617: astore #8
    //   1619: aload #8
    //   1621: ifnull -> 1636
    //   1624: aload #10
    //   1626: aload #7
    //   1628: aload #8
    //   1630: invokevirtual A00 : (Ljava/lang/String;)Landroidx/fragment/app/Fragment;
    //   1633: putfield mTarget : Landroidx/fragment/app/Fragment;
    //   1636: aload #7
    //   1638: aload_0
    //   1639: invokevirtual A07 : (LX/08v;)V
    //   1642: goto -> 2808
    //   1645: aload #10
    //   1647: iconst_0
    //   1648: putfield mInLayout : Z
    //   1651: goto -> 1685
    //   1654: aload #10
    //   1656: getfield mView : Landroid/view/View;
    //   1659: invokevirtual findFocus : ()Landroid/view/View;
    //   1662: astore #7
    //   1664: aload #7
    //   1666: ifnull -> 1676
    //   1669: aload #10
    //   1671: aload #7
    //   1673: invokevirtual setFocusedView : (Landroid/view/View;)V
    //   1676: aload #10
    //   1678: getfield mView : Landroid/view/View;
    //   1681: fconst_0
    //   1682: invokevirtual setAlpha : (F)V
    //   1685: aload #10
    //   1687: iconst_2
    //   1688: putfield mState : I
    //   1691: goto -> 2808
    //   1694: aload #10
    //   1696: iload_1
    //   1697: putfield mState : I
    //   1700: goto -> 2808
    //   1703: aload #10
    //   1705: getfield mBeingSaved : Z
    //   1708: ifeq -> 1792
    //   1711: aload_0
    //   1712: getfield A04 : LX/0D0;
    //   1715: astore #7
    //   1717: aload #10
    //   1719: getfield mWho : Ljava/lang/String;
    //   1722: astore #8
    //   1724: aload_0
    //   1725: invokevirtual A01 : ()Landroid/os/Bundle;
    //   1728: astore #9
    //   1730: aload #7
    //   1732: getfield A03 : Ljava/util/HashMap;
    //   1735: aload #8
    //   1737: aload #9
    //   1739: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1742: pop
    //   1743: aload #10
    //   1745: getfield mView : Landroid/view/View;
    //   1748: ifnull -> 1783
    //   1751: aload #10
    //   1753: getfield mContainer : Landroid/view/ViewGroup;
    //   1756: astore #7
    //   1758: aload #7
    //   1760: ifnull -> 1783
    //   1763: aload_0
    //   1764: aload #7
    //   1766: aload #10
    //   1768: invokevirtual getParentFragmentManager : ()LX/0Cy;
    //   1771: invokestatic A00 : (Landroid/view/ViewGroup;LX/0Cy;)LX/097;
    //   1774: getstatic X/0Xy.A00 : Ljava/lang/Integer;
    //   1777: getstatic X/0Xy.A0C : Ljava/lang/Integer;
    //   1780: invokestatic A03 : (LX/08v;LX/097;Ljava/lang/Integer;Ljava/lang/Integer;)V
    //   1783: aload #10
    //   1785: iconst_3
    //   1786: putfield mState : I
    //   1789: goto -> 2808
    //   1792: aload #10
    //   1794: getfield mView : Landroid/view/View;
    //   1797: ifnull -> 1743
    //   1800: aload #10
    //   1802: getfield mSavedViewState : Landroid/util/SparseArray;
    //   1805: ifnonnull -> 1743
    //   1808: aload_0
    //   1809: invokespecial A00 : ()V
    //   1812: goto -> 1743
    //   1815: aload #10
    //   1817: invokevirtual performDetach : ()V
    //   1820: aload_0
    //   1821: getfield A03 : LX/0D4;
    //   1824: aload #10
    //   1826: iconst_0
    //   1827: invokevirtual A09 : (Landroidx/fragment/app/Fragment;Z)V
    //   1830: aload #10
    //   1832: iconst_m1
    //   1833: putfield mState : I
    //   1836: aload #10
    //   1838: aconst_null
    //   1839: putfield mHost : LX/0Cu;
    //   1842: aload #10
    //   1844: aconst_null
    //   1845: putfield mParentFragment : Landroidx/fragment/app/Fragment;
    //   1848: aload #10
    //   1850: aconst_null
    //   1851: putfield mFragmentManager : LX/0Cy;
    //   1854: aload #10
    //   1856: getfield mRemoving : Z
    //   1859: ifeq -> 1881
    //   1862: aload #10
    //   1864: getfield mBackStackNesting : I
    //   1867: invokestatic A13 : (I)Z
    //   1870: ifne -> 1881
    //   1873: aload #10
    //   1875: invokevirtual initState : ()V
    //   1878: goto -> 2808
    //   1881: aload_0
    //   1882: getfield A04 : LX/0D0;
    //   1885: getfield A00 : LX/0DZ;
    //   1888: astore #7
    //   1890: aload #7
    //   1892: getfield A03 : Ljava/util/HashMap;
    //   1895: aload #10
    //   1897: getfield mWho : Ljava/lang/String;
    //   1900: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   1903: ifeq -> 1873
    //   1906: aload #7
    //   1908: getfield A05 : Z
    //   1911: ifeq -> 1873
    //   1914: aload #7
    //   1916: getfield A00 : Z
    //   1919: ifeq -> 2808
    //   1922: goto -> 1873
    //   1925: aload #10
    //   1927: getfield mContainer : Landroid/view/ViewGroup;
    //   1930: astore #7
    //   1932: aload #7
    //   1934: ifnull -> 1956
    //   1937: aload #10
    //   1939: getfield mView : Landroid/view/View;
    //   1942: astore #8
    //   1944: aload #8
    //   1946: ifnull -> 1956
    //   1949: aload #7
    //   1951: aload #8
    //   1953: invokevirtual removeView : (Landroid/view/View;)V
    //   1956: aload #10
    //   1958: invokevirtual performDestroyView : ()V
    //   1961: aload_0
    //   1962: getfield A03 : LX/0D4;
    //   1965: aload #10
    //   1967: invokevirtual A06 : (Landroidx/fragment/app/Fragment;)V
    //   1970: aload #10
    //   1972: aconst_null
    //   1973: putfield mContainer : Landroid/view/ViewGroup;
    //   1976: aload #10
    //   1978: aconst_null
    //   1979: putfield mView : Landroid/view/View;
    //   1982: aload #10
    //   1984: aconst_null
    //   1985: putfield mViewLifecycleOwner : LX/093;
    //   1988: aload #10
    //   1990: getfield mViewLifecycleOwnerLiveData : LX/00j;
    //   1993: aconst_null
    //   1994: invokevirtual A09 : (Ljava/lang/Object;)V
    //   1997: aload #10
    //   1999: iconst_0
    //   2000: putfield mInLayout : Z
    //   2003: aload #10
    //   2005: iconst_1
    //   2006: putfield mState : I
    //   2009: goto -> 2808
    //   2012: aload #10
    //   2014: invokevirtual performStop : ()V
    //   2017: aload_0
    //   2018: getfield A03 : LX/0D4;
    //   2021: aload #10
    //   2023: iconst_0
    //   2024: invokevirtual A0D : (Landroidx/fragment/app/Fragment;Z)V
    //   2027: goto -> 2808
    //   2030: aload #10
    //   2032: invokevirtual performPause : ()V
    //   2035: aload_0
    //   2036: getfield A03 : LX/0D4;
    //   2039: aload #10
    //   2041: iconst_0
    //   2042: invokevirtual A0A : (Landroidx/fragment/app/Fragment;Z)V
    //   2045: goto -> 2808
    //   2048: aload_0
    //   2049: getfield A00 : I
    //   2052: istore_3
    //   2053: aload #10
    //   2055: getfield mMaxState : LX/0cr;
    //   2058: invokevirtual ordinal : ()I
    //   2061: istore_2
    //   2062: iload_3
    //   2063: istore_1
    //   2064: iload_2
    //   2065: iconst_4
    //   2066: if_icmpeq -> 2117
    //   2069: iload_2
    //   2070: iconst_3
    //   2071: if_icmpeq -> 2102
    //   2074: iload_2
    //   2075: iconst_2
    //   2076: if_icmpeq -> 2093
    //   2079: iload_2
    //   2080: iconst_1
    //   2081: if_icmpeq -> 2111
    //   2084: iload_3
    //   2085: iconst_m1
    //   2086: invokestatic min : (II)I
    //   2089: istore_1
    //   2090: goto -> 2117
    //   2093: iload_3
    //   2094: iconst_1
    //   2095: invokestatic min : (II)I
    //   2098: istore_1
    //   2099: goto -> 2117
    //   2102: iload_3
    //   2103: iconst_5
    //   2104: invokestatic min : (II)I
    //   2107: istore_1
    //   2108: goto -> 2117
    //   2111: iload_3
    //   2112: iconst_0
    //   2113: invokestatic min : (II)I
    //   2116: istore_1
    //   2117: iload_1
    //   2118: istore_2
    //   2119: iload_2
    //   2120: istore_1
    //   2121: aload #10
    //   2123: getfield mFromLayout : Z
    //   2126: ifeq -> 2173
    //   2129: aload #10
    //   2131: getfield mInLayout : Z
    //   2134: ifeq -> 2415
    //   2137: iload_3
    //   2138: iconst_2
    //   2139: invokestatic max : (II)I
    //   2142: istore_2
    //   2143: aload #10
    //   2145: getfield mView : Landroid/view/View;
    //   2148: astore #7
    //   2150: iload_2
    //   2151: istore_1
    //   2152: aload #7
    //   2154: ifnull -> 2173
    //   2157: iload_2
    //   2158: istore_1
    //   2159: aload #7
    //   2161: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   2164: ifnonnull -> 2173
    //   2167: iload_2
    //   2168: iconst_2
    //   2169: invokestatic min : (II)I
    //   2172: istore_1
    //   2173: iload_1
    //   2174: istore_3
    //   2175: aload #10
    //   2177: getfield mInDynamicContainer : Z
    //   2180: ifeq -> 2199
    //   2183: iload_1
    //   2184: istore_3
    //   2185: aload #10
    //   2187: getfield mContainer : Landroid/view/ViewGroup;
    //   2190: ifnonnull -> 2199
    //   2193: iload_1
    //   2194: iconst_4
    //   2195: invokestatic min : (II)I
    //   2198: istore_3
    //   2199: iload_3
    //   2200: istore_2
    //   2201: aload #10
    //   2203: getfield mAdded : Z
    //   2206: ifne -> 2215
    //   2209: iload_3
    //   2210: iconst_1
    //   2211: invokestatic min : (II)I
    //   2214: istore_2
    //   2215: aconst_null
    //   2216: astore #7
    //   2218: aconst_null
    //   2219: astore #8
    //   2221: aload #10
    //   2223: getfield mContainer : Landroid/view/ViewGroup;
    //   2226: astore #9
    //   2228: aload #9
    //   2230: ifnull -> 2465
    //   2233: aload #9
    //   2235: aload #10
    //   2237: invokevirtual getParentFragmentManager : ()LX/0Cy;
    //   2240: invokestatic A00 : (Landroid/view/ViewGroup;LX/0Cy;)LX/097;
    //   2243: astore #11
    //   2245: aload #11
    //   2247: getfield A03 : Ljava/util/List;
    //   2250: invokeinterface iterator : ()Ljava/util/Iterator;
    //   2255: astore #9
    //   2257: aload #9
    //   2259: invokeinterface hasNext : ()Z
    //   2264: ifeq -> 2927
    //   2267: aload #9
    //   2269: invokeinterface next : ()Ljava/lang/Object;
    //   2274: astore #7
    //   2276: aload #7
    //   2278: checkcast X/099
    //   2281: astore #12
    //   2283: aload #12
    //   2285: getfield A07 : Landroidx/fragment/app/Fragment;
    //   2288: aload #10
    //   2290: invokestatic A0S : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   2293: ifeq -> 2257
    //   2296: aload #12
    //   2298: getfield A03 : Z
    //   2301: ifne -> 2257
    //   2304: aload #7
    //   2306: checkcast X/099
    //   2309: astore #12
    //   2311: aconst_null
    //   2312: astore #9
    //   2314: aload #8
    //   2316: astore #7
    //   2318: aload #12
    //   2320: ifnull -> 2330
    //   2323: aload #12
    //   2325: getfield A01 : Ljava/lang/Integer;
    //   2328: astore #7
    //   2330: aload #11
    //   2332: getfield A04 : Ljava/util/List;
    //   2335: invokeinterface iterator : ()Ljava/util/Iterator;
    //   2340: astore #11
    //   2342: aload #11
    //   2344: invokeinterface hasNext : ()Z
    //   2349: ifeq -> 2921
    //   2352: aload #11
    //   2354: invokeinterface next : ()Ljava/lang/Object;
    //   2359: astore #8
    //   2361: aload #8
    //   2363: checkcast X/099
    //   2366: astore #12
    //   2368: aload #12
    //   2370: getfield A07 : Landroidx/fragment/app/Fragment;
    //   2373: aload #10
    //   2375: invokestatic A0S : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   2378: ifeq -> 2342
    //   2381: aload #12
    //   2383: getfield A03 : Z
    //   2386: ifne -> 2342
    //   2389: aload #8
    //   2391: checkcast X/099
    //   2394: astore #11
    //   2396: aload #9
    //   2398: astore #8
    //   2400: aload #11
    //   2402: ifnull -> 2442
    //   2405: aload #11
    //   2407: getfield A01 : Ljava/lang/Integer;
    //   2410: astore #8
    //   2412: goto -> 2442
    //   2415: iload_3
    //   2416: iconst_4
    //   2417: if_icmpge -> 2433
    //   2420: iload_2
    //   2421: aload #10
    //   2423: getfield mState : I
    //   2426: invokestatic min : (II)I
    //   2429: istore_1
    //   2430: goto -> 2173
    //   2433: iload_2
    //   2434: iconst_1
    //   2435: invokestatic min : (II)I
    //   2438: istore_1
    //   2439: goto -> 2173
    //   2442: aload #7
    //   2444: ifnull -> 2933
    //   2447: aload #7
    //   2449: invokevirtual intValue : ()I
    //   2452: istore_1
    //   2453: iload_1
    //   2454: iconst_m1
    //   2455: if_icmpeq -> 2933
    //   2458: iload_1
    //   2459: ifeq -> 2933
    //   2462: goto -> 2465
    //   2465: aload #7
    //   2467: getstatic X/0Xy.A01 : Ljava/lang/Integer;
    //   2470: if_acmpne -> 2526
    //   2473: iload_2
    //   2474: bipush #6
    //   2476: invokestatic min : (II)I
    //   2479: istore_1
    //   2480: iload_1
    //   2481: istore_2
    //   2482: aload #10
    //   2484: getfield mDeferStart : Z
    //   2487: ifeq -> 2507
    //   2490: iload_1
    //   2491: istore_2
    //   2492: aload #10
    //   2494: getfield mState : I
    //   2497: iconst_5
    //   2498: if_icmpge -> 2507
    //   2501: iload_1
    //   2502: iconst_4
    //   2503: invokestatic min : (II)I
    //   2506: istore_2
    //   2507: iload_2
    //   2508: istore_1
    //   2509: aload #10
    //   2511: getfield mTransitioning : Z
    //   2514: ifeq -> 35
    //   2517: iload_2
    //   2518: iconst_3
    //   2519: invokestatic max : (II)I
    //   2522: istore_1
    //   2523: goto -> 35
    //   2526: aload #7
    //   2528: getstatic X/0Xy.A0C : Ljava/lang/Integer;
    //   2531: if_acmpne -> 2543
    //   2534: iload_2
    //   2535: iconst_3
    //   2536: invokestatic max : (II)I
    //   2539: istore_1
    //   2540: goto -> 2480
    //   2543: iload_2
    //   2544: istore_1
    //   2545: aload #10
    //   2547: getfield mRemoving : Z
    //   2550: ifeq -> 2480
    //   2553: aload #10
    //   2555: getfield mBackStackNesting : I
    //   2558: invokestatic A13 : (I)Z
    //   2561: ifeq -> 2573
    //   2564: iload_2
    //   2565: iconst_1
    //   2566: invokestatic min : (II)I
    //   2569: istore_1
    //   2570: goto -> 2480
    //   2573: iload_2
    //   2574: iconst_m1
    //   2575: invokestatic min : (II)I
    //   2578: istore_1
    //   2579: goto -> 2480
    //   2582: iload #4
    //   2584: ifne -> 2650
    //   2587: iload_2
    //   2588: iconst_m1
    //   2589: if_icmpne -> 2650
    //   2592: aload #10
    //   2594: getfield mRemoving : Z
    //   2597: ifeq -> 2650
    //   2600: aload #10
    //   2602: getfield mBackStackNesting : I
    //   2605: invokestatic A13 : (I)Z
    //   2608: ifne -> 2650
    //   2611: aload #10
    //   2613: getfield mBeingSaved : Z
    //   2616: ifne -> 2650
    //   2619: aload_0
    //   2620: getfield A04 : LX/0D0;
    //   2623: astore #7
    //   2625: aload #7
    //   2627: getfield A00 : LX/0DZ;
    //   2630: aload #10
    //   2632: getfield mWho : Ljava/lang/String;
    //   2635: iconst_1
    //   2636: invokestatic A00 : (LX/0DZ;Ljava/lang/String;Z)V
    //   2639: aload #7
    //   2641: aload_0
    //   2642: invokevirtual A07 : (LX/08v;)V
    //   2645: aload #10
    //   2647: invokevirtual initState : ()V
    //   2650: aload #10
    //   2652: getfield mHiddenChanged : Z
    //   2655: ifeq -> 2786
    //   2658: aload #10
    //   2660: getfield mView : Landroid/view/View;
    //   2663: ifnull -> 2710
    //   2666: aload #10
    //   2668: getfield mContainer : Landroid/view/ViewGroup;
    //   2671: astore #7
    //   2673: aload #7
    //   2675: ifnull -> 2710
    //   2678: aload #7
    //   2680: aload #10
    //   2682: invokevirtual getParentFragmentManager : ()LX/0Cy;
    //   2685: invokestatic A00 : (Landroid/view/ViewGroup;LX/0Cy;)LX/097;
    //   2688: astore #7
    //   2690: aload #10
    //   2692: getfield mHidden : Z
    //   2695: ifeq -> 2771
    //   2698: aload_0
    //   2699: aload #7
    //   2701: getstatic X/0Xy.A0C : Ljava/lang/Integer;
    //   2704: getstatic X/0Xy.A00 : Ljava/lang/Integer;
    //   2707: invokestatic A03 : (LX/08v;LX/097;Ljava/lang/Integer;Ljava/lang/Integer;)V
    //   2710: aload #10
    //   2712: getfield mFragmentManager : LX/0Cy;
    //   2715: astore #7
    //   2717: aload #7
    //   2719: ifnull -> 2744
    //   2722: aload #10
    //   2724: getfield mAdded : Z
    //   2727: ifeq -> 2744
    //   2730: aload #10
    //   2732: invokestatic A0I : (Landroidx/fragment/app/Fragment;)Z
    //   2735: ifeq -> 2744
    //   2738: aload #7
    //   2740: iconst_1
    //   2741: putfield A0G : Z
    //   2744: aload #10
    //   2746: iconst_0
    //   2747: putfield mHiddenChanged : Z
    //   2750: aload #10
    //   2752: aload #10
    //   2754: getfield mHidden : Z
    //   2757: invokevirtual onHiddenChanged : (Z)V
    //   2760: aload #10
    //   2762: getfield mChildFragmentManager : LX/0Cy;
    //   2765: invokevirtual A0Z : ()V
    //   2768: goto -> 2786
    //   2771: aload_0
    //   2772: aload #7
    //   2774: getstatic X/0Xy.A01 : Ljava/lang/Integer;
    //   2777: getstatic X/0Xy.A00 : Ljava/lang/Integer;
    //   2780: invokestatic A03 : (LX/08v;LX/097;Ljava/lang/Integer;Ljava/lang/Integer;)V
    //   2783: goto -> 2710
    //   2786: aload_0
    //   2787: iconst_0
    //   2788: putfield A01 : Z
    //   2791: return
    //   2792: astore #7
    //   2794: aload_0
    //   2795: iconst_0
    //   2796: putfield A01 : Z
    //   2799: aload #7
    //   2801: athrow
    //   2802: return
    //   2803: astore #7
    //   2805: goto -> 314
    //   2808: iconst_1
    //   2809: istore #4
    //   2811: goto -> 15
    //   2814: iconst_4
    //   2815: istore_1
    //   2816: goto -> 1694
    //   2819: bipush #6
    //   2821: istore_1
    //   2822: goto -> 1694
    //   2825: aconst_null
    //   2826: astore #8
    //   2828: goto -> 201
    //   2831: aload #9
    //   2833: astore #7
    //   2835: goto -> 484
    //   2838: iload_1
    //   2839: ifne -> 1685
    //   2842: goto -> 1654
    //   2845: iload_2
    //   2846: iconst_1
    //   2847: isub
    //   2848: tableswitch default -> 2896, -1 -> 1815, 0 -> 1209, 1 -> 1925, 2 -> 1645, 3 -> 1703, 4 -> 2012, 5 -> 2916, 6 -> 2030
    //   2896: goto -> 2808
    //   2899: iconst_0
    //   2900: istore_1
    //   2901: iload_1
    //   2902: ifeq -> 1300
    //   2905: goto -> 1395
    //   2908: iload #5
    //   2910: ifeq -> 1515
    //   2913: goto -> 1499
    //   2916: iconst_5
    //   2917: istore_1
    //   2918: goto -> 1694
    //   2921: aconst_null
    //   2922: astore #8
    //   2924: goto -> 2389
    //   2927: aconst_null
    //   2928: astore #7
    //   2930: goto -> 2304
    //   2933: aload #8
    //   2935: astore #7
    //   2937: goto -> 2465
    // Exception table:
    //   from	to	target	type
    //   7	12	2792	finally
    //   15	35	2792	finally
    //   35	41	2792	finally
    //   100	115	2792	finally
    //   120	162	2792	finally
    //   165	184	2792	finally
    //   192	201	2792	finally
    //   201	224	2792	finally
    //   232	238	2792	finally
    //   247	264	2792	finally
    //   273	281	2792	finally
    //   285	293	2792	finally
    //   293	311	2803	android/content/res/Resources$NotFoundException
    //   293	311	2792	finally
    //   319	376	2792	finally
    //   379	411	2792	finally
    //   418	451	2792	finally
    //   455	480	2792	finally
    //   484	509	2792	finally
    //   514	532	2792	finally
    //   537	541	2792	finally
    //   541	559	2792	finally
    //   559	576	2792	finally
    //   581	586	2792	finally
    //   586	638	2792	finally
    //   641	657	2792	finally
    //   660	667	2792	finally
    //   672	700	2792	finally
    //   705	724	2792	finally
    //   724	729	2792	finally
    //   729	782	2792	finally
    //   785	831	2792	finally
    //   834	841	2792	finally
    //   846	863	2792	finally
    //   872	918	2792	finally
    //   918	921	2792	finally
    //   924	931	2792	finally
    //   936	945	2792	finally
    //   945	985	2792	finally
    //   988	999	2792	finally
    //   1005	1012	2792	finally
    //   1017	1026	2792	finally
    //   1026	1044	2792	finally
    //   1047	1062	2792	finally
    //   1065	1072	2792	finally
    //   1077	1094	2792	finally
    //   1099	1118	2792	finally
    //   1121	1143	2792	finally
    //   1143	1206	2792	finally
    //   1209	1265	2792	finally
    //   1265	1272	2792	finally
    //   1280	1290	2792	finally
    //   1300	1352	2792	finally
    //   1357	1366	2792	finally
    //   1371	1386	2792	finally
    //   1386	1392	2792	finally
    //   1395	1427	2792	finally
    //   1427	1454	2792	finally
    //   1457	1464	2792	finally
    //   1464	1484	2792	finally
    //   1488	1496	2792	finally
    //   1499	1515	2792	finally
    //   1515	1546	2792	finally
    //   1546	1568	2792	finally
    //   1573	1609	2792	finally
    //   1612	1619	2792	finally
    //   1624	1636	2792	finally
    //   1636	1642	2792	finally
    //   1645	1651	2792	finally
    //   1654	1664	2792	finally
    //   1669	1676	2792	finally
    //   1676	1685	2792	finally
    //   1685	1691	2792	finally
    //   1694	1700	2792	finally
    //   1703	1743	2792	finally
    //   1743	1758	2792	finally
    //   1763	1783	2792	finally
    //   1783	1789	2792	finally
    //   1792	1812	2792	finally
    //   1815	1873	2792	finally
    //   1873	1878	2792	finally
    //   1881	1922	2792	finally
    //   1925	1932	2792	finally
    //   1937	1944	2792	finally
    //   1949	1956	2792	finally
    //   1956	2009	2792	finally
    //   2012	2027	2792	finally
    //   2030	2045	2792	finally
    //   2048	2062	2792	finally
    //   2084	2090	2792	finally
    //   2093	2099	2792	finally
    //   2102	2108	2792	finally
    //   2111	2117	2792	finally
    //   2121	2150	2792	finally
    //   2159	2173	2792	finally
    //   2175	2183	2792	finally
    //   2185	2199	2792	finally
    //   2201	2215	2792	finally
    //   2221	2228	2792	finally
    //   2233	2257	2792	finally
    //   2257	2304	2792	finally
    //   2304	2311	2792	finally
    //   2323	2330	2792	finally
    //   2330	2342	2792	finally
    //   2342	2389	2792	finally
    //   2389	2396	2792	finally
    //   2405	2412	2792	finally
    //   2420	2430	2792	finally
    //   2433	2439	2792	finally
    //   2447	2453	2792	finally
    //   2465	2480	2792	finally
    //   2482	2490	2792	finally
    //   2492	2507	2792	finally
    //   2509	2523	2792	finally
    //   2526	2540	2792	finally
    //   2545	2570	2792	finally
    //   2573	2579	2792	finally
    //   2592	2650	2792	finally
    //   2650	2673	2792	finally
    //   2678	2710	2792	finally
    //   2710	2717	2792	finally
    //   2722	2744	2792	finally
    //   2744	2768	2792	finally
    //   2771	2783	2792	finally
  }
  
  public final void A05(ClassLoader paramClassLoader) {
    Fragment fragment = this.A02;
    Bundle bundle = fragment.mSavedFragmentState;
    if (bundle != null) {
      bundle.setClassLoader(paramClassLoader);
      if (fragment.mSavedFragmentState.getBundle("savedInstanceState") == null)
        fragment.mSavedFragmentState.putBundle("savedInstanceState", new Bundle()); 
      try {
        fragment.mSavedViewState = fragment.mSavedFragmentState.getSparseParcelableArray("viewState");
        fragment.mSavedViewRegistryState = fragment.mSavedFragmentState.getBundle("viewRegistryState");
        FragmentState fragmentState = (FragmentState)fragment.mSavedFragmentState.getParcelable("state");
        if (fragmentState != null) {
          fragment.mTargetWho = fragmentState.A05;
          fragment.mTargetRequestCode = fragmentState.A03;
          Boolean bool = fragment.mSavedUserVisibleHint;
          if (bool != null) {
            fragment.mUserVisibleHint = bool.booleanValue();
            fragment.mSavedUserVisibleHint = null;
          } else {
            fragment.mUserVisibleHint = fragmentState.A0C;
          } 
        } 
        if (!fragment.mUserVisibleHint) {
          fragment.mDeferStart = true;
          return;
        } 
      } catch (BadParcelableException badParcelableException) {
        throw new IllegalStateException(002.A0T(fragment, "Failed to restore view hierarchy state for fragment ", 001.A0s()), badParcelableException);
      } 
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */