package X;

import android.os.ConditionVariable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

public final class 07W {
  public final ConditionVariable A00 = new ConditionVariable(true);
  
  public final ExecutorService A01 = Executors.newSingleThreadExecutor();
  
  public final AtomicBoolean A02 = 001.A1C();
  
  public final AtomicLong A03 = new AtomicLong(-1L);
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07W.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */