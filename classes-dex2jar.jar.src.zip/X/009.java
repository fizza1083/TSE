package X;

import android.content.Context;
import com.facebook.quicklog.LightweightQuickPerformanceLogger;
import java.io.File;

public final class 009 {
  public static 009 A07;
  
  public Context A00;
  
  public LightweightQuickPerformanceLogger A01;
  
  public 14W A02;
  
  public boolean A03 = false;
  
  public boolean A04 = false;
  
  public final 00B A05;
  
  public final 00E A06 = 00E.A00();
  
  public 009(Context paramContext) {
    this.A05 = 00B1;
    this.A00 = paramContext;
  }
  
  public static 009 A00(Context paramContext) {
    // Byte code:
    //   0: ldc X/009
    //   2: monitorenter
    //   3: getstatic X/009.A07 : LX/009;
    //   6: astore_2
    //   7: aload_2
    //   8: astore_1
    //   9: aload_2
    //   10: ifnonnull -> 40
    //   13: aload_0
    //   14: astore_1
    //   15: aload_0
    //   16: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   19: ifnull -> 27
    //   22: aload_0
    //   23: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   26: astore_1
    //   27: new X/009
    //   30: dup
    //   31: aload_1
    //   32: invokespecial <init> : (Landroid/content/Context;)V
    //   35: astore_1
    //   36: aload_1
    //   37: putstatic X/009.A07 : LX/009;
    //   40: ldc X/009
    //   42: monitorexit
    //   43: aload_1
    //   44: areturn
    //   45: astore_0
    //   46: ldc X/009
    //   48: monitorexit
    //   49: aload_0
    //   50: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	45	finally
    //   15	27	45	finally
    //   27	40	45	finally
  }
  
  public final String[] A01(File paramFile, String paramString1, String paramString2) {
    // Byte code:
    //   0: invokestatic A12 : ()Ljava/util/HashSet;
    //   3: astore #10
    //   5: iconst_0
    //   6: istore #5
    //   8: aload_1
    //   9: ifnull -> 26
    //   12: aload_1
    //   13: invokevirtual exists : ()Z
    //   16: istore #7
    //   18: iconst_1
    //   19: istore #4
    //   21: iload #7
    //   23: ifne -> 29
    //   26: iconst_0
    //   27: istore #4
    //   29: aload_0
    //   30: getfield A00 : Landroid/content/Context;
    //   33: aload_2
    //   34: invokestatic A00 : (Landroid/content/Context;Ljava/lang/String;)Ljava/io/File;
    //   37: astore #9
    //   39: aload #9
    //   41: astore #8
    //   43: aload #9
    //   45: ifnonnull -> 57
    //   48: aload_0
    //   49: getfield A00 : Landroid/content/Context;
    //   52: invokestatic A0G : (Landroid/content/Context;)Ljava/io/File;
    //   55: astore #8
    //   57: iload #4
    //   59: ifeq -> 226
    //   62: aload_1
    //   63: invokevirtual getCanonicalPath : ()Ljava/lang/String;
    //   66: pop
    //   67: iload #4
    //   69: ifeq -> 209
    //   72: new X/0EA
    //   75: dup
    //   76: aload_0
    //   77: getfield A00 : Landroid/content/Context;
    //   80: aload_1
    //   81: aload_2
    //   82: invokespecial <init> : (Landroid/content/Context;Ljava/io/File;Ljava/lang/String;)V
    //   85: astore_1
    //   86: aload_1
    //   87: getfield A03 : Ljava/util/zip/ZipFile;
    //   90: astore #9
    //   92: aload #9
    //   94: ifnull -> 162
    //   97: aload_1
    //   98: getfield A02 : Ljava/util/List;
    //   101: invokeinterface iterator : ()Ljava/util/Iterator;
    //   106: astore #11
    //   108: aload #11
    //   110: invokeinterface hasNext : ()Z
    //   115: ifeq -> 203
    //   118: aload #9
    //   120: aload #11
    //   122: invokeinterface next : ()Ljava/lang/Object;
    //   127: checkcast java/lang/String
    //   130: ldc 'metadata.txt'
    //   132: invokestatic A0b : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   135: invokevirtual getEntry : (Ljava/lang/String;)Ljava/util/zip/ZipEntry;
    //   138: ifnull -> 108
    //   141: iconst_1
    //   142: istore #4
    //   144: iload #4
    //   146: ifeq -> 385
    //   149: invokestatic A0y : ()Ljava/util/ArrayList;
    //   152: astore #9
    //   154: invokestatic A0y : ()Ljava/util/ArrayList;
    //   157: astore #11
    //   159: goto -> 256
    //   162: aload_1
    //   163: getfield A00 : Landroid/content/Context;
    //   166: invokevirtual getAssets : ()Landroid/content/res/AssetManager;
    //   169: astore #9
    //   171: aload #9
    //   173: aload_1
    //   174: getfield A01 : Ljava/lang/String;
    //   177: getstatic java/io/File.separator : Ljava/lang/String;
    //   180: ldc 'metadata.txt'
    //   182: invokestatic A0p : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   185: invokevirtual open : (Ljava/lang/String;)Ljava/io/InputStream;
    //   188: astore #9
    //   190: aload #9
    //   192: ifnull -> 203
    //   195: aload #9
    //   197: invokevirtual close : ()V
    //   200: goto -> 141
    //   203: iconst_0
    //   204: istore #4
    //   206: goto -> 144
    //   209: new X/0EA
    //   212: dup
    //   213: aload_0
    //   214: getfield A00 : Landroid/content/Context;
    //   217: aconst_null
    //   218: aload_2
    //   219: invokespecial <init> : (Landroid/content/Context;Ljava/io/File;Ljava/lang/String;)V
    //   222: astore_1
    //   223: goto -> 86
    //   226: aload_0
    //   227: getfield A00 : Landroid/content/Context;
    //   230: invokevirtual getApplicationInfo : ()Landroid/content/pm/ApplicationInfo;
    //   233: getfield sourceDir : Ljava/lang/String;
    //   236: aload #8
    //   238: invokevirtual getCanonicalPath : ()Ljava/lang/String;
    //   241: invokevirtual equals : (Ljava/lang/Object;)Z
    //   244: ifne -> 67
    //   247: aload #8
    //   249: invokevirtual getCanonicalPath : ()Ljava/lang/String;
    //   252: pop
    //   253: goto -> 67
    //   256: aload_0
    //   257: getfield A00 : Landroid/content/Context;
    //   260: astore #12
    //   262: ldc com/facebook/common/dextricks/DexLibLoader
    //   264: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   267: astore #13
    //   269: aload #12
    //   271: invokevirtual getApplicationInfo : ()Landroid/content/pm/ApplicationInfo;
    //   274: aload #13
    //   276: aload #9
    //   278: aload #11
    //   280: invokestatic A00 : (Landroid/content/pm/ApplicationInfo;Ljava/lang/ClassLoader;Ljava/util/List;Ljava/util/List;)Z
    //   283: pop
    //   284: goto -> 308
    //   287: astore #12
    //   289: ldc 'FbVoltronModuleLoader'
    //   291: aload #12
    //   293: ldc 'cannot read base.apk element from ClassLoader'
    //   295: invokestatic A0R : (Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V
    //   298: aload #9
    //   300: invokevirtual clear : ()V
    //   303: aload #11
    //   305: invokevirtual clear : ()V
    //   308: aload_0
    //   309: getfield A05 : LX/00B;
    //   312: aload_2
    //   313: aload_3
    //   314: invokevirtual A03 : (Ljava/lang/String;Ljava/lang/String;)LX/00H;
    //   317: aload #8
    //   319: aload_1
    //   320: aload #9
    //   322: aload #11
    //   324: invokestatic open : (Ljava/io/File;Ljava/io/File;Lcom/facebook/common/dextricks/ResProvider;Ljava/util/ArrayList;Ljava/util/ArrayList;)Lcom/facebook/common/dextricks/DexStore;
    //   327: astore_1
    //   328: aload_1
    //   329: invokevirtual loadManifest : ()Lcom/facebook/common/dextricks/DexManifest;
    //   332: pop
    //   333: aload_1
    //   334: invokevirtual loadManifest : ()Lcom/facebook/common/dextricks/DexManifest;
    //   337: getfield requires : [Ljava/lang/String;
    //   340: astore_1
    //   341: aload_1
    //   342: arraylength
    //   343: istore #6
    //   345: iconst_0
    //   346: istore #4
    //   348: iload #4
    //   350: iload #6
    //   352: if_icmpge -> 385
    //   355: aload_1
    //   356: iload #4
    //   358: aaload
    //   359: astore_3
    //   360: aload_3
    //   361: ldc 'dex'
    //   363: invokevirtual equals : (Ljava/lang/Object;)Z
    //   366: ifne -> 376
    //   369: aload #10
    //   371: aload_3
    //   372: invokevirtual add : (Ljava/lang/Object;)Z
    //   375: pop
    //   376: iload #4
    //   378: iconst_1
    //   379: iadd
    //   380: istore #4
    //   382: goto -> 348
    //   385: invokestatic A0y : ()Ljava/util/ArrayList;
    //   388: astore_1
    //   389: iconst_0
    //   390: istore #4
    //   392: aload_2
    //   393: iload #4
    //   395: invokestatic A0m : (Ljava/lang/String;I)Ljava/lang/String;
    //   398: astore_3
    //   399: aload_3
    //   400: ifnull -> 418
    //   403: aload_1
    //   404: aload_3
    //   405: invokevirtual add : (Ljava/lang/Object;)Z
    //   408: pop
    //   409: iload #4
    //   411: iconst_1
    //   412: iadd
    //   413: istore #4
    //   415: goto -> 392
    //   418: aload_1
    //   419: invokevirtual iterator : ()Ljava/util/Iterator;
    //   422: astore_1
    //   423: aload_1
    //   424: invokeinterface hasNext : ()Z
    //   429: ifeq -> 447
    //   432: aload #10
    //   434: aload_1
    //   435: invokeinterface next : ()Ljava/lang/Object;
    //   440: invokevirtual add : (Ljava/lang/Object;)Z
    //   443: pop
    //   444: goto -> 423
    //   447: aload #10
    //   449: invokevirtual size : ()I
    //   452: anewarray java/lang/String
    //   455: astore_1
    //   456: aload #10
    //   458: invokevirtual iterator : ()Ljava/util/Iterator;
    //   461: astore_2
    //   462: iload #5
    //   464: istore #4
    //   466: aload_2
    //   467: invokeinterface hasNext : ()Z
    //   472: ifeq -> 494
    //   475: aload_1
    //   476: iload #4
    //   478: aload_2
    //   479: invokeinterface next : ()Ljava/lang/Object;
    //   484: aastore
    //   485: iload #4
    //   487: iconst_1
    //   488: iadd
    //   489: istore #4
    //   491: goto -> 466
    //   494: aload_1
    //   495: areturn
    //   496: astore #9
    //   498: goto -> 203
    // Exception table:
    //   from	to	target	type
    //   171	190	496	java/io/IOException
    //   195	200	496	java/io/IOException
    //   256	284	287	X/0my
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\009.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */