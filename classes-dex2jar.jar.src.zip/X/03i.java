package X;

import com.facebook.fury.context.ReqContext;
import com.facebook.fury.context.ReqContextLifecycleCallbacks;

public final class 03i implements ReqContextLifecycleCallbacks {
  public final ReqContextLifecycleCallbacks[] A00;
  
  public 03i(ReqContextLifecycleCallbacks... paramVarArgs) {
    this.A00 = paramVarArgs;
  }
  
  public final 0uD Bq6() {
    0uD 0uD2;
    0uD 0uD1 = 0uD.A03;
    ReqContextLifecycleCallbacks[] arrayOfReqContextLifecycleCallbacks = this.A00;
    int j = arrayOfReqContextLifecycleCallbacks.length;
    int i = 0;
    while (true) {
      0uD2 = 0uD1;
      if (i < j) {
        int k = arrayOfReqContextLifecycleCallbacks[i].Bq6().ordinal();
        if (k != 0) {
          if (k == 1)
            0uD1 = 0uD.A01; 
          i++;
          continue;
        } 
        0uD2 = 0uD.A02;
      } 
      break;
    } 
    return 0uD2;
  }
  
  public final void onActivate(ReqContext paramReqContext) {
    ReqContextLifecycleCallbacks[] arrayOfReqContextLifecycleCallbacks = this.A00;
    int j = arrayOfReqContextLifecycleCallbacks.length;
    for (int i = 0; i < j; i++) {
      if (arrayOfReqContextLifecycleCallbacks[i].Bq6() != 0uD.A03)
        arrayOfReqContextLifecycleCallbacks[i].onActivate(paramReqContext); 
    } 
  }
  
  public final void onDeactivate(ReqContext paramReqContext) {
    ReqContextLifecycleCallbacks[] arrayOfReqContextLifecycleCallbacks = this.A00;
    int j = arrayOfReqContextLifecycleCallbacks.length;
    for (int i = 0; i < j; i++) {
      if (arrayOfReqContextLifecycleCallbacks[i].Bq6() != 0uD.A03)
        arrayOfReqContextLifecycleCallbacks[i].onDeactivate(paramReqContext); 
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\03i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */