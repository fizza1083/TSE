package X;

import java.util.Map;
import java.util.NoSuchElementException;

public abstract class 01n {
  public static final Object A0H(Object paramObject, Map paramMap) {
    if (paramMap instanceof 07m) {
      07m 07m = (07m)paramMap;
      Map map = 07m.A00;
      paramMap = (Map)map.get(paramObject);
      Object object = paramMap;
      if (paramMap == null) {
        object = paramMap;
        if (!map.containsKey(paramObject))
          object = 07m.A01.invoke(paramObject); 
      } 
      return object;
    } 
    Object object2 = paramMap.get(paramObject);
    Object object1 = object2;
    if (object2 == null) {
      object1 = object2;
      if (!paramMap.containsKey(paramObject)) {
        StringBuilder stringBuilder = 001.A0s();
        stringBuilder.append("Key ");
        stringBuilder.append(paramObject);
        throw new NoSuchElementException(001.A0l(" is missing in the map.", stringBuilder));
      } 
    } 
    return object1;
  }
  
  public static final Map A0I(Map paramMap, 0BQ param0BQ) {
    return (paramMap instanceof 07m) ? A0I(((07m)paramMap).A00, param0BQ) : new 07m(paramMap, param0BQ);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */