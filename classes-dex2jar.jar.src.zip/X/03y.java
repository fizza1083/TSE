package X;

import java.io.File;

public final class 03y {
  public final File A00;
  
  public final Integer A01;
  
  public final String A02;
  
  public final boolean A03;
  
  public 03y(File paramFile, Integer paramInteger, String paramString, boolean paramBoolean) {
    this.A00 = paramFile;
    this.A02 = paramString;
    this.A01 = paramInteger;
    this.A03 = paramBoolean;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\03y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */