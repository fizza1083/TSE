package X;

import java.nio.ByteBuffer;

public final class 06O {
  public static final int[] A03 = new int[] { 0, 4 };
  
  public static final boolean[] A04 = new boolean[] { true, false };
  
  public int A00;
  
  public byte[] A01;
  
  public byte[] A02;
  
  public final int A00(ByteBuffer paramByteBuffer) {
    byte[] arrayOfByte = new byte[paramByteBuffer.get()];
    this.A01 = arrayOfByte;
    paramByteBuffer.get(arrayOfByte);
    int j = this.A01.length;
    byte b = paramByteBuffer.get();
    this.A00 = 0;
    byte b2 = 1;
    int i = b;
    byte b1 = b2;
    if (b < 0) {
      i = Math.abs(b);
      this.A00 = i;
      int k = A03[i];
      i = k;
      b1 = b2;
      if (k <= 0) {
        i = paramByteBuffer.get();
        b1 = 2;
      } 
    } 
    arrayOfByte = new byte[i];
    this.A02 = arrayOfByte;
    paramByteBuffer.get(arrayOfByte);
    return j + 1 + b1 + i;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\06O.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */