package X;

public final class 06j extends 06k {
  public int A00;
  
  public boolean A01;
  
  public final int A02;
  
  public final int A03;
  
  public 06j(int paramInt1, int paramInt2, int paramInt3) {
    this.A03 = paramInt3;
    this.A02 = paramInt2;
    boolean bool = true;
    if ((paramInt3 > 0) ? (paramInt1 <= paramInt2) : (paramInt1 >= paramInt2))
      bool = false; 
    this.A01 = bool;
    if (!bool)
      paramInt1 = paramInt2; 
    this.A00 = paramInt1;
  }
  
  public final int A00() {
    int i = this.A00;
    if (i == this.A02) {
      if (this.A01) {
        this.A01 = false;
        return i;
      } 
      throw 001.A1B();
    } 
    this.A00 = this.A03 + i;
    return i;
  }
  
  public final boolean hasNext() {
    return this.A01;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\06j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */