package X;

import java.io.Serializable;

public final class 068 implements Serializable {
  public final Throwable exception;
  
  public 068(Throwable paramThrowable) {
    this.exception = paramThrowable;
  }
  
  public final boolean equals(Object paramObject) {
    if (paramObject instanceof 068) {
      boolean bool1 = 16F.A0S(this.exception, ((068)paramObject).exception);
      boolean bool = true;
      return !bool1 ? false : bool;
    } 
    return false;
  }
  
  public final int hashCode() {
    return this.exception.hashCode();
  }
  
  public final String toString() {
    StringBuilder stringBuilder = 001.A0s();
    stringBuilder.append("Failure(");
    return 002.A0U(this.exception, stringBuilder);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\068.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */