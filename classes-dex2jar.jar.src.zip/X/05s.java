package X;

public abstract class 05s extends 04k implements 04l, 05D, 058 {
  public final 04I A00;
  
  public 05s(04I param04I, boolean paramBoolean) {
    04p 04p;
    if (paramBoolean) {
      04p = 04n.A00;
    } else {
      04p = 04n.A01;
    } 
    this._state$volatile = 04p;
    A0K((04l)param04I.get(04l.A00));
    this.A00 = param04I.plus(this);
  }
  
  public final String A0D() {
    return 0XK.A0b(getClass().getSimpleName(), " was cancelled");
  }
  
  public String A0E() {
    return 001.A0g(this);
  }
  
  public final void A0H(Object paramObject) {
    if (paramObject instanceof 0IX) {
      paramObject = paramObject;
      Throwable throwable = ((0IX)paramObject).A00;
      int i = 0IX.A01.get(paramObject);
      boolean bool = false;
      if (i != 0)
        bool = true; 
      A0V(throwable, bool);
      return;
    } 
    A0U(paramObject);
  }
  
  public final void A0J(Throwable paramThrowable) {
    17L.A00(this.A00, paramThrowable);
  }
  
  public final void A0S(Integer paramInteger, Object paramObject, 053 param053) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: \r\n\tat com.googlecode.dex2jar.ir.ts.NewTransformer.transform(NewTransformer.java:134)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:148)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public void A0T(Object paramObject) {
    A0G(paramObject);
  }
  
  public void A0U(Object paramObject) {}
  
  public void A0V(Throwable paramThrowable, boolean paramBoolean) {}
  
  public final 04I B2c() {
    return this.A00;
  }
  
  public final 04I B32() {
    return this.A00;
  }
  
  public final void DiG(Object paramObject) {
    Throwable throwable = 067.A00(paramObject);
    if (throwable != null)
      paramObject = new 0IX(throwable, false); 
    paramObject = A0B(paramObject);
    if (paramObject != 04n.A04)
      A0T(paramObject); 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\05s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */