package X;

import java.io.Serializable;

public final class 02z implements 0BT, Serializable {
  public Object _value;
  
  public 0BK initializer;
  
  private final Object writeReplace() {
    return new 0i1(getValue());
  }
  
  public final Object getValue() {
    Object object2 = this._value;
    Object object1 = object2;
    if (object2 == 0BU.A00) {
      object1 = this.initializer;
      16F.A0D(object1);
      object1 = object1.invoke();
      this._value = object1;
      this.initializer = null;
    } 
    return object1;
  }
  
  public final boolean isInitialized() {
    Object object = this._value;
    0BU 0BU = 0BU.A00;
    boolean bool = false;
    if (object != 0BU)
      bool = true; 
    return bool;
  }
  
  public final String toString() {
    return isInitialized() ? String.valueOf(getValue()) : "Lazy value not initialized yet.";
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\02z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */