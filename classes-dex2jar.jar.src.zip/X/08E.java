package X;

import java.util.Iterator;
import java.util.Map;

public final class 08E implements Iterator, Map.Entry {
  public int A00;
  
  public int A01;
  
  public boolean A02;
  
  public 08E(00Z param00Z) {
    this.A00 = param00Z.size() - 1;
    this.A01 = -1;
  }
  
  public final boolean equals(Object paramObject) {
    if (this.A02) {
      boolean bool = paramObject instanceof Map.Entry;
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (bool) {
        paramObject = paramObject;
        Object object = paramObject.getKey();
        00Z 00Z1 = this.A03;
        bool1 = bool2;
        if (16F.A0S(object, 00Z1.A05(this.A01))) {
          bool1 = bool2;
          if (16F.A0S(paramObject.getValue(), 00Z1.A07(this.A01)))
            bool1 = true; 
        } 
      } 
      return bool1;
    } 
    throw 001.A0S("This container does not support retaining Map.Entry objects");
  }
  
  public final Object getKey() {
    if (this.A02)
      return this.A03.A05(this.A01); 
    throw 001.A0S("This container does not support retaining Map.Entry objects");
  }
  
  public final Object getValue() {
    if (this.A02)
      return this.A03.A07(this.A01); 
    throw 001.A0S("This container does not support retaining Map.Entry objects");
  }
  
  public final boolean hasNext() {
    int i = this.A01;
    int j = this.A00;
    boolean bool = false;
    if (i < j)
      bool = true; 
    return bool;
  }
  
  public final int hashCode() {
    if (this.A02) {
      00Z 00Z1 = this.A03;
      Object object1 = 00Z1.A05(this.A01);
      Object object2 = 00Z1.A07(this.A01);
      int i = 0;
      int j = 002.A04(object1);
      if (object2 != null)
        i = object2.hashCode(); 
      return j ^ i;
    } 
    throw 001.A0S("This container does not support retaining Map.Entry objects");
  }
  
  public final void remove() {
    if (this.A02) {
      this.A03.A06(this.A01);
      this.A01--;
      this.A00--;
      this.A02 = false;
      return;
    } 
    throw 001.A0Q();
  }
  
  public final Object setValue(Object paramObject) {
    if (this.A02) {
      00Z 00Z1 = this.A03;
      int i = this.A01;
      if (i >= 0 && i < 00Z1.A00) {
        i = (i << 1) + 1;
        Object[] arrayOfObject = 00Z1.A02;
        Object object = arrayOfObject[i];
        arrayOfObject[i] = paramObject;
        return object;
      } 
      0XK.A1I(i);
      throw 0GH.createAndThrow();
    } 
    throw 001.A0S("This container does not support retaining Map.Entry objects");
  }
  
  public final String toString() {
    StringBuilder stringBuilder = 001.A0s();
    stringBuilder.append(getKey());
    stringBuilder.append("=");
    return 001.A0i(getValue(), stringBuilder);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08E.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */