package X;

import java.util.Set;

public abstract class 026 {
  public static final 0MU A03(Set paramSet) {
    0MU 0MU2 = (0MU)paramSet;
    09t 09t = 0MU2.backing;
    09t.A05();
    09t.isReadOnly = true;
    if (09t.size() <= 0)
      16F.A0I(09t.A00, "null cannot be cast to non-null type kotlin.collections.Map<K of kotlin.collections.builders.MapBuilder, V of kotlin.collections.builders.MapBuilder>"); 
    0MU 0MU1 = 0MU2;
    if (0MU2.size() <= 0)
      0MU1 = 0MU.A00; 
    return 0MU1;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\026.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */