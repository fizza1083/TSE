package X;

import android.app.ActivityManager;
import android.content.Context;
import java.lang.reflect.Field;

public final class 00v extends 00w {
  public 00v() {
    super("activity", null, null, null);
  }
  
  public final void A01(Context paramContext, 013 param013) {
    Field field = param013.A03(ActivityManager.class, "IActivityManagerSingleton");
    paramContext = null;
    if (field != null) {
      Object object;
      try {
        Object object1 = field.get(null);
        object = object1;
      } catch (Exception exception) {}
      if (object != null) {
        Class clazz = param013.A01("android.util.Singleton");
        if (clazz != null) {
          Field field1 = param013.A03(clazz, "mInstance");
          if (field1 != null)
            try {
              Object object1 = field1.get(object);
              if (object1 != null) {
                Class clazz1 = param013.A01("android.app.IActivityManager");
                if (clazz1 != null) {
                  Object object2 = 00w.A00(this, clazz1, object1);
                  field1.set(object, object2);
                } 
              } 
              return;
            } catch (Exception exception) {
              return;
            }  
        } 
      } 
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */