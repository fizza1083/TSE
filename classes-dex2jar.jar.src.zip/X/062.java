package X;

public abstract class 062 {
  public static final 04o A00;
  
  public static final 04o A01 = 04o.A00("UNDEFINED");
  
  static {
    A00 = 04o.A00("REUSABLE_CLAIMED");
  }
  
  public static final void A00(Object paramObject, 05D param05D) {
    Object object;
    04F 04F;
    if (param05D instanceof 05y) {
      05y 05y = (05y)param05D;
      object = paramObject;
      Throwable throwable = 067.A00(paramObject);
      if (throwable != null)
        object = new 0IX(throwable, false); 
      04F = 05y.A03;
      05D 05D1 = 05y.A02;
      if (04F.A04(05D1.B2c())) {
        05y.A00 = object;
        05y.A00 = 1;
        04F.A05(05y, 05D1.B2c());
        return;
      } 
      04F = 0IP.A00();
      long l = ((05q)04F).A00;
      if (l >= 4294967296L) {
        05y.A00 = object;
        05y.A00 = 1;
        04F.A08(05y);
        return;
      } 
      ((05q)04F).A00 = l + 4294967296L;
      try {
        04l 04l = (04l)05D1.B2c().get(04l.A00);
        if (04l != null && !04l.C2C()) {
          paramObject = 04l.AzG();
          05y.A0B(object, (Throwable)paramObject);
          05y.DiG(new 068((Throwable)paramObject));
        } else {
          object = 05y.A01;
          04I 04I = 05D1.B2c();
          Object object1 = 063.A00(object, 04I);
          if (object1 != 063.A01) {
            object = 05G.A02(object1, 05D1, 04I);
          } else {
            object = null;
          } 
          try {
            05D1.DiG(paramObject);
          } finally {
            if (object == null || object.A0W())
              063.A01(object1, 04I); 
          } 
        } 
      } finally {
        paramObject = null;
      } 
    } else {
      object.DiG(paramObject);
      return;
    } 
    04F.A09(true);
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\062.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */