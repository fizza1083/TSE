package X;

import java.io.Serializable;
import java.util.Collection;
import java.util.Map;
import java.util.Set;

public final class 01o implements Map, Serializable, 16M {
  public static final 01o A00;
  
  public static final long serialVersionUID = 8246714829545688274L;
  
  static {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: \r\n\tat com.googlecode.dex2jar.ir.ts.NewTransformer.transform(NewTransformer.java:134)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:148)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  private final Object readResolve() {
    return A00;
  }
  
  public final void clear() {
    throw 002.A0b();
  }
  
  public final boolean containsKey(Object paramObject) {
    return false;
  }
  
  public final boolean equals(Object paramObject) {
    if (paramObject instanceof Map) {
      boolean bool1 = ((Map)paramObject).isEmpty();
      boolean bool = true;
      return !bool1 ? false : bool;
    } 
    return false;
  }
  
  public final int hashCode() {
    return 0;
  }
  
  public final boolean isEmpty() {
    return true;
  }
  
  public final void putAll(Map paramMap) {
    throw 002.A0b();
  }
  
  public final String toString() {
    return "{}";
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */