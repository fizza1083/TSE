package X;

import android.view.WindowInsets;

public abstract class 07R extends 07S {
  public 07U A00;
  
  public final 07U A02() {
    07U 07U2 = this.A00;
    07U 07U1 = 07U2;
    if (07U2 == null) {
      WindowInsets windowInsets = this.A02;
      07U1 = 07U.A00(windowInsets.getStableInsetLeft(), windowInsets.getStableInsetTop(), windowInsets.getStableInsetRight(), windowInsets.getStableInsetBottom());
      this.A00 = 07U1;
    } 
    return 07U1;
  }
  
  public final 07N A07() {
    WindowInsets windowInsets = this.A02.consumeStableInsets();
    07N 07N = 07N.A01;
    windowInsets.getClass();
    return new 07N(windowInsets);
  }
  
  public final 07N A08() {
    WindowInsets windowInsets = this.A02.consumeSystemWindowInsets();
    07N 07N = 07N.A01;
    windowInsets.getClass();
    return new 07N(windowInsets);
  }
  
  public final boolean A0B() {
    return this.A02.isConsumed();
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */