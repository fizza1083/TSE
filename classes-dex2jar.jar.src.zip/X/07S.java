package X;

import android.view.WindowInsets;

public abstract class 07S extends 07T {
  public 07N A00;
  
  public 07U A01 = null;
  
  public final WindowInsets A02;
  
  public 07S(07N param07N, WindowInsets paramWindowInsets) {
    super(param07N);
    this.A02 = paramWindowInsets;
  }
  
  public final 07U A04() {
    07U 07U2 = this.A01;
    07U 07U1 = 07U2;
    if (07U2 == null) {
      WindowInsets windowInsets = this.A02;
      07U1 = 07U.A00(windowInsets.getSystemWindowInsetLeft(), windowInsets.getSystemWindowInsetTop(), windowInsets.getSystemWindowInsetRight(), windowInsets.getSystemWindowInsetBottom());
      this.A01 = 07U1;
    } 
    return 07U1;
  }
  
  public final void A0A(07N param07N) {
    this.A00 = param07N;
  }
  
  public final boolean A0C() {
    return this.A02.isRound();
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07S.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */