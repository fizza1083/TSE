package X;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class 06l implements 06m, 06o {
  public static final HashMap A01;
  
  public static final Map A02;
  
  public static final Map A03;
  
  public static final HashMap A04;
  
  public static final HashMap A05;
  
  public final Class A00;
  
  static {
    int i = 0;
    List list = 1An.A1G((Object[])new Class[] { 
          0BK.class, 0BQ.class, 053.class, 06p.class, 06q.class, 06r.class, 06s.class, 06t.class, 06u.class, 06v.class, 
          06w.class, 06x.class, 06y.class, 06z.class, 070.class, 071.class, 072.class, 073.class, 074.class, 075.class, 
          076.class, 077.class, 078.class });
    ArrayList<0BW> arrayList = 154.A16(list);
    for (Object object : list) {
      if (i) {
        1An.A1K();
        throw 0GH.createAndThrow();
      } 
      arrayList.add(new 0BW(object, Integer.valueOf(i)));
      i++;
    } 
    A02 = 01l.A07(arrayList);
    HashMap<String, String> hashMap2 = 001.A11();
    hashMap2.put("boolean", "kotlin.Boolean");
    hashMap2.put("char", "kotlin.Char");
    hashMap2.put("byte", "kotlin.Byte");
    hashMap2.put("short", "kotlin.Short");
    hashMap2.put("int", "kotlin.Int");
    hashMap2.put("float", "kotlin.Float");
    hashMap2.put("long", "kotlin.Long");
    hashMap2.put("double", "kotlin.Double");
    A04 = hashMap2;
    HashMap<String, String> hashMap3 = 001.A11();
    hashMap3.put("java.lang.Boolean", "kotlin.Boolean");
    hashMap3.put("java.lang.Character", "kotlin.Char");
    hashMap3.put("java.lang.Byte", "kotlin.Byte");
    hashMap3.put("java.lang.Short", "kotlin.Short");
    hashMap3.put("java.lang.Integer", "kotlin.Int");
    hashMap3.put("java.lang.Float", "kotlin.Float");
    hashMap3.put("java.lang.Long", "kotlin.Long");
    hashMap3.put("java.lang.Double", "kotlin.Double");
    A05 = hashMap3;
    HashMap<String, String> hashMap1 = 001.A11();
    hashMap1.put("java.lang.Object", "kotlin.Any");
    hashMap1.put("java.lang.String", "kotlin.String");
    hashMap1.put("java.lang.CharSequence", "kotlin.CharSequence");
    hashMap1.put("java.lang.Throwable", "kotlin.Throwable");
    hashMap1.put("java.lang.Cloneable", "kotlin.Cloneable");
    hashMap1.put("java.lang.Number", "kotlin.Number");
    hashMap1.put("java.lang.Comparable", "kotlin.Comparable");
    hashMap1.put("java.lang.Enum", "kotlin.Enum");
    hashMap1.put("java.lang.annotation.Annotation", "kotlin.Annotation");
    hashMap1.put("java.lang.Iterable", "kotlin.collections.Iterable");
    hashMap1.put("java.util.Iterator", "kotlin.collections.Iterator");
    hashMap1.put("java.util.Collection", "kotlin.collections.Collection");
    hashMap1.put("java.util.List", "kotlin.collections.List");
    hashMap1.put("java.util.Set", "kotlin.collections.Set");
    hashMap1.put("java.util.ListIterator", "kotlin.collections.ListIterator");
    hashMap1.put("java.util.Map", "kotlin.collections.Map");
    hashMap1.put("java.util.Map$Entry", "kotlin.collections.Map.Entry");
    hashMap1.put("X.16J", "kotlin.String.Companion");
    hashMap1.put("X.WIU", "kotlin.Enum.Companion");
    hashMap1.putAll(hashMap2);
    hashMap1.putAll(hashMap3);
    Collection<String> collection = hashMap2.values();
    16F.A0A(collection);
    for (String str : collection) {
      16F.A0D(str);
      hashMap1.put(0XK.A0p("kotlin.jvm.internal.", 0Xm.A0G(str, str), "CompanionObject"), 0XK.A0b(str, ".Companion"));
    } 
    Iterator<Map.Entry> iterator2 = 001.A16(A02);
    while (iterator2.hasNext()) {
      Map.Entry entry = iterator2.next();
      Class clazz = (Class)entry.getKey();
      i = ((Number)entry.getValue()).intValue();
      hashMap1.put(clazz.getName(), 0XK.A0Z("X.0BG", i));
    } 
    A01 = hashMap1;
    LinkedHashMap<Object, Object> linkedHashMap = new LinkedHashMap<Object, Object>(01m.A0D(hashMap1.size()));
    Iterator<Map.Entry> iterator1 = 001.A14(hashMap1);
    while (iterator1.hasNext()) {
      Map.Entry entry = iterator1.next();
      hashMap3 = (HashMap<String, String>)entry.getKey();
      String str = (String)entry.getValue();
      linkedHashMap.put(hashMap3, 0Xm.A0G(str, str));
    } 
    A03 = linkedHashMap;
  }
  
  public 06l(Class paramClass) {
    this.A00 = paramClass;
  }
  
  public static final Class A00(06m param06m) {
    Class<Integer> clazz2;
    Class<Double> clazz;
    String str;
    16F.A0E(param06m, 0);
    Class<Short> clazz4 = ((06o)param06m).BKI();
    Class<Short> clazz3 = clazz4;
    if (clazz4.isPrimitive()) {
      str = clazz4.getName();
      clazz3 = clazz4;
      if (str != null) {
        Class<Float> clazz16;
        Class<Short> clazz15;
        Class<Boolean> clazz14;
        Class<Short> clazz13;
        Class<Void> clazz12;
        Class<Short> clazz11;
        Class<Long> clazz10;
        Class<Short> clazz9;
        Class<Character> clazz8;
        Class<Short> clazz7;
        Class<Byte> clazz6;
        Class<Short> clazz5;
        switch (str.hashCode()) {
          default:
            return clazz4;
          case 109413500:
            clazz3 = clazz4;
            if (str.equals("short"))
              clazz3 = Short.class; 
            return clazz3;
          case 97526364:
            clazz3 = clazz4;
            if (str.equals("float"))
              clazz16 = Float.class; 
            return clazz16;
          case 64711720:
            clazz15 = clazz4;
            if (str.equals("boolean"))
              clazz14 = Boolean.class; 
            return clazz14;
          case 3625364:
            clazz13 = clazz4;
            if (str.equals("void"))
              clazz12 = Void.class; 
            return clazz12;
          case 3327612:
            clazz11 = clazz4;
            if (str.equals("long"))
              clazz10 = Long.class; 
            return clazz10;
          case 3052374:
            clazz9 = clazz4;
            if (str.equals("char"))
              clazz8 = Character.class; 
            return clazz8;
          case 3039496:
            clazz7 = clazz4;
            if (str.equals("byte"))
              clazz6 = Byte.class; 
            return clazz6;
          case 104431:
            clazz5 = clazz4;
            if (str.equals("int"))
              clazz2 = Integer.class; 
            return clazz2;
          case -1325958191:
            break;
        } 
      } else {
        return clazz2;
      } 
    } else {
      return clazz2;
    } 
    Class<Short> clazz1 = clazz4;
    if (str.equals("double"))
      clazz = Double.class; 
    return clazz;
  }
  
  public final Class BKI() {
    return this.A00;
  }
  
  public final String BiK() {
    return 079.A01(this.A00);
  }
  
  public final boolean C6H(Object paramObject) {
    Class clazz2 = this.A00;
    Map map = A02;
    16F.A0I(map, "null cannot be cast to non-null type kotlin.collections.Map<K of kotlin.collections.MapsKt__MapsKt.get, V of kotlin.collections.MapsKt__MapsKt.get>");
    Number number = (Number)map.get(clazz2);
    if (number != null)
      return 0AZ.A08(paramObject, number.intValue()); 
    Class clazz1 = clazz2;
    if (clazz2.isPrimitive())
      clazz1 = A00(new 06l(clazz2)); 
    return clazz1.isInstance(paramObject);
  }
  
  public final boolean equals(Object paramObject) {
    if (paramObject instanceof 06l) {
      boolean bool1 = 16F.A0S(A00(this), A00((06m)paramObject));
      boolean bool = true;
      return !bool1 ? false : bool;
    } 
    return false;
  }
  
  public final List getAnnotations() {
    throw 0GH.createAndThrow();
  }
  
  public final int hashCode() {
    return A00(this).hashCode();
  }
  
  public final String toString() {
    return 0XK.A0b(this.A00.toString(), " (Kotlin reflection is not available)");
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\06l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */