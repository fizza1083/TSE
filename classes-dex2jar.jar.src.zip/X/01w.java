package X;

public final class 01w {
  public final boolean equals(Object paramObject) {
    return 001.A1Y(paramObject, this);
  }
  
  public final int hashCode() {
    return 0;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */