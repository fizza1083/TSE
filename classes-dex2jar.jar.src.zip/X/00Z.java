package X;

import java.util.Arrays;
import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public final class 00Z<K, V> extends 0Xi<K, V> implements Map<K, V> {
  public 08C A00;
  
  public 0OJ A01;
  
  public 0RL A02;
  
  public 00Z() {
    super(0);
  }
  
  public final boolean A09(Collection paramCollection) {
    int j = size();
    boolean bool = true;
    for (int i = j - 1; i >= 0; i--) {
      if (!paramCollection.contains(A05(i)))
        A06(i); 
    } 
    if (j == size())
      bool = false; 
    return bool;
  }
  
  public final Set entrySet() {
    08C 08C2 = this.A00;
    08C 08C1 = 08C2;
    if (08C2 == null) {
      08C1 = new 08C(this);
      this.A00 = 08C1;
    } 
    return 08C1;
  }
  
  public final Set keySet() {
    0OJ 0OJ2 = this.A01;
    0OJ 0OJ1 = 0OJ2;
    if (0OJ2 == null) {
      0OJ1 = new 0OJ(this);
      this.A01 = 0OJ1;
    } 
    return 0OJ1;
  }
  
  public final void putAll(Map paramMap) {
    int i = size() + paramMap.size();
    int j = super.A00;
    int[] arrayOfInt = super.A01;
    if (arrayOfInt.length < i) {
      arrayOfInt = Arrays.copyOf(arrayOfInt, i);
      16F.A0A(arrayOfInt);
      super.A01 = arrayOfInt;
      arrayOfInt = Arrays.copyOf((int[])super.A02, i * 2);
      16F.A0A(arrayOfInt);
      super.A02 = (Object[])arrayOfInt;
    } 
    if (super.A00 == j) {
      Iterator<Map.Entry> iterator = 001.A16(paramMap);
      while (iterator.hasNext()) {
        Map.Entry entry = iterator.next();
        put(entry.getKey(), entry.getValue());
      } 
      return;
    } 
    throw new ConcurrentModificationException();
  }
  
  public final Collection values() {
    0RL 0RL2 = this.A02;
    0RL 0RL1 = 0RL2;
    if (0RL2 == null) {
      0RL1 = new 0RL(this);
      this.A02 = 0RL1;
    } 
    return 0RL1;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00Z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */