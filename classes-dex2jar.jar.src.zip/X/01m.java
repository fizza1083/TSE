package X;

import java.util.Collections;
import java.util.Comparator;
import java.util.Map;
import java.util.TreeMap;

public abstract class 01m extends 01n {
  public static final int A0D(int paramInt) {
    int i = paramInt;
    if (paramInt >= 0) {
      if (paramInt < 3)
        return paramInt + 1; 
    } else {
      return i;
    } 
    return (paramInt < 1073741824) ? (int)(paramInt / 0.75F + 1.0F) : Integer.MAX_VALUE;
  }
  
  public static final Map A0E(0BW param0BW) {
    16F.A0E(param0BW, 0);
    Map<Object, Object> map = Collections.singletonMap(param0BW.first, param0BW.second);
    16F.A0A(map);
    return map;
  }
  
  public static final TreeMap A0F(Comparator<?> paramComparator, Map<?, ?> paramMap) {
    16F.A0E(paramMap, 0);
    TreeMap<Object, Object> treeMap = new TreeMap<Object, Object>(paramComparator);
    treeMap.putAll(paramMap);
    return treeMap;
  }
  
  public static final 09t A0G(Map paramMap) {
    09t 09t = (09t)paramMap;
    09t.A05();
    09t.isReadOnly = true;
    paramMap = 09t;
    if (09t.size() <= 0) {
      paramMap = 09t.A00;
      16F.A0I(paramMap, "null cannot be cast to non-null type kotlin.collections.Map<K of kotlin.collections.builders.MapBuilder, V of kotlin.collections.builders.MapBuilder>");
    } 
    return (09t)paramMap;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */