package X;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public abstract class 01a {
  public static boolean A00;
  
  public static final Map A01 = new ConcurrentHashMap<Object, Object>();
  
  public static String A00(Class paramClass) {
    if (!A00)
      try {
        return (String)paramClass.getDeclaredField("__redex_internal_original_name").get(paramClass);
      } catch (NoSuchFieldException noSuchFieldException) {
        return paramClass.getName();
      } catch (Exception exception) {
        throw new Error(exception);
      }  
    return A01.computeIfAbsent(exception.getName(), new 06c((Class)exception));
  }
  
  public static String A01(Class paramClass) {
    String str = A00(paramClass);
    int i = str.lastIndexOf('.');
    if (i != -1) {
      if (i != str.length())
        try {
          return str.substring(i + 1);
        } catch (Exception exception) {
          throw new Error(exception);
        }  
      throw new Error(0XK.A0p("Unexpected string ", exception, " in __redex_internal_original_name"));
    } 
    return (String)exception;
  }
  
  public static String A02(Object paramObject) {
    return A01(paramObject.getClass());
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */