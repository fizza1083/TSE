package X;

import java.util.ArrayList;

public final class 043 {
  public ArrayList A00 = 001.A0y();
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\043.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */