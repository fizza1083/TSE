package X;

public abstract class 052 {
  public static String A00(String paramString, Object... paramVarArgs) {
    paramString = String.valueOf(paramString);
    int i = paramString.length();
    int k = paramVarArgs.length;
    StringBuilder stringBuilder = 001.A0t(i + k * 16);
    i = 0;
    int j = 0;
    while (i < k) {
      int m = paramString.indexOf("%s", j);
      if (m != -1) {
        stringBuilder.append(paramString.substring(j, m));
        stringBuilder.append(paramVarArgs[i]);
        j = m + 2;
        i++;
      } 
    } 
    stringBuilder.append(paramString.substring(j));
    if (i < k) {
      stringBuilder.append(" [");
      j = i + 1;
      stringBuilder.append(paramVarArgs[i]);
      for (i = j; i < k; i++) {
        001.A1P(stringBuilder);
        stringBuilder.append(paramVarArgs[i]);
      } 
      stringBuilder.append(']');
    } 
    return stringBuilder.toString();
  }
  
  public static void A01(int paramInt1, int paramInt2) {
    if (paramInt1 >= 0) {
      if (paramInt1 < paramInt2)
        return; 
    } else {
      Object[] arrayOfObject = 001.A1b("index", paramInt1);
      String str = "%s (%s) must not be negative";
      throw new IndexOutOfBoundsException(A00(str, arrayOfObject));
    } 
    if (paramInt2 >= 0) {
      Object[] arrayOfObject = { "index", Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) };
      String str = "%s (%s) must be less than size (%s)";
      throw new IndexOutOfBoundsException(A00(str, arrayOfObject));
    } 
    throw 0XK.A03("negative size: ", paramInt2);
  }
  
  public static void A02(Boolean paramBoolean) {
    if (paramBoolean != null && !paramBoolean.booleanValue())
      throw new IllegalArgumentException(); 
  }
  
  public static void A03(Object paramObject1, Object paramObject2) {
    if (paramObject1 != null)
      return; 
    throw 001.A0V(String.valueOf(paramObject2));
  }
  
  public static void A04(boolean paramBoolean) {
    if (paramBoolean)
      return; 
    throw 001.A0Q();
  }
  
  public static void A05(boolean paramBoolean, Object paramObject) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException(String.valueOf(paramObject));
  }
  
  public static void A06(boolean paramBoolean, Object paramObject) {
    if (paramBoolean)
      return; 
    throw new IllegalStateException(String.valueOf(paramObject));
  }
  
  public static void A07(boolean paramBoolean, String paramString, Object... paramVarArgs) {
    if (paramBoolean)
      return; 
    throw 001.A0O(A00(paramString, paramVarArgs));
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\052.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */