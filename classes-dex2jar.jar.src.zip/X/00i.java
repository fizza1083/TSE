package X;

import android.content.Context;
import android.util.Log;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public final class 00i {
  public static 00i A2c;
  
  public static Field[] A2d;
  
  public static final Object A2e = 001.A0W();
  
  public double A00 = 0.0D;
  
  public double A01 = 0.0D;
  
  public double A02 = 0.0D;
  
  public double A03 = 0.0D;
  
  public double A04 = 0.0D;
  
  public double A05 = 0.0D;
  
  public double A06 = 0.0D;
  
  public double A07 = 0.0D;
  
  public double A08 = 0.0D;
  
  public double A09 = 0.0D;
  
  public float A0A = 0.0F;
  
  public float A0B = 0.0F;
  
  public float A0C = 0.0F;
  
  public int A0D = 0;
  
  public int A0E = 0;
  
  public int A0F = 0;
  
  public int A0G = 0;
  
  public int A0H = 0;
  
  public int A0I = 0;
  
  public int A0J = 0;
  
  public int A0K = 1000;
  
  public int A0L = 0;
  
  public int A0M = 10;
  
  public int A0N = 0;
  
  public int A0O = 0;
  
  public int A0P = 9;
  
  public int A0Q = 1;
  
  public int A0R = 0;
  
  public int A0S = 0;
  
  public int A0T = 0;
  
  public int A0U = 0;
  
  public int A0V = 0;
  
  public int A0W = 0;
  
  public int A0X = 0;
  
  public int A0Y = 0;
  
  public int A0Z = 0;
  
  public int A0a = 0;
  
  public int A0b = 0;
  
  public int A0c = 0;
  
  public int A0d = 0;
  
  public int A0e = 0;
  
  public int A0f = 0;
  
  public int A0g = 0;
  
  public int A0h = 0;
  
  public int A0i = 0;
  
  public int A0j = 0;
  
  public int A0k = 0;
  
  public int A0l = 0;
  
  public int A0m = 0;
  
  public int A0n = 0;
  
  public long A0o = 0L;
  
  public boolean A0p = false;
  
  public boolean A0q = false;
  
  public boolean A0r = false;
  
  public boolean A0s = false;
  
  public boolean A0t = false;
  
  public boolean A0u = false;
  
  public boolean A0v = false;
  
  public boolean A0w = false;
  
  public boolean A0x = false;
  
  public boolean A0y = false;
  
  public boolean A0z = false;
  
  public boolean A10 = false;
  
  public boolean A11 = false;
  
  public boolean A12 = false;
  
  public boolean A13 = false;
  
  public boolean A14 = false;
  
  public boolean A15 = false;
  
  public boolean A16 = false;
  
  public boolean A17 = false;
  
  public boolean A18 = false;
  
  public boolean A19 = false;
  
  public boolean A1A = false;
  
  public boolean A1B = false;
  
  public boolean A1C = false;
  
  public boolean A1D = false;
  
  public boolean A1E = false;
  
  public boolean A1F = false;
  
  public boolean A1G = false;
  
  public boolean A1H = false;
  
  public boolean A1I = false;
  
  public boolean A1J = false;
  
  public boolean A1K = false;
  
  public boolean A1L = false;
  
  public boolean A1M = false;
  
  public boolean A1N = false;
  
  public boolean A1O = false;
  
  public boolean A1P = false;
  
  public boolean A1Q = false;
  
  public boolean A1R = false;
  
  public boolean A1S = false;
  
  public boolean A1T = false;
  
  public boolean A1U = false;
  
  public boolean A1V = false;
  
  public boolean A1W = false;
  
  public boolean A1X = false;
  
  public boolean A1Y = false;
  
  public boolean A1Z = false;
  
  public boolean A1a = false;
  
  public boolean A1b = false;
  
  public boolean A1c = false;
  
  public boolean A1d = false;
  
  public boolean A1e = false;
  
  public boolean A1f = false;
  
  public boolean A1g = false;
  
  public boolean A1h = false;
  
  public boolean A1i = false;
  
  public boolean A1j = false;
  
  public boolean A1k = false;
  
  public boolean A1l = false;
  
  public boolean A1m = false;
  
  public boolean A1n = false;
  
  public boolean A1o = false;
  
  public boolean A1p = false;
  
  public boolean A1q = false;
  
  public boolean A1r = false;
  
  public boolean A1s = false;
  
  public boolean A1t = false;
  
  public boolean A1u = false;
  
  public boolean A1v = false;
  
  public boolean A1w = false;
  
  public boolean A1x = false;
  
  public boolean A1y = false;
  
  public boolean A1z = false;
  
  public boolean A20 = false;
  
  public boolean A21 = false;
  
  public boolean A22 = false;
  
  public boolean A23 = false;
  
  public boolean A24 = false;
  
  public boolean A25 = false;
  
  public boolean A26 = false;
  
  public boolean A27 = false;
  
  public boolean A28 = false;
  
  public boolean A29 = false;
  
  public boolean A2A = false;
  
  public boolean A2B = false;
  
  public boolean A2C = false;
  
  public boolean A2D = false;
  
  public boolean A2E = false;
  
  public boolean A2F = false;
  
  public boolean A2G = false;
  
  public boolean A2H = false;
  
  public boolean A2I = false;
  
  public boolean A2J = false;
  
  public boolean A2K = false;
  
  public boolean A2L = false;
  
  public boolean A2M = false;
  
  public boolean A2N = false;
  
  public boolean A2O = false;
  
  public boolean A2P = false;
  
  public boolean A2Q = false;
  
  public boolean A2R = false;
  
  public boolean A2S = false;
  
  public boolean A2T = false;
  
  public boolean A2U = false;
  
  public boolean A2V = false;
  
  public boolean A2W = false;
  
  public boolean A2X = false;
  
  public boolean A2Y = false;
  
  public boolean A2Z = false;
  
  public boolean A2a = false;
  
  public boolean A2b = false;
  
  public static 00i A00(Context paramContext) {
    // Byte code:
    //   0: getstatic X/00i.A2c : LX/00i;
    //   3: ifnonnull -> 2124
    //   6: getstatic X/00i.A2e : Ljava/lang/Object;
    //   9: astore_2
    //   10: aload_2
    //   11: monitorenter
    //   12: getstatic X/00i.A2c : LX/00i;
    //   15: ifnonnull -> 81
    //   18: invokestatic A00 : ()LX/0ot;
    //   21: astore_1
    //   22: aload_1
    //   23: ifnull -> 2138
    //   26: aload_1
    //   27: invokevirtual A05 : ()Z
    //   30: ifne -> 2138
    //   33: aload_1
    //   34: invokevirtual A04 : ()Ljava/lang/String;
    //   37: astore_1
    //   38: ldc_w 'RSC_READ_'
    //   41: aload_1
    //   42: invokestatic A0b : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   45: astore_1
    //   46: new java/io/File
    //   49: dup
    //   50: aload_0
    //   51: ldc_w 1832390025
    //   54: invokestatic A00 : (Landroid/content/Context;I)Ljava/io/File;
    //   57: aload_1
    //   58: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   61: invokevirtual exists : ()Z
    //   64: iconst_1
    //   65: ixor
    //   66: ifne -> 86
    //   69: new X/00i
    //   72: dup
    //   73: invokespecial <init> : ()V
    //   76: astore_0
    //   77: aload_0
    //   78: putstatic X/00i.A2c : LX/00i;
    //   81: aload_2
    //   82: monitorexit
    //   83: goto -> 2124
    //   86: new X/00i
    //   89: dup
    //   90: invokespecial <init> : ()V
    //   93: astore_1
    //   94: new java/io/DataInputStream
    //   97: dup
    //   98: new java/io/BufferedInputStream
    //   101: dup
    //   102: new java/io/FileInputStream
    //   105: dup
    //   106: aload_0
    //   107: ldc_w 'risky_startup_config'
    //   110: invokevirtual getFileStreamPath : (Ljava/lang/String;)Ljava/io/File;
    //   113: invokespecial <init> : (Ljava/io/File;)V
    //   116: invokespecial <init> : (Ljava/io/InputStream;)V
    //   119: invokespecial <init> : (Ljava/io/InputStream;)V
    //   122: astore #4
    //   124: aload_0
    //   125: invokestatic A01 : (Landroid/content/Context;)LX/13Q;
    //   128: getfield A4h : Z
    //   131: ifeq -> 482
    //   134: aload_1
    //   135: aload #4
    //   137: invokevirtual readBoolean : ()Z
    //   140: putfield A2Y : Z
    //   143: aload_1
    //   144: aload #4
    //   146: invokevirtual readDouble : ()D
    //   149: putfield A06 : D
    //   152: aload_1
    //   153: aload #4
    //   155: invokevirtual readBoolean : ()Z
    //   158: putfield A2E : Z
    //   161: aload_1
    //   162: aload #4
    //   164: invokevirtual readBoolean : ()Z
    //   167: putfield A2C : Z
    //   170: aload_1
    //   171: aload #4
    //   173: invokevirtual readBoolean : ()Z
    //   176: putfield A2D : Z
    //   179: aload_1
    //   180: aload #4
    //   182: invokevirtual readInt : ()I
    //   185: putfield A0a : I
    //   188: aload_1
    //   189: aload #4
    //   191: invokevirtual readBoolean : ()Z
    //   194: putfield A0s : Z
    //   197: aload_1
    //   198: aload #4
    //   200: invokevirtual readBoolean : ()Z
    //   203: putfield A12 : Z
    //   206: aload_1
    //   207: aload #4
    //   209: invokevirtual readInt : ()I
    //   212: putfield A0m : I
    //   215: aload_1
    //   216: aload #4
    //   218: invokevirtual readBoolean : ()Z
    //   221: putfield A2U : Z
    //   224: aload_1
    //   225: aload #4
    //   227: invokevirtual readBoolean : ()Z
    //   230: putfield A0p : Z
    //   233: aload_1
    //   234: aload #4
    //   236: invokevirtual readBoolean : ()Z
    //   239: putfield A0t : Z
    //   242: aload #4
    //   244: invokevirtual readBoolean : ()Z
    //   247: pop
    //   248: aload #4
    //   250: invokevirtual readBoolean : ()Z
    //   253: pop
    //   254: aload #4
    //   256: invokevirtual readBoolean : ()Z
    //   259: pop
    //   260: aload_1
    //   261: aload #4
    //   263: invokevirtual readBoolean : ()Z
    //   266: putfield A15 : Z
    //   269: aload_1
    //   270: aload #4
    //   272: invokevirtual readBoolean : ()Z
    //   275: putfield A2a : Z
    //   278: aload #4
    //   280: invokevirtual readBoolean : ()Z
    //   283: pop
    //   284: aload #4
    //   286: invokevirtual readBoolean : ()Z
    //   289: pop
    //   290: aload #4
    //   292: invokevirtual readBoolean : ()Z
    //   295: pop
    //   296: aload_1
    //   297: aload #4
    //   299: invokevirtual readBoolean : ()Z
    //   302: putfield A1F : Z
    //   305: aload_1
    //   306: aload #4
    //   308: invokevirtual readInt : ()I
    //   311: putfield A0N : I
    //   314: aload_1
    //   315: aload #4
    //   317: invokevirtual readInt : ()I
    //   320: putfield A0H : I
    //   323: aload_1
    //   324: aload #4
    //   326: invokevirtual readInt : ()I
    //   329: putfield A0M : I
    //   332: aload_1
    //   333: aload #4
    //   335: invokevirtual readInt : ()I
    //   338: putfield A0I : I
    //   341: aload_1
    //   342: aload #4
    //   344: invokevirtual readInt : ()I
    //   347: putfield A0J : I
    //   350: aload_1
    //   351: aload #4
    //   353: invokevirtual readInt : ()I
    //   356: putfield A0L : I
    //   359: aload_1
    //   360: aload #4
    //   362: invokevirtual readInt : ()I
    //   365: putfield A0K : I
    //   368: aload_1
    //   369: aload #4
    //   371: invokevirtual readBoolean : ()Z
    //   374: putfield A1A : Z
    //   377: aload_1
    //   378: aload #4
    //   380: invokevirtual readBoolean : ()Z
    //   383: putfield A1B : Z
    //   386: aload #4
    //   388: invokevirtual readInt : ()I
    //   391: pop
    //   392: aload #4
    //   394: invokevirtual readBoolean : ()Z
    //   397: pop
    //   398: aload #4
    //   400: invokevirtual readInt : ()I
    //   403: pop
    //   404: aload #4
    //   406: invokevirtual readInt : ()I
    //   409: pop
    //   410: aload #4
    //   412: invokevirtual readInt : ()I
    //   415: pop
    //   416: aload #4
    //   418: invokevirtual readBoolean : ()Z
    //   421: pop
    //   422: aload #4
    //   424: invokevirtual readInt : ()I
    //   427: pop
    //   428: aload #4
    //   430: invokevirtual readBoolean : ()Z
    //   433: pop
    //   434: aload_1
    //   435: aload #4
    //   437: invokevirtual readBoolean : ()Z
    //   440: putfield A13 : Z
    //   443: aload_1
    //   444: aload #4
    //   446: invokevirtual readBoolean : ()Z
    //   449: putfield A2Z : Z
    //   452: aload_1
    //   453: aload #4
    //   455: invokevirtual readBoolean : ()Z
    //   458: putfield A1q : Z
    //   461: aload_1
    //   462: aload #4
    //   464: invokevirtual readBoolean : ()Z
    //   467: putfield A1r : Z
    //   470: aload_1
    //   471: aload #4
    //   473: invokevirtual readBoolean : ()Z
    //   476: putfield A1p : Z
    //   479: goto -> 2042
    //   482: aload_1
    //   483: aload #4
    //   485: invokevirtual readBoolean : ()Z
    //   488: putfield A18 : Z
    //   491: aload_1
    //   492: aload #4
    //   494: invokevirtual readBoolean : ()Z
    //   497: putfield A0z : Z
    //   500: aload_1
    //   501: aload #4
    //   503: invokevirtual readBoolean : ()Z
    //   506: putfield A10 : Z
    //   509: aload_1
    //   510: aload #4
    //   512: invokevirtual readBoolean : ()Z
    //   515: putfield A0y : Z
    //   518: aload_1
    //   519: aload #4
    //   521: invokevirtual readBoolean : ()Z
    //   524: putfield A0v : Z
    //   527: aload_1
    //   528: aload #4
    //   530: invokevirtual readInt : ()I
    //   533: putfield A0E : I
    //   536: aload_1
    //   537: aload #4
    //   539: invokevirtual readBoolean : ()Z
    //   542: putfield A0w : Z
    //   545: aload_1
    //   546: aload #4
    //   548: invokevirtual readInt : ()I
    //   551: putfield A0F : I
    //   554: aload_1
    //   555: aload #4
    //   557: invokevirtual readBoolean : ()Z
    //   560: putfield A0x : Z
    //   563: aload_1
    //   564: aload #4
    //   566: invokevirtual readInt : ()I
    //   569: putfield A0G : I
    //   572: aload_1
    //   573: aload #4
    //   575: invokevirtual readBoolean : ()Z
    //   578: putfield A2b : Z
    //   581: aload_1
    //   582: aload #4
    //   584: invokevirtual readInt : ()I
    //   587: putfield A0n : I
    //   590: aload_1
    //   591: aload #4
    //   593: invokevirtual readBoolean : ()Z
    //   596: putfield A28 : Z
    //   599: aload_1
    //   600: aload #4
    //   602: invokevirtual readInt : ()I
    //   605: putfield A0X : I
    //   608: aload_1
    //   609: aload #4
    //   611: invokevirtual readBoolean : ()Z
    //   614: putfield A2F : Z
    //   617: aload_1
    //   618: aload #4
    //   620: invokevirtual readInt : ()I
    //   623: putfield A0b : I
    //   626: aload_1
    //   627: aload #4
    //   629: invokevirtual readBoolean : ()Z
    //   632: putfield A1G : Z
    //   635: aload_1
    //   636: aload #4
    //   638: invokevirtual readInt : ()I
    //   641: putfield A0O : I
    //   644: aload_1
    //   645: aload #4
    //   647: invokevirtual readBoolean : ()Z
    //   650: putfield A0u : Z
    //   653: aload_1
    //   654: aload #4
    //   656: invokevirtual readInt : ()I
    //   659: putfield A0D : I
    //   662: aload_1
    //   663: aload #4
    //   665: invokevirtual readBoolean : ()Z
    //   668: putfield A2W : Z
    //   671: aload_1
    //   672: aload #4
    //   674: invokevirtual readBoolean : ()Z
    //   677: putfield A2V : Z
    //   680: aload_1
    //   681: aload #4
    //   683: invokevirtual readBoolean : ()Z
    //   686: putfield A17 : Z
    //   689: aload_1
    //   690: aload #4
    //   692: invokevirtual readBoolean : ()Z
    //   695: putfield A16 : Z
    //   698: aload_1
    //   699: aload #4
    //   701: invokevirtual readBoolean : ()Z
    //   704: putfield A2T : Z
    //   707: aload_1
    //   708: aload #4
    //   710: invokevirtual readBoolean : ()Z
    //   713: putfield A2J : Z
    //   716: aload_1
    //   717: aload #4
    //   719: invokevirtual readBoolean : ()Z
    //   722: putfield A2P : Z
    //   725: aload_1
    //   726: aload #4
    //   728: invokevirtual readInt : ()I
    //   731: putfield A0k : I
    //   734: aload_1
    //   735: aload #4
    //   737: invokevirtual readBoolean : ()Z
    //   740: putfield A2S : Z
    //   743: aload_1
    //   744: aload #4
    //   746: invokevirtual readInt : ()I
    //   749: putfield A0l : I
    //   752: aload_1
    //   753: aload #4
    //   755: invokevirtual readBoolean : ()Z
    //   758: putfield A2K : Z
    //   761: aload_1
    //   762: aload #4
    //   764: invokevirtual readInt : ()I
    //   767: putfield A0f : I
    //   770: aload_1
    //   771: aload #4
    //   773: invokevirtual readBoolean : ()Z
    //   776: putfield A2N : Z
    //   779: aload_1
    //   780: aload #4
    //   782: invokevirtual readInt : ()I
    //   785: putfield A0i : I
    //   788: aload_1
    //   789: aload #4
    //   791: invokevirtual readBoolean : ()Z
    //   794: putfield A2M : Z
    //   797: aload_1
    //   798: aload #4
    //   800: invokevirtual readInt : ()I
    //   803: putfield A0h : I
    //   806: aload_1
    //   807: aload #4
    //   809: invokevirtual readBoolean : ()Z
    //   812: putfield A2O : Z
    //   815: aload_1
    //   816: aload #4
    //   818: invokevirtual readInt : ()I
    //   821: putfield A0j : I
    //   824: aload_1
    //   825: aload #4
    //   827: invokevirtual readBoolean : ()Z
    //   830: putfield A2L : Z
    //   833: aload_1
    //   834: aload #4
    //   836: invokevirtual readInt : ()I
    //   839: putfield A0g : I
    //   842: aload_1
    //   843: aload #4
    //   845: invokevirtual readBoolean : ()Z
    //   848: putfield A2R : Z
    //   851: aload_1
    //   852: aload #4
    //   854: invokevirtual readBoolean : ()Z
    //   857: putfield A2Q : Z
    //   860: aload_1
    //   861: aload #4
    //   863: invokevirtual readBoolean : ()Z
    //   866: putfield A2I : Z
    //   869: aload_1
    //   870: aload #4
    //   872: invokevirtual readBoolean : ()Z
    //   875: putfield A1g : Z
    //   878: aload_1
    //   879: aload #4
    //   881: invokevirtual readDouble : ()D
    //   884: putfield A01 : D
    //   887: aload_1
    //   888: aload #4
    //   890: invokevirtual readDouble : ()D
    //   893: putfield A02 : D
    //   896: aload_1
    //   897: aload #4
    //   899: invokevirtual readDouble : ()D
    //   902: putfield A03 : D
    //   905: aload_1
    //   906: aload #4
    //   908: invokevirtual readDouble : ()D
    //   911: putfield A09 : D
    //   914: aload_1
    //   915: aload #4
    //   917: invokevirtual readDouble : ()D
    //   920: putfield A07 : D
    //   923: aload_1
    //   924: aload #4
    //   926: invokevirtual readDouble : ()D
    //   929: putfield A08 : D
    //   932: aload_1
    //   933: aload #4
    //   935: invokevirtual readDouble : ()D
    //   938: putfield A04 : D
    //   941: aload_1
    //   942: aload #4
    //   944: invokevirtual readDouble : ()D
    //   947: putfield A00 : D
    //   950: aload_1
    //   951: aload #4
    //   953: invokevirtual readBoolean : ()Z
    //   956: putfield A19 : Z
    //   959: aload_1
    //   960: aload #4
    //   962: invokevirtual readBoolean : ()Z
    //   965: putfield A1b : Z
    //   968: aload_1
    //   969: aload #4
    //   971: invokevirtual readBoolean : ()Z
    //   974: putfield A1f : Z
    //   977: aload_1
    //   978: aload #4
    //   980: invokevirtual readBoolean : ()Z
    //   983: putfield A2X : Z
    //   986: aload_1
    //   987: aload #4
    //   989: invokevirtual readBoolean : ()Z
    //   992: putfield A1K : Z
    //   995: aload_1
    //   996: aload #4
    //   998: invokevirtual readBoolean : ()Z
    //   1001: putfield A1Z : Z
    //   1004: aload_1
    //   1005: aload #4
    //   1007: invokevirtual readBoolean : ()Z
    //   1010: putfield A1j : Z
    //   1013: aload_1
    //   1014: aload #4
    //   1016: invokevirtual readBoolean : ()Z
    //   1019: putfield A1W : Z
    //   1022: aload_1
    //   1023: aload #4
    //   1025: invokevirtual readBoolean : ()Z
    //   1028: putfield A1X : Z
    //   1031: aload_1
    //   1032: aload #4
    //   1034: invokevirtual readBoolean : ()Z
    //   1037: putfield A1O : Z
    //   1040: aload_1
    //   1041: aload #4
    //   1043: invokevirtual readBoolean : ()Z
    //   1046: putfield A1V : Z
    //   1049: aload_1
    //   1050: aload #4
    //   1052: invokevirtual readBoolean : ()Z
    //   1055: putfield A1h : Z
    //   1058: aload_1
    //   1059: aload #4
    //   1061: invokevirtual readBoolean : ()Z
    //   1064: putfield A1I : Z
    //   1067: aload_1
    //   1068: aload #4
    //   1070: invokevirtual readBoolean : ()Z
    //   1073: putfield A1c : Z
    //   1076: aload_1
    //   1077: aload #4
    //   1079: invokevirtual readBoolean : ()Z
    //   1082: putfield A1l : Z
    //   1085: aload_1
    //   1086: aload #4
    //   1088: invokevirtual readBoolean : ()Z
    //   1091: putfield A1Y : Z
    //   1094: aload_1
    //   1095: aload #4
    //   1097: invokevirtual readBoolean : ()Z
    //   1100: putfield A1k : Z
    //   1103: aload_1
    //   1104: aload #4
    //   1106: invokevirtual readBoolean : ()Z
    //   1109: putfield A1J : Z
    //   1112: aload_1
    //   1113: aload #4
    //   1115: invokevirtual readBoolean : ()Z
    //   1118: putfield A1e : Z
    //   1121: aload_1
    //   1122: aload #4
    //   1124: invokevirtual readBoolean : ()Z
    //   1127: putfield A1m : Z
    //   1130: aload_1
    //   1131: aload #4
    //   1133: invokevirtual readDouble : ()D
    //   1136: putfield A05 : D
    //   1139: aload_1
    //   1140: aload #4
    //   1142: invokevirtual readBoolean : ()Z
    //   1145: putfield A1d : Z
    //   1148: aload_1
    //   1149: aload #4
    //   1151: invokevirtual readInt : ()I
    //   1154: putfield A0P : I
    //   1157: aload_1
    //   1158: aload #4
    //   1160: invokevirtual readInt : ()I
    //   1163: putfield A0Q : I
    //   1166: aload_1
    //   1167: aload #4
    //   1169: invokevirtual readBoolean : ()Z
    //   1172: putfield A1U : Z
    //   1175: aload_1
    //   1176: aload #4
    //   1178: invokevirtual readBoolean : ()Z
    //   1181: putfield A1M : Z
    //   1184: aload_1
    //   1185: aload #4
    //   1187: invokevirtual readBoolean : ()Z
    //   1190: putfield A1L : Z
    //   1193: aload_1
    //   1194: aload #4
    //   1196: invokevirtual readBoolean : ()Z
    //   1199: putfield A1P : Z
    //   1202: aload_1
    //   1203: aload #4
    //   1205: invokevirtual readBoolean : ()Z
    //   1208: putfield A1S : Z
    //   1211: aload_1
    //   1212: aload #4
    //   1214: invokevirtual readBoolean : ()Z
    //   1217: putfield A1a : Z
    //   1220: aload_1
    //   1221: aload #4
    //   1223: invokevirtual readBoolean : ()Z
    //   1226: putfield A1R : Z
    //   1229: aload_1
    //   1230: aload #4
    //   1232: invokevirtual readBoolean : ()Z
    //   1235: putfield A1Q : Z
    //   1238: aload_1
    //   1239: aload #4
    //   1241: invokevirtual readBoolean : ()Z
    //   1244: putfield A1H : Z
    //   1247: aload_1
    //   1248: aload #4
    //   1250: invokevirtual readBoolean : ()Z
    //   1253: putfield A1i : Z
    //   1256: aload_1
    //   1257: aload #4
    //   1259: invokevirtual readBoolean : ()Z
    //   1262: putfield A1T : Z
    //   1265: aload_1
    //   1266: aload #4
    //   1268: invokevirtual readBoolean : ()Z
    //   1271: putfield A1N : Z
    //   1274: aload_1
    //   1275: aload #4
    //   1277: invokevirtual readBoolean : ()Z
    //   1280: putfield A2Y : Z
    //   1283: aload_1
    //   1284: aload #4
    //   1286: invokevirtual readDouble : ()D
    //   1289: putfield A06 : D
    //   1292: aload_1
    //   1293: aload #4
    //   1295: invokevirtual readBoolean : ()Z
    //   1298: putfield A1v : Z
    //   1301: aload_1
    //   1302: aload #4
    //   1304: invokevirtual readInt : ()I
    //   1307: putfield A0S : I
    //   1310: aload_1
    //   1311: aload #4
    //   1313: invokevirtual readBoolean : ()Z
    //   1316: putfield A1t : Z
    //   1319: aload_1
    //   1320: aload #4
    //   1322: invokevirtual readInt : ()I
    //   1325: putfield A0R : I
    //   1328: aload_1
    //   1329: aload #4
    //   1331: invokevirtual readBoolean : ()Z
    //   1334: putfield A1u : Z
    //   1337: aload_1
    //   1338: aload #4
    //   1340: invokevirtual readLong : ()J
    //   1343: putfield A0o : J
    //   1346: aload_1
    //   1347: aload #4
    //   1349: invokevirtual readBoolean : ()Z
    //   1352: putfield A1s : Z
    //   1355: aload_1
    //   1356: aload #4
    //   1358: invokevirtual readFloat : ()F
    //   1361: putfield A0A : F
    //   1364: aload_1
    //   1365: aload #4
    //   1367: invokevirtual readBoolean : ()Z
    //   1370: putfield A1z : Z
    //   1373: aload_1
    //   1374: aload #4
    //   1376: invokevirtual readFloat : ()F
    //   1379: putfield A0C : F
    //   1382: aload_1
    //   1383: aload #4
    //   1385: invokevirtual readBoolean : ()Z
    //   1388: putfield A1y : Z
    //   1391: aload_1
    //   1392: aload #4
    //   1394: invokevirtual readFloat : ()F
    //   1397: putfield A0B : F
    //   1400: aload_1
    //   1401: aload #4
    //   1403: invokevirtual readBoolean : ()Z
    //   1406: putfield A1x : Z
    //   1409: aload_1
    //   1410: aload #4
    //   1412: invokevirtual readBoolean : ()Z
    //   1415: putfield A1w : Z
    //   1418: aload_1
    //   1419: aload #4
    //   1421: invokevirtual readBoolean : ()Z
    //   1424: putfield A2E : Z
    //   1427: aload_1
    //   1428: aload #4
    //   1430: invokevirtual readBoolean : ()Z
    //   1433: putfield A2C : Z
    //   1436: aload_1
    //   1437: aload #4
    //   1439: invokevirtual readBoolean : ()Z
    //   1442: putfield A2D : Z
    //   1445: aload_1
    //   1446: aload #4
    //   1448: invokevirtual readInt : ()I
    //   1451: putfield A0a : I
    //   1454: aload_1
    //   1455: aload #4
    //   1457: invokevirtual readBoolean : ()Z
    //   1460: putfield A2B : Z
    //   1463: aload_1
    //   1464: aload #4
    //   1466: invokevirtual readInt : ()I
    //   1469: putfield A0Z : I
    //   1472: aload_1
    //   1473: aload #4
    //   1475: invokevirtual readBoolean : ()Z
    //   1478: putfield A2A : Z
    //   1481: aload_1
    //   1482: aload #4
    //   1484: invokevirtual readInt : ()I
    //   1487: putfield A0Y : I
    //   1490: aload_1
    //   1491: aload #4
    //   1493: invokevirtual readBoolean : ()Z
    //   1496: putfield A0s : Z
    //   1499: aload_1
    //   1500: aload #4
    //   1502: invokevirtual readBoolean : ()Z
    //   1505: putfield A29 : Z
    //   1508: aload_1
    //   1509: aload #4
    //   1511: invokevirtual readBoolean : ()Z
    //   1514: putfield A11 : Z
    //   1517: aload_1
    //   1518: aload #4
    //   1520: invokevirtual readInt : ()I
    //   1523: putfield A0e : I
    //   1526: aload_1
    //   1527: aload #4
    //   1529: invokevirtual readBoolean : ()Z
    //   1532: putfield A12 : Z
    //   1535: aload_1
    //   1536: aload #4
    //   1538: invokevirtual readInt : ()I
    //   1541: putfield A0m : I
    //   1544: aload_1
    //   1545: aload #4
    //   1547: invokevirtual readBoolean : ()Z
    //   1550: putfield A2U : Z
    //   1553: aload_1
    //   1554: aload #4
    //   1556: invokevirtual readBoolean : ()Z
    //   1559: putfield A0p : Z
    //   1562: aload_1
    //   1563: aload #4
    //   1565: invokevirtual readBoolean : ()Z
    //   1568: putfield A0t : Z
    //   1571: aload #4
    //   1573: invokevirtual readBoolean : ()Z
    //   1576: pop
    //   1577: aload #4
    //   1579: invokevirtual readBoolean : ()Z
    //   1582: pop
    //   1583: aload #4
    //   1585: invokevirtual readBoolean : ()Z
    //   1588: pop
    //   1589: aload_1
    //   1590: aload #4
    //   1592: invokevirtual readBoolean : ()Z
    //   1595: putfield A14 : Z
    //   1598: aload_1
    //   1599: aload #4
    //   1601: invokevirtual readBoolean : ()Z
    //   1604: putfield A0r : Z
    //   1607: aload_1
    //   1608: aload #4
    //   1610: invokevirtual readBoolean : ()Z
    //   1613: putfield A0q : Z
    //   1616: aload_1
    //   1617: aload #4
    //   1619: invokevirtual readBoolean : ()Z
    //   1622: putfield A2G : Z
    //   1625: aload_1
    //   1626: aload #4
    //   1628: invokevirtual readInt : ()I
    //   1631: putfield A0c : I
    //   1634: aload_1
    //   1635: aload #4
    //   1637: invokevirtual readBoolean : ()Z
    //   1640: putfield A2H : Z
    //   1643: aload_1
    //   1644: aload #4
    //   1646: invokevirtual readInt : ()I
    //   1649: putfield A0d : I
    //   1652: aload_1
    //   1653: aload #4
    //   1655: invokevirtual readBoolean : ()Z
    //   1658: putfield A15 : Z
    //   1661: aload_1
    //   1662: aload #4
    //   1664: invokevirtual readBoolean : ()Z
    //   1667: putfield A2a : Z
    //   1670: aload #4
    //   1672: invokevirtual readBoolean : ()Z
    //   1675: pop
    //   1676: aload #4
    //   1678: invokevirtual readBoolean : ()Z
    //   1681: pop
    //   1682: aload #4
    //   1684: invokevirtual readBoolean : ()Z
    //   1687: pop
    //   1688: aload_1
    //   1689: aload #4
    //   1691: invokevirtual readBoolean : ()Z
    //   1694: putfield A1F : Z
    //   1697: aload_1
    //   1698: aload #4
    //   1700: invokevirtual readInt : ()I
    //   1703: putfield A0N : I
    //   1706: aload_1
    //   1707: aload #4
    //   1709: invokevirtual readInt : ()I
    //   1712: putfield A0H : I
    //   1715: aload_1
    //   1716: aload #4
    //   1718: invokevirtual readInt : ()I
    //   1721: putfield A0M : I
    //   1724: aload_1
    //   1725: aload #4
    //   1727: invokevirtual readInt : ()I
    //   1730: putfield A0I : I
    //   1733: aload_1
    //   1734: aload #4
    //   1736: invokevirtual readInt : ()I
    //   1739: putfield A0J : I
    //   1742: aload_1
    //   1743: aload #4
    //   1745: invokevirtual readInt : ()I
    //   1748: putfield A0L : I
    //   1751: aload_1
    //   1752: aload #4
    //   1754: invokevirtual readInt : ()I
    //   1757: putfield A0K : I
    //   1760: aload_1
    //   1761: aload #4
    //   1763: invokevirtual readBoolean : ()Z
    //   1766: putfield A1A : Z
    //   1769: aload_1
    //   1770: aload #4
    //   1772: invokevirtual readBoolean : ()Z
    //   1775: putfield A1B : Z
    //   1778: aload #4
    //   1780: invokevirtual readInt : ()I
    //   1783: pop
    //   1784: aload #4
    //   1786: invokevirtual readBoolean : ()Z
    //   1789: pop
    //   1790: aload #4
    //   1792: invokevirtual readInt : ()I
    //   1795: pop
    //   1796: aload #4
    //   1798: invokevirtual readInt : ()I
    //   1801: pop
    //   1802: aload #4
    //   1804: invokevirtual readInt : ()I
    //   1807: pop
    //   1808: aload #4
    //   1810: invokevirtual readBoolean : ()Z
    //   1813: pop
    //   1814: aload #4
    //   1816: invokevirtual readInt : ()I
    //   1819: pop
    //   1820: aload #4
    //   1822: invokevirtual readBoolean : ()Z
    //   1825: pop
    //   1826: aload_1
    //   1827: aload #4
    //   1829: invokevirtual readBoolean : ()Z
    //   1832: putfield A13 : Z
    //   1835: aload_1
    //   1836: aload #4
    //   1838: invokevirtual readBoolean : ()Z
    //   1841: putfield A22 : Z
    //   1844: aload_1
    //   1845: aload #4
    //   1847: invokevirtual readBoolean : ()Z
    //   1850: putfield A20 : Z
    //   1853: aload_1
    //   1854: aload #4
    //   1856: invokevirtual readBoolean : ()Z
    //   1859: putfield A24 : Z
    //   1862: aload_1
    //   1863: aload #4
    //   1865: invokevirtual readBoolean : ()Z
    //   1868: putfield A26 : Z
    //   1871: aload_1
    //   1872: aload #4
    //   1874: invokevirtual readInt : ()I
    //   1877: putfield A0W : I
    //   1880: aload_1
    //   1881: aload #4
    //   1883: invokevirtual readInt : ()I
    //   1886: putfield A0U : I
    //   1889: aload_1
    //   1890: aload #4
    //   1892: invokevirtual readBoolean : ()Z
    //   1895: putfield A1C : Z
    //   1898: aload_1
    //   1899: aload #4
    //   1901: invokevirtual readBoolean : ()Z
    //   1904: putfield A23 : Z
    //   1907: aload_1
    //   1908: aload #4
    //   1910: invokevirtual readBoolean : ()Z
    //   1913: putfield A21 : Z
    //   1916: aload_1
    //   1917: aload #4
    //   1919: invokevirtual readBoolean : ()Z
    //   1922: putfield A25 : Z
    //   1925: aload_1
    //   1926: aload #4
    //   1928: invokevirtual readBoolean : ()Z
    //   1931: putfield A27 : Z
    //   1934: aload_1
    //   1935: aload #4
    //   1937: invokevirtual readInt : ()I
    //   1940: putfield A0V : I
    //   1943: aload_1
    //   1944: aload #4
    //   1946: invokevirtual readInt : ()I
    //   1949: putfield A0T : I
    //   1952: aload_1
    //   1953: aload #4
    //   1955: invokevirtual readBoolean : ()Z
    //   1958: putfield A1n : Z
    //   1961: aload_1
    //   1962: aload #4
    //   1964: invokevirtual readBoolean : ()Z
    //   1967: putfield A1o : Z
    //   1970: aload_1
    //   1971: aload #4
    //   1973: invokevirtual readBoolean : ()Z
    //   1976: putfield A2Z : Z
    //   1979: aload_1
    //   1980: aload #4
    //   1982: invokevirtual readBoolean : ()Z
    //   1985: putfield A1D : Z
    //   1988: aload_1
    //   1989: aload #4
    //   1991: invokevirtual readBoolean : ()Z
    //   1994: putfield A1E : Z
    //   1997: aload #4
    //   1999: invokevirtual readBoolean : ()Z
    //   2002: pop
    //   2003: aload #4
    //   2005: invokevirtual readBoolean : ()Z
    //   2008: pop
    //   2009: aload #4
    //   2011: invokevirtual readInt : ()I
    //   2014: pop
    //   2015: aload_1
    //   2016: aload #4
    //   2018: invokevirtual readBoolean : ()Z
    //   2021: putfield A1q : Z
    //   2024: aload_1
    //   2025: aload #4
    //   2027: invokevirtual readBoolean : ()Z
    //   2030: putfield A1r : Z
    //   2033: aload_1
    //   2034: aload #4
    //   2036: invokevirtual readBoolean : ()Z
    //   2039: putfield A1p : Z
    //   2042: aload #4
    //   2044: invokevirtual close : ()V
    //   2047: goto -> 2103
    //   2050: astore_3
    //   2051: aload #4
    //   2053: invokevirtual close : ()V
    //   2056: goto -> 2067
    //   2059: astore #4
    //   2061: aload_3
    //   2062: aload #4
    //   2064: invokestatic A00 : (Ljava/lang/Throwable;Ljava/lang/Throwable;)V
    //   2067: aload_3
    //   2068: athrow
    //   2069: astore_3
    //   2070: ldc_w 'RiskyStartupConfig'
    //   2073: ldc_w 'Failed to read risky config, some values left unset'
    //   2076: aload_3
    //   2077: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   2080: pop
    //   2081: goto -> 2103
    //   2084: astore_3
    //   2085: aload_3
    //   2086: invokevirtual getMessage : ()Ljava/lang/String;
    //   2089: pop
    //   2090: goto -> 2103
    //   2093: ldc_w 'RiskyStartupConfig'
    //   2096: ldc_w 'Config not found, using default values. This likely means that this is a fresh install, data was cleared, or that the prior startup attempt crashed.'
    //   2099: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   2102: pop
    //   2103: aload_0
    //   2104: invokestatic A01 : (Landroid/content/Context;)V
    //   2107: aload_1
    //   2108: astore_0
    //   2109: goto -> 77
    //   2112: astore_1
    //   2113: aload_0
    //   2114: invokestatic A01 : (Landroid/content/Context;)V
    //   2117: aload_1
    //   2118: athrow
    //   2119: astore_0
    //   2120: aload_2
    //   2121: monitorexit
    //   2122: aload_0
    //   2123: athrow
    //   2124: getstatic X/00i.A2c : LX/00i;
    //   2127: astore_0
    //   2128: aload_0
    //   2129: invokestatic A00 : (Ljava/lang/Object;)V
    //   2132: aload_0
    //   2133: areturn
    //   2134: astore_3
    //   2135: goto -> 2093
    //   2138: ldc_w '#MAIN#'
    //   2141: astore_1
    //   2142: goto -> 38
    // Exception table:
    //   from	to	target	type
    //   12	22	2119	finally
    //   26	38	2119	finally
    //   38	77	2119	finally
    //   77	81	2119	finally
    //   81	83	2119	finally
    //   86	94	2112	finally
    //   94	124	2134	java/io/FileNotFoundException
    //   94	124	2084	java/io/EOFException
    //   94	124	2069	java/io/IOException
    //   94	124	2112	finally
    //   124	479	2050	finally
    //   482	2042	2050	finally
    //   2042	2047	2134	java/io/FileNotFoundException
    //   2042	2047	2084	java/io/EOFException
    //   2042	2047	2069	java/io/IOException
    //   2042	2047	2112	finally
    //   2051	2056	2059	finally
    //   2061	2067	2134	java/io/FileNotFoundException
    //   2061	2067	2084	java/io/EOFException
    //   2061	2067	2069	java/io/IOException
    //   2061	2067	2112	finally
    //   2067	2069	2134	java/io/FileNotFoundException
    //   2067	2069	2084	java/io/EOFException
    //   2067	2069	2069	java/io/IOException
    //   2067	2069	2112	finally
    //   2070	2081	2112	finally
    //   2085	2090	2112	finally
    //   2093	2103	2112	finally
    //   2103	2107	2119	finally
    //   2113	2119	2119	finally
    //   2120	2122	2119	finally
  }
  
  public static void A01(Context paramContext) {
    0ot 0ot = 0ot.A00();
    if (0ot != null && !0ot.A05()) {
      str = 0ot.A04();
    } else {
      str = "#MAIN#";
    } 
    String str = 0XK.A0b("RSC_READ_", str);
    File file = 001.A0E(13c.A00(paramContext, 1832390025), str);
    if (!file.exists())
      try {
        if (!file.createNewFile()) {
          001.A1O("Could not create has read marker file for %s", "RiskyStartupConfig", new Object[] { file.getName() });
          return;
        } 
      } catch (IOException iOException) {
        Log.e("RiskyStartupConfig", String.format("Error creating has read marker file for %s", new Object[] { file.getName() }), iOException);
      }  
  }
  
  public static Object[] A02(Object paramObject) {
    Field[] arrayOfField = A03();
    int j = arrayOfField.length;
    Object[] arrayOfObject = new Object[j];
    int i = 0;
    while (i < j) {
      Field field = arrayOfField[i];
      try {
        arrayOfObject[i] = field.get(paramObject);
        i++;
      } catch (IllegalAccessException illegalAccessException) {
        throw 001.A0b(illegalAccessException);
      } 
    } 
    return arrayOfObject;
  }
  
  public static Field[] A03() {
    Field[] arrayOfField2 = A2d;
    Field[] arrayOfField1 = arrayOfField2;
    if (arrayOfField2 == null) {
      arrayOfField1 = 00i.class.getDeclaredFields();
      int j = arrayOfField1.length;
      ArrayList<Field> arrayList = 001.A0z(j);
      for (int i = 0; i < j; i++) {
        Field field = arrayOfField1[i];
        if ((field.getModifiers() & 0x8) != 8) {
          Class<?> clazz = field.getType();
          if (!clazz.isPrimitive() && !String.class.isAssignableFrom(clazz)) {
            clazz.isPrimitive();
            String.class.isAssignableFrom(clazz);
          } else {
            field.setAccessible(true);
            arrayList.add(field);
          } 
        } 
      } 
      Collections.sort(arrayList, new 1Bn(2));
      arrayOfField1 = arrayList.<Field>toArray(new Field[arrayList.size()]);
      A2d = arrayOfField1;
    } 
    return arrayOfField1;
  }
  
  public final boolean equals(Object paramObject) {
    return (paramObject != null && paramObject instanceof 00i) ? Arrays.deepEquals(A02(this), A02(paramObject)) : false;
  }
  
  public final int hashCode() {
    return Arrays.deepHashCode(A02(this));
  }
  
  public final String toString() {
    StringBuilder stringBuilder = 001.A0s();
    try {
      stringBuilder.append('[');
      stringBuilder.append('\n');
      for (Field field : A03()) {
        stringBuilder.append('\t');
        stringBuilder.append(field.getName());
        stringBuilder.append(": ");
        stringBuilder.append(field.get(this));
        stringBuilder.append('\n');
      } 
      stringBuilder.append(']');
      return stringBuilder.toString();
    } catch (IllegalAccessException illegalAccessException) {
      throw 001.A0b(illegalAccessException);
    } 
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\00i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */