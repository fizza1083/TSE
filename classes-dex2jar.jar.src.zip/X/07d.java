package X;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Base64;
import java.io.UnsupportedEncodingException;
import java.util.Collections;
import org.json.JSONException;
import org.json.JSONObject;

public abstract class 07d {
  public static final String A00 = 0XK.A0Z("Null metadata in caller identity, API=", Build.VERSION.SDK_INT);
  
  public static 0Hx A00(Context paramContext, Intent paramIntent, 11P param11P, int paramInt) {
    if (paramIntent == null) {
      String str = "Null launching intent.";
    } else {
      Intent intent = null;
      String str = null;
      if (!paramIntent.hasExtra("_ci_")) {
        String str1 = "Missing caller identity intent extra.";
      } else {
        String str1;
        PendingIntent pendingIntent = (PendingIntent)paramIntent.getParcelableExtra("_ci_");
        if (pendingIntent == null) {
          Bundle bundle = paramIntent.getExtras();
          if (bundle != null && bundle.get("_ci_") == null) {
            str1 = "Null caller identity intent extra.";
          } else {
            str1 = "Caller identity extra is not a PendingIntent.";
          } 
        } else {
          String str2 = pendingIntent.getCreatorPackage();
          int i = pendingIntent.getCreatorUid();
          if (str2 == null)
            return null; 
          try {
            02B 02B = 0Hv.A02((Context)str1, str2);
            try {
              str1 = (String)PendingIntent.class.getMethod("getTag", new Class[] { String.class }).invoke(pendingIntent, new Object[] { "" });
              if (str1 != null) {
                try {
                  String str3;
                  long l1;
                  JSONObject jSONObject = new JSONObject(new String(Base64.decode(str1, 11), "UTF-8"));
                  str1 = str;
                  if (jSONObject.has("d"))
                    str1 = jSONObject.getString("d"); 
                  paramIntent = intent;
                  if (jSONObject.has("v"))
                    str3 = jSONObject.getString("v"); 
                  boolean bool = jSONObject.has("t");
                  long l2 = -1L;
                  if (bool) {
                    l1 = Long.parseLong(jSONObject.getString("t"));
                  } else {
                    l1 = -1L;
                  } 
                  if (jSONObject.has("r"))
                    l2 = Long.parseLong(jSONObject.getString("r")); 
                  long l3 = System.currentTimeMillis();
                  long l4 = paramInt;
                  if (l3 - l1 >= l4 && SystemClock.elapsedRealtime() - l2 >= l4) {
                    if (param11P != null) {
                      param11P.DfI("CallerInfoHelper", "Caller identity has expired.", null);
                      return null;
                    } 
                  } else {
                    return new 0Hx(str3, str1, Collections.singletonList(str2), Collections.singletonList(02B), i);
                  } 
                } catch (UnsupportedEncodingException unsupportedEncodingException) {
                
                } catch (JSONException jSONException) {
                  if (param11P != null)
                    param11P.DfI("CallerInfoHelper", "Error parsing metadata from caller identity.", (Throwable)jSONException); 
                  return null;
                } catch (IllegalArgumentException illegalArgumentException) {}
                return null;
              } 
            } catch (NoSuchMethodException|java.lang.reflect.InvocationTargetException|IllegalAccessException noSuchMethodException) {
              if (param11P != null)
                param11P.DfI("CallerInfoHelper", "Error extracting metadata from caller identity.", noSuchMethodException); 
            } 
            str1 = A00;
            if (param11P != null)
              param11P.DfI("CallerInfoHelper", str1, null); 
            return null;
          } catch (SecurityException securityException) {
            if (param11P != null)
              param11P.DfI("CallerInfoHelper", "Failed to get signature.", securityException); 
            return null;
          } 
        } 
      } 
    } 
    if (param11P != null)
      param11P.DfI("CallerInfoHelper", (String)securityException, null); 
    return null;
  }
  
  public static void A01(Context paramContext, Intent paramIntent, 11P param11P, String paramString) {
    try {
      A02(paramContext, paramIntent, paramString);
      return;
    } catch (0GV 0GV) {
      param11P.DfI("CallerInfoHelper", "Error attaching caller info to Intent.", 0GV);
      return;
    } 
  }
  
  public static void A02(Context paramContext, Intent paramIntent, String paramString) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: \r\n\tat com.googlecode.dex2jar.ir.ts.NewTransformer.transform(NewTransformer.java:134)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:148)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\07d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */