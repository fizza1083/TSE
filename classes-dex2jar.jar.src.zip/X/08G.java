package X;

import com.facebook.quicklog.MarkerEditor;
import com.facebook.quicklog.PointEditor;

public final class 08G extends MarkerEditor implements PointEditor {
  public static final 08G A00;
  
  static {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: \r\n\tat com.googlecode.dex2jar.ir.ts.NewTransformer.transform(NewTransformer.java:134)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:148)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public final PointEditor addPointData(String paramString, double paramDouble) {
    return this;
  }
  
  public final PointEditor addPointData(String paramString, float paramFloat) {
    return this;
  }
  
  public final PointEditor addPointData(String paramString, int paramInt) {
    return this;
  }
  
  public final PointEditor addPointData(String paramString, long paramLong) {
    return this;
  }
  
  public final PointEditor addPointData(String paramString1, String paramString2) {
    return this;
  }
  
  public final PointEditor addPointData(String paramString, boolean paramBoolean) {
    return this;
  }
  
  public final PointEditor addPointData(String paramString, double[] paramArrayOfdouble) {
    return this;
  }
  
  public final PointEditor addPointData(String paramString, float[] paramArrayOffloat) {
    return this;
  }
  
  public final PointEditor addPointData(String paramString, int[] paramArrayOfint) {
    return this;
  }
  
  public final PointEditor addPointData(String paramString, long[] paramArrayOflong) {
    return this;
  }
  
  public final PointEditor addPointData(String paramString, String[] paramArrayOfString) {
    return this;
  }
  
  public final PointEditor addPointData(String paramString, boolean[] paramArrayOfboolean) {
    return this;
  }
  
  public final MarkerEditor annotate(String paramString, double paramDouble) {
    return this;
  }
  
  public final MarkerEditor annotate(String paramString, int paramInt) {
    return this;
  }
  
  public final MarkerEditor annotate(String paramString, long paramLong) {
    return this;
  }
  
  public final MarkerEditor annotate(String paramString1, String paramString2) {
    return this;
  }
  
  public final MarkerEditor annotate(String paramString, boolean paramBoolean) {
    return this;
  }
  
  public final MarkerEditor annotate(String paramString, double[] paramArrayOfdouble) {
    return this;
  }
  
  public final MarkerEditor annotate(String paramString, int[] paramArrayOfint) {
    return this;
  }
  
  public final MarkerEditor annotate(String paramString, long[] paramArrayOflong) {
    return this;
  }
  
  public final MarkerEditor annotate(String paramString, String[] paramArrayOfString) {
    return this;
  }
  
  public final MarkerEditor annotate(String paramString, boolean[] paramArrayOfboolean) {
    return this;
  }
  
  public final boolean isSampled() {
    return false;
  }
  
  public final void markerEditingCompleted() {}
  
  public final MarkerEditor point(String paramString) {
    return this;
  }
  
  public final MarkerEditor point(String paramString, long paramLong) {
    return this;
  }
  
  public final MarkerEditor point(String paramString1, String paramString2) {
    return this;
  }
  
  public final MarkerEditor point(String paramString1, String paramString2, long paramLong) {
    return this;
  }
  
  public final PointEditor pointCustomTimestamp(long paramLong) {
    return this;
  }
  
  public final MarkerEditor pointEditingCompleted() {
    return this;
  }
  
  public final PointEditor pointEditor(String paramString) {
    return this;
  }
  
  public final PointEditor pointShouldIncludeMetadata(boolean paramBoolean) {
    return this;
  }
  
  public final MarkerEditor pointWithMetadata(String paramString1, String paramString2, long paramLong) {
    return this;
  }
  
  public final MarkerEditor setSurviveUserSwitch(boolean paramBoolean) {
    return this;
  }
  
  public final MarkerEditor withLevel(int paramInt) {
    return this;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\08G.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */