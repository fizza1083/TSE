package X;

import android.content.Context;
import android.content.Intent;

public final class 03L extends 03J {
  public final boolean A00(Context paramContext, Intent paramIntent, 11P param11P, Object paramObject) {
    return false;
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\03L.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */