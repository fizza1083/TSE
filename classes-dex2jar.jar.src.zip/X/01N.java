package X;

import java.lang.reflect.Method;

public final class 01N extends 00q {
  public 01N(03e param03e) {}
  
  public final void Ci8(Object paramObject, String paramString, Method paramMethod, Object[] paramArrayOfObject, long paramLong) {
    if (paramString.equals("activity"))
      try {
      
      } finally {
        paramObject = null;
      }  
  }
}


/* Location:              C:\Users\Hp\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\X\01N.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */